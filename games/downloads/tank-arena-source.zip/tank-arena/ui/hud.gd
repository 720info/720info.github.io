extends Control
## 游戏内 HUD。
##
## 逻辑分辨率固定 1280x720（stretch=canvas_items/keep），所以一律用绝对坐标定位，
## 不依赖锚点——HUD 挂在 CanvasLayer 下，锚点行为在这里没有额外收益，反而更难预测。
##
## 版面分区（从左到右、从上到下）：
##   左上   生命 + 管理员徽标
##   左中   武器栏（4 格，含冷却条与解锁状态）
##   中上   模式面板（计时 / 波次 + 进度条 / 生命）
##   右上   计分板
##   右下   击杀播报（最多 5 条，逐条淡出）
##   中央   横幅（波次开始）、结算面板、命中反馈
##   鼠标   准星

const UiTheme := preload("res://ui/ui_theme.gd")
const Weapons := preload("res://game/weapons.gd")
const Progress := preload("res://game/progress.gd")

const KILL_LIFE := 4.0
const KILL_MAX := 5

var _vp: Vector2 = Vector2(1280, 720)
var _mode: Dictionary = {}

# --- 左上 ---
var _hp_panel: PanelContainer
var _hp_row: HBoxContainer
var _hp_cells: Array = []
var _admin_badge: PanelContainer

# --- 武器栏 ---
var _weapon_root: PanelContainer
var _slots: Array = []            # [{root, name, key, bar, bar_bg, locked}]

# --- 中上 ---
var _mode_panel: PanelContainer
var _mode_name: Label
var _mode_timer: Label
var _mode_sub: Label
var _bar_bg: ColorRect
var _bar: ColorRect
var _lives_row: HBoxContainer
var _lives_cells: Array = []
var _zone_time: Label

# --- 右上 ---
var _score_panel: PanelContainer
var _score: Label

# --- 右下 ---
var _kill_box: VBoxContainer
var _kill_lines: Array = []       # [{node, ttl}]

# --- 中央 ---
var _banner: Label
var _banner_sub: Label
var _banner_left: float = 0.0
var _toast: Label
var _toast_left: float = 0.0
var _status: Label
var _result_dim: ColorRect
var _result_panel: PanelContainer
var _result_title: Label
var _result_body: Label

# --- 鼠标 ---
var _reticle: Node2D
var _hit_marks: Array = []
var _hit_t: float = 0.0

var _tip: Label
var _last_weapon: String = ""
var _last_lives: int = -1

# ---------------------------------------------------------------- 生命周期

func _ready() -> void:
	# 父节点是 CanvasLayer（不是 Control/Window），主题链断了，得自己补挂。
	UiTheme.attach(self)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vp = get_viewport_rect().size
	_build()
	set_process(true)

func _process(delta: float) -> void:
	_toast_left = _tick_fade(_toast, _toast_left, delta)
	_banner_left = _tick_fade(_banner, _banner_left, delta)
	if _banner_left <= 0.0 and _banner_sub != null:
		_banner_sub.visible = false
	_tick_kill_feed(delta)
	_tick_reticle(delta)

func _tick_fade(node: Control, left: float, delta: float) -> float:
	if node == null or left <= 0.0:
		return 0.0
	left -= delta
	if left <= 0.0:
		node.visible = false
	return maxf(left, 0.0)

func _tick_kill_feed(delta: float) -> void:
	var doomed: Array = []
	for e in _kill_lines:
		e.ttl = float(e.ttl) - delta
		var n: Label = e.node
		if not is_instance_valid(n):
			doomed.append(e)
			continue
		n.modulate = Color(1, 1, 1, clampf(float(e.ttl) / 1.2, 0.0, 1.0))
		if float(e.ttl) <= 0.0:
			doomed.append(e)
	for e in doomed:
		_kill_lines.erase(e)
		var n: Label = e.node
		if is_instance_valid(n):
			n.queue_free()

func _tick_reticle(delta: float) -> void:
	if _reticle == null:
		return
	_reticle.position = get_viewport().get_mouse_position()
	if _hit_t > 0.0:
		_hit_t = maxf(0.0, _hit_t - delta * 4.0)
		var s := 1.0 + (1.0 - _hit_t) * 0.55
		for m in _hit_marks:
			m.visible = _hit_t > 0.01
			m.scale = Vector2(s, s)
			m.modulate = Color(1, 1, 1, _hit_t)

# ---------------------------------------------------------------- 对外：初始化

## mode 是 modes.gd 的条目，map_def 是 maps.gd 的条目，arena 用于取控制区半径
func setup(mode: Dictionary, map_def: Dictionary, arena: Node) -> void:
	_mode = mode
	var rules: String = str(mode.get("rules", "ffa"))
	# 教学关没有计时/波次，整块模式面板藏起来，让位给教学关自己的步骤面板
	var show_panel := rules != "tutorial"
	if _mode_panel != null:
		_mode_panel.visible = show_panel
	if _mode_name != null:
		_mode_name.text = "%s · %s" % [str(mode.get("name", "对战")), str(map_def.get("name", ""))]
	if _mode_timer != null:
		_mode_timer.visible = true
	if _lives_row != null:
		_lives_row.visible = rules == "coop"
	if _bar_bg != null:
		_bar_bg.visible = rules != "coop"
	if _score_panel != null:
		_score_panel.visible = show_panel      # 教学关没有对手，计分板是噪音
	show_banner(str(mode.get("name", "对战")), str(map_def.get("name", "")) + " · " + str(mode.get("subtitle", "")))

## 界面实际遮挡的世界区域。
## 相机居中、视野正好等于地图大小（1280x720），所以 HUD 的逻辑坐标可以直接当成世界坐标。
## 出生点校验（--selftest）会读这张表，确保没有坦克一出生就被面板压住。
## 注意：改版面之后要重新跑一次 --selftest 复核。
func occluded_rects() -> Array:
	var out: Array = []
	for n in [_hp_panel, _admin_badge, _weapon_root, _mode_panel, _score_panel]:
		if n != null and is_instance_valid(n) and n.visible:
			out.append(Rect2(n.global_position, n.size))
	return out

# ---------------------------------------------------------------- 对外：状态

func set_hp(hp: int, max_hp: int) -> void:
	while _hp_cells.size() < max_hp:
		var c := ColorRect.new()
		c.custom_minimum_size = Vector2(26, 12)
		c.color = Color("#4ade80")
		_hp_row.add_child(c)
		_hp_cells.append(c)
	for i in range(_hp_cells.size()):
		_hp_cells[i].color = Color("#4ade80") if i < hp else Color("#313b4d")

func set_alive(alv: bool) -> void:
	if _status != null:
		_status.visible = not alv

func set_admin(on: bool) -> void:
	if _admin_badge != null:
		_admin_badge.visible = on

func set_respawn_hint(remain: float) -> void:
	if _status != null:
		_status.text = "已被击毁 · %.1f 秒后重生" % maxf(remain, 0.0)

func show_toast(text: String, seconds: float = 2.0) -> void:
	if _toast == null:
		return
	_toast.text = text
	_toast.visible = true
	_toast_left = seconds

## 中央大横幅：波次开始、模式开始这类「一句话通知」
func show_banner(title: String, sub: String = "") -> void:
	if _banner == null:
		return
	_banner.text = title
	_banner.visible = true
	_banner_left = 2.4
	if _banner_sub != null:
		_banner_sub.text = sub
		_banner_sub.visible = sub != ""

## 击杀播报（右下角滚动）
func show_kill(text: String) -> void:
	if _kill_box == null:
		return
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 15)
	l.add_theme_color_override("font_color", Color("#ffd9a0"))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("outline_size", 5)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_kill_box.add_child(l)
	_kill_lines.append({"node": l, "ttl": KILL_LIFE})
	while _kill_lines.size() > KILL_MAX:
		var old = _kill_lines.pop_front()
		var n: Label = old.node
		if is_instance_valid(n):
			n.queue_free()

## 命中反馈：准星闪 + 击杀时更重
func on_hit(amount: int, killed: bool) -> void:
	_hit_t = 1.0
	var col := Color(1, 1, 1, 0.95) if not killed else Color(1.0, 0.42, 0.42, 1.0)
	for m in _hit_marks:
		m.default_color = col

## 结算面板
func show_result(text: String) -> void:
	if _result_panel == null:
		return
	var lines := text.split("\n")
	if lines.size() > 0:
		_result_title.text = str(lines[0])
		var rest: Array = []
		for i in range(1, lines.size()):
			rest.append(str(lines[i]))
		_result_body.text = "\n".join(rest)
	_result_dim.visible = true
	_result_panel.visible = true
	_hide_status()

func _hide_status() -> void:
	if _status != null:
		_status.visible = false

## 武器栏：cd / max_cd 用来画冷却条
func set_weapon(id: String, cd: float, max_cd: float) -> void:
	var unlocked: Array = Profile.unlocked_weapons()
	for i in range(_slots.size()):
		var s: Dictionary = _slots[i]
		var wid := str(Weapons.LIST[i].id)
		var has := unlocked.has(wid)
		var is_cur := wid == id
		var root: PanelContainer = s.root
		var state := 0 if is_cur else (1 if has else 2)
		if int(s.applied) != state:
			s.applied = state
			root.add_theme_stylebox_override("panel",
				s.st_cur if state == 0 else (s.st_idle if state == 1 else s.st_lock))
		var name_l: Label = s.name
		var key_l: Label = s.key
		if has:
			name_l.text = str(Weapons.LIST[i].short)
			name_l.add_theme_color_override("font_color",
				Color("#ffffff") if is_cur else Color("#9fb2cf"))
			key_l.text = str(i + 1)
			key_l.add_theme_color_override("font_color",
				Color("#0b1018") if is_cur else Color("#7f93b3"))
		else:
			name_l.text = "%s Lv%d" % [str(Weapons.LIST[i].short), int(Weapons.LIST[i].unlock_level)]
			name_l.add_theme_color_override("font_color", Color(1, 1, 1, 0.28))
			key_l.text = str(i + 1)
			key_l.add_theme_color_override("font_color", Color(1, 1, 1, 0.22))
		var bar: ColorRect = s.bar
		var bg: ColorRect = s.bar_bg
		if is_cur and max_cd > 0.0:
			var ratio := clampf(1.0 - cd / max_cd, 0.0, 1.0)
			bar.size.x = (bg.size.x) * ratio
			bar.visible = true
		else:
			bar.visible = false
	# 换枪时给一次提示（解锁需求等由 game.gd 负责，这里只做视觉）
	if id != _last_weapon:
		_last_weapon = id

## 模式面板数据。字段：time_left / lives / wave / wave_gap / zone_owner_name /
## wave_ai / local_score / local_kills / local_streak / over
func set_mode_info(info: Dictionary) -> void:
	if _mode_panel == null:
		return
	var rules: String = str(_mode.get("rules", "ffa"))
	var tl: float = float(info.get("time_left", 0.0))
	var limit := int(_mode.get("score_limit", 0))
	var mine := int(info.get("local_score", 0))

	if rules == "coop":
		var wv := int(info.get("wave", 0))
		_mode_timer.text = "准备" if wv <= 0 else "第 %d 波" % wv
		var alive := int(info.get("wave_ai", 0))
		if alive > 0:
			_mode_sub.text = "剩余敌人 %d" % alive
		elif wv <= 0:
			_mode_sub.text = "第一波 %.0f 秒后开始" % maxf(float(info.get("wave_gap", 0.0)), 0.0)
		else:
			_mode_sub.text = "下一波 %.0f 秒" % maxf(float(info.get("wave_gap", 0.0)), 0.0)
		_update_lives(int(info.get("lives", 0)))
	else:
		_mode_timer.text = _mmss(tl)
		if rules == "zone":
			var owner_name: String = str(info.get("zone_owner_name", ""))
			var who := "控制区空置" if owner_name == "" else "%s 控制中" % owner_name
			_mode_sub.text = "%s · 你 %d / %d 分" % [who, mine, limit]
		else:
			_mode_sub.text = "目标 %d 分 · 你 %d 分" % [limit, mine]
		if _bar_bg != null and _bar_bg.visible:
			var ratio := 0.0 if limit <= 0 else clampf(float(mine) / float(limit), 0.0, 1.0)
			_bar.size.x = _bar_bg.size.x * ratio

## 占点模式里自己累计控制了多少秒
func set_zone_seconds(s: float) -> void:
	if _zone_time == null:
		return
	_zone_time.text = "控制时长 %s" % _mmss(s)
	_zone_time.visible = true

func refresh(players: Dictionary, local_id: int) -> void:
	if _score == null:
		return
	var ids := players.keys()
	ids.sort()
	var lines: Array = []
	for id in ids:
		var info: Dictionary = players[id]
		var mark := " ◀" if int(id) == local_id else ""
		var wname := str(Weapons.get_weapon(str(info.get("weapon", "mg"))).short)
		var nm := str(info.get("name", "?"))
		if bool(info.get("wave", false)):
			nm = "电脑"
		lines.append("%s  %s  %d%s" % [nm, wname, int(info.get("score", 0)), mark])
	_score.text = "\n".join(lines)

# ---------------------------------------------------------------- 构建

func _build() -> void:
	_build_bg_marks()
	_build_hp()
	_build_admin()
	_build_weapons()
	_build_mode()
	_build_score()
	_build_kill_feed()
	_build_center()
	_build_tip()
	_build_reticle()

func _build_bg_marks() -> void:
	# 顶部/底部两条极淡的横向压暗带，让 HUD 文字压在亮色地板边缘时也能看清
	for y in [0.0, _vp.y - 56.0]:
		var r := ColorRect.new()
		r.color = Color(0, 0, 0, 0.18)
		r.position = Vector2(0, y)
		r.size = Vector2(_vp.x, 56.0)
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(r)

func _build_hp() -> void:
	var panel := _panel()
	panel.position = Vector2(20, 16)
	add_child(panel)
	_hp_panel = panel

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	panel.add_child(box)

	var title := _cap("生命")
	box.add_child(title)

	_hp_row = HBoxContainer.new()
	_hp_row.add_theme_constant_override("separation", 6)
	box.add_child(_hp_row)
	set_hp(3, 3)
	panel.reset_size()

## 管理员徽标：贴在生命面板右侧、与之垂直居中，开启时才显示。
## 不能放在生命面板下方——1 号出生点 (150,150) 的坦克名字标签正好落在那块区域，会被压住。
func _build_admin() -> void:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.30, 0.22, 0.02, 0.82)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(8)
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color("#ffd54a")
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(p)

	var l := Label.new()
	l.text = "★ 管理员 · 无敌 / 加速 / 超级射速"
	l.add_theme_font_size_override("font_size", 13)
	l.add_theme_color_override("font_color", Color("#ffd54a"))
	p.add_child(l)
	p.reset_size()
	p.position = Vector2(
		_hp_panel.position.x + _hp_panel.size.x + 10.0,
		_hp_panel.position.y + (_hp_panel.size.y - p.size.y) * 0.5
	)
	p.visible = false
	_admin_badge = p

## 武器栏：4 格竖排，每格显示快捷键、简称、冷却条。未解锁的显示所需等级。
##
## 为什么竖着放：横排时面板会盖住 y∈[86,152] 的左侧区域，
## 而 1 号出生点 (150,150) 正好落在那里 —— 玩家一出生就看不见自己的车。
## 竖排只占 x∈[20,130]，8 个出生点一个都不压。
func _build_weapons() -> void:
	var panel := _panel()
	panel.position = Vector2(20, 90)
	add_child(panel)
	_weapon_root = panel

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	panel.add_child(col)

	for i in range(Weapons.LIST.size()):
		var w: Dictionary = Weapons.LIST[i]
		var cell := PanelContainer.new()
		cell.custom_minimum_size = Vector2(86, 44)
		cell.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cell.add_theme_stylebox_override("panel", _slot_style(false, true))
		col.add_child(cell)

		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 3)
		cell.add_child(vb)

		var top := HBoxContainer.new()
		top.add_theme_constant_override("separation", 6)
		vb.add_child(top)

		var key := Label.new()
		key.text = str(i + 1)
		key.add_theme_font_size_override("font_size", 12)
		key.custom_minimum_size = Vector2(14, 0)
		key.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		top.add_child(key)

		var nm := Label.new()
		nm.text = str(w.short)
		nm.add_theme_font_size_override("font_size", 14)
		top.add_child(nm)

		var bar_bg := ColorRect.new()
		bar_bg.color = Color(1, 1, 1, 0.10)
		bar_bg.custom_minimum_size = Vector2(0, 4)
		bar_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vb.add_child(bar_bg)

		var bar := ColorRect.new()
		bar.color = w.color
		bar.position = Vector2.ZERO
		bar.size = Vector2(0, 4)
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bar.visible = false
		bar_bg.add_child(bar)

		# 三种状态的样式盒预先建好，避免每帧 new 出几百个 StyleBoxFlat
		_slots.append({
			"root": cell, "name": nm, "key": key, "bar": bar, "bar_bg": bar_bg,
			"st_cur": _slot_style(true, true),
			"st_idle": _slot_style(false, true),
			"st_lock": _slot_style(false, false),
			"applied": -1,
		})
	panel.reset_size()

func _build_mode() -> void:
	var panel := _panel()
	add_child(panel)
	_mode_panel = panel

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	vb.custom_minimum_size = Vector2(300, 0)
	panel.add_child(vb)

	_mode_name = Label.new()
	_mode_name.text = "对战"
	_mode_name.add_theme_font_size_override("font_size", 13)
	_mode_name.add_theme_color_override("font_color", Color("#9fb2cf"))
	_mode_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_mode_name)

	_mode_timer = Label.new()
	_mode_timer.text = "0:00"
	_mode_timer.add_theme_font_size_override("font_size", 36)
	_mode_timer.add_theme_color_override("font_color", Color("#e8f0ff"))
	_mode_timer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_mode_timer)

	_bar_bg = ColorRect.new()
	_bar_bg.color = Color(1, 1, 1, 0.10)
	_bar_bg.custom_minimum_size = Vector2(0, 6)
	_bar_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(_bar_bg)

	_bar = ColorRect.new()
	_bar.color = Color("#4ade80")
	_bar.size = Vector2(0, 6)
	_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bar_bg.add_child(_bar)

	_lives_row = HBoxContainer.new()
	_lives_row.add_theme_constant_override("separation", 6)
	_lives_row.alignment = BoxContainer.ALIGNMENT_CENTER
	_lives_row.visible = false
	vb.add_child(_lives_row)

	_mode_sub = Label.new()
	_mode_sub.text = ""
	_mode_sub.add_theme_font_size_override("font_size", 14)
	_mode_sub.add_theme_color_override("font_color", Color("#c7d7ef"))
	_mode_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_mode_sub)

	panel.reset_size()
	panel.position = Vector2((_vp.x - panel.size.x) * 0.5, 16.0)

	_zone_time = Label.new()
	_zone_time.text = ""
	_zone_time.add_theme_font_size_override("font_size", 13)
	_zone_time.add_theme_color_override("font_color", Color("#8fb8a0"))
	_zone_time.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_zone_time.size = Vector2(300, 20)
	_zone_time.position = Vector2(panel.position.x, panel.position.y + panel.size.y + 4.0)
	_zone_time.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_zone_time.visible = false
	add_child(_zone_time)

func _build_score() -> void:
	var panel := _panel()
	add_child(panel)
	_score_panel = panel

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	box.custom_minimum_size = Vector2(248, 0)
	panel.add_child(box)

	box.add_child(_cap("计分板"))

	_score = Label.new()
	_score.text = "—"
	_score.add_theme_font_size_override("font_size", 15)
	_score.add_theme_color_override("font_color", Color("#e8f0ff"))
	box.add_child(_score)
	panel.reset_size()
	panel.position = Vector2(_vp.x - 20.0 - panel.size.x, 16.0)

func _build_kill_feed() -> void:
	_kill_box = VBoxContainer.new()
	_kill_box.add_theme_constant_override("separation", 3)
	_kill_box.alignment = BoxContainer.ALIGNMENT_END
	_kill_box.size = Vector2(520, 130)
	_kill_box.position = Vector2(_vp.x - 20.0 - 520.0, _vp.y - 56.0 - 132.0)
	_kill_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_kill_box)

func _build_center() -> void:
	# 横幅/提示统一排在模式面板下方（面板底边 y≈124），别压在计时器上
	_banner = Label.new()
	_banner.text = ""
	_banner.add_theme_font_size_override("font_size", 44)
	_banner.add_theme_color_override("font_color", Color("#ffe9a8"))
	_banner.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_banner.add_theme_constant_override("outline_size", 8)
	_banner.position = Vector2(_vp.x * 0.5 - 340.0, 142.0)
	_banner.size = Vector2(680, 56)
	_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.visible = false
	add_child(_banner)

	_banner_sub = Label.new()
	_banner_sub.text = ""
	_banner_sub.add_theme_font_size_override("font_size", 18)
	_banner_sub.add_theme_color_override("font_color", Color("#cfe0f7"))
	_banner_sub.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_banner_sub.add_theme_constant_override("outline_size", 6)
	_banner_sub.position = Vector2(_vp.x * 0.5 - 340.0, 198.0)
	_banner_sub.size = Vector2(680, 26)
	_banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner_sub.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_banner_sub.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner_sub.visible = false
	add_child(_banner_sub)

	_toast = Label.new()
	_toast.text = ""
	_toast.add_theme_font_size_override("font_size", 20)
	_toast.add_theme_color_override("font_color", Color("#ffe9a8"))
	_toast.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	_toast.add_theme_constant_override("outline_size", 6)
	_toast.position = Vector2(_vp.x * 0.5 - 340.0, 236.0)
	_toast.size = Vector2(680, 30)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast.visible = false
	add_child(_toast)

	_status = Label.new()
	_status.text = "已被击毁 · 等待重生…"
	_status.add_theme_font_size_override("font_size", 30)
	_status.add_theme_color_override("font_color", Color("#ff7b7b"))
	_status.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	_status.add_theme_constant_override("outline_size", 6)
	_status.position = Vector2(_vp.x * 0.5 - 240.0, _vp.y * 0.5 - 40.0)
	_status.size = Vector2(480, 44)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_status.visible = false
	add_child(_status)

	# --- 结算面板 ---
	_result_dim = ColorRect.new()
	_result_dim.color = Color(0, 0, 0, 0.55)
	_result_dim.position = Vector2.ZERO
	_result_dim.size = _vp
	_result_dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_result_dim.visible = false
	add_child(_result_dim)

	var rp := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.055, 0.078, 0.125, 0.96)
	sb.set_corner_radius_all(16)
	sb.set_content_margin_all(28)
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color(1, 1, 1, 0.12)
	rp.add_theme_stylebox_override("panel", sb)
	rp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(rp)
	_result_panel = rp

	var rvb := VBoxContainer.new()
	rvb.add_theme_constant_override("separation", 12)
	rvb.custom_minimum_size = Vector2(420, 0)
	rp.add_child(rvb)

	_result_title = Label.new()
	_result_title.text = "对局结束"
	_result_title.add_theme_font_size_override("font_size", 32)
	_result_title.add_theme_color_override("font_color", Color("#ffe9a8"))
	_result_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rvb.add_child(_result_title)

	_result_body = Label.new()
	_result_body.text = ""
	_result_body.add_theme_font_size_override("font_size", 17)
	_result_body.add_theme_color_override("font_color", Color("#cfe0f7"))
	_result_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rvb.add_child(_result_body)

	rp.reset_size()
	rp.position = Vector2((_vp.x - rp.size.x) * 0.5, (_vp.y - rp.size.y) * 0.5)
	rp.visible = false

func _build_tip() -> void:
	_tip = Label.new()
	_tip.text = "WASD 移动 · 鼠标瞄准 · 左键/空格 开火 · 1-4 / Q E 换枪 · P 管理员 · M 静音 · ESC 退出"
	_tip.add_theme_font_size_override("font_size", 14)
	_tip.add_theme_color_override("font_color", Color(1, 1, 1, 0.5))
	_tip.position = Vector2(0, _vp.y - 42.0)
	_tip.size = Vector2(_vp.x, 26)
	_tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_tip.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_tip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_tip)

## 准星 + 命中反馈，用 Node2D 画（Control 下挂 Node2D 的坐标与视口一致）
func _build_reticle() -> void:
	_reticle = Node2D.new()
	_reticle.z_index = 40
	add_child(_reticle)

	var accent := Color(1, 1, 1, 0.62)
	var d := 9.0
	var ln := 6.0
	for v in [Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]:
		var l := Line2D.new()
		l.points = PackedVector2Array([v * d, v * (d + ln)])
		l.width = 1.6
		l.default_color = accent
		_reticle.add_child(l)

	var dot := Polygon2D.new()
	dot.polygon = PackedVector2Array([
		Vector2(-1.2, 0), Vector2(0, -1.2), Vector2(1.2, 0), Vector2(0, 1.2)
	])
	dot.color = Color(1, 1, 1, 0.55)
	_reticle.add_child(dot)

	# 命中标记：四条斜线，命中瞬间亮起
	var hm := Node2D.new()
	hm.visible = false
	for v in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
		var l := Line2D.new()
		l.points = PackedVector2Array([v * 7.0, v * 15.0])
		l.width = 2.4
		l.default_color = Color(1, 1, 1, 0.95)
		hm.add_child(l)
	_reticle.add_child(hm)
	_hit_marks.append(hm)

# ---------------------------------------------------------------- 小工具

func _cap(t: String) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 13)
	l.add_theme_color_override("font_color", Color("#9fb2cf"))
	return l

func _update_lives(n: int) -> void:
	if _lives_row == null or n == _last_lives:
		return
	_last_lives = n
	while _lives_cells.size() < n:
		var c := ColorRect.new()
		c.custom_minimum_size = Vector2(16, 10)
		c.color = Color("#4ade80")
		_lives_row.add_child(c)
		_lives_cells.append(c)
	while _lives_cells.size() > n:
		var c: ColorRect = _lives_cells.pop_back()
		c.queue_free()
	for c in _lives_cells:
		c.color = Color("#4ade80")

func _mmss(t: float) -> String:
	var s := int(maxf(t, 0.0))
	return "%d:%02d" % [s / 60, s % 60]

func _slot_style(current: bool, unlocked: bool) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	if current:
		sb.bg_color = Color(0.10, 0.17, 0.28, 0.92)
	elif unlocked:
		sb.bg_color = Color(0.05, 0.08, 0.12, 0.72)
	else:
		sb.bg_color = Color(0.04, 0.05, 0.07, 0.55)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(8)
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color("#7f9ecf") if current else Color(1, 1, 1, 0.07)
	return sb

func _panel() -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.08, 0.12, 0.72)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(12)
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color(1, 1, 1, 0.07)
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p
