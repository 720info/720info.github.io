extends Node2D
## 教学关：5 步交互式引导，边打边学。
##
## 设计取舍：
##  - 复用正式的 Arena / Player / HUD，而不是另写一套「演示场景」。
##    玩家学到的操作和真局完全一致，改游戏时教学关不会悄悄失效。
##  - 靶子的落点不写死坐标，而是从玩家当前位置向外做射线探测，挑一条没有遮挡的方向。
##    地图一旦改动，教学关也不会出现「靶子被墙挡住、永远打不到」的死局。
##  - 靶子是纯本地节点（不参与网络同步），所以逻辑不受「只在权威端跑」的限制。
##  - 教学关临时解锁全部武器（Profile.unlock_all_temp），否则 1 级新人没法完成换枪那一步。
##  - 教学关里的击杀不计入档案，避免开一局教学就刷满「百人斩」。

signal finished()

const ArenaScript := preload("res://game/arena.gd")
const PlayerScript := preload("res://game/player.gd")
const HudScript := preload("res://ui/hud.gd")
const Maps := preload("res://game/maps.gd")
const Weapons := preload("res://game/weapons.gd")
const UiTheme := preload("res://ui/ui_theme.gd")

const TUTORIAL_MAP := "yard"
## 出生点：不能直接用 arena.spawn_for(1)=(150,150) —— 那块正好被左上角的
## 生命面板 + 武器栏压住，玩家一进来就看不见自己的车。
const PLAYER_SPAWN := Vector2(180, 540)
const REACH_RADIUS := 48.0
const COVER_HOLD := 1.0

var arena: Node2D
var players_root: Node2D
var bullets_root: Node2D
var hud: Control
var cam: Camera2D

var _player_nodes: Dictionary = {}
var me: Node = null
var _steps: Array = []
var _step: int = 0
var _step_t: float = 0.0
var _dummy_seq: int = 0
var _targets: Array = []
var _kills: int = 0
var _cover_t: float = 0.0
var _step_weapon: String = ""
var _finished: bool = false

var _panel: PanelContainer
var _title: Label
var _hint: Label
var _progress: Label
var _marker: Node2D
var _marker_pos: Vector2 = Vector2.ZERO
var _done_panel: PanelContainer
var _done_dim: ColorRect

# ---------------------------------------------------------------- 初始化

func _ready() -> void:
	# 教学关同时进 "game"（玩家的炮弹容器 / 音效监听靠它找）和 "tutorial"（统计隔离靠它判断）
	add_to_group("game")
	add_to_group("tutorial")
	Profile.unlock_all_temp = true

	arena = ArenaScript.new()
	arena.name = "Arena"
	arena.map_id = TUTORIAL_MAP
	add_child(arena)

	cam = Camera2D.new()
	cam.position = Vector2(Maps.W * 0.5, Maps.H * 0.5)
	cam.enabled = true
	add_child(cam)

	players_root = Node2D.new()
	players_root.name = "Players"
	players_root.z_index = 5
	add_child(players_root)

	bullets_root = Node2D.new()
	bullets_root.name = "Bullets"
	bullets_root.z_index = 8
	add_child(bullets_root)

	_build_steps()
	_build_ui()
	_spawn_player()
	_build_marker()
	_enter_step(0)
	print("[TUTORIAL] 教学关开始 · 地图=%s" % TUTORIAL_MAP)

func _exit_tree() -> void:
	Profile.unlock_all_temp = false

func _build_steps() -> void:
	_steps = [
		{
			"title": "第 1 步 · 移动",
			"hint": "用 W A S D 把坦克开进发光的圆环里。",
			"kind": "reach",
		},
		{
			"title": "第 2 步 · 瞄准与开火",
			"hint": "鼠标瞄准，按住左键（或空格）开火。打掉那个静止的靶子。",
			"kind": "kill", "count": 1, "patrol": false, "dist": 300.0,
		},
		{
			"title": "第 3 步 · 利用掩体",
			"hint": "绕到障碍物后面，让靶子看不到你，并保持 1 秒。",
			"kind": "cover", "dist": 300.0,
		},
		{
			"title": "第 4 步 · 切换武器",
			"hint": "按 1 / 2 / 3 / 4 直接选枪，或按 Q / E 前后切换。四把枪手感完全不同。",
			"kind": "weapon",
		},
		{
			"title": "第 5 步 · 打移动目标",
			"hint": "靶子在绕圈跑。预判它的走位，把弹道提前量留出来，击毁 2 个。",
			"kind": "kill", "count": 2, "patrol": true, "dist": 280.0,
		},
	]

func _spawn_player() -> void:
	var sp: Vector2 = PLAYER_SPAWN
	me = PlayerScript.new()
	me.name = "P1"
	me.peer_id = 1
	me.player_name = Profile.player_name
	me.is_ai = false
	me.team = 0
	me.weapon_id = "mg"
	me.skin_id = Profile.selected_skin
	me.spawn_point = sp
	me.position = sp
	me.color = arena.color_for(1)
	players_root.add_child(me)
	_player_nodes[1] = me

# ---------------------------------------------------------------- 步骤推进

func _enter_step(i: int) -> void:
	_step = i
	_step_t = 0.0
	_cover_t = 0.0
	_kills = 0
	_clear_targets()
	_marker.visible = false

	if i >= _steps.size():
		_finish()
		return

	var s: Dictionary = _steps[i]
	_title.text = str(s.title)
	_hint.text = str(s.hint)
	_progress.text = "%d / %d" % [i + 1, _steps.size()]
	_panel.visible = true

	var kind := str(s.kind)
	if kind == "reach":
		var p := _open_spot(me.global_position, 330.0)
		_marker_pos = p
		_marker.position = p
		_marker.visible = true
	elif kind == "kill":
		var n := int(s.get("count", 1))
		var dist := float(s.get("dist", 300.0))
		var patrol := bool(s.get("patrol", false))
		for k in range(n):
			var base: Vector2 = me.global_position
			var pos := _open_spot(base, dist + float(k) * 90.0)
			_targets.append(_spawn_dummy(pos, patrol, k))
	elif kind == "cover":
		var pos := _open_spot(me.global_position, float(s.get("dist", 300.0)))
		_targets.append(_spawn_dummy(pos, false, 0))
	elif kind == "weapon":
		_step_weapon = str(me.weapon_id)
	print("[TUTORIAL] 进入步骤 %d：%s" % [i + 1, str(s.title)])

func _process(delta: float) -> void:
	_step_t += delta
	_tick_marker(delta)
	_sync_hud()
	if _finished or _step >= _steps.size():
		return
	match str(_steps[_step].kind):
		"reach": _check_reach()
		"kill": _check_kill()
		"cover": _check_cover(delta)
		"weapon": _check_weapon()

func _check_reach() -> void:
	if me.global_position.distance_to(_marker_pos) <= REACH_RADIUS:
		_advance()

func _check_kill() -> void:
	if _kills >= int(_steps[_step].get("count", 1)):
		_advance()

func _check_cover(delta: float) -> void:
	if _targets.is_empty():
		return
	var d = _targets[0]
	if not is_instance_valid(d) or not d.alive:
		return
	if _los_blocked(d, me):
		_cover_t += delta
		_progress.text = "遮蔽中 %.1f / %.1f 秒" % [minf(_cover_t, COVER_HOLD), COVER_HOLD]
		if _cover_t >= COVER_HOLD:
			_advance()
	else:
		_cover_t = maxf(0.0, _cover_t - delta * 2.0)

func _check_weapon() -> void:
	if me.weapon_id != _step_weapon:
		_advance()

func _advance() -> void:
	_step_t = 0.0
	_enter_step(_step + 1)

func _finish() -> void:
	if _finished:
		return
	_finished = true
	_panel.visible = false
	_marker.visible = false
	_clear_targets()
	Profile.mark_tutorial_done()
	_done_panel.visible = true
	if _done_dim != null:
		_done_dim.visible = true
	_title.text = "训练完成"
	_hint.text = ""
	print("[TUTORIAL] 教学关完成 · 已发放 60 经验 · 当前 Lv%d" % Profile.level())

# ---------------------------------------------------------------- 靶子

func _spawn_dummy(pos: Vector2, patrol: bool, idx: int) -> Node:
	_dummy_seq += 1
	var d = PlayerScript.new()
	d.name = "Dummy%d" % _dummy_seq
	d.peer_id = 100 + _dummy_seq
	d.player_name = "靶子"
	d.is_ai = true
	d.is_dummy = true
	d.dummy_patrol = patrol
	d.dummy_radius = 58.0 + 10.0 * float(idx)
	d.dummy_orbit = (0.85 if idx % 2 == 0 else -0.85) + 0.12 * float(idx)
	d.team = 1
	d.color = Color(1.00, 0.48, 0.32)
	d.spawn_point = pos
	d.position = pos
	players_root.add_child(d)
	return d

func _clear_targets() -> void:
	for d in _targets:
		if is_instance_valid(d):
			d.queue_free()
	_targets.clear()

## 从 origin 向四周找一条没被挡住的射线，返回落点。
## 教学关的靶子位置全部由此决定 —— 地图改了也不会出现「靶子在墙后打不到」。
func _open_spot(origin: Vector2, dist: float) -> Vector2:
	var space := get_world_2d().direct_space_state
	var margin := 90.0
	var best := Vector2.ZERO
	var best_score := -INF
	for i in range(32):
		var a := TAU * float(i) / 32.0
		var dir := Vector2.RIGHT.rotated(a)
		var to := origin + dir * dist
		if to.x < margin or to.x > Maps.W - margin or to.y < 210.0 or to.y > Maps.H - 90.0:
			continue
		var q := PhysicsRayQueryParameters2D.create(origin, to)
		q.collision_mask = 2
		var hit := space.intersect_ray(q)
		# 完全无遮挡优先；其次选遮挡得最远的那个方向
		var score := dist
		if not hit.is_empty():
			score = origin.distance_to(hit.position) - dist
		if score > best_score:
			best_score = score
			best = to
	if best == Vector2.ZERO:
		best = origin + Vector2(dist, 0)
	return best

func _los_blocked(from: Node, to: Node) -> bool:
	var space := get_world_2d().direct_space_state
	var q := PhysicsRayQueryParameters2D.create(from.global_position, to.global_position)
	q.collision_mask = 2
	q.exclude = [from.get_rid()]
	return not space.intersect_ray(q).is_empty()

# ---------------------------------------------------------------- 供 player.gd 调用

## player.gd 会在权威端结算击杀时回调这里取连杀数
func note_kill(pid: int) -> int:
	var n: Node = _player_nodes.get(pid)
	if n == null:
		return 0
	n.streak = int(n.streak) + 1
	return int(n.streak)

func kill_feed(killer_id: int, victim_id: int, weapon: String = "mg", streak: int = 0) -> void:
	if killer_id == 1:
		_kills += 1
	if hud != null:
		hud.show_kill("%s  ·  %s" % [Weapons.get_weapon(weapon).name, "靶子"])

## player.gd 换枪后回调，用来显示一句提示
func on_local_weapon_changed(id: String) -> void:
	if hud != null:
		var w := Weapons.get_weapon(id)
		hud.show_toast("「%s」· %s" % [w.name, w.hint], 2.0)

func player_node(pid: int) -> Node:
	return _player_nodes.get(pid)

# ---------------------------------------------------------------- HUD

func _sync_hud() -> void:
	if hud == null or me == null:
		return
	hud.set_hp(me.health, me.MAX_HEALTH)
	hud.set_alive(me.alive)
	hud.set_weapon(me.weapon_id, me._fire_cd, me.fire_cooldown())

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.name = "UiLayer"
	layer.layer = 10
	add_child(layer)

	hud = HudScript.new()
	hud.name = "Hud"
	layer.add_child(hud)
	hud.setup(
		{"id": "tutorial", "name": "教学关", "subtitle": "跟着提示走", "rules": "tutorial"},
		Maps.get_map(TUTORIAL_MAP),
		arena
	)

	# 步骤面板：放在 HUD 模式面板原来的位置（教学关里那块是空的）
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UiTheme.attach(root)
	layer.add_child(root)

	_panel = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.08, 0.12, 0.86)
	sb.set_corner_radius_all(12)
	sb.set_content_margin_all(16)
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color(0.376, 0.647, 0.980, 0.55)
	_panel.add_theme_stylebox_override("panel", sb)
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	vb.custom_minimum_size = Vector2(520, 0)
	_panel.add_child(vb)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	vb.add_child(head)

	_title = Label.new()
	_title.text = ""
	_title.add_theme_font_size_override("font_size", 20)
	_title.add_theme_color_override("font_color", Color("#8fd0ff"))
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(_title)

	_progress = Label.new()
	_progress.text = ""
	_progress.add_theme_font_size_override("font_size", 14)
	_progress.add_theme_color_override("font_color", Color("#7f93b3"))
	_progress.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	head.add_child(_progress)

	_hint = Label.new()
	_hint.text = ""
	_hint.add_theme_font_size_override("font_size", 15)
	_hint.add_theme_color_override("font_color", Color("#cfe0f7"))
	_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hint.custom_minimum_size = Vector2(520, 0)
	vb.add_child(_hint)

	_panel.reset_size()
	_panel.position = Vector2((1280.0 - _panel.size.x) * 0.5, 16.0)

	_build_done_panel(root)

func _build_done_panel(root: Control) -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.position = Vector2.ZERO
	dim.size = Vector2(1280, 720)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dim.visible = false
	root.add_child(dim)

	_done_panel = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.055, 0.078, 0.125, 0.96)
	sb.set_corner_radius_all(16)
	sb.set_content_margin_all(30)
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color(1, 1, 1, 0.14)
	_done_panel.add_theme_stylebox_override("panel", sb)
	_done_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_done_panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.custom_minimum_size = Vector2(440, 0)
	_done_panel.add_child(vb)

	var t := Label.new()
	t.text = "训练完成"
	t.add_theme_font_size_override("font_size", 32)
	t.add_theme_color_override("font_color", Color("#ffe9a8"))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)

	var body := Label.new()
	body.text = "你已经会开坦克、会打靶、会躲掩体、会换枪了。\n\n正式对局里还有三种模式等着你：\n死斗、占点、生存。\n\n按 ESC 返回菜单"
	body.add_theme_font_size_override("font_size", 17)
	body.add_theme_color_override("font_color", Color("#cfe0f7"))
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(body)

	var lv := Label.new()
	lv.text = "等级 %d %s · %d 经验" % [Profile.level(), Profile.title(), Profile.xp]
	lv.add_theme_font_size_override("font_size", 15)
	lv.add_theme_color_override("font_color", Color("#8fd0ff"))
	lv.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(lv)

	_done_panel.reset_size()
	_done_panel.position = Vector2((1280.0 - _done_panel.size.x) * 0.5, (720.0 - _done_panel.size.y) * 0.5)
	_done_panel.visible = false
	dim.visible = false
	_done_dim = dim

func _build_marker() -> void:
	_marker = Node2D.new()
	_marker.name = "Marker"
	_marker.z_index = -10
	_marker.visible = false
	add_child(_marker)

	var fill := Polygon2D.new()
	fill.polygon = _circle_pts(REACH_RADIUS, 40)
	fill.color = Color(0.376, 0.647, 0.980, 0.13)
	fill.name = "Fill"
	_marker.add_child(fill)

	var ring := Line2D.new()
	var pts := _circle_pts(REACH_RADIUS, 40)
	pts.append(pts[0])
	ring.points = pts
	ring.width = 3.0
	ring.default_color = Color(0.376, 0.647, 0.980, 0.9)
	ring.name = "Ring"
	_marker.add_child(ring)

func _tick_marker(delta: float) -> void:
	if _marker == null or not _marker.visible:
		return
	var ring := _marker.get_node_or_null("Ring")
	var fill := _marker.get_node_or_null("Fill")
	if ring == null or fill == null:
		return
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 260.0)
	ring.width = 2.6 + 1.6 * pulse
	fill.color = Color(0.376, 0.647, 0.980, 0.09 + 0.09 * pulse)

# ---------------------------------------------------------------- 输入

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	match event.keycode:
		KEY_ESCAPE:
			_leave()
		KEY_M:
			var m: bool = Sfx.toggle_mute()
			if hud != null:
				hud.show_toast("音效已%s" % ("关闭" if m else "开启"), 1.2)
		KEY_Q:
			me.cycle_weapon(-1)
		KEY_E:
			me.cycle_weapon(1)
		KEY_1, KEY_2, KEY_3, KEY_4:
			var ids: Array = Weapons.ids()
			var idx := int(event.keycode) - int(KEY_1)
			if idx < ids.size():
				me.switch_weapon(str(ids[idx]))

func _leave() -> void:
	NetworkManager.leave()
	get_tree().reload_current_scene()

func _circle_pts(r: float, seg: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in range(seg):
		var a := TAU * float(i) / float(seg)
		pts.append(Vector2(cos(a), sin(a)) * r)
	return pts
