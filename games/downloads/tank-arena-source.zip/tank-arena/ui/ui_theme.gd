extends RefCounted
## UI 主题补挂工具。
##
## 背景：Godot 的主题归属是沿 Control/Window 祖先链传播的。本项目里 HUD 挂在 Node2D
## （game.gd）下面、坦克名字标签挂在 CharacterBody2D（player.gd）下面，链在中间断掉，
## 这些控件拿不到 Window 上的主题，会一路掉回内置默认主题 —— 也就是 Open Sans，
## 中文全靠系统兜底字形，个别字会掉进 LastResort，渲染成写着码位的豆腐块
## （例如「敌」→ 一个框里写着 654C）。
##
## 所以：凡父节点不是 Control/Window 的控件，都要在 _ready() 里、构建子节点之前
## 调一次 attach()，否则尺寸会按旧字体算错。

static func attach(c: Control) -> void:
	var w := c.get_window()
	if w != null and w.theme != null:
		c.theme = w.theme
