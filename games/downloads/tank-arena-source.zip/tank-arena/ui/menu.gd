extends Control
## 主菜单。三个功能区：
##   左栏 —— 身份 / 涂装 / 挑战（成长曲线的「可见部分」）
##   右栏 —— 模式 / 地图 / 武器 / 开始 / 联机
##
## 设计取舍：不做标签页，一屏全给。理由是这个游戏的选择项本身就不多，
## 藏进标签页反而让人找不到「生存模式在哪」；一屏铺开，第一次打开就能看完所有玩法。
## 唯一的例外是挑战列表（20 条），它放在左栏底部自己滚。

const UiTheme := preload("res://ui/ui_theme.gd")
const Modes := preload("res://game/modes.gd")
const Maps := preload("res://game/maps.gd")
const Weapons := preload("res://game/weapons.gd")
const Progress := preload("res://game/progress.gd")

signal solo_requested(player_name: String, ai_count: int, mode: String, map: String)
signal host_requested(player_name: String, mode: String, map: String)
signal join_requested(player_name: String, ip: String, port: int)
signal tutorial_requested(player_name: String)

const ACCENT := Color("#5aa9f0")
const ACCENT_SOFT := Color(0.376, 0.647, 0.980, 0.55)

var _name_edit: LineEdit
var _ip_edit: LineEdit
var _port_edit: LineEdit
var _ai_option: OptionButton
var _status: Label

var _mode_id: String = "deathmatch"
var _map_id: String = "yard"
var _weapon_id: String = "mg"
var _skin_id: String = "standard"

var _mode_btns: Array = []
var _map_btns: Array = []
var _weapon_btns: Array = []
var _skin_btns: Array = []
var _mode_desc: Label
var _map_desc: Label
var _weapon_desc: Label
var _lvl_label: Label
var _lvl_bar_bg: ColorRect
var _lvl_bar: ColorRect
var _chal_label: Label
var _chal_box: VBoxContainer

# ---------------------------------------------------------------- 生命周期

func _ready() -> void:
	# 父节点是普通 Node，主题链断了，得自己补挂（见 ui/ui_theme.gd）
	UiTheme.attach(self)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_name_edit = null
	_build()
	_refresh_profile()
	if NetworkManager.last_error != "":
		set_status(NetworkManager.last_error)
		NetworkManager.last_error = ""

func set_status(msg: String) -> void:
	if is_instance_valid(_status):
		_status.text = msg

# ---------------------------------------------------------------- 构建

func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#0b1018")
	bg.position = Vector2.ZERO
	bg.size = Vector2(1280, 720)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 26)
	margin.add_theme_constant_override("margin_right", 26)
	margin.add_theme_constant_override("margin_top", 14)
	margin.add_theme_constant_override("margin_bottom", 12)
	add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	margin.add_child(col)

	col.add_child(_build_header())

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(row)

	row.add_child(_build_left())
	row.add_child(_build_right())

	_status = Label.new()
	_status.text = ""
	_status.add_theme_font_size_override("font_size", 13)
	_status.add_theme_color_override("font_color", Color("#ffb37a"))
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.custom_minimum_size = Vector2(0, 20)
	col.add_child(_status)

func _build_header() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)

	var t := Label.new()
	t.text = "坦 克 竞 技 场"
	t.add_theme_font_size_override("font_size", 30)
	t.add_theme_color_override("font_color", Color("#e8f0ff"))
	h.add_child(t)

	var s := Label.new()
	s.text = "局域网多人对战 · 4 张地图 · 3 种模式 · 4 把武器"
	s.add_theme_font_size_override("font_size", 14)
	s.add_theme_color_override("font_color", Color("#7f93b3"))
	s.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(s)

	_lvl_label = Label.new()
	_lvl_label.text = ""
	_lvl_label.add_theme_font_size_override("font_size", 15)
	_lvl_label.add_theme_color_override("font_color", Color("#8fd0ff"))
	_lvl_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(_lvl_label)
	return h

# ---------------------------------------------------------------- 左栏

func _build_left() -> Control:
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	col.custom_minimum_size = Vector2(392, 0)
	col.size_flags_vertical = Control.SIZE_EXPAND_FILL

	# --- 身份 ---
	var idp := _panel()
	col.add_child(idp)
	var iv := VBoxContainer.new()
	iv.add_theme_constant_override("separation", 7)
	idp.add_child(iv)

	var nrow := HBoxContainer.new()
	nrow.add_theme_constant_override("separation", 8)
	iv.add_child(nrow)
	var nl := _cap("昵称")
	nl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	nrow.add_child(nl)
	_name_edit = LineEdit.new()
	_name_edit.text = Profile.player_name
	_name_edit.max_length = 10
	_name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	nrow.add_child(_name_edit)

	var trow := HBoxContainer.new()
	trow.add_theme_constant_override("separation", 8)
	iv.add_child(trow)
	_chal_label = Label.new()
	_chal_label.text = ""
	_chal_label.add_theme_font_size_override("font_size", 13)
	_chal_label.add_theme_color_override("font_color", Color("#9fb2cf"))
	_chal_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	trow.add_child(_chal_label)

	_lvl_bar_bg = ColorRect.new()
	_lvl_bar_bg.color = Color(1, 1, 1, 0.10)
	_lvl_bar_bg.custom_minimum_size = Vector2(0, 8)
	_lvl_bar_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	iv.add_child(_lvl_bar_bg)
	# 用锚点表示进度：父节点是普通 ColorRect（有真实尺寸），比手动算像素宽稳
	_lvl_bar = ColorRect.new()
	_lvl_bar.color = ACCENT
	_lvl_bar.anchor_left = 0.0
	_lvl_bar.anchor_top = 0.0
	_lvl_bar.anchor_right = 0.0
	_lvl_bar.anchor_bottom = 1.0
	_lvl_bar.offset_left = 0.0
	_lvl_bar.offset_right = 0.0
	_lvl_bar.offset_top = 0.0
	_lvl_bar.offset_bottom = 0.0
	_lvl_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lvl_bar_bg.add_child(_lvl_bar)

	# --- 涂装 ---
	var skp := _panel()
	col.add_child(skp)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 7)
	skp.add_child(sv)
	sv.add_child(_cap("涂装（车体主色仍按槽位分配，这里只改图案）"))
	var srow1 := HBoxContainer.new()
	srow1.add_theme_constant_override("separation", 6)
	var srow2 := HBoxContainer.new()
	srow2.add_theme_constant_override("separation", 6)
	sv.add_child(srow1)
	sv.add_child(srow2)
	for i in range(Progress.SKINS.size()):
		var sk: Dictionary = Progress.SKINS[i]
		var b := Button.new()
		b.text = str(sk.name)
		b.custom_minimum_size = Vector2(0, 28)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_size_override("font_size", 12)
		b.tooltip_text = str(sk.get("desc", ""))
		b.pressed.connect(_on_skin_pressed.bind(str(sk.id)))
		(srow1 if i < 4 else srow2).add_child(b)
		_skin_btns.append(b)

	# --- 挑战 ---
	var cp := _panel()
	cp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(cp)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 6)
	cp.add_child(cv)
	cv.add_child(_cap("挑战"))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	cv.add_child(sc)
	_chal_box = VBoxContainer.new()
	_chal_box.add_theme_constant_override("separation", 4)
	_chal_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_chal_box)
	return col

# ---------------------------------------------------------------- 右栏

func _build_right() -> Control:
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 9)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.size_flags_vertical = Control.SIZE_EXPAND_FILL

	# --- 模式 ---
	var mp := _panel()
	col.add_child(mp)
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 7)
	mp.add_child(mv)
	mv.add_child(_cap("对战模式"))
	var mrow := HBoxContainer.new()
	mrow.add_theme_constant_override("separation", 8)
	mv.add_child(mrow)
	for i in range(Modes.LIST.size()):
		var m: Dictionary = Modes.LIST[i]
		var b := _card(str(m.name))
		b.pressed.connect(_on_mode_pressed.bind(str(m.id)))
		mrow.add_child(b)
		_mode_btns.append(b)
	_mode_desc = _desc()
	mv.add_child(_mode_desc)

	# --- 地图 ---
	var map_p := _panel()
	col.add_child(map_p)
	var av := VBoxContainer.new()
	av.add_theme_constant_override("separation", 7)
	map_p.add_child(av)
	av.add_child(_cap("地图"))
	var arow := HBoxContainer.new()
	arow.add_theme_constant_override("separation", 8)
	av.add_child(arow)
	for i in range(Maps.LIST.size()):
		var m: Dictionary = Maps.LIST[i]
		var b := _card(str(m.name))
		b.pressed.connect(_on_map_pressed.bind(str(m.id)))
		arow.add_child(b)
		_map_btns.append(b)
	_map_desc = _desc()
	av.add_child(_map_desc)

	# --- 武器 ---
	var wp := _panel()
	col.add_child(wp)
	var wv := VBoxContainer.new()
	wv.add_theme_constant_override("separation", 7)
	wp.add_child(wv)
	wv.add_child(_cap("初始武器（对局里可随时用 1-4 / Q E 切换）"))
	var wrow := HBoxContainer.new()
	wrow.add_theme_constant_override("separation", 8)
	wv.add_child(wrow)
	for i in range(Weapons.LIST.size()):
		var w: Dictionary = Weapons.LIST[i]
		var b := _card(str(w.short))
		b.pressed.connect(_on_weapon_pressed.bind(str(w.id)))
		wrow.add_child(b)
		_weapon_btns.append(b)
	_weapon_desc = _desc()
	wv.add_child(_weapon_desc)

	# --- 开始 ---
	var sp := _panel()
	col.add_child(sp)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 7)
	sp.add_child(sv)
	sv.add_child(_cap("开始游戏"))
	var srow := HBoxContainer.new()
	srow.add_theme_constant_override("separation", 8)
	sv.add_child(srow)

	var solo := Button.new()
	solo.text = "开始单机"
	solo.custom_minimum_size = Vector2(0, 44)
	solo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	solo.add_theme_font_size_override("font_size", 18)
	solo.pressed.connect(_on_solo_pressed)
	srow.add_child(solo)

	var tut := Button.new()
	tut.text = "教学关（推荐第一次先打）"
	tut.custom_minimum_size = Vector2(240, 44)
	tut.add_theme_font_size_override("font_size", 15)
	tut.pressed.connect(_on_tutorial_pressed)
	srow.add_child(tut)

	_ai_option = OptionButton.new()
	_ai_option.custom_minimum_size = Vector2(118, 44)
	_ai_option.add_item("1 个电脑", 1)
	_ai_option.add_item("2 个电脑", 2)
	_ai_option.add_item("3 个电脑", 3)
	_ai_option.add_item("4 个电脑", 4)
	_ai_option.select(2)
	srow.add_child(_ai_option)

	# --- 联机 ---
	var lp := _panel()
	col.add_child(lp)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 7)
	lp.add_child(lv)
	lv.add_child(_cap("局域网联机（主机点「创建房间」，其他人填主机 IP 后点「加入房间」）"))
	var lrow := HBoxContainer.new()
	lrow.add_theme_constant_override("separation", 8)
	lv.add_child(lrow)

	_ip_edit = LineEdit.new()
	_ip_edit.placeholder_text = "主机 IP，例如 192.168.1.5"
	_ip_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lrow.add_child(_ip_edit)

	_port_edit = LineEdit.new()
	_port_edit.text = "7000"
	_port_edit.custom_minimum_size = Vector2(78, 0)
	lrow.add_child(_port_edit)

	var hb := Button.new()
	hb.text = "创建房间"
	hb.custom_minimum_size = Vector2(122, 36)
	hb.pressed.connect(_on_host_pressed)
	lrow.add_child(hb)

	var jb := Button.new()
	jb.text = "加入房间"
	jb.custom_minimum_size = Vector2(122, 36)
	jb.pressed.connect(_on_join_pressed)
	lrow.add_child(jb)

	var ips := _local_ips()
	var tip := Label.new()
	tip.text = "本机局域网 IP：%s" % ("、".join(ips) if ips.size() > 0 else "未检测到")
	tip.add_theme_font_size_override("font_size", 12)
	tip.add_theme_color_override("font_color", Color("#61799b"))
	lv.add_child(tip)

	_ip_edit.text_submitted.connect(func(_t): _on_join_pressed())

	_refresh_selection()
	return col

# ---------------------------------------------------------------- 选择

func _on_mode_pressed(id: String) -> void:
	_mode_id = id
	_refresh_selection()

func _on_map_pressed(id: String) -> void:
	_map_id = id
	_refresh_selection()

func _on_weapon_pressed(id: String) -> void:
	if not Profile.is_weapon_unlocked(id):
		return
	_weapon_id = id
	Profile.set_weapon(id)
	_refresh_selection()

func _on_skin_pressed(id: String) -> void:
	if not Profile.is_skin_unlocked(id):
		set_status("「%s」还没解锁" % str(Progress.get_skin(id).name))
		return
	_skin_id = id
	Profile.set_skin(id)
	_refresh_profile()

func _refresh_selection() -> void:
	var m := Modes.get_mode(_mode_id)
	for i in range(_mode_btns.size()):
		_style_selected(_mode_btns[i], str(Modes.LIST[i].id) == _mode_id, true)
	_mode_desc.text = "%s · %s" % [str(m.subtitle), str(m.desc)]

	var mp := Maps.get_map(_map_id)
	for i in range(_map_btns.size()):
		_style_selected(_map_btns[i], str(Maps.LIST[i].id) == _map_id, true)
	_map_desc.text = "%s" % str(mp.subtitle)

	for i in range(_weapon_btns.size()):
		var w: Dictionary = Weapons.LIST[i]
		var wid := str(w.id)
		var ok: bool = Profile.is_weapon_unlocked(wid)
		var b: Button = _weapon_btns[i]
		b.disabled = not ok
		b.text = str(w.short) if ok else "%s · %d级" % [str(w.short), int(w.unlock_level)]
		_style_selected(b, ok and wid == _weapon_id, ok)

	if not Profile.is_weapon_unlocked(_weapon_id):
		_weapon_id = Profile.selected_weapon
	if not Profile.is_weapon_unlocked(_weapon_id):
		_weapon_id = "mg"
	var wc := Weapons.get_weapon(_weapon_id)
	if _weapon_desc != null:
		_weapon_desc.text = "%s · %s" % [str(wc.name), str(wc.hint)]

# ---------------------------------------------------------------- 档案刷新

func _refresh_profile() -> void:
	var lv := Profile.level()
	_lvl_label.text = "Lv %d  %s   %d 经验" % [lv, Profile.title(), Profile.xp]
	_chal_label.text = "挑战 %d / %d 完成" % [Profile.challenges_done_count(), Profile.challenges_total()]
	_lvl_bar.anchor_right = Profile.level_ratio()

	for i in range(_skin_btns.size()):
		var sk: Dictionary = Progress.SKINS[i]
		var ok: bool = Profile.is_skin_unlocked(str(sk.id))
		var b: Button = _skin_btns[i]
		b.disabled = not ok
		_style_selected(b, str(sk.id) == Profile.selected_skin, ok)

	_refresh_challenges()
	_refresh_selection()

func _refresh_challenges() -> void:
	for c in _chal_box.get_children():
		c.queue_free()
	for ch in Progress.CHALLENGES:
		var done: bool = Profile.done_challenges.has(str(ch.id))
		var have := int(Profile.stats.get(str(ch.stat), 0))
		var target := int(ch.target)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)

		var mark := Label.new()
		mark.text = "●" if done else "○"
		mark.add_theme_font_size_override("font_size", 12)
		mark.add_theme_color_override("font_color",
			Color("#4ade80") if done else Color(1, 1, 1, 0.25))
		row.add_child(mark)

		var nm := Label.new()
		nm.text = str(ch.name)
		nm.add_theme_font_size_override("font_size", 12)
		nm.add_theme_color_override("font_color",
			Color("#cfe0f7") if done else Color(1, 1, 1, 0.62))
		nm.custom_minimum_size = Vector2(88, 0)
		row.add_child(nm)

		var ds := Label.new()
		ds.text = str(ch.desc)
		ds.add_theme_font_size_override("font_size", 12)
		ds.add_theme_color_override("font_color", Color(1, 1, 1, 0.42))
		ds.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(ds)

		var pg := Label.new()
		pg.text = "%d/%d" % [mini(have, target), target]
		pg.add_theme_font_size_override("font_size", 12)
		pg.add_theme_color_override("font_color",
			Color("#4ade80") if done else Color(1, 1, 1, 0.35))
		row.add_child(pg)
		_chal_box.add_child(row)

# ---------------------------------------------------------------- 交互

func _player_name() -> String:
	if _name_edit == null:
		return Profile.player_name
	var t := _name_edit.text.strip_edges()
	if t == "":
		t = "玩家"
	Profile.set_player_name(t)
	return t

func _on_solo_pressed() -> void:
	solo_requested.emit(_player_name(), _ai_option.get_selected_id(), _mode_id, _map_id)

func _on_tutorial_pressed() -> void:
	tutorial_requested.emit(_player_name())

func _on_host_pressed() -> void:
	host_requested.emit(_player_name(), _mode_id, _map_id)

func _on_join_pressed() -> void:
	var port := NetworkManager.DEFAULT_PORT
	if _port_edit.text.strip_edges().is_valid_int():
		port = int(_port_edit.text.strip_edges())
	join_requested.emit(_player_name(), _ip_edit.text.strip_edges(), port)

# ---------------------------------------------------------------- 小工具

func _panel() -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color("#111a29")
	sb.set_corner_radius_all(12)
	sb.set_content_margin_all(10)
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color("#22314a")
	p.add_theme_stylebox_override("panel", sb)
	return p

func _cap(t: String) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 12)
	l.add_theme_color_override("font_color", Color("#7f93b3"))
	return l

func _desc() -> Label:
	var l := Label.new()
	l.text = ""
	l.add_theme_font_size_override("font_size", 13)
	l.add_theme_color_override("font_color", Color("#9fb2cf"))
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(0, 28)
	l.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	return l

## 一张「卡片按钮」：名字一行，选中时亮蓝边框
func _card(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 44)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 15)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	_style_selected(b, false, true)
	return b

func _style_selected(b: Button, selected: bool, enabled: bool) -> void:
	var n := StyleBoxFlat.new()
	n.set_corner_radius_all(9)
	n.set_content_margin_all(8)
	if not enabled:
		n.bg_color = Color(0.06, 0.07, 0.09, 0.9)
		n.border_width_left = 1
		n.border_width_top = 1
		n.border_width_right = 1
		n.border_width_bottom = 1
		n.border_color = Color(1, 1, 1, 0.05)
	elif selected:
		n.bg_color = Color(0.11, 0.20, 0.33, 1.0)
		n.border_width_left = 2
		n.border_width_top = 2
		n.border_width_right = 2
		n.border_width_bottom = 2
		n.border_color = ACCENT
	else:
		n.bg_color = Color(0.075, 0.105, 0.165, 1.0)
		n.border_width_left = 1
		n.border_width_top = 1
		n.border_width_right = 1
		n.border_width_bottom = 1
		n.border_color = Color("#22314a")

	var h: StyleBoxFlat = n.duplicate()
	h.bg_color = n.bg_color.lightened(0.10)

	var p: StyleBoxFlat = n.duplicate()
	p.bg_color = n.bg_color.lightened(0.18)

	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", p)
	b.add_theme_stylebox_override("disabled", n)
	b.add_theme_color_override("font_color",
		Color("#ffffff") if (selected and enabled) else (Color(1, 1, 1, 0.85) if enabled else Color(1, 1, 1, 0.30)))
	b.add_theme_color_override("font_hover_color", Color("#ffffff"))
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.30))

func _local_ips() -> Array:
	var out := []
	for a in IP.get_local_addresses():
		if a.contains(":"):
			continue
		if a.begins_with("127.") or a.begins_with("169.254."):
			continue
		out.append(a)
	return out
