extends Node
## 入口：设置全局字体/输入映射，负责「菜单 <-> 游戏 / 教学关」场景切换，以及全部自动化测试入口。

const MenuScene := preload("res://ui/menu.gd")
const GameScene := preload("res://game/game.gd")
const TutorialScene := preload("res://ui/tutorial.gd")
const PlayerScript := preload("res://game/player.gd")
const Weapons := preload("res://game/weapons.gd")
const Maps := preload("res://game/maps.gd")
const Modes := preload("res://game/modes.gd")
const Progress := preload("res://game/progress.gd")

var _menu: Control
var _game: Node2D
## 命令行 --admin：进入游戏后自动开启管理员模式（自动化测试用）
var _cli_admin: bool = false

func _ready() -> void:
	_setup_theme()
	_setup_input()
	NetworkManager.join_failed.connect(_on_join_failed)
	NetworkManager.host_left.connect(_on_host_left)
	_show_menu()
	_handle_cmdline()

func _exit_tree() -> void:
	NetworkManager.leave()

# ---------------------------------------------------------------- 初始化

func _setup_theme() -> void:
	# Godot 内置字体不含中文字形。
	# 桌面端靠系统字体还凑合，但 Web 构建**没有系统字体**（SystemFont 依赖
	# OS.get_system_font_path()，Web 平台未实现），只用 SystemFont 会导致
	# 网页版中文全部乱码/豆腐块。所以内嵌一份 Noto Sans SC 子集（OFL 许可，
	# 见 assets/fonts/OFL.txt），系统字体仅作桌面端兜底。
	var sys_font := SystemFont.new()
	# font_names 是「优先级列表」而不是「回退链」：Godot 只用第一个能解析到的字体，
	# 后续名字不会用来补缺字。所以顺序必须按字形覆盖度排，而不是按好看程度排。
	# 踩过的坑：某些 macOS 上 "PingFang SC" 能解析到、却不含「敌」等字，
	# 排在第一位会让界面出现豆腐块。可用 `--fonttest` 复测。
	sys_font.font_names = PackedStringArray([
		"Hiragino Sans GB",          # macOS：中文覆盖最全
		"Heiti SC", "STHeiti",
		"Songti SC", "STSong",
		"PingFang SC",               # macOS 新系统首选，但覆盖不全时只作兜底
		"Microsoft YaHei", "SimHei", # Windows
		"Noto Sans CJK SC", "Source Han Sans SC", "WenQuanYi Micro Hei",
		"sans-serif",
	])
	sys_font.subpixel_positioning = TextServer.SUBPIXEL_POSITIONING_AUTO

	const BUNDLED_FONT := "res://assets/fonts/NotoSansSC-Regular.woff2"
	var f: Font = sys_font
	if ResourceLoader.exists(BUNDLED_FONT):
		var base: Font = load(BUNDLED_FONT)
		if base != null:
			var fv := FontVariation.new()
			fv.base_font = base
			fv.fallbacks = [sys_font]
			f = fv
	else:
		push_warning("未找到内置中文字体 %s，网页版中文会乱码" % BUNDLED_FONT)
	var t := Theme.new()
	t.default_font = f
	t.default_font_size = 18
	# 只设 default_font 是不够的：内置默认主题里 Label/Button 等类型各自带 font 条目，
	# 主题查找是「哪个主题有这条目就用哪个」，内置主题有、我们的没有，
	# 于是所有控件其实一直在用默认主题的 Open Sans，中文全靠系统兜底字形，
	# 个别字会掉进 LastResort，渲染成写着码位的豆腐块（例如「敌」→ 654C）。
	# 这里把默认主题里所有字体条目都覆写成我们的字体，确保真正生效。
	var def := ThemeDB.get_default_theme()
	for ty in def.get_font_type_list():
		for item in def.get_font_list(ty):
			t.set_font(item, ty, f)
	# 主题归属是沿 Control/Window 祖先链传播的：HUD 挂在 CanvasLayer 下、
	# 坦克名字标签挂在 CharacterBody2D 下面，链在中间断掉，这些控件拿不到 Window 上的主题。
	# 所以挂在非 Control 父节点下的控件要自己补挂，见 ui/ui_theme.gd。
	get_tree().root.theme = t

func _setup_input() -> void:
	var defs := {
		"move_up": [KEY_W, KEY_UP],
		"move_down": [KEY_S, KEY_DOWN],
		"move_left": [KEY_A, KEY_LEFT],
		"move_right": [KEY_D, KEY_RIGHT],
		"fire": [KEY_SPACE],
	}
	for action_name in defs.keys():
		if InputMap.has_action(action_name):
			InputMap.erase_action(action_name)
		InputMap.add_action(action_name)
		for k in defs[action_name]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action_name, ev)
	var mb := InputEventMouseButton.new()
	mb.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("fire", mb)

# ---------------------------------------------------------------- 场景切换

func _show_menu() -> void:
	if is_instance_valid(_game):
		_game.queue_free()
		_game = null
	_menu = MenuScene.new()
	_menu.solo_requested.connect(_on_solo_requested)
	_menu.host_requested.connect(_on_host_requested)
	_menu.join_requested.connect(_on_join_requested)
	_menu.tutorial_requested.connect(_on_tutorial_requested)
	add_child(_menu)

func _start_game() -> void:
	if is_instance_valid(_menu):
		_menu.queue_free()          # 按钮信号是在菜单自己的回调里发出的，必须延迟释放
		_menu = null
	if is_instance_valid(_game):
		_game.free()                # 立刻释放：自动化测试会连续开好几局
		_game = null
	_game = GameScene.new()
	_game.name = "Game"
	add_child(_game)
	if _cli_admin:
		_apply_cli_admin()

func _start_tutorial() -> void:
	if is_instance_valid(_menu):
		_menu.queue_free()
		_menu = null
	if is_instance_valid(_game):
		_game.free()
		_game = null
	_game = TutorialScene.new()
	_game.name = "Tutorial"
	add_child(_game)

func _apply_cli_admin() -> void:
	# 联机时 _start_game() 跑在连接建立之前，本地玩家节点还没生成，得等它出现
	for i in range(300):
		await get_tree().process_frame
		if is_instance_valid(_game) and _game._player_nodes.has(NetworkManager.local_id()):
			_game.toggle_admin()
			return

# ---------------------------------------------------------------- 菜单回调

func _on_solo_requested(pname: String, ai_count: int, mode: String, map: String) -> void:
	NetworkManager.my_name = pname if pname.strip_edges() != "" else "玩家"
	NetworkManager.start_solo(ai_count, mode, map)
	_start_game()

func _on_host_requested(pname: String, mode: String = "deathmatch", map: String = "yard") -> void:
	NetworkManager.my_name = pname if pname.strip_edges() != "" else "主机"
	var err := NetworkManager.host_game(NetworkManager.DEFAULT_PORT, mode, map)
	if err != OK:
		if is_instance_valid(_menu):
			_menu.set_status("创建房间失败：端口 %d 可能被占用（错误码 %d）" % [NetworkManager.DEFAULT_PORT, err])
		return
	_start_game()

func _on_join_requested(pname: String, ip: String, port: int = NetworkManager.DEFAULT_PORT) -> void:
	NetworkManager.my_name = pname if pname.strip_edges() != "" else "玩家"
	if ip.strip_edges() == "":
		if is_instance_valid(_menu):
			_menu.set_status("请先填写主机 IP")
		return
	var err := NetworkManager.join_game(ip.strip_edges(), port)
	if err != OK:
		if is_instance_valid(_menu):
			_menu.set_status("无法连接 %s（错误码 %d）" % [ip, err])
		return
	# 这里**不能**立刻 _start_game()：此刻还没收到房主的对局设置，
	# mode_id/map_id 仍是默认的「死斗 / 训练场」，会先按错地图建一局；
	# 而 settings_changed 之后没人监听，地图和模式就永远换不回来了
	# （踩过：主机在「蜂巢·占点」，客户端却在「训练场·死斗」里跑）。
	# 所以留在菜单里等，等主机把设置发过来再开局。
	if is_instance_valid(_menu):
		_menu.set_status("正在连接 %s …" % ip.strip_edges())
	NetworkManager.settings_changed.connect(_on_join_settings_ready, CONNECT_ONE_SHOT)
	_join_watchdog(ip.strip_edges())

## 房主把「模式 / 地图」发过来了 —— 现在才真正开局
func _on_join_settings_ready() -> void:
	if is_instance_valid(_game):
		return
	print("[NET] 已收到房主设置，按 %s / %s 开局" % [NetworkManager.mode_id, NetworkManager.map_id])
	_start_game()

## 连上了却迟迟收不到对局设置的兜底（房主卡死、或双方版本不一致）
func _join_watchdog(ip: String) -> void:
	await get_tree().create_timer(8.0).timeout
	if is_instance_valid(_game):
		return
	if is_instance_valid(_menu):
		_menu.set_status("已连上 %s，但没收到对局设置。请确认双方是同一个版本。" % ip)
	NetworkManager.leave()

func _on_tutorial_requested(pname: String) -> void:
	NetworkManager.my_name = pname if pname.strip_edges() != "" else "玩家"
	NetworkManager.leave()
	_start_tutorial()

func _on_join_failed() -> void:
	NetworkManager.leave()
	get_tree().reload_current_scene()

func _on_host_left() -> void:
	get_tree().reload_current_scene()

# ---------------------------------------------------------------- 命令行参数
## godot --path . -- --host
## godot --path . -- --join=192.168.1.5
## godot --path . -- --solo=3 --mode=king --map=hive
## godot --path . -- --shot-all / --shot-game=survival:atoll / --shot-tutorial
## godot --headless --path . -- --selftest / --progression / --fonttest

func _arg(args: PackedStringArray, key: String, fallback: String) -> String:
	for a in args:
		if a.begins_with(key + "="):
			return a.substr(key.length() + 1)
	return fallback

func _handle_cmdline() -> void:
	var args := OS.get_cmdline_user_args()
	_cli_admin = args.has("--admin")
	var mode := _arg(args, "--mode", "deathmatch")
	var map := _arg(args, "--map", "yard")
	# --autoquit 必须在动作分发**之前**解析：下面每个分支命中就 return，
	# 放在循环里的话「--host --autoquit=20」永远读不到 autoquit，
	# 无头冒烟测试就会挂住不退（踩过：两个进程都卡到超时被杀）。
	var aq := _arg(args, "--autoquit", "")
	if aq != "":
		_autoquit(float(aq))
	elif args.has("--shot-all") or args.has("--shot-menu") or args.has("--shot-tutorial") \
			or args.has("--shot") or args.has("--shot-solo") or args.has("--shot-admin") \
			or _arg(args, "--shot-game", "") != "":
		# 截图流程要有兜底退出：窗口一旦被遮挡就可能卡在等渲染帧上，
		# 没有兜底的话进程会一直挂着（踩过：--shot-all 挂了几分钟）。
		_autoquit(60.0)

	# --shot-res=1920x1080：截图分辨率。和 --autoquit 一样必须在动作分发**之前**处理，
	# 否则 --shot-all 命中就 return，分辨率根本设不上。
	#
	# 为什么改窗口大小就能得到真·1080p：项目用的是 canvas_items 拉伸模式，
	# 窗口变大 = 画布变换整体缩放，字体和矢量图形会按新分辨率**重新栅格化**，
	# 而不是把小图放大（viewport 拉伸模式才会糊）。逻辑坐标仍是 1280x720，
	# 所以 HUD 的绝对坐标布局完全不受影响。
	# Steam 商店页要求截图 ≥1920x1080，默认的 1280x720 不合格。
	var res := _arg(args, "--shot-res", "")
	if res != "":
		var parts := res.split("x")
		if parts.size() == 2:
			var want := Vector2i(int(parts[0]), int(parts[1]))
			var scr := DisplayServer.screen_get_size()
			print("[SHOT] 请求截图分辨率 %dx%d · 屏幕 %dx%d" % [want.x, want.y, scr.x, scr.y])
			DisplayServer.window_set_size(want)
	for a in args:
		if a == "--host":
			_on_host_requested("主机", mode, map)
			return
		if a.begins_with("--join="):
			_on_join_requested("访客", a.substr("--join=".length()))
			return
		if a == "--solo":
			_on_solo_requested("玩家", 3, mode, map)
			return
		if a.begins_with("--solo="):
			_on_solo_requested("玩家", int(a.substr("--solo=".length())), mode, map)
			return
		if a == "--tutorial":
			_on_tutorial_requested("玩家")
			return
		if a.begins_with("--autoquit="):
			continue   # 上面已经处理过了
		if a == "--selftest":
			_run_selftest()
			return
		if a == "--progression":
			_run_progression_test()
			return
		if a == "--fonttest":
			_run_fonttest()
			return
		if a == "--shot-all":
			_run_shot_all()
			return
		if a == "--shot-menu":
			_run_shot_menu()
			return
		if a == "--shot-tutorial":
			_run_shot_tutorial()
			return
		if a.begins_with("--shot-game="):
			var v := a.substr("--shot-game=".length())
			var parts := v.split(":")
			_run_shot_game(parts[0], parts[1] if parts.size() > 1 else "yard")
			return
		if a == "--shot":
			_run_shot_menu()
			return
		if a == "--shot-solo":
			_run_shot_game("deathmatch", "yard")
			return
		if a == "--shot-admin":
			_run_shot_admin()
			return

## N 秒后自动退出。
## 局域网冒烟测试必须用它，不能用 --quit-after：--quit-after 是按帧计数的，
## 而无头模式的主循环不锁帧，几百帧几毫秒就跑完了 —— 主机会在客户端连上之前就退出。
func _autoquit(secs: float) -> void:
	print("[TEST] %s 秒后自动退出" % str(secs))
	await get_tree().create_timer(secs).timeout
	print("[TEST] autoquit 到时，退出")
	get_tree().quit()

# ---------------------------------------------------------------- 截图

func _save_shot(tag: String) -> void:
	# 必须等这一帧真正画完再取纹理：直接 get_image() 拿到的是上一帧甚至更早的内容，
	# 连续截多张时会得到一堆一模一样的图（踩过：6 张里 4 张 md5 相同）。
	#
	# 但 frame_post_draw 不是「一定会来」：窗口被完全遮挡、或系统把进程挂起时，
	# 渲染线程可能停止出帧，await 就永久挂起，整个 --shot-* 流程静默卡死
	# （踩过：--shot-all 挂了几分钟不退出，最后只能手动 kill）。
	# 所以这里和超时赛跑，超时就拿当前纹理凑合，并打一行警告。
	var arrived := [false]
	var cb := func() -> void: arrived[0] = true
	RenderingServer.frame_post_draw.connect(cb, CONNECT_ONE_SHOT)
	var waited := 0.0
	while not arrived[0] and waited < 3.0:
		await get_tree().process_frame
		waited += get_process_delta_time()
	if not arrived[0]:
		if RenderingServer.frame_post_draw.is_connected(cb):
			RenderingServer.frame_post_draw.disconnect(cb)
		printerr("[SHOT] 等渲染帧超时（窗口可能被遮挡），改用当前纹理")
	var img := get_viewport().get_texture().get_image()
	var path := "res://shot_%s.png" % tag
	img.save_png(path)
	var who := "（无对局）"
	# toggle_admin 只有 game.gd 有，教学关没有 mode/map_def
	if is_instance_valid(_game) and _game.has_method("toggle_admin"):
		who = "模式=%s 地图=%s 节点=%d" % [
			str(_game.mode.get("name", "?")), str(_game.map_def.get("name", "?")),
			_game.get_child_count()]
	# 顺带打印实际像素尺寸：窗口被系统钳制时这里会露馅（Steam 要求 ≥1920x1080）
	print("[SHOT] %s  %dx%d  [%s]" % [
		ProjectSettings.globalize_path(path), img.get_width(), img.get_height(), who])

func _run_shot_menu() -> void:
	await get_tree().create_timer(0.9).timeout
	await _save_shot("menu")
	get_tree().quit()

## 截图前把本地玩家拉回活体状态并打一发。
## 截图时玩家是站桩的，几秒内必被 AI 打死，画面中央会挂一句「已被击毁」——
## 那对「这游戏长什么样」的表达是负分。这里强制复活 + 开一枪，画面里就有炮口焰和弹道。
func _prep_shot_player(weapon: String = "railgun") -> void:
	var me = _game._player_nodes.get(1)
	if me == null:
		return
	me.health = me.MAX_HEALTH
	me.alive = true
	me.visible = true
	me._refresh_hp()
	me.weapon_id = weapon if Profile.is_weapon_unlocked(weapon) else "mg"
	me._fire_cd = 0.0
	me._turret_rot = 0.0
	me._fire()

func _run_shot_game(mode: String, map: String) -> void:
	NetworkManager.my_name = "玩家"
	NetworkManager.start_solo(3, mode, map)
	_start_game()
	await get_tree().create_timer(1.4).timeout
	_prep_shot_player("railgun")
	await get_tree().create_timer(0.13).timeout
	await _save_shot("game_%s_%s" % [mode, map])
	get_tree().quit()

## 一次拍完整套：4 张地图（死斗）+ 另外两种模式，用来审视「截图墙」够不够多样
func _run_shot_all() -> void:
	NetworkManager.my_name = "玩家"
	var jobs: Array = []
	for m in Maps.LIST:
		jobs.append(["deathmatch", str(m.id)])
	jobs.append(["king", "crossroads"])
	jobs.append(["survival", "atoll"])
	for j in jobs:
		NetworkManager.start_solo(3, str(j[0]), str(j[1]))
		_start_game()
		await get_tree().create_timer(1.4).timeout
		_prep_shot_player("railgun")
		await get_tree().create_timer(0.13).timeout
		await _save_shot("game_%s_%s" % [str(j[0]), str(j[1])])
	await get_tree().create_timer(0.2).timeout
	get_tree().quit()

func _run_shot_tutorial() -> void:
	NetworkManager.my_name = "玩家"
	NetworkManager.leave()
	_start_tutorial()
	await get_tree().create_timer(1.2).timeout
	await _save_shot("tutorial")
	await get_tree().create_timer(1.4).timeout
	await _save_shot("tutorial_b")
	get_tree().quit()

## 截图验证管理员模式：godot --path . -- --shot-admin
func _run_shot_admin() -> void:
	NetworkManager.my_name = "玩家"
	NetworkManager.start_solo(3, "deathmatch", "yard")
	_start_game()
	await get_tree().create_timer(1.0).timeout
	_game.toggle_admin()
	var me = _game._player_nodes.get(1)
	print("[TEST] 管理员开启: %s" % str(me != null and me.admin))
	await get_tree().create_timer(3.2).timeout
	await _save_shot("admin")

	# 手动对本地玩家来一发，拍「护盾挡弹」的瞬间，并核对血量没掉
	if me != null:
		me.health = 3
		me._refresh_hp()
		me.take_damage(1, 2)
		await get_tree().create_timer(0.05).timeout
		print("[TEST] 管理员挨一发后血量: %d（期望 3）" % me.health)
		await _save_shot("admin_block")
		# 关掉再挨一发，确认无敌确实解除了
		_game.toggle_admin()
		me.take_damage(1, 2)
		print("[TEST] 关闭管理员后挨一发血量: %d（期望 1）" % me.health)
	await get_tree().create_timer(0.4).timeout
	get_tree().quit()

# ---------------------------------------------------------------- 字体探测
## godot --headless --path . -- --fonttest

func _run_fonttest() -> void:
	var probe := "管理员无敌加速超级射速靶子教学掩体切换武器挑战涂装占点生存"
	var names := [
		"PingFang SC", "Hiragino Sans GB", "Songti SC", "STSong",
		"Heiti SC", "STHeiti", "Heiti TC", "Arial Unicode MS",
		"Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Source Han Sans SC",
		"WenQuanYi Micro Hei", "sans-serif",
	]
	print("[FONT] ---- 单字体缺字探测（探针: %s）----" % probe)
	for n in names:
		var f := SystemFont.new()
		f.font_names = PackedStringArray([n])
		var miss := ""
		for i in range(probe.length()):
			if not f.has_char(probe.unicode_at(i)):
				miss += probe[i]
		print("[FONT] %-20s 缺字: %s" % [n, miss if miss != "" else "（无）"])
	var cur: Font = get_tree().root.theme.default_font
	var miss2 := ""
	if cur != null:
		for i in range(probe.length()):
			if not cur.has_char(probe.unicode_at(i)):
				miss2 += probe[i]
	print("[FONT] 当前主题字体 缺字: %s" % (miss2 if miss2 != "" else "（无）"))
	get_tree().quit()

# ---------------------------------------------------------------- 成长曲线自检
## godot --headless --path . -- --progression

func _run_progression_test() -> void:
	print("[TEST] ---- 成长曲线 ----")
	for lv in [1, 3, 5, 10, 20, 30]:
		print("[TEST] Lv%-2d 称号=%-4s 升下一级需要 %5d 经验 · 累计 %6d" % [
			lv, Progress.title_for_level(lv), Progress.xp_to_next(lv), Progress.total_xp_for_level(lv)])

	var top := Progress.total_xp_for_level(Progress.MAX_LEVEL)
	print("[TEST] 满级（Lv%d）累计经验: %d" % [Progress.MAX_LEVEL, top])

	# 一局死斗按 20 杀 + 胜利算
	var per_match := 20 * int(Modes.get_mode("deathmatch").xp.kill) + int(Modes.get_mode("deathmatch").xp.win)
	print("[TEST] 一局死斗（20 杀 + 胜）约 %d 经验" % per_match)
	print("[TEST] 打满 30 级大约需要 %.0f 局" % (float(top) / float(per_match)))

	# 往返一致性：等级 → 累计经验 → 等级
	var bad := 0
	for lv in range(1, Progress.MAX_LEVEL + 1):
		if Progress.level_for_xp(Progress.total_xp_for_level(lv)) != lv:
			bad += 1
	print("[TEST] 等级往返一致性: %s（不一致 %d 个）" % ["通过" if bad == 0 else "失败", bad])

	# 单调性：经验必须严格递增
	var mono := true
	var prev := 0
	for lv in range(1, Progress.MAX_LEVEL):
		var v := Progress.xp_to_next(lv)
		if v <= prev:
			mono = false
		prev = v
	print("[TEST] 升级经验单调递增: %s" % str(mono))

	print("[TEST] 挑战 %d 个 · 涂装 %d 个" % [Progress.CHALLENGES.size(), Progress.SKINS.size()])
	var stat_keys: Dictionary = {}
	for c in Progress.CHALLENGES:
		stat_keys[str(c.stat)] = true
	var missing: Array = []
	for k in stat_keys.keys():
		if not Profile.stats.has(k):
			missing.append(k)
	print("[TEST] 挑战引用的统计键全部存在于档案: %s%s" % [
		"是" if missing.is_empty() else "否", "" if missing.is_empty() else " 缺失=" + str(missing)])

	# 模拟 300 局，看档案能不能正常涨到满级
	Profile.xp = 0
	Profile.stats = Profile.DEFAULT_STATS.duplicate(true)
	Profile.done_challenges.clear()
	Profile.maps_played.clear()
	Profile.modes_played.clear()
	var ids := Maps.ids()
	var mids := Modes.ids()
	for i in range(300):
		for k in range(12):
			Profile.record_kill(str(["mg", "shotgun", "railgun", "rocket"][k % 4]))
		Profile.finish_match({
			"mode": str(mids[i % mids.size()]),
			"map": str(ids[i % ids.size()]),
			"kills": 12, "deaths": 5, "won": i % 3 == 0,
			"best_streak": 4, "wave": 8, "zone_seconds": 40.0,
		})
	print("[TEST] 模拟 300 局后：Lv%d %s · %d 经验 · %d 击杀 · 挑战 %d/%d" % [
		Profile.level(), Profile.title(), Profile.xp, int(Profile.stats.kills),
		Profile.done_challenges.size(), Progress.CHALLENGES.size()])
	# 清掉模拟数据，别污染真实存档
	Profile.xp = 0
	Profile.stats = Profile.DEFAULT_STATS.duplicate(true)
	Profile.done_challenges.clear()
	Profile.maps_played.clear()
	Profile.modes_played.clear()
	Profile.save_profile()
	print("[TEST] ---- 成长曲线检查结束 ----")
	get_tree().quit()

# ---------------------------------------------------------------- 工具

## 按住方向键跑几帧，返回观察到的最大速度。
## 用速度而不是位移：速度是常量，不管 physics_frame 信号在节点处理之前还是之后发出，
## 读到的都是同一个值；位移则会随「计时器落在第几帧」抖动。
func _measure_speed(adm) -> float:
	adm.velocity = Vector2.ZERO
	Input.action_press("move_right")
	var best := 0.0
	for i in range(4):
		await get_tree().physics_frame
		best = maxf(best, adm.velocity.length())
	Input.action_release("move_right")
	return best

## 按住开火键跑若干物理帧，返回观察到的最大开火冷却。
## 注意：只 await 一帧就读值会踩到 physics_frame 的发射时机（可能早于节点处理），
## 因此这里多采几帧取峰值，稳定反映「刚开完火」那一刻的冷却。
func _measure_fire_cd(adm) -> float:
	adm._fire_cd = 0.0
	Input.action_press("fire")
	var best := 0.0
	for i in range(8):
		await get_tree().physics_frame
		best = maxf(best, adm._fire_cd)
	Input.action_release("fire")
	return best

func _wait_physics(n: int) -> void:
	for i in range(n):
		await get_tree().physics_frame

# ---------------------------------------------------------------- 自检
## godot --headless --path . -- --selftest

func _run_selftest() -> void:
	print("[TEST] ---- 开始自检 ----")
	# 自检会真的打完一局、真的结算档案。先存档快照，跑完还原，
	# 免得开发机上的真实进度被测试数据冲掉。
	var snap := {
		"xp": Profile.xp,
		"stats": Profile.stats.duplicate(true),
		"challenges": Profile.done_challenges.duplicate(true),
		"maps": Profile.maps_played.duplicate(true),
		"modes": Profile.modes_played.duplicate(true),
		"weapon": Profile.selected_weapon,
		"skin": Profile.selected_skin,
	}
	_test_data_layer()
	await _test_spawn_clearance()
	await _test_deathmatch()
	await _test_admin()
	await _test_zone()
	await _test_survival()
	await _test_result()
	Profile.xp = int(snap.xp)
	Profile.stats = snap.stats
	Profile.done_challenges = snap.challenges
	Profile.maps_played = snap.maps
	Profile.modes_played = snap.modes
	Profile.selected_weapon = str(snap.weapon)
	Profile.selected_skin = str(snap.skin)
	Profile.save_profile()
	print("[TEST] 已还原自检前的档案快照（Lv%d · %d 经验）" % [Profile.level(), Profile.xp])
	print("[TEST] ---- 自检结束 ----")
	await get_tree().create_timer(0.3).timeout
	get_tree().quit()

func _test_data_layer() -> void:
	print("[TEST] ---- 数据层 ----")
	print("[TEST] 武器 %d 把 · 地图 %d 张 · 模式 %d 种" % [
		Weapons.LIST.size(), Maps.LIST.size(), Modes.LIST.size()])
	var ok := true
	var cd_seen: Dictionary = {}
	var dmg_seen: Dictionary = {}
	for w in Weapons.LIST:
		print("[TEST]   武器 %-8s 冷却 %.2fs 伤害 %d 弹丸 %d 射程 %.0f 解锁 %d 级" % [
			str(w.short), float(w.fire_cd), int(w.damage), int(w.pellets),
			float(w.speed) * float(w.life), int(w.unlock_level)])
		cd_seen[str(w.fire_cd)] = true
		dmg_seen[str(w.damage) + "x" + str(w.pellets)] = true
		if float(w.fire_cd) <= 0.0 or int(w.damage) <= 0 or int(w.pellets) <= 0:
			ok = false
	print("[TEST]   武器差异：冷却 %d 种 / 伤害组合 %d 种 → %s" % [
		cd_seen.size(), dmg_seen.size(), "有区分度" if cd_seen.size() >= 3 else "差异不足"])
	for m in Maps.LIST:
		var sp: Array = m.spawns
		print("[TEST]   地图 %-8s 障碍 %2d 个 出生点 %d 个 控制区半径 %.0f" % [
			str(m.name), (m.blocks as Array).size(), sp.size(), float(m.capture_r)])
		if sp.size() < 8 or (m.blocks as Array).size() < 8:
			ok = false
	for m in Modes.LIST:
		print("[TEST]   模式 %-8s 规则=%-5s 时限 %.0fs 分数上限 %d 敌方AI=%s" % [
			str(m.name), str(m.rules), float(m.time_limit), int(m.score_limit),
			str(Modes.spawns_ai_opponents(str(m.id)))])
		if not m.has("rules") or not m.has("xp"):
			ok = false
	print("[TEST] 数据层完整性: %s" % ("通过" if ok else "失败"))

func _open_game(mode: String, map: String, ai: int) -> void:
	# 必须先释放旧对局：start_solo 会 emit players_changed，
	# 如果旧节点还活着，它会用旧地图的出生点去生成新名单里的玩家。
	if is_instance_valid(_game):
		_game.free()
		_game = null
	NetworkManager.my_name = "主机"
	NetworkManager.start_solo(ai, mode, map)
	_start_game()
	await get_tree().process_frame
	await get_tree().process_frame

func _test_deathmatch() -> void:
	print("[TEST] ---- 对局链路（死斗 / 训练场）----")
	await _open_game("deathmatch", "yard", 2)
	var target = _game._player_nodes.get(2)
	print("[TEST] 靶子节点存在: %s" % str(target != null))
	if target == null:
		return
	var before := int(NetworkManager.players[1]["score"])
	print("[TEST] 靶子初始血量: %d" % target.health)
	target.take_damage(1, 1)
	target.take_damage(1, 1)
	print("[TEST] 命中2次后血量: %d alive=%s" % [target.health, str(target.alive)])
	target.take_damage(1, 1)
	print("[TEST] 命中3次后血量: %d alive=%s" % [target.health, str(target.alive)])
	print("[TEST] 击杀后分数 %d → %d（期望 +%d）" % [
		before, int(NetworkManager.players[1]["score"]),
		int(Modes.get_mode("deathmatch").kill_score)])

	# 炮弹命中判定：真人开火 → 飞行 → 扣血
	var p1 = _game._player_nodes.get(1)
	var p2 = _game._player_nodes.get(2)
	if p1 != null and p2 != null:
		p1.position = Vector2(250, 150)
		p1._t_pos = p1.position
		p2.position = Vector2(500, 150)
		p2._t_pos = p2.position
		p2.health = 3
		p2.alive = true
		p2.visible = true
		# 关掉 AI：否则它会在这 0.8 秒里自己走开，测不到命中
		p2.is_ai = false
		p2._t_pos = p2.position
		p1.weapon_id = "mg"
		p1._turret_rot = 0.0
		p1._fire_cd = 0.0
		p1._fire()
		await get_tree().physics_frame
		print("[TEST] 开火后炮弹节点数: %d" % _game.get_node("Bullets").get_child_count())
		await get_tree().create_timer(0.8).timeout
		print("[TEST] 命中判定后靶子血量: %d（期望 2）" % p2.health)

	# 四把枪的弹丸数差异。
	# 每次开火前必须先清空 Bullets：命中火花和爆炸特效也挂在同一个容器下面，
	# 不清空的话上一发打墙留下的 5 个火花会被算进这一发的账里
	# （踩过：火箭明明只射 1 发，却数出 6 发）。
	var all_ok := true
	for wid in ["mg", "shotgun", "railgun", "rocket"]:
		for c in _game.get_node("Bullets").get_children():
			c.free()
		p1.weapon_id = wid
		p1._fire_cd = 0.0
		p1._fire()
		await get_tree().physics_frame
		var want := int(Weapons.get_weapon(wid).pellets)
		var got: int = _game.get_node("Bullets").get_child_count()
		var ok := got == want
		all_ok = all_ok and ok
		print("[TEST]   %s 一次开火产生 %d 发弹丸（期望 %d）%s" % [
			wid, got, want, "通过" if ok else "失败"])
	print("[TEST] 武器差异: %s" % ("通过" if all_ok else "失败"))

func _test_admin() -> void:
	print("[TEST] ---- 管理员模式 ----")
	var adm = _game._player_nodes.get(1)
	if adm == null:
		return
	adm.health = 3
	adm.alive = true
	adm.weapon_id = "mg"
	_game.toggle_admin()
	print("[TEST] admin 标志: %s" % str(adm.admin))
	adm.take_damage(1, 2)
	print("[TEST] 无敌挨一发血量: %d（期望 3）" % adm.health)

	# 加速：按住方向键读速度。速度是常量，不受帧对齐影响，比量位移稳。
	# （量位移会踩「await create_timer 落在第几帧」的抖动，实测能飘到 2.07 倍）
	var v_admin: float = await _measure_speed(adm)
	_game.toggle_admin()
	var v_normal: float = await _measure_speed(adm)
	print("[TEST] 移动速度：普通 %.1f px/s / 管理员 %.1f px/s（倍率 %.2f，期望 %.2f）"
		% [v_normal, v_admin, v_admin / maxf(v_normal, 1.0), PlayerScript.ADMIN_SPEED_MUL])

	# 射速：按住开火，取若干帧内观察到的最大冷却值（即刚开完火那一刻的冷却）
	var base_cd := float(Weapons.get_weapon("mg").fire_cd)
	_game.toggle_admin()
	var cd_admin: float = await _measure_fire_cd(adm)
	_game.toggle_admin()
	var cd_normal: float = await _measure_fire_cd(adm)
	print("[TEST] 开火冷却：普通 %.3f 秒 / 管理员 %.3f 秒（期望 %.3f）"
		% [cd_normal, cd_admin, base_cd * PlayerScript.ADMIN_FIRE_MUL])

	print("[TEST] 收尾 admin 标志: %s（期望 false）" % str(adm.admin))
	adm.health = 3
	adm.take_damage(1, 2)
	print("[TEST] 关闭后挨一发血量: %d（期望 1）" % adm.health)

func _test_zone() -> void:
	print("[TEST] ---- 占点模式 ----")
	await _open_game("king", "crossroads", 1)
	var me = _game._player_nodes.get(1)
	if me == null:
		return
	# 占点测试只关心「站在圈里会不会涨分」，先把 AI 打死的可能性排除掉
	me.set_admin(true)
	print("[TEST] 控制区半径 %.0f · 每秒 +%.1f 分" % [
		_game.arena.capture_r(), float(Modes.get_mode("king").capture_rate)])
	var before := int(NetworkManager.players[1]["score"])
	# 先把玩家放到圈外，确认不得分
	me.position = Vector2(120, 120)
	me._t_pos = me.position
	await get_tree().create_timer(1.0).timeout
	var outside := int(NetworkManager.players[1]["score"])
	# 再放进圈里
	me.position = _game.arena.capture_pos()
	me._t_pos = me.position
	await get_tree().create_timer(2.0).timeout
	var inside := int(NetworkManager.players[1]["score"])
	print("[TEST] 圈外 1 秒得分 %d · 圈内 2 秒得分 %d（起始 %d）" % [
		outside - before, inside - outside, before])
	print("[TEST] 占点计分: %s" % ("通过" if inside - outside >= 3 else "失败（圈内没涨分）"))

func _test_survival() -> void:
	print("[TEST] ---- 生存模式 ----")
	await _open_game("survival", "atoll", 3)
	var ai_at_start: int = NetworkManager.wave_ai_alive()
	print("[TEST] 开局波次敌人数量: %d（期望 0，敌人按波次刷）" % ai_at_start)
	print("[TEST] 共享生命: %d（期望 %d）" % [_game.lives, int(Modes.get_mode("survival").lives)])
	_game.wave_gap_left = 0.05
	await get_tree().create_timer(0.6).timeout
	var alive: int = NetworkManager.wave_ai_alive()
	print("[TEST] 第一波敌人数量: %d（期望 %d）" % [alive, Modes.wave_size("survival", 1)])
	var waves: Array = []
	for w in range(1, 11):
		waves.append(Modes.wave_size("survival", w))
	print("[TEST] 前 10 波规模: %s" % str(waves))
	var has_weapons: Dictionary = {}
	for id in NetworkManager.players.keys():
		if bool(NetworkManager.players[id].get("wave", false)):
			has_weapons[str(NetworkManager.players[id].get("weapon", "?"))] = true
	print("[TEST] 第一波敌人使用的武器: %s" % str(has_weapons.keys()))
	print("[TEST] 生存模式: %s" % ("通过" if alive >= 2 else "失败（没刷出敌人）"))


func _test_result() -> void:
	print("[TEST] ---- 结算链路（死斗 / 训练场）----")
	await _open_game("deathmatch", "yard", 1)
	var xp0: int = Profile.xp
	var m0: int = int(Profile.stats.matches)
	# 直接把分数顶到上限，逼权威端判胜（不靠慢慢打）
	NetworkManager.players[1]["score"] = int(Modes.get_mode("deathmatch").score_limit)
	await get_tree().create_timer(0.5).timeout
	print("[TEST] 对局结束标志: %s（期望 true）· 胜者 id=%d（期望 1）" % [
		str(_game.match_over), _game.winner_id])
	print("[TEST] 结算面板可见: %s" % str(_game.hud._result_panel.visible))
	print("[TEST] 结算文本:\n%s" % _game._result_text())
	print("[TEST] 档案：局数 %d → %d · 经验 %d → %d" % [
		m0, int(Profile.stats.matches), xp0, Profile.xp])
	var ok: bool = _game.match_over and _game.winner_id == 1 \
		and int(Profile.stats.matches) == m0 + 1 and Profile.xp > xp0
	print("[TEST] 结算链路: %s" % ("通过" if ok else "失败"))


## 出生点遮挡检查：把 HUD 面板的真实矩形和地图障碍拿来对，逐个出生点验。
## 这个问题肉眼很难发现（要一张图一张图看），但一旦发生就是「一出生就看不见自己的车」。
func _spawn_issue(p: Vector2, rects: Array, blocks: Array) -> String:
	var box := Rect2(p - Vector2(PlayerScript.RADIUS, PlayerScript.RADIUS),
		Vector2(PlayerScript.RADIUS * 2.0, PlayerScript.RADIUS * 2.0))
	for r in rects:
		var rr: Rect2 = r
		if rr.intersects(box):
			return "被 HUD 遮挡"
	for b in blocks:
		var bb: Rect2 = b
		if bb.intersects(box):
			return "卡在障碍里"
	return ""

func _test_spawn_clearance() -> void:
	print("[TEST] ---- 出生点遮挡检查 ----")
	await _open_game("deathmatch", "yard", 0)
	var rects: Array = _game.hud.occluded_rects()
	var names: Array = []
	for r in rects:
		var rr: Rect2 = r
		names.append("(%.0f,%.0f %.0fx%.0f)" % [rr.position.x, rr.position.y, rr.size.x, rr.size.y])
	print("[TEST] HUD 遮挡区域 %d 块: %s" % [rects.size(), " ".join(names)])

	var bad := 0
	for m in Maps.LIST:
		var problems: Array = []
		var sp: Array = m.spawns
		for i in range(sp.size()):
			var p: Vector2 = sp[i]
			var issue := _spawn_issue(p, rects, m.blocks)
			if issue != "":
				problems.append("#%d%s%s" % [i + 1, issue, str(p)])
		var ai_sp: Array = m.get("ai_spawns", m.spawns)
		for i in range(ai_sp.size()):
			var p2: Vector2 = ai_sp[i]
			var issue2 := _spawn_issue(p2, rects, m.blocks)
			if issue2 != "":
				problems.append("AI#%d%s%s" % [i + 1, issue2, str(p2)])
		print("[TEST]   %-8s %s" % [str(m.name), "全部可用" if problems.is_empty() else " / ".join(problems)])
		bad += problems.size()
	print("[TEST] 出生点检查: %s（%d 个问题）" % ["通过" if bad == 0 else "有冲突", bad])
