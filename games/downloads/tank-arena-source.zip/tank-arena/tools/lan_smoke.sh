#!/bin/bash
# 局域网联机冒烟测试：起一个无头主机 + 一个无头客户端，跑十几秒，然后核对日志。
#
# 为什么要有这个脚本（而不是直接在命令行敲两行）：
#   1. 残留进程会占住 7000 端口，下一轮的「主机」就 create_server 失败（错误码 20），
#      而客户端会悄悄连到上一轮的僵尸主机上 —— 日志看起来「成功」，其实测的是空气。
#      所以开跑前必须先清场。
#   2. 主机的 --autoquit 必须比客户端长，否则主机先退，客户端收不到对局状态。
#   3. 用 --quit-after 不行：它按帧计数，而无头主循环不锁帧，几毫秒就跑完几百帧。
#
# 用法：bash tools/lan_smoke.sh [模式] [地图] [主机秒数] [客户端秒数]
set -u

GODOT="${GODOT:-/Applications/Godot.app/Contents/MacOS/Godot}"
MODE="${1:-king}"
MAP="${2:-hive}"
HOST_SECS="${3:-18}"
CLIENT_SECS="${4:-11}"

cd "$(dirname "$0")/.." || exit 1

echo "=== 清场：杀掉残留的无头 Godot ==="
pkill -f "Godot --headless" 2>/dev/null
sleep 2
if pgrep -f "Godot --headless" >/dev/null 2>&1; then
	echo "!! 仍有残留进程，端口可能被占用，结果不可信"
	pgrep -fl "Godot --headless"
else
	echo "端口干净"
fi

rm -f /tmp/lan_host.log /tmp/lan_client.log

echo "=== 起主机：模式=$MODE 地图=$MAP ==="
"$GODOT" --headless --path . -- --host --mode="$MODE" --map="$MAP" \
	--autoquit="$HOST_SECS" > /tmp/lan_host.log 2>&1 &
HOST_PID=$!
sleep 4

echo "=== 起客户端（故意不带 --mode/--map，验证它听房主的）==="
"$GODOT" --headless --path . -- --join=127.0.0.1 \
	--autoquit="$CLIENT_SECS" > /tmp/lan_client.log 2>&1
wait "$HOST_PID" 2>/dev/null

echo
echo "=== 核对 ==="
fail=0

check() { # 文件 描述 模式
	if grep -qE "$3" "$1"; then
		echo "  [OK]   $2"
	else
		echo "  [FAIL] $2"
		fail=1
	fi
}

check /tmp/lan_host.log   "主机建房成功（端口未被占用）"      "房间已创建 · 端口 7000"
check /tmp/lan_host.log   "主机收到客户端并登记昵称/武器"     "昵称：.*武器："
check /tmp/lan_client.log "客户端连上主机"                   "已连接到主机"
check /tmp/lan_client.log "客户端收到房主的模式/地图"        "收到对局设置：模式=$MODE 地图=$MAP"
check /tmp/lan_client.log "客户端按房主设置开局（非默认地图）" "对局开始 · 模式=.* 地图=.*"
check /tmp/lan_client.log "两端都按时自动退出"               "autoquit 到时，退出"

# 「客户端不该自己开默认局」需要反向断言
if grep -q "对局开始 · 模式=死斗 地图=训练场" /tmp/lan_client.log; then
	echo "  [FAIL] 客户端仍然先开了默认的死斗/训练场局"
	fail=1
else
	echo "  [OK]   客户端没有先开默认的死斗/训练场局"
fi

# 就绪门控生效：不应再出现 Main/Game 找不到的 RPC 报错
if grep -q "Node not found" /tmp/lan_client.log; then
	echo "  [FAIL] 客户端仍有 Main/Game 的 RPC 报错"
	grep -m3 "Node not found" /tmp/lan_client.log
	fail=1
else
	echo "  [OK]   无 Main/Game RPC 报错（就绪门控生效）"
fi

echo
if [ "$fail" -eq 0 ]; then
	echo "局域网冒烟测试：全部通过"
else
	echo "局域网冒烟测试：有失败项，日志见 /tmp/lan_host.log /tmp/lan_client.log"
fi
exit "$fail"
