extends Node
## 程序化音效：不依赖任何音频素材，开火/命中/爆炸的波形全部运行时合成。
## 距离本地坦克越远，音量越低（世界音）；UI 音与管理员音不衰减，满音量。
##
## 四把枪各有各的音色，这是「换枪手感不同」里最便宜也最有效的一环：
##   机枪   短促方波下扫，密集但不吵
##   霰弹   一记宽噪声，有「砰」的钝感
##   狙击   正弦上扫，像电容放电
##   火箭   低频噪声 + 下扫，笨重

const POOL_SIZE := 24
const RATE := 22050

var muted: bool = false

var _fire: Dictionary = {}          # weapon_id -> AudioStreamWAV
var _hit: AudioStreamWAV
var _death: AudioStreamWAV
var _shield: AudioStreamWAV
var _blast: AudioStreamWAV
var _switch: AudioStreamWAV
var _wave: AudioStreamWAV
var _admin_on: AudioStreamWAV
var _admin_off: AudioStreamWAV
var _players: Array[AudioStreamPlayer] = []
var _idx: int = 0

func _ready() -> void:
	# --- 四把枪的开火音 ---
	_fire["mg"] = _make_tone(900.0, 240.0, 0.075, 0.26, 1)
	_fire["shotgun"] = _make_noise(0.19, 0.34, 2100.0)
	_fire["railgun"] = _make_tone(380.0, 1850.0, 0.22, 0.22, 0)
	_fire["rocket"] = _make_noise(0.28, 0.30, 620.0)
	# 未知武器兜底
	_fire["_default"] = _fire["mg"]

	# 命中：一记短噪声
	_hit = _make_noise(0.10, 0.30, 2800.0)
	# 死亡：低沉长噪声
	_death = _make_noise(0.42, 0.40, 700.0)
	# 护盾挡弹：清脆的金属「叮」
	_shield = _make_tone(1750.0, 900.0, 0.11, 0.32, 0)
	# 火箭爆炸：比死亡更闷更长的低频
	_blast = _make_noise(0.52, 0.46, 420.0)
	# 换枪：一声轻脆的机械卡榫
	_switch = _make_tone(1400.0, 620.0, 0.055, 0.20, 2)
	# 波次警报：两声上行
	_wave = _make_tone(320.0, 900.0, 0.34, 0.24, 0)
	# 管理员开关：上行方波 = 启动，下行 = 关闭
	_admin_on = _make_tone(300.0, 1250.0, 0.24, 0.26, 1)
	_admin_off = _make_tone(900.0, 260.0, 0.20, 0.24, 1)

	for i in range(POOL_SIZE):
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)

func toggle_mute() -> bool:
	muted = not muted
	if muted:
		for p in _players:
			p.stop()
	return muted

# ---------------------------------------------------------------- 世界音（按距离衰减）

## weapon 决定音色；不传就是机枪
func play_fire(pos: Vector2, weapon: String = "mg") -> void:
	_play(_fire.get(weapon, _fire["_default"]), pos)

func play_hit(pos: Vector2) -> void:
	_play(_hit, pos)

func play_death(pos: Vector2) -> void:
	_play(_death, pos)

func play_shield(pos: Vector2) -> void:
	_play(_shield, pos)

## 火箭爆炸
func play_blast(pos: Vector2) -> void:
	_play(_blast, pos)

## 换枪
func play_switch(pos: Vector2) -> void:
	_play(_switch, pos)

# ---------------------------------------------------------------- 全局音（不衰减）

## 波次开始。不是从某个坐标发出的，是全场的警报，所以不衰减。
func play_wave() -> void:
	_play_flat(_wave, -5.0)

## 管理员模式开关音
func play_admin(on: bool) -> void:
	_play_flat(_admin_on if on else _admin_off, -4.0)

# ---------------------------------------------------------------- 内部

func _play(stream: AudioStreamWAV, pos: Vector2) -> void:
	if muted or stream == null:
		return
	var vol_db := 0.0
	var lp := _listener_pos()
	if lp != Vector2.INF:
		var d := lp.distance_to(pos)
		var att := clampf(1.0 - d / 1100.0, 0.0, 1.0)
		if att <= 0.03:
			return
		vol_db = linear_to_db(att * 0.9)
	_play_flat(stream, vol_db)

func _play_flat(stream: AudioStreamWAV, vol_db: float) -> void:
	if muted or stream == null:
		return
	var p := _players[_idx]
	_idx = (_idx + 1) % POOL_SIZE
	p.stream = stream
	p.volume_db = vol_db
	p.play()

func _listener_pos() -> Vector2:
	var g := get_tree().get_first_node_in_group("game")
	if g == null:
		return Vector2.INF
	var me = g._player_nodes.get(NetworkManager.local_id())
	if me == null:
		return Vector2.INF
	return me.global_position

# ---------------------------------------------------------------- 波形合成

func _make_tone(f0: float, f1: float, dur: float, vol: float, shape: int) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase := 0.0
	for i in range(n):
		var t := float(i) / float(n)
		phase += lerpf(f0, f1, t) / float(RATE)
		var s := 0.0
		if shape == 0:
			s = sin(phase * TAU)
		elif shape == 1:
			s = 1.0 if fmod(phase, 1.0) < 0.5 else -1.0
		else:
			s = fmod(phase, 1.0) * 2.0 - 1.0
		var env := pow(1.0 - t, 1.6)
		data.encode_s16(i * 2, int(clampf(s * env * vol, -1.0, 1.0) * 32767.0))
	return _wrap(data)

func _make_noise(dur: float, vol: float, cutoff_hz: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var lp := 0.0
	var alpha := clampf(cutoff_hz / float(RATE), 0.01, 1.0)
	for i in range(n):
		var t := float(i) / float(n)
		lp += alpha * ((randf() * 2.0 - 1.0) - lp)
		var env := pow(1.0 - t, 2.0)
		data.encode_s16(i * 2, int(clampf(lp * env * vol * 2.2, -1.0, 1.0) * 32767.0))
	return _wrap(data)

func _wrap(data: PackedByteArray) -> AudioStreamWAV:
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = data
	return s
