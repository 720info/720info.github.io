extends Node
## 玩家档案（Autoload）：等级 / 经验 / 统计 / 挑战 / 涂装解锁，持久化到 user://profile.cfg
##
## 这是「内容曲线」的骨架。所有统计都走 record_* 系列接口，
## 每局结束调一次 finish_match()，由它统一结算经验、更新计数、检查挑战。

signal changed()
signal leveled_up(new_level: int)
signal challenge_done(data: Dictionary)

const Progress := preload("res://game/progress.gd")
const Weapons := preload("res://game/weapons.gd")
const SAVE_PATH := "user://profile.cfg"

var player_name: String = "玩家"
var xp: int = 0
var tutorial_done: bool = false
var selected_weapon: String = "mg"
var selected_skin: String = "standard"

## 计数器。挑战表用 stat 键索引这里。
var stats: Dictionary = {}
var done_challenges: Dictionary = {}     # challenge_id -> true
var maps_played: Dictionary = {}         # map_id -> true（算「去过几张图」）
var modes_played: Dictionary = {}        # mode_id -> true

const DEFAULT_STATS := {
	"matches": 0, "wins": 0, "kills": 0, "deaths": 0,
	"best_match_kills": 0, "best_streak": 0,
	"kills_mg": 0, "kills_shotgun": 0, "kills_railgun": 0, "kills_rocket": 0,
	"zone_seconds": 0, "best_wave": 0,
	"maps_played": 0, "modes_played": 0, "level": 1, "tutorial_done": 0,
}

func _ready() -> void:
	load_profile()

# ---------------------------------------------------------------- 读写

func load_profile() -> void:
	stats = DEFAULT_STATS.duplicate(true)
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		_sync_derived()
		return
	player_name = str(cfg.get_value("player", "name", "玩家"))
	xp = int(cfg.get_value("player", "xp", 0))
	tutorial_done = bool(cfg.get_value("player", "tutorial_done", false))
	selected_weapon = str(cfg.get_value("player", "weapon", "mg"))
	selected_skin = str(cfg.get_value("player", "skin", "standard"))
	var s = cfg.get_value("player", "stats", {})
	if s is Dictionary:
		for k in s.keys():
			stats[k] = int(s[k])
	done_challenges = _to_dict(cfg.get_value("player", "challenges", []))
	maps_played = _to_dict(cfg.get_value("player", "maps", []))
	modes_played = _to_dict(cfg.get_value("player", "modes", []))
	_sync_derived()
	print("[PROFILE] 已载入：Lv%d %s · %d 经验 · %d 击杀 · %d 个挑战" % [
		level(), title(), xp, int(stats.kills), done_challenges.size()])

func save_profile() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("player", "name", player_name)
	cfg.set_value("player", "xp", xp)
	cfg.set_value("player", "tutorial_done", tutorial_done)
	cfg.set_value("player", "weapon", selected_weapon)
	cfg.set_value("player", "skin", selected_skin)
	cfg.set_value("player", "stats", stats)
	cfg.set_value("player", "challenges", done_challenges.keys())
	cfg.set_value("player", "maps", maps_played.keys())
	cfg.set_value("player", "modes", modes_played.keys())
	cfg.save(SAVE_PATH)

## 把「去过哪些图/模式」的字典大小同步进 stats，供挑战判定使用
func _sync_derived() -> void:
	stats["maps_played"] = maps_played.size()
	stats["modes_played"] = modes_played.size()
	stats["tutorial_done"] = 1 if tutorial_done else 0
	stats["level"] = level()

func _to_dict(arr) -> Dictionary:
	var d: Dictionary = {}
	if arr is Array:
		for v in arr:
			d[str(v)] = true
	return d

# ---------------------------------------------------------------- 等级

func level() -> int:
	return Progress.level_for_xp(xp)

func title() -> String:
	return Progress.title_for_level(level())

func xp_into() -> int:
	return Progress.xp_into_level(xp)

func xp_need() -> int:
	return Progress.xp_to_next(level())

## 等级进度 0~1
func level_ratio() -> float:
	var need := xp_need()
	if need <= 0:
		return 1.0
	return clampf(float(xp_into()) / float(need), 0.0, 1.0)

func add_xp(amount: int) -> void:
	if amount <= 0:
		return
	var before := level()
	xp += amount
	_sync_derived()
	var after := level()
	if after > before:
		leveled_up.emit(after)
		print("[PROFILE] 升级！Lv%d %s" % [after, title()])
	changed.emit()

# ---------------------------------------------------------------- 解锁

## 教学关临时解锁全部武器。只影响本次运行，不写存档 ——
## 否则 1 级新人根本走不到「切换武器」那一步。
var unlock_all_temp: bool = false

func is_weapon_unlocked(id: String) -> bool:
	if unlock_all_temp:
		return true
	return int(Weapons.get_weapon(id).get("unlock_level", 1)) <= level()

func unlocked_weapons() -> Array:
	if unlock_all_temp:
		return Weapons.ids()
	return Weapons.unlocked_for(level())

func is_skin_unlocked(id: String) -> bool:
	var s := Progress.get_skin(id)
	if str(s.get("unlock", "level")) == "level":
		return level() >= int(s.get("need", 1))
	return done_challenges.has(str(s.get("need", "")))

func unlocked_skins() -> Array:
	var out: Array = []
	for s in Progress.SKINS:
		if is_skin_unlocked(s.id):
			out.append(s.id)
	return out

func challenges_done_count() -> int:
	return done_challenges.size()

func challenges_total() -> int:
	return Progress.CHALLENGES.size()

# ---------------------------------------------------------------- 统计写入

func record_kill(weapon_id: String) -> void:
	stats["kills"] = int(stats.kills) + 1
	var key := "kills_" + weapon_id
	stats[key] = int(stats.get(key, 0)) + 1

func record_death() -> void:
	stats["deaths"] = int(stats.deaths) + 1

func record_zone(seconds: float) -> void:
	stats["zone_seconds"] = int(stats.zone_seconds) + int(round(seconds))

## 单局结算。result 字段：
##   mode, map, kills, deaths, won, best_streak, wave, zone_seconds
func finish_match(result: Dictionary) -> Array:
	stats["matches"] = int(stats.matches) + 1
	if bool(result.get("won", false)):
		stats["wins"] = int(stats.wins) + 1
	stats["best_match_kills"] = maxi(int(stats.best_match_kills), int(result.get("kills", 0)))
	stats["best_streak"] = maxi(int(stats.best_streak), int(result.get("best_streak", 0)))
	stats["best_wave"] = maxi(int(stats.best_wave), int(result.get("wave", 0)))

	var mid := str(result.get("map", ""))
	if mid != "":
		maps_played[mid] = true
	var mode := str(result.get("mode", ""))
	if mode != "":
		modes_played[mode] = true
	_sync_derived()

	# 结算经验
	var m := preload("res://game/modes.gd").get_mode(mode)
	var xp_cfg: Dictionary = m.get("xp", {})
	var gained := 0
	gained += int(xp_cfg.get("kill", 10)) * int(result.get("kills", 0))
	if bool(result.get("won", false)):
		gained += int(xp_cfg.get("win", 0))
	else:
		gained += int(xp_cfg.get("lose", 0))
	gained += int(xp_cfg.get("wave", 0)) * int(result.get("wave", 0))
	gained += int(xp_cfg.get("capture", 0)) * int(round(float(result.get("zone_seconds", 0.0)) * 2.0))
	add_xp(gained)

	var new_ones := _check_challenges()
	save_profile()
	print("[PROFILE] 本局结算：+%d 经验 · 总计 %d（Lv%d）%s" % [
		gained, xp, level(), "" if new_ones.is_empty() else " · 新完成挑战 %d 个" % new_ones.size()])
	return new_ones

func mark_tutorial_done() -> void:
	tutorial_done = true
	_sync_derived()
	add_xp(60)
	_check_challenges()
	save_profile()

# ---------------------------------------------------------------- 挑战判定

## 反复检查直到没有新完成（挑战奖励的经验可能触发升级、进而完成「满级」挑战）
func _check_challenges() -> Array:
	var newly: Array = []
	var guard := 0
	while guard < 8:
		guard += 1
		var progressed := false
		for c in Progress.CHALLENGES:
			var cid := str(c.id)
			if done_challenges.has(cid):
				continue
			var stat_key := str(c.stat)
			var have := int(stats.get(stat_key, 0))
			if have >= int(c.target):
				done_challenges[cid] = true
				newly.append(c)
				progressed = true
				var reward := int(c.get("xp", 0))
				if reward > 0:
					add_xp(reward)
				print("[CHALLENGE] 完成「%s」+%d 经验" % [c.name, reward])
				challenge_done.emit(c)
		_sync_derived()
		if not progressed:
			break
	return newly

# ---------------------------------------------------------------- 菜单用

## 注意：不能叫 set_name —— 会与 Node.set_name(StringName) 签名冲突
func set_player_name(n: String) -> void:
	var t := n.strip_edges()
	if t == "":
		return
	player_name = t
	save_profile()

func set_weapon(id: String) -> void:
	if not is_weapon_unlocked(id):
		return
	selected_weapon = id
	save_profile()

func set_skin(id: String) -> void:
	if not is_skin_unlocked(id):
		return
	selected_skin = id
	save_profile()
