extends Node
## 局域网联机管理器（Autoload 单例）
## 职责：创建/加入房间、维护玩家名单（昵称+分数+武器）、同步对局设置（模式/地图）。

signal players_changed()
signal settings_changed()
signal join_ok()
signal join_failed()
signal host_left()

const DEFAULT_PORT := 7000
const MAX_CLIENTS := 8

var my_name: String = "Player"
var players: Dictionary = {}      # peer_id(int) -> {"name","score","weapon","ai"?,"wave"?}
var is_host: bool = false
var game_active: bool = false

## 对局设置：由房主决定，加入房间时同步过来
var mode_id: String = "deathmatch"
var map_id: String = "yard"
## 单机模式用：玩家自己选的武器（联机时每人各自选，存在 players[pid].weapon）
var my_weapon: String = "mg"

## 最近一次联机错误，供菜单在返回后展示
var last_error: String = ""

## 已经建好 Game 节点、可以接收对局 RPC 的端（peer_id -> true）。
## 客户端是「收到房主设置之后」才创建 Game 节点的，在那之前主机的
## match_state（5Hz）/ server_state（30Hz）广播会命中还不存在的 Main/Game，
## 客户端会刷一屏 "Node not found: Main/Game"。功能上无害（客户端随后就建好了），
## 但日志完全没法看，所以这里维护一张就绪表，广播只发给表里的端。
var ready_peers: Dictionary = {}

func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)

func is_networked() -> bool:
	return multiplayer.multiplayer_peer != null

## 是否由本端做权威判定。单机模式恒为 true。
## 注意：无 peer 时直接调 multiplayer.is_server() 会报错，必须走这里。
func is_authority() -> bool:
	if multiplayer.multiplayer_peer == null:
		return true
	return multiplayer.is_server()

func local_id() -> int:
	if multiplayer.multiplayer_peer == null:
		return 1          # 单机模式：本地玩家固定为 1 号
	return multiplayer.get_unique_id()

## 单机模式：不开任何网络，本地 1 号 + N 个电脑对手（生存模式则 N=0，敌人按波次刷）
func start_solo(ai_count: int, mode: String = "deathmatch", map: String = "yard") -> void:
	leave()
	is_host = false
	game_active = true
	mode_id = mode
	map_id = map
	players.clear()
	players[1] = {"name": my_name, "score": 0, "weapon": my_weapon}
	var n := 0 if preload("res://game/modes.gd").is_wave_mode(mode) else maxi(ai_count, 1)
	for i in range(n):
		var pid := i + 2
		players[pid] = {
			"name": "电脑%d" % (i + 1), "score": 0, "ai": true,
			"weapon": ["mg", "shotgun", "railgun", "rocket"][i % 4],
		}
	settings_changed.emit()
	players_changed.emit()

# ---------------------------------------------------------------- 房间操作

func host_game(port: int = DEFAULT_PORT, mode: String = "deathmatch", map: String = "yard") -> int:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, MAX_CLIENTS)
	if err != OK:
		printerr("[NET] 创建房间失败，错误码 %d" % err)
		return err
	multiplayer.multiplayer_peer = peer
	is_host = true
	game_active = true
	mode_id = mode
	map_id = map
	players.clear()
	players[1] = {"name": my_name, "score": 0, "weapon": my_weapon}
	print("[NET] 房间已创建 · 端口 %d · 本机 ID=1 · 模式=%s 地图=%s" % [port, mode, map])
	settings_changed.emit()
	players_changed.emit()
	return OK

func join_game(ip: String, port: int = DEFAULT_PORT) -> int:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, port)
	if err != OK:
		printerr("[NET] 无法发起连接，错误码 %d" % err)
		return err
	multiplayer.multiplayer_peer = peer
	is_host = false
	game_active = true
	print("[NET] 正在连接 %s:%d ..." % [ip, port])
	return OK

func leave() -> void:
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	players.clear()
	ready_peers.clear()
	is_host = false
	game_active = false

# ---------------------------------------------------------------- 就绪握手

## 各端在 Game 节点建好之后调用一次，之后才会收到对局状态广播
func mark_ready() -> void:
	if not is_networked():
		ready_peers[1] = true
		return
	if multiplayer.is_server():
		ready_peers[1] = true
		return
	report_ready.rpc_id(1)

@rpc("any_peer", "reliable")
func report_ready() -> void:
	if not multiplayer.is_server():
		return
	ready_peers[multiplayer.get_remote_sender_id()] = true

# ---------------------------------------------------------------- 服务器侧事件

func _on_peer_connected(id: int) -> void:
	if not multiplayer.is_server():
		return
	if not players.has(id):
		players[id] = {"name": "玩家%d" % id, "score": 0, "weapon": "mg"}
	print("[NET] 玩家 %d 已加入房间" % id)
	_broadcast_players()

func _on_peer_disconnected(id: int) -> void:
	if multiplayer.is_server():
		players.erase(id)
		ready_peers.erase(id)
		print("[NET] 玩家 %d 已离开房间" % id)
		_broadcast_players()
	else:
		players.erase(id)
		ready_peers.erase(id)
		players_changed.emit()

# ---------------------------------------------------------------- 客户端侧事件

func _on_connected_to_server() -> void:
	print("[NET] 已连接到主机，本机 ID=%d" % local_id())
	request_join.rpc_id(1, my_name, my_weapon)
	join_ok.emit()

func _on_connection_failed() -> void:
	printerr("[NET] 连接主机失败")
	last_error = "连接失败：请确认对方已点「创建房间」，且 IP 填的是主机在局域网中的地址。"
	leave()
	join_failed.emit()

func _on_server_disconnected() -> void:
	printerr("[NET] 与主机断开连接")
	last_error = "主机已离开房间。"
	leave()
	host_left.emit()

# ---------------------------------------------------------------- RPC

@rpc("any_peer", "reliable")
func request_join(pname: String, weapon: String = "mg") -> void:
	if not multiplayer.is_server():
		return
	var id := multiplayer.get_remote_sender_id()
	if not players.has(id):
		players[id] = {"name": pname, "score": 0, "weapon": weapon}
	else:
		players[id]["name"] = pname
		players[id]["weapon"] = weapon
	print("[NET] 玩家 %d 昵称：%s · 武器：%s" % [id, pname, weapon])
	# 先把对局设置发给新来的，再广播名单
	sync_settings.rpc_id(id, mode_id, map_id)
	_broadcast_players()

@rpc("authority", "call_local", "reliable")
func sync_players(data: Dictionary) -> void:
	players = data.duplicate(true)
	players_changed.emit()

@rpc("authority", "reliable")
func sync_settings(mode: String, map: String) -> void:
	mode_id = mode
	map_id = map
	print("[NET] 收到对局设置：模式=%s 地图=%s" % [mode, map])
	settings_changed.emit()

## 客户端改武器 → 请房主登记并广播
@rpc("any_peer", "reliable")
func report_weapon(weapon: String) -> void:
	if not multiplayer.is_server():
		return
	var id := multiplayer.get_remote_sender_id()
	if players.has(id):
		players[id]["weapon"] = weapon
		_broadcast_players()

func set_my_weapon(weapon: String) -> void:
	my_weapon = weapon
	if not is_networked():
		if players.has(1):
			players[1]["weapon"] = weapon
		players_changed.emit()
		return
	if multiplayer.is_server():
		if players.has(1):
			players[1]["weapon"] = weapon
		_broadcast_players()
	else:
		report_weapon.rpc_id(1, weapon)

func weapon_of(pid: int) -> String:
	if players.has(pid):
		return str(players[pid].get("weapon", "mg"))
	return "mg"

# ---------------------------------------------------------------- 分数

## 任意端调用：给某玩家加分（内部自动决定本地加还是上报主机）
func submit_score(pid: int, amount: int = 1) -> void:
	if amount == 0:
		return
	if not is_networked():
		_add_score_local(pid, amount)
		return
	if multiplayer.is_server():
		_add_score_local(pid, amount)
	else:
		report_score.rpc_id(1, pid, amount)

func submit_kill(killer_id: int) -> void:
	submit_score(killer_id, 1)

@rpc("any_peer", "reliable")
func report_score(pid: int, amount: int) -> void:
	if not multiplayer.is_server():
		return
	# 只信任「上报者给自己加分」，避免客户端随便给别人刷分
	if multiplayer.get_remote_sender_id() != pid:
		return
	_add_score_local(pid, amount)

func _add_score_local(pid: int, amount: int) -> void:
	if not players.has(pid):
		return
	players[pid]["score"] = int(players[pid]["score"]) + amount
	_broadcast_players()

func _broadcast_players() -> void:
	if multiplayer.multiplayer_peer == null:
		players_changed.emit()
		return
	sync_players.rpc(players)

# ---------------------------------------------------------------- 波次敌人（生存模式，仅权威端调用）

const WAVE_ID_BASE := 1000

func wave_ai_id(n: int) -> int:
	return WAVE_ID_BASE + n

func add_wave_ai(id: int, weapon: String, wave: int) -> void:
	if not is_authority():
		return
	players[id] = {"name": "电脑", "score": 0, "ai": true, "wave": true,
		"weapon": weapon, "wave_no": wave}
	_broadcast_players()

func clear_wave_ai() -> void:
	if not is_authority():
		return
	var doomed: Array = []
	for id in players.keys():
		if bool(players[id].get("wave", false)):
			doomed.append(id)
	for id in doomed:
		players.erase(id)
	if not doomed.is_empty():
		_broadcast_players()

func wave_ai_alive() -> int:
	var n := 0
	for id in players.keys():
		if bool(players[id].get("wave", false)):
			n += 1
	return n

## 人类玩家数量（生存模式判定「全灭」用）
func human_count() -> int:
	var n := 0
	for id in players.keys():
		if not bool(players[id].get("ai", false)):
			n += 1
	return n
