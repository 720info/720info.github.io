extends Node2D
## 竞技场：按 maps.gd 里的定义构建地板 / 网格 / 障碍 / 边界，并提供出生点与配色。
##
## 全部图形都是运行时用 Polygon2D / Line2D / GradientTexture2D 画出来的，零美术资源。
## 地图布局硬编码，各端完全一致，所以只有「地图 id」需要网络同步，几何本身零成本。
##
## 想改外观就看 maps.gd 的 theme 字段；想加地图就照抄一份 LIST 条目。

const Maps := preload("res://game/maps.gd")

var map_id: String = "yard"
var map: Dictionary = {}

## 占点模式的控制区节点（show_zone 时才有）
var zone_root: Node2D
var zone_ring: Line2D
var zone_fill: Polygon2D
var _zone_r: float = 80.0
var _zone_pulse: float = 0.0
var _zone_holder: Color = Color(0, 0, 0, 0)

func _ready() -> void:
	map = Maps.get_map(map_id)
	_build()

func _process(delta: float) -> void:
	if zone_root == null or not zone_root.visible:
		return
	# 呼吸：让控制区在静态画面里也显眼，方便玩家一眼找到该去哪
	_zone_pulse += delta
	var a := 0.42 + 0.22 * sin(_zone_pulse * 2.2)
	var col: Color = _zone_holder if _zone_holder.a > 0.0 else map.theme.accent
	zone_ring.modulate = Color(1, 1, 1, clampf(a + 0.35, 0.0, 1.0))
	zone_ring.default_color = col
	zone_fill.color = Color(col.r, col.g, col.b, 0.075 + 0.035 * sin(_zone_pulse * 2.2))

# ---------------------------------------------------------------- 对外查询

func spawn_for(id: int) -> Vector2:
	var sp: Array = map.spawns
	return sp[((id - 1) % sp.size() + sp.size()) % sp.size()]

## 生存模式的 AI 波次出生点。
## 默认复用本图的出生点环并旋转半圈 —— 8 个点构成一个环，转半圈正好是离玩家出生点
## 最远的那半圈；而且这组点已经被出生点遮挡检查覆盖过，不会出现「敌人刷在面板底下」。
## 想给某张图单独指定，就加一个 ai_spawns 字段。
func ai_spawn_for(n: int) -> Vector2:
	var sp: Array = map.get("ai_spawns", map.spawns)
	var size := sp.size()
	if size == 0:
		return Vector2(Maps.W * 0.5, Maps.H * 0.5)
	var i := ((n - NetworkManager.WAVE_ID_BASE + size / 2) % size + size) % size
	return sp[i]

func color_for(id: int) -> Color:
	var n := Maps.PLAYER_COLORS.size()
	return Maps.PLAYER_COLORS[((id - 1) % n + n) % n]

func capture_pos() -> Vector2:
	return map.get("capture", Vector2(640, 360))

func capture_r() -> float:
	return float(map.get("capture_r", 80.0))

## 某点是否在控制区内
func in_capture(p: Vector2) -> bool:
	return p.distance_to(capture_pos()) <= capture_r()

## 控制区当前被谁占着（用于把圈染成持有者的颜色）。传 Color(0,0,0,0) 表示无人。
func set_zone_holder(c: Color) -> void:
	_zone_holder = c

func show_zone(on: bool) -> void:
	if zone_root != null:
		zone_root.visible = on

# ---------------------------------------------------------------- 构建

func _build() -> void:
	_build_floor()
	_build_grid()
	_build_border()
	for r in map.blocks:
		_build_block(r)
	_build_zone()
	_build_corner_marks()

func _build_floor() -> void:
	var th: Dictionary = map.theme
	# 径向渐变地板：中心亮、边缘暗，比纯色平铺耐看很多，而且不用任何贴图素材
	var grad := Gradient.new()
	grad.set_color(0, th.floor_glow)
	grad.set_color(1, th.floor)
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.46)
	tex.fill_to = Vector2(1.06, 0.46)
	tex.width = 256
	tex.height = 144

	var bg := Polygon2D.new()
	bg.polygon = PackedVector2Array([
		Vector2.ZERO, Vector2(Maps.W, 0), Vector2(Maps.W, Maps.H), Vector2(0, Maps.H)
	])
	bg.texture = tex
	bg.uv = PackedVector2Array([
		Vector2.ZERO, Vector2(tex.width, 0),
		Vector2(tex.width, tex.height), Vector2(0, tex.height)
	])
	bg.z_index = -30
	add_child(bg)

func _build_grid() -> void:
	var th: Dictionary = map.theme
	var style := str(th.get("grid_style", "grid"))
	var col: Color = th.grid
	var layer := Node2D.new()
	layer.z_index = -25
	add_child(layer)

	match style:
		"dots":
			# 点阵：每 64px 一个小圆点
			var dot := _circle_pts(2.2, 6)
			for x in range(32, int(Maps.W), 64):
				for y in range(32, int(Maps.H), 64):
					var p := Polygon2D.new()
					p.polygon = dot
					p.position = Vector2(x, y)
					p.color = col
					layer.add_child(p)
		"diag":
			# 斜向平行线
			var i := -int(Maps.H)
			while i < int(Maps.W):
				var l := Line2D.new()
				l.points = PackedVector2Array([Vector2(i, 0), Vector2(i + Maps.H, Maps.H)])
				l.width = 1.0
				l.default_color = col
				layer.add_child(l)
				i += 92
		"slabs":
			# 用固定种子生成一批地面色块，保证各端长得一样
			var rng := RandomNumberGenerator.new()
			rng.seed = 20260927
			for k in range(26):
				var w := rng.randf_range(70.0, 210.0)
				var h := rng.randf_range(46.0, 140.0)
				var p := Polygon2D.new()
				p.polygon = PackedVector2Array([
					Vector2.ZERO, Vector2(w, 0), Vector2(w, h), Vector2(0, h)
				])
				p.position = Vector2(
					rng.randf_range(0.0, Maps.W - w), rng.randf_range(0.0, Maps.H - h))
				p.color = col
				layer.add_child(p)
		_:
			for x in range(0, int(Maps.W) + 1, 80):
				var l := Line2D.new()
				l.points = PackedVector2Array([Vector2(x, 0), Vector2(x, Maps.H)])
				l.width = 1.0
				l.default_color = col
				layer.add_child(l)
			for y in range(0, int(Maps.H) + 1, 80):
				var l := Line2D.new()
				l.points = PackedVector2Array([Vector2(0, y), Vector2(Maps.W, y)])
				l.width = 1.0
				l.default_color = col
				layer.add_child(l)

func _build_border() -> void:
	var th: Dictionary = map.theme
	var outer := Color(th.block).darkened(0.45)
	var w := Maps.WALL
	# 边界墙比普通障碍更厚重、颜色更暗，让「场内/场外」一眼分明
	for r in [
		Rect2(0, 0, Maps.W, w), Rect2(0, Maps.H - w, Maps.W, w),
		Rect2(0, 0, w, Maps.H), Rect2(Maps.W - w, 0, w, Maps.H),
	]:
		var body := StaticBody2D.new()
		body.collision_layer = 2
		body.collision_mask = 0
		var cs := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = r.size
		cs.shape = shape
		cs.position = r.position + r.size * 0.5
		body.add_child(cs)
		_add_block_visual(body, r, outer, Color(th.edge).darkened(0.25), 3.0)
		add_child(body)

func _build_block(r: Rect2) -> void:
	var th: Dictionary = map.theme
	var body := StaticBody2D.new()
	body.collision_layer = 2
	body.collision_mask = 0

	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = r.size
	cs.shape = shape
	cs.position = r.position + r.size * 0.5
	body.add_child(cs)

	_add_block_visual(body, r, th.block, th.edge, 2.0)
	add_child(body)

## 障碍外观：投影 + 主体 + 顶面高光 + 描边。
## 俯视角下这几层叠起来就有「立起来」的感觉，比单个纯色矩形好看得多。
func _add_block_visual(parent: Node2D, r: Rect2, fill: Color, edge: Color, line_w: float) -> void:
	var th: Dictionary = map.theme

	var shadow := Polygon2D.new()
	shadow.polygon = PackedVector2Array([
		r.position + Vector2(4, 6),
		r.position + Vector2(r.size.x + 4, r.size.y + 6),
		r.position + r.size,
		r.position,
	])
	shadow.color = Color(0, 0, 0, 0.32)
	parent.add_child(shadow)

	var body := Polygon2D.new()
	body.polygon = PackedVector2Array([
		r.position, r.position + Vector2(r.size.x, 0),
		r.position + r.size, r.position + Vector2(0, r.size.y),
	])
	body.color = fill
	parent.add_child(body)

	# 顶面高光：上方一条更亮的窄条，模拟受光面
	var top_h := minf(r.size.y * 0.42, 12.0)
	var top := Polygon2D.new()
	top.polygon = PackedVector2Array([
		r.position, r.position + Vector2(r.size.x, 0),
		r.position + Vector2(r.size.x, top_h), r.position + Vector2(0, top_h),
	])
	top.color = th.get("block_top", fill.lightened(0.15))
	parent.add_child(top)

	var edge_line := Line2D.new()
	edge_line.points = PackedVector2Array([
		r.position, r.position + Vector2(r.size.x, 0),
		r.position + r.size, r.position + Vector2(0, r.size.y), r.position,
	])
	edge_line.width = line_w
	edge_line.default_color = edge
	parent.add_child(edge_line)

func _build_zone() -> void:
	zone_root = Node2D.new()
	zone_root.name = "Zone"
	zone_root.z_index = -18            # 在地板之上、玩家之下
	zone_root.visible = false
	add_child(zone_root)

	var c := capture_pos()
	_zone_r = capture_r()
	zone_root.position = c

	var th: Dictionary = map.theme
	zone_fill = Polygon2D.new()
	zone_fill.polygon = _circle_pts(_zone_r, 48)
	zone_fill.color = Color(th.accent.r, th.accent.g, th.accent.b, 0.08)
	zone_root.add_child(zone_fill)

	zone_ring = Line2D.new()
	var pts := _circle_pts(_zone_r, 48)
	pts.append(pts[0])
	zone_ring.points = pts
	zone_ring.width = 3.0
	zone_ring.default_color = th.accent
	zone_root.add_child(zone_ring)

	# 内圈：让控制区看起来像「一个目标点」而不是随手画的圈
	var inner := Line2D.new()
	var ip := _circle_pts(_zone_r * 0.62, 32)
	ip.append(ip[0])
	inner.points = ip
	inner.width = 1.5
	inner.default_color = Color(th.accent.r, th.accent.g, th.accent.b, 0.45)
	zone_root.add_child(inner)

func _build_corner_marks() -> void:
	# 四角小三角，纯装饰，让空旷的边界不那么死板
	var th: Dictionary = map.theme
	var col := Color(th.accent.r, th.accent.g, th.accent.b, 0.28)
	var d := 34.0
	var m := 6.0
	var corners := [
		[Vector2(m, m), Vector2(m + d, m), Vector2(m, m + d)],
		[Vector2(Maps.W - m, m), Vector2(Maps.W - m - d, m), Vector2(Maps.W - m, m + d)],
		[Vector2(m, Maps.H - m), Vector2(m + d, Maps.H - m), Vector2(m, Maps.H - m - d)],
		[Vector2(Maps.W - m, Maps.H - m), Vector2(Maps.W - m - d, Maps.H - m), Vector2(Maps.W - m, Maps.H - m - d)],
	]
	for c in corners:
		var p := Polygon2D.new()
		p.polygon = PackedVector2Array(c)
		p.color = col
		p.z_index = -19
		add_child(p)

func _circle_pts(r: float, seg: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in range(seg):
		var a := TAU * float(i) / float(seg)
		pts.append(Vector2(cos(a), sin(a)) * r)
	return pts
