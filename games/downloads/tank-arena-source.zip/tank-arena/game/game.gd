extends Node2D
## 游戏世界：竞技场 + 玩家 + 炮弹 + HUD，同时充当网络 RPC 的汇聚点与「模式裁判」。
##
## 裁判权划分：
##   权威端（单机房主）—— 跑对局时钟、控制区计分、生存波次、胜负判定，
##                        再按 5Hz 用 match_state 广播给所有人。
##   各端              —— 只负责把 match_state 显示出来，不做任何判定，
##                        所以不会出现「两边显示的时间不一样」。

const ArenaScript := preload("res://game/arena.gd")
const PlayerScript := preload("res://game/player.gd")
const BulletScript := preload("res://game/bullet.gd")
const HudScript := preload("res://ui/hud.gd")
const Modes := preload("res://game/modes.gd")
const Maps := preload("res://game/maps.gd")
const Weapons := preload("res://game/weapons.gd")
const Progress := preload("res://game/progress.gd")

const STATE_RATE := 1.0 / 5.0

var arena: Node2D
var players_root: Node2D
var bullets_root: Node2D
var hud: Control
var cam: Camera2D
var fx_root: Node2D

var mode: Dictionary = {}
var map_def: Dictionary = {}

# --- 对局状态（权威端写入，各端由 match_state 覆盖）---
var time_left: float = 0.0
var match_over: bool = false
var winner_id: int = -1
var lives: int = 0
var wave: int = 0
var wave_gap_left: float = 0.0
var zone_owner: int = -1

var _player_nodes: Dictionary = {}   # peer_id -> Player
var _last_hp: int = -1
var _last_alive: bool = true
var _state_accum: float = 0.0
## 本端是否已经结算过。不能靠「match_over 从 false 变 true」来判断：
## _end_match() 会先置 match_over 再广播，那样读到的永远是「早就结束了」，结算会被吞掉。
var _settled: bool = false

# --- 本地战绩（结算用，各端各算各的）---
var _local_kills: int = 0
var _local_best_streak: int = 0
var _local_zone_seconds: float = 0.0
var _zone_tick: float = 0.0

# --- 屏幕震动 ---
var _shake_amt: float = 0.0
var _shake_dur: float = 0.0
var _shake_t: float = 0.0

# ---------------------------------------------------------------- 初始化

func _ready() -> void:
	add_to_group("game")
	mode = Modes.get_mode(NetworkManager.mode_id)
	map_def = Maps.get_map(NetworkManager.map_id)

	arena = ArenaScript.new()
	arena.name = "Arena"
	arena.map_id = NetworkManager.map_id
	add_child(arena)
	arena.show_zone(bool(mode.get("show_zone", false)))

	cam = Camera2D.new()
	cam.position = Vector2(Maps.W * 0.5, Maps.H * 0.5)
	cam.enabled = true
	add_child(cam)

	players_root = Node2D.new()
	players_root.name = "Players"
	players_root.z_index = 5
	add_child(players_root)

	bullets_root = Node2D.new()
	bullets_root.name = "Bullets"
	bullets_root.z_index = 8
	add_child(bullets_root)

	fx_root = Node2D.new()
	fx_root.name = "Fx"
	fx_root.z_index = 14
	add_child(fx_root)

	# HUD 放进独立的 CanvasLayer：这样屏幕震动只晃世界，不会把界面一起晃
	var layer := CanvasLayer.new()
	layer.name = "UiLayer"
	layer.layer = 10
	add_child(layer)
	hud = HudScript.new()
	hud.name = "Hud"
	layer.add_child(hud)
	hud.setup(mode, map_def, arena)

	# 先定初始生命池，再 _reconcile()：_reconcile() 结尾会按「人类玩家数量」
	# 重新撑大生命池，此时若 lives 还是 0 会多打一条「0 → 5」的日志，看着像 bug。
	time_left = float(mode.get("time_limit", 0.0))
	lives = int(mode.get("lives", 0)) * maxi(NetworkManager.human_count(), 1)

	NetworkManager.players_changed.connect(_reconcile)
	NetworkManager.host_left.connect(_on_host_left)
	_reconcile()
	# 报到：在这之后房主才会把 match_state / server_state 广播过来。
	# 必须在 Game 节点建好之后调用，否则广播会打到不存在的 Main/Game。
	NetworkManager.mark_ready()

	if Modes.is_wave_mode(NetworkManager.mode_id):
		wave_gap_left = 4.0
	if Modes.is_wave_mode(NetworkManager.mode_id):
		print("[GAME] 对局开始 · 模式=%s 地图=%s · 共享生命=%d" % [
			mode.name, map_def.name, lives])
	else:
		print("[GAME] 对局开始 · 模式=%s 地图=%s · 目标=%d 分 / %.0f 秒" % [
			mode.name, map_def.name, int(mode.get("score_limit", 0)),
			float(mode.get("time_limit", 0.0))])

func _exit_tree() -> void:
	if NetworkManager.players_changed.is_connected(_reconcile):
		NetworkManager.players_changed.disconnect(_reconcile)

func player_node(pid: int) -> Node:
	return _player_nodes.get(pid)

# ---------------------------------------------------------------- 主循环

func _process(delta: float) -> void:
	_update_shake(delta)
	if NetworkManager.is_authority() and not match_over:
		_tick_match(delta)
	_update_hud(delta)

func _tick_match(delta: float) -> void:
	var rules := str(mode.get("rules", "ffa"))

	if rules == "zone":
		_tick_zone(delta)
	elif rules == "coop":
		_tick_waves(delta)

	var tl := float(mode.get("time_limit", 0.0))
	if tl > 0.0:
		time_left = maxf(0.0, time_left - delta)
		if time_left <= 0.0:
			_end_match(_leader())

	# 分数上限判定（生存模式没有上限）
	var limit := int(mode.get("score_limit", 0))
	if limit > 0:
		for pid in NetworkManager.players.keys():
			if int(NetworkManager.players[pid].get("score", 0)) >= limit:
				_end_match(int(pid))
				break

	_state_accum += delta
	if _state_accum >= STATE_RATE:
		_state_accum = 0.0
		if NetworkManager.is_networked():
			rpc_to_ready("match_state", [time_left, lives, wave, wave_gap_left, zone_owner, match_over, winner_id])
		else:
			_apply_match_state(time_left, lives, wave, wave_gap_left, zone_owner, match_over, winner_id)

## 占点：每个站在控制区里的玩家都按秒得分（逼所有人往中间挤，而不是各躲各的）
func _tick_zone(delta: float) -> void:
	var rate := float(mode.get("capture_rate", 2.0))
	var inside: Array = []
	for pid in _player_nodes.keys():
		var p: Node = _player_nodes[pid]
		if not is_instance_valid(p) or not p.alive:
			continue
		if arena.in_capture(p.global_position):
			inside.append(pid)
			NetworkManager.submit_score(pid, 0)     # 保持接口一致，0 分不产生网络包
	if inside.is_empty():
		zone_owner = -1
	else:
		# 圈里分数最高的那个负责给圈上色，纯粹是视觉提示
		var best := int(inside[0])
		for pid in inside:
			if int(NetworkManager.players[pid].get("score", 0)) > int(NetworkManager.players[best].get("score", 0)):
				best = pid
		zone_owner = best
		# 按累计时间加分：攒够 1 分再提交，避免每帧发小包
		_zone_tick += delta * rate
		if _zone_tick >= 1.0:
			var whole := int(_zone_tick)
			_zone_tick -= float(whole)
			for pid in inside:
				NetworkManager.submit_score(pid, whole)
		if inside.has(NetworkManager.local_id()):
			_local_zone_seconds += delta
			Profile.record_zone(delta)

## 生存：间歇 → 刷波 → 清完 → 再间歇
func _tick_waves(delta: float) -> void:
	if NetworkManager.wave_ai_alive() == 0:
		wave_gap_left = maxf(0.0, wave_gap_left - delta)
		if wave_gap_left <= 0.0:
			_spawn_wave()
	else:
		# 波次清空后给玩家一点喘息时间
		if wave_gap_left <= 0.0:
			wave_gap_left = float(mode.get("wave_gap", 8.0))

	if lives <= 0:
		_end_match(-1)

func _spawn_wave() -> void:
	wave += 1
	var n := Modes.wave_size(NetworkManager.mode_id, wave)
	var rng := RandomNumberGenerator.new()
	rng.seed = 100003 + wave * 7919          # 固定种子，波次构成可复现
	# 武器池随波次解锁：前两波只有机枪和霰弹，狙击/火箭从第 3、5 波才开始出现
	var pool := ["mg", "mg", "mg", "shotgun", "shotgun"]
	if wave >= 3:
		pool.append("railgun")
	if wave >= 5:
		pool.append("rocket")
	for i in range(n):
		var id := NetworkManager.wave_ai_id(wave * 100 + i)
		NetworkManager.add_wave_ai(id, pool[rng.randi() % pool.size()], wave)
	print("[GAME] 第 %d 波开始 · 敌人 %d 个" % [wave, n])
	if NetworkManager.is_networked():
		rpc_to_ready("wave_feed", [wave, n])
	else:
		wave_feed(wave, n)

func _leader() -> int:
	var best := -1
	var best_score := -1
	for pid in NetworkManager.players.keys():
		if bool(NetworkManager.players[pid].get("wave", false)):
			continue
		var s := int(NetworkManager.players[pid].get("score", 0))
		if s > best_score:
			best_score = s
			best = int(pid)
	return best

func _end_match(winner: int) -> void:
	if match_over:
		return
	match_over = true
	winner_id = winner
	var wname := "无人" if winner < 0 else _name_of(winner)
	print("[GAME] 对局结束 · 胜者=%s · 波次=%d" % [wname, wave])
	# 立即广播一次，别让其他端多等 200ms
	if NetworkManager.is_networked():
		rpc_to_ready("match_state", [time_left, lives, wave, wave_gap_left, zone_owner, match_over, winner_id])
	else:
		_apply_match_state(time_left, lives, wave, wave_gap_left, zone_owner, match_over, winner_id)

# ---------------------------------------------------------------- 对局状态同步

## 把一条对局 RPC 只发给「已经建好 Game 节点」的端（player.gd 的 30Hz 上报也走这里）。
## 主机自己保持 call_local 语义（直接本地调用，不走网络）。
## 为什么不用 .rpc()：客户端加入后要先等房主把模式/地图发过来才创建 Game 节点，
## 在这个空窗期里 .rpc() 会打到不存在的 Main/Game，客户端刷一屏 Node not found。
## 生存模式尤其明显：房主一刷波次敌人，那批 AI 立刻开始 30Hz 上报位置。
func rpc_to_ready(method: String, args: Array) -> void:
	if not NetworkManager.is_networked():
		return
	var me := NetworkManager.local_id()
	if NetworkManager.ready_peers.has(me):
		callv(method, args)
	for pid in NetworkManager.ready_peers.keys():
		var id := int(pid)
		if id == me:
			continue
		var send: Array = [id, method]
		send.append_array(args)
		callv("rpc_id", send)

@rpc("authority", "reliable", "call_local")
func match_state(tl: float, lv: int, wv: int, gap: float, zo: int, over: bool, win: int) -> void:
	_apply_match_state(tl, lv, wv, gap, zo, over, win)

func _apply_match_state(tl: float, lv: int, wv: int, gap: float, zo: int, over: bool, win: int) -> void:
	time_left = tl
	lives = lv
	wave = wv
	wave_gap_left = gap
	zone_owner = zo
	match_over = over
	winner_id = win

	if arena != null:
		if zo >= 0:
			var p: Node = _player_nodes.get(zo)
			arena.set_zone_holder(p.color if p != null else Color(0, 0, 0, 0))
		else:
			arena.set_zone_holder(Color(0, 0, 0, 0))

	if match_over and not _settled:
		_settled = true
		_settle_local()
		if hud != null:
			hud.show_result(_result_text())

@rpc("authority", "reliable", "call_local")
func wave_feed(w: int, n: int) -> void:
	print("[WAVE] 第 %d 波 · %d 个敌人" % [w, n])
	if hud != null:
		hud.show_banner("第 %d 波" % w, "敌人 %d 个" % n)
	Sfx.play_wave()

# ---------------------------------------------------------------- 结算

## 每个端各自结算自己的档案（分数是共享的，档案是各人各自的）
func _settle_local() -> void:
	var me := NetworkManager.local_id()
	var won := winner_id == me
	var result := {
		"mode": NetworkManager.mode_id,
		"map": NetworkManager.map_id,
		"kills": _local_kills,
		"deaths": 0,
		"won": won,
		"best_streak": _local_best_streak,
		"wave": wave,
		"zone_seconds": _local_zone_seconds,
	}
	var newly: Array = Profile.finish_match(result)
	if hud != null and not newly.is_empty():
		var names: Array = []
		for c in newly:
			names.append(str(c.name))
		hud.show_toast("完成挑战：%s" % " · ".join(names), 4.0)

func _result_text() -> String:
	var lines: Array = []
	if winner_id >= 0:
		lines.append("胜者：%s" % _name_of(winner_id))
	else:
		lines.append("本局结束")
	if Modes.is_wave_mode(NetworkManager.mode_id):
		lines.append("坚持到第 %d 波" % wave)
	lines.append("你本局：%d 杀 · 最高连杀 %d" % [_local_kills, _local_best_streak])
	lines.append("等级 %d %s · %d 经验" % [Profile.level(), Profile.title(), Profile.xp])
	lines.append("按 ESC 返回菜单")
	return "\n".join(lines)

# ---------------------------------------------------------------- 屏幕震动

func shake(amount: float, dur: float) -> void:
	if amount > _shake_amt:
		_shake_amt = amount
	_shake_dur = maxf(_shake_dur, dur)
	_shake_t = _shake_dur

func _update_shake(delta: float) -> void:
	if cam == null:
		return
	if _shake_t > 0.0:
		_shake_t = maxf(0.0, _shake_t - delta)
		var k := _shake_t / maxf(_shake_dur, 0.001)
		var a := _shake_amt * k * k
		cam.offset = Vector2(randf_range(-a, a), randf_range(-a, a)) * 60.0
		if _shake_t <= 0.0:
			_shake_amt = 0.0
			_shake_dur = 0.0
			cam.offset = Vector2.ZERO

# ---------------------------------------------------------------- HUD 驱动

func _update_hud(delta: float) -> void:
	if hud == null:
		return
	var me: Node = _player_nodes.get(NetworkManager.local_id())
	if me != null:
		if me.health != _last_hp:
			_last_hp = me.health
			hud.set_hp(me.health, me.MAX_HEALTH)
		if me.alive != _last_alive:
			_last_alive = me.alive
			hud.set_alive(me.alive)
		if not me.alive:
			hud.set_respawn_hint(me._local_respawn_left)
		hud.set_weapon(me.weapon_id, me._fire_cd, me.fire_cooldown())

	var my_score := 0
	if NetworkManager.players.has(NetworkManager.local_id()):
		my_score = int(NetworkManager.players[NetworkManager.local_id()].get("score", 0))

	hud.set_mode_info({
		"time_left": time_left,
		"lives": lives,
		"wave": wave,
		"wave_gap": wave_gap_left,
		"zone_owner": -1 if zone_owner < 0 else zone_owner,
		"zone_owner_name": "" if zone_owner < 0 else _name_of(zone_owner),
		"over": match_over,
		"wave_ai": NetworkManager.wave_ai_alive(),
		"local_score": my_score,
		"local_kills": _local_kills,
		"local_streak": _local_best_streak,
	})
	if _local_zone_seconds > 0.0:
		hud.set_zone_seconds(_local_zone_seconds)

# ---------------------------------------------------------------- 输入

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	var me: Node = _player_nodes.get(NetworkManager.local_id())
	match event.keycode:
		KEY_ESCAPE:
			NetworkManager.leave()
			get_tree().reload_current_scene()
		KEY_M:
			var now_muted: bool = Sfx.toggle_mute()
			hud.show_toast("音效已%s（M 键切换）" % ("关闭" if now_muted else "开启"), 1.4)
		KEY_P:
			toggle_admin()
		KEY_Q:
			if me != null:
				me.cycle_weapon(-1)
		KEY_E:
			if me != null:
				me.cycle_weapon(1)
		KEY_1, KEY_2, KEY_3, KEY_4:
			var idx := int(event.keycode) - int(KEY_1)
			var unlocked: Array = Profile.unlocked_weapons()
			if idx < unlocked.size() and me != null:
				me.switch_weapon(str(unlocked[idx]))
			elif idx < Weapons.LIST.size():
				var w: Dictionary = Weapons.LIST[idx]
				hud.show_toast("「%s」需要 %d 级解锁（当前 %d 级）" % [
					w.name, int(w.unlock_level), Profile.level()], 2.4)

func on_local_weapon_changed(id: String) -> void:
	NetworkManager.set_my_weapon(id)
	Profile.set_weapon(id)
	var w := Weapons.get_weapon(id)
	if hud != null:
		hud.show_toast("切换到「%s」· %s" % [w.name, w.hint], 1.8)

# ---------------------------------------------------------------- 管理员模式（P 键）
## 效果：无敌 + 加速 + 超级射速。
## 单机 / 房主：本地直接生效，并把状态广播给所有人。
## 访客：位置和射速本来就是本机模拟，按下去立刻生效；无敌必须由房主放行，
##       所以这里额外发一条请求，房主收到后再广播，避免各端状态不一致。

func toggle_admin() -> void:
	var me: Node = _player_nodes.get(NetworkManager.local_id())
	if me == null:
		return
	var on: bool = not me.admin
	apply_admin(NetworkManager.local_id(), on)
	if not NetworkManager.is_networked():
		return
	if NetworkManager.is_authority():
		rpc_to_ready("admin_state", [NetworkManager.local_id(), on])
	else:
		request_admin.rpc_id(1, on)

@rpc("any_peer", "reliable")
func request_admin(enabled: bool) -> void:
	if not multiplayer.is_server():
		return
	rpc_to_ready("admin_state", [multiplayer.get_remote_sender_id(), enabled])

@rpc("authority", "reliable", "call_local")
func admin_state(pid: int, enabled: bool) -> void:
	apply_admin(pid, enabled)

func apply_admin(pid: int, enabled: bool) -> void:
	var n: Node = _player_nodes.get(pid)
	if n == null:
		return
	if not n.set_admin(enabled):
		return                      # 状态没变，不重复播提示
	print("[ADMIN] %s 管理员模式 %s" % [_name_of(pid), "开启" if enabled else "关闭"])
	if hud == null:
		return
	if pid == NetworkManager.local_id():
		hud.set_admin(enabled)
		Sfx.play_admin(enabled)
		hud.show_toast("管理员模式已%s：无敌 · 加速 · 超级射速" % ("开启" if enabled else "关闭"), 2.6)
	else:
		hud.show_toast("%s 开启了管理员模式" % _name_of(pid), 2.0)

# ---------------------------------------------------------------- 玩家节点对齐

func _reconcile() -> void:
	var data := NetworkManager.players

	for id in data.keys():
		var pid := int(id)
		if not _player_nodes.has(pid):
			_create_player(pid)

	var stale: Array = []
	for pid in _player_nodes.keys():
		if not data.has(pid):
			stale.append(pid)
	for pid in stale:
		var n: Node = _player_nodes[pid]
		if is_instance_valid(n):
			n.queue_free()
		_player_nodes.erase(pid)

	for pid in _player_nodes.keys():
		var n: Node = _player_nodes[pid]
		if is_instance_valid(n) and data.has(pid):
			n.set_player_name(str(data[pid].get("name", "Player")))

	if hud != null:
		hud.refresh(data, NetworkManager.local_id())
	_sync_shared_lives()

## 生存模式的共享生命 = 每人份数 × 人类数量，且只在有人加入时变多。
## 房主 _ready() 的时候房间里通常只有自己，之后加入的队友不会自动把生命池撑大
## （踩过：2 人联机、每人 5 条命，实际却只共享 5 条）。
## 中途有人退出也不扣：否则剩下的人会被队友的离开直接害死。
func _sync_shared_lives() -> void:
	if not Modes.is_wave_mode(NetworkManager.mode_id):
		return
	var want := int(mode.get("lives", 0)) * maxi(NetworkManager.human_count(), 1)
	if want > lives:
		print("[GAME] 共享生命 %d → %d（人类玩家 %d 人）" % [
			lives, want, NetworkManager.human_count()])
		lives = want

func _create_player(pid: int) -> void:
	var info: Dictionary = NetworkManager.players[pid]
	var p = PlayerScript.new()
	p.name = "P%d" % pid
	p.peer_id = pid
	p.is_ai = bool(info.get("ai", false))
	p.is_wave_ai = bool(info.get("wave", false))
	p.wave_no = int(info.get("wave_no", 0))
	p.player_name = str(info.get("name", "Player"))
	p.weapon_id = str(info.get("weapon", "mg"))
	p.skin_id = str(info.get("skin", "standard"))

	# 阵营：生存模式真人 0 队 / 波次敌人 1 队；其他模式人人各成一队
	if Modes.is_wave_mode(NetworkManager.mode_id):
		p.team = 1 if p.is_wave_ai else 0
	else:
		p.team = pid

	# 本机玩家一律以「自己档案里的选择」为准，别被还没同步到的名单覆盖
	if pid == NetworkManager.local_id():
		p.weapon_id = Profile.selected_weapon
		p.skin_id = Profile.selected_skin

	if p.is_wave_ai:
		p.spawn_point = arena.ai_spawn_for(pid)
	else:
		p.spawn_point = arena.spawn_for(pid)
	p.color = arena.color_for(pid)
	p.position = p.spawn_point

	if p.is_ai:
		_apply_ai_personality(p, pid)

	players_root.add_child(p)
	_player_nodes[pid] = p
	print("[GAME] 生成玩家节点 P%d @ %s%s" % [
		pid, str(p.spawn_point), "（波次敌人·第%d波）" % p.wave_no if p.is_wave_ai else ("（AI）" if p.is_ai else "")])

func _apply_ai_personality(p: Node, pid: int) -> void:
	var ai_total := 0
	for id in NetworkManager.players.keys():
		if bool(NetworkManager.players[id].get("ai", false)):
			ai_total += 1
	var weaken := 1.0 + 0.22 * float(maxi(ai_total, 1) - 1)   # AI 越多，单个越弱
	p._ai_strafe = 1.0 if pid % 2 == 0 else -1.0
	p._ai_turn = randf_range(3.4, 4.6)
	p._ai_spread = randf_range(0.09, 0.17)
	p._ai_fire_scale = randf_range(2.0, 2.9) * weaken
	# 波次敌人越往后越凶：手更快、更准、更爱绕
	if p.is_wave_ai:
		var w := float(maxi(p.wave_no, 1))
		p._ai_turn = 3.6 + minf(w * 0.16, 2.4)
		p._ai_spread = maxf(0.05, 0.17 - w * 0.008)
		p._ai_fire_scale = maxf(1.05, 2.9 - w * 0.14)

# ---------------------------------------------------------------- 位置同步 RPC

@rpc("any_peer", "unreliable_ordered")
func client_state(pos: Vector2, b_rot: float, t_rot: float) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	var node: Node = _player_nodes.get(sender)
	if node == null:
		return
	node.set_net_target(pos, b_rot, t_rot)
	rpc_to_ready("server_state", [sender, pos, b_rot, t_rot])

@rpc("authority", "unreliable_ordered", "call_local")
func server_state(pid: int, pos: Vector2, b_rot: float, t_rot: float) -> void:
	if pid == NetworkManager.local_id():
		return
	var node: Node = _player_nodes.get(pid)
	if node == null:
		return
	node.set_net_target(pos, b_rot, t_rot)

# ---------------------------------------------------------------- 血量 / 死亡 RPC

@rpc("authority", "reliable", "call_local")
func server_health(pid: int, hp: int, alv: bool) -> void:
	var node: Node = _player_nodes.get(pid)
	if node == null:
		return
	node.set_net_health(hp, alv)
	if not alv and NetworkManager.is_authority():
		_on_authority_death(pid)

## 权威端处理死亡后续：扣共享生命、摘掉已死的波次敌人
func _on_authority_death(pid: int) -> void:
	var node: Node = _player_nodes.get(pid)
	if node == null:
		return
	if node.is_wave_ai:
		# 波次敌人不复活，等一小会儿让它淡出，然后从名单摘掉
		await get_tree().create_timer(1.1).timeout
		if is_instance_valid(node) and not node.alive:
			NetworkManager.players.erase(pid)
			NetworkManager._broadcast_players()
		return
	if Modes.is_wave_mode(NetworkManager.mode_id):
		lives = maxi(0, lives - 1)
		if lives <= 0:
			_end_match(-1)

@rpc("authority", "reliable", "call_local")
func respawn_player(pid: int) -> void:
	var node: Node = _player_nodes.get(pid)
	if node == null:
		return
	node.do_respawn()

## 击杀者的连杀数 +1，返回当前值。
## 由 kill_feed 带着这个数字广播出去，各端不需要自己维护一份连杀表。
func note_kill(pid: int) -> int:
	var n: Node = _player_nodes.get(pid)
	if n == null:
		return 0
	n.streak = int(n.streak) + 1
	return int(n.streak)

## 击杀播报。顺带让各端各自记录自己的战绩 —— 档案是本地的，不该由房主代写。
@rpc("authority", "reliable", "call_local")
func kill_feed(killer_id: int, victim_id: int, weapon: String = "mg", streak: int = 0) -> void:
	var wname: String = str(Weapons.get_weapon(weapon).name)
	print("[KILL] %s（%s）击毁 %s" % [_name_of(killer_id), wname, _name_of(victim_id)])
	if killer_id == NetworkManager.local_id():
		_local_kills += 1
		_local_best_streak = maxi(_local_best_streak, streak)
	if hud == null:
		return
	var vn := _name_of(victim_id)
	if killer_id == victim_id:
		hud.show_toast("%s  自爆了" % vn, 2.2)
	else:
		hud.show_kill("%s  ·  %s  ·  %s" % [_name_of(killer_id), wname, vn])

## 射击者收到命中确认：准星闪一下 + 冒个伤害数字
@rpc("authority", "unreliable")
func hit_confirm(amount: int, killed: bool) -> void:
	if hud != null:
		hud.on_hit(amount, killed)

func _name_of(pid: int) -> String:
	if NetworkManager.players.has(pid):
		return str(NetworkManager.players[pid].get("name", "玩家%d" % pid))
	if pid == NetworkManager.local_id():
		return NetworkManager.my_name
	return "玩家%d" % pid

# ---------------------------------------------------------------- 开火 RPC

@rpc("any_peer", "reliable")
func request_fire(origin: Vector2, angles: PackedFloat32Array, weapon: String) -> void:
	if not multiplayer.is_server():
		return
	rpc_to_ready("spawn_bullet", [multiplayer.get_remote_sender_id(), origin, angles, weapon])

@rpc("authority", "reliable", "call_local")
func spawn_bullet(shooter: int, origin: Vector2, angles: PackedFloat32Array, weapon: String) -> void:
	var node: Node = _player_nodes.get(shooter)
	var col := Color.WHITE
	if node != null:
		col = node.color
	for a in angles:
		var b = BulletScript.new()
		b.shooter_id = shooter
		b.direction = Vector2.RIGHT.rotated(a)
		b.position = origin + b.direction * 26.0
		b.authoritative = NetworkManager.is_authority()
		b.setup(weapon, col)
		bullets_root.add_child(b)
	Sfx.play_fire(origin, weapon)

# ---------------------------------------------------------------- 事件

func _on_host_left() -> void:
	pass
