extends RefCounted
## 成长曲线的纯数据层：等级曲线 / 挑战表 / 涂装表。
## 状态与持久化在 autoload/profile.gd，这里只有常量和纯函数，方便单独测。

const MAX_LEVEL := 30

## 升到下一级需要的经验。二次增长：前 10 级约 1 小时（把 4 把枪发完），
## 10→30 级累计约 11 万经验，按一局 400 经验算约 280 局、10 小时以上。
static func xp_to_next(level: int) -> int:
	var k := maxi(level - 1, 0)
	return 120 + 60 * k + 12 * k * k

## 总经验 → 等级
static func level_for_xp(total_xp: int) -> int:
	var lv := 1
	var remain := maxi(total_xp, 0)
	while lv < MAX_LEVEL and remain >= xp_to_next(lv):
		remain -= xp_to_next(lv)
		lv += 1
	return lv

## 总经验 → 当前等级内已积累的经验
static func xp_into_level(total_xp: int) -> int:
	var lv := 1
	var remain := maxi(total_xp, 0)
	while lv < MAX_LEVEL and remain >= xp_to_next(lv):
		remain -= xp_to_next(lv)
		lv += 1
	return remain

static func total_xp_for_level(level: int) -> int:
	var sum := 0
	for l in range(1, level):
		sum += xp_to_next(l)
	return sum

const TITLES := [
	[1, "新兵"], [3, "下士"], [5, "中士"], [8, "上尉"],
	[12, "少校"], [16, "上校"], [20, "准将"], [25, "少将"], [30, "元帅"],
]

static func title_for_level(level: int) -> String:
	var t := "新兵"
	for pair in TITLES:
		if level >= int(pair[0]):
			t = str(pair[1])
	return t

# ---------------------------------------------------------------- 涂装
## 涂装只改「图案 + 点缀色」，车体主色仍然是各玩家的槽位色 ——
## 这样既有外观差异，又不会让玩家在混战里认不出谁是谁。
const SKINS := [
	{"id": "standard", "name": "标准涂装", "pattern": "solid", "trim": Color(1, 1, 1, 0.0),
		"unlock": "level", "need": 1, "desc": "出厂配色"},
	{"id": "stripe", "name": "双斜纹", "pattern": "stripe", "trim": Color(1, 1, 1, 0.22),
		"unlock": "level", "need": 4, "desc": "两道斜向装饰纹"},
	{"id": "camo", "name": "迷彩", "pattern": "camo", "trim": Color(0, 0, 0, 0.30),
		"unlock": "level", "need": 8, "desc": "三色斑块迷彩"},
	{"id": "hex", "name": "蜂窝", "pattern": "hex", "trim": Color(1, 1, 1, 0.16),
		"unlock": "level", "need": 12, "desc": "六边形网格覆层"},
	{"id": "neon", "name": "霓虹", "pattern": "neon", "trim": Color(0.30, 1.00, 0.95),
		"unlock": "level", "need": 20, "desc": "亮青色描边，暗处也扎眼"},
	{"id": "gold", "name": "黄金", "pattern": "solid", "trim": Color(1.00, 0.84, 0.25),
		"unlock": "challenge", "need": "veteran", "desc": "通体镀金"},
	{"id": "shadow", "name": "暗影", "pattern": "stripe", "trim": Color(0.55, 0.35, 1.00),
		"unlock": "challenge", "need": "hundred_kills", "desc": "紫黑条纹"},
	{"id": "lava", "name": "熔岩", "pattern": "camo", "trim": Color(1.00, 0.42, 0.10),
		"unlock": "challenge", "need": "wave_legend", "desc": "橙红熔岩斑"},
]

static func get_skin(id: String) -> Dictionary:
	for s in SKINS:
		if s.id == id:
			return s
	return SKINS[0]

# ---------------------------------------------------------------- 挑战
## stat 键对应 profile.stats 里的计数器；达到 target 即完成。
## xp 是额外奖励，unlock_skin 用来解锁涂装。
const CHALLENGES := [
	{"id": "first_match", "name": "初次上阵", "desc": "完成任意一局对战",
		"stat": "matches", "target": 1, "xp": 50},
	{"id": "tutorial", "name": "毕业典礼", "desc": "完成教学关",
		"stat": "tutorial_done", "target": 1, "xp": 80},
	{"id": "match_10", "name": "常客", "desc": "累计完成 10 局对战",
		"stat": "matches", "target": 10, "xp": 150},
	{"id": "match_50", "name": "老油条", "desc": "累计完成 50 局对战",
		"stat": "matches", "target": 50, "xp": 600},

	{"id": "kills_100", "name": "百人斩", "desc": "累计击毁 100 台坦克",
		"stat": "kills", "target": 100, "xp": 300},
	{"id": "kills_500", "name": "千锤百炼", "desc": "累计击毁 500 台坦克",
		"stat": "kills", "target": 500, "xp": 900, "unlock_skin": "shadow"},
	{"id": "match_kills_10", "name": "单局十杀", "desc": "单局内击毁 10 台坦克",
		"stat": "best_match_kills", "target": 10, "xp": 200},
	{"id": "streak_5", "name": "势不可挡", "desc": "单局内连续击毁 5 台且不死",
		"stat": "best_streak", "target": 5, "xp": 300},

	{"id": "mg_150", "name": "枪械大师", "desc": "用速射机枪击毁 150 台",
		"stat": "kills_mg", "target": 150, "xp": 250},
	{"id": "shotgun_50", "name": "散弹达人", "desc": "用霰弹枪击毁 50 台",
		"stat": "kills_shotgun", "target": 50, "xp": 250},
	{"id": "railgun_50", "name": "狙击精英", "desc": "用电磁狙击炮击毁 50 台",
		"stat": "kills_railgun", "target": 50, "xp": 300},
	{"id": "rocket_50", "name": "爆破专家", "desc": "用火箭炮击毁 50 台",
		"stat": "kills_rocket", "target": 50, "xp": 300},

	{"id": "zone_600", "name": "守土有责", "desc": "在占点模式里累计控制 10 分钟",
		"stat": "zone_seconds", "target": 600, "xp": 300},
	{"id": "wave_5", "name": "波次新兵", "desc": "生存模式撑到第 5 波",
		"stat": "best_wave", "target": 5, "xp": 150},
	{"id": "veteran", "name": "波次老兵", "desc": "生存模式撑到第 10 波",
		"stat": "best_wave", "target": 10, "xp": 400, "unlock_skin": "gold"},
	{"id": "wave_legend", "name": "波次传奇", "desc": "生存模式撑到第 20 波",
		"stat": "best_wave", "target": 20, "xp": 1200, "unlock_skin": "lava"},

	{"id": "all_maps", "name": "地图旅行家", "desc": "在 4 张地图上各完成一局",
		"stat": "maps_played", "target": 4, "xp": 300},
	{"id": "all_modes", "name": "三线作战", "desc": "在 3 种模式里各完成一局",
		"stat": "modes_played", "target": 3, "xp": 250},
	{"id": "max_level", "name": "登峰造极", "desc": "达到 30 级",
		"stat": "level", "target": 30, "xp": 2000},
]

static func get_challenge(id: String) -> Dictionary:
	for c in CHALLENGES:
		if c.id == id:
			return c
	return {}
