extends Area2D
## 炮弹：所有端各自按相同参数做直线运动（视觉），
## 只有权威端实例（authoritative=true）负责命中判定与扣血。
##
## 外观与数值全部来自 weapons.gd，所以同一发炮弹在各端长得一样、飞得一样快，
## 只需要把 weapon_id 一起同步过去即可（见 game.gd 的 spawn_bullet）。

const Weapons := preload("res://game/weapons.gd")

var shooter_id: int = 0
var weapon_id: String = "mg"
var direction: Vector2 = Vector2.RIGHT
var speed: float = 640.0
var authoritative: bool = false
var life: float = 2.0
var tint: Color = Color(1.0, 0.88, 0.54)
var damage: int = 1
var pierce: int = 0                 # 还能额外穿透几个目标
var splash: float = 0.0             # 爆炸半径，0 表示无溅射
var splash_damage: int = 0
var trail: bool = false
var bullet_r: float = 4.5
var glow_r: float = 9.0

var _dead: bool = false
var _hits_left: int = 1
var _hit_ids: Dictionary = {}

func setup(wid: String, owner_color: Color) -> void:
	var w := Weapons.get_weapon(wid)
	weapon_id = wid
	speed = float(w.speed)
	life = float(w.life)
	damage = int(w.damage)
	pierce = int(w.get("pierce", 0))
	splash = float(w.get("splash", 0.0))
	splash_damage = int(w.get("splash_damage", 0))
	trail = bool(w.get("trail", false))
	bullet_r = float(w.get("bullet_r", 4.5))
	glow_r = float(w.get("glow_r", 9.0))
	# 炮弹染成武器色和车体色的混合，既认得出是谁打的，也认得出是什么枪
	var wc: Color = w.color
	tint = wc.lerp(owner_color, 0.35).lightened(0.2)
	_hits_left = pierce + 1

func _ready() -> void:
	add_to_group("bullet")
	collision_layer = 4
	collision_mask = 1 | 2        # 玩家 + 墙
	monitorable = false

	var cs := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = bullet_r
	cs.shape = shape
	add_child(cs)

	if trail:
		# 高速弹的拖尾：在弹体后方拉一条渐细的实心条，比粒子便宜且更锐利
		var len_ := clampf(speed * 0.032, 26.0, 64.0)
		var streak := Polygon2D.new()
		streak.polygon = PackedVector2Array([
			Vector2(-len_, -bullet_r * 0.55), Vector2(0, -bullet_r * 0.35),
			Vector2(0, bullet_r * 0.35), Vector2(-len_, bullet_r * 0.55),
		])
		streak.color = Color(tint.r, tint.g, tint.b, 0.42)
		streak.rotation = direction.angle()
		add_child(streak)

	var outer := Polygon2D.new()
	outer.polygon = _circle(glow_r, 12)
	outer.color = Color(tint.r, tint.g, tint.b, 0.20)
	add_child(outer)

	var mid := Polygon2D.new()
	mid.polygon = _circle(bullet_r * 1.55, 12)
	mid.color = Color(tint.r, tint.g, tint.b, 0.45)
	add_child(mid)

	var core := Polygon2D.new()
	core.polygon = _circle(bullet_r, 12)
	core.color = tint.lightened(0.35)
	add_child(core)

	body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	position += direction * speed * delta
	life -= delta
	if life <= 0.0:
		_detonate(false)
		return

func _on_body_entered(body: Node) -> void:
	if _dead:
		return
	if body is StaticBody2D:
		_detonate(true)
		return
	if not authoritative:
		return
	if not body.has_method("take_damage"):
		return
	if body.peer_id == shooter_id:
		return
	if _hit_ids.has(body.peer_id):
		return
	_hit_ids[body.peer_id] = true

	body.take_damage(shooter_id, damage, weapon_id)
	_hits_left -= 1
	if _hits_left <= 0:
		_detonate(false)
	else:
		# 穿透弹：打中后继续飞，只在弹体上留个记号
		var sparks := Color(tint.r, tint.g, tint.b, 0.9)
		_spawn_sparks(global_position, sparks, 4)

## 弹体终结：有溅射就炸一片，否则只留个命中火花
func _detonate(hit_wall: bool) -> void:
	if _dead:
		return
	_dead = true
	if splash > 0.0:
		_spawn_blast()
		if authoritative:
			_apply_splash()
	elif hit_wall:
		_spawn_sparks(global_position, tint, 5)
	queue_free()

func _apply_splash() -> void:
	var here := global_position
	for t in get_tree().get_nodes_in_group("tank"):
		if not is_instance_valid(t) or not t.alive:
			continue
		if t.peer_id == shooter_id:
			continue                       # 不炸自己，避免贴脸开炮的挫败感
		if t.global_position.distance_to(here) <= splash:
			t.take_damage(shooter_id, splash_damage, weapon_id)

func _spawn_blast() -> void:
	var node := Node2D.new()
	node.position = global_position
	node.z_index = 12
	get_parent().add_child(node)
	# 两圈扩散的环 + 一团芯，0.35 秒内放大淡出
	for i in range(2):
		var ring := Line2D.new()
		var pts := PackedVector2Array()
		var seg := 26
		for k in range(seg + 1):
			var a := TAU * float(k) / float(seg)
			pts.append(Vector2(cos(a), sin(a)) * (splash * (0.35 + 0.65 * float(i))))
		ring.points = pts
		ring.width = 3.0 - float(i)
		ring.default_color = Color(tint.r, tint.g, tint.b, 0.85 - 0.35 * float(i))
		node.add_child(ring)

	var core := Polygon2D.new()
	core.polygon = _circle(splash * 0.45, 20)
	core.color = Color(1.0, 0.92, 0.72, 0.55)
	node.add_child(core)

	Sfx.play_blast(global_position)
	_ping_game(0.55, 0.22)

	var tw := node.create_tween()
	tw.set_parallel(true)
	tw.tween_property(node, "scale", Vector2(1.5, 1.5), 0.34)
	tw.tween_property(node, "modulate:a", 0.0, 0.34)
	tw.chain().tween_callback(node.queue_free)

func _spawn_sparks(at: Vector2, col: Color, n: int) -> void:
	var node := Node2D.new()
	node.position = at
	node.z_index = 12
	get_parent().add_child(node)
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for i in range(n):
		var p := Polygon2D.new()
		p.polygon = PackedVector2Array([
			Vector2(-2.4, -1.2), Vector2(2.4, -1.2), Vector2(2.4, 1.2), Vector2(-2.4, 1.2)
		])
		p.color = col
		node.add_child(p)
		var dir := Vector2.RIGHT.rotated(rng.randf() * TAU)
		var dist := rng.randf_range(10.0, 26.0)
		var tw := node.create_tween()
		tw.set_parallel(true)
		tw.tween_property(p, "position", dir * dist, 0.22)
		tw.tween_property(p, "modulate:a", 0.0, 0.22)
	var tw2 := node.create_tween()
	tw2.tween_interval(0.26)
	tw2.tween_callback(node.queue_free)

## 让 game.gd 做屏幕震动（炮弹不该知道 HUD 的存在，所以走 duck typing）
func _ping_game(amount: float, dur: float) -> void:
	var g := get_tree().get_first_node_in_group("game")
	if g != null and g.has_method("shake"):
		g.shake(amount, dur)

func _circle(r: float, seg: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in range(seg):
		var a := TAU * float(i) / float(seg)
		pts.append(Vector2(cos(a), sin(a)) * r)
	return pts
