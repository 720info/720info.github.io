extends RefCounted
## 武器表 —— 所有数值集中在这里，player.gd / bullet.gd / hud.gd / sfx.gd 都读它。
##
## 设计基线：血量固定 3 点，所以每把枪的「几枪打死人」是核心手感指标：
##   机枪   1 伤 / 0.13s  → 理论 0.39s 打死，但需要持续跟枪
##   霰弹   1 伤 ×5 弹丸   → 贴脸一发秒，远了基本打不中
##   狙击   3 伤 / 1.15s   → 一枪一个，代价是冷却长、容错低
##   火箭   2 伤直击 + 1 伤溅射 → 打地也行，但飞行慢、要预判
##
## 颜色用 Color(r,g,b) 浮点构造，这样整个字典能写成 const（Color("...") 不是常量表达式）。

const LIST := [
	{
		"id": "mg",
		"name": "速射机枪",
		"short": "机枪",
		"desc": "射速最快，单发伤害最低。适合贴身缠斗和持续压制。",
		"hint": "按住左键扫射，靠跟枪取胜",
		"fire_cd": 0.13,
		"damage": 1,
		"speed": 820.0,
		"spread": 0.050,
		"pellets": 1,
		"life": 1.5,
		"pierce": 0,
		"recoil": 0.020,
		"bullet_r": 4.2,
		"glow_r": 9.0,
		"color": Color(0.50, 0.83, 1.00),
		"trail": false,
		"sfx": 0,
		"ai_range": 300.0,        # AI 拿这把枪时想保持的距离
		"unlock_level": 1,
	},
	{
		"id": "shotgun",
		"name": "霰弹枪",
		"short": "霰弹",
		"desc": "一次打出 5 颗弹丸，扇形覆盖。贴脸能一发带走，远了几乎打不中。",
		"hint": "绕到敌人身边再开枪",
		"fire_cd": 0.62,
		"damage": 1,
		"speed": 640.0,
		"spread": 0.215,
		"pellets": 5,
		"life": 0.52,
		"pierce": 0,
		"recoil": 0.070,
		"bullet_r": 3.4,
		"glow_r": 7.5,
		"color": Color(1.00, 0.77, 0.42),
		"trail": false,
		"sfx": 1,
		"ai_range": 155.0,        # 霰弹：AI 必须贴上去
		"unlock_level": 3,
	},
	{
		"id": "railgun",
		"name": "电磁狙击炮",
		"short": "狙击",
		"desc": "一枪 3 点伤害，正面命中即击毁。弹道笔直无散布，还能打穿两个目标。",
		"hint": "冷却很长，打空就是活靶子",
		"fire_cd": 1.15,
		"damage": 3,
		"speed": 1600.0,
		"spread": 0.0,
		"pellets": 1,
		"life": 1.2,
		"pierce": 2,
		"recoil": 0.120,
		"bullet_r": 3.0,
		"glow_r": 15.0,
		"color": Color(0.79, 0.65, 1.00),
		"trail": true,
		"sfx": 2,
		"ai_range": 470.0,        # 狙击：拉开距离才安全
		"unlock_level": 6,
	},
	{
		"id": "rocket",
		"name": "火箭炮",
		"short": "火箭",
		"desc": "飞行慢但命中后范围爆炸，打地面和墙角一样能蹭到人。",
		"hint": "往敌人脚下或掩体后面打",
		"fire_cd": 0.95,
		"damage": 2,
		"speed": 430.0,
		"spread": 0.018,
		"pellets": 1,
		"life": 2.6,
		"pierce": 0,
		"recoil": 0.090,
		"bullet_r": 6.0,
		"glow_r": 13.0,
		"color": Color(1.00, 0.54, 0.36),
		"trail": true,
		"splash": 78.0,          # 爆炸半径
		"splash_damage": 1,      # 溅射伤害（对射击者无效，避免自爆挫败感）
		"sfx": 3,
		"ai_range": 360.0,        # 火箭：中距离，留出预判余量
		"unlock_level": 10,
	},
]

## 全部武器 id，按解锁顺序
static func ids() -> Array:
	var out: Array = []
	for w in LIST:
		out.append(w.id)
	return out

static func get_weapon(id: String) -> Dictionary:
	for w in LIST:
		if w.id == id:
			return w
	return LIST[0]

static func index_of(id: String) -> int:
	for i in range(LIST.size()):
		if LIST[i].id == id:
			return i
	return 0

static func unlocked_for(level: int) -> Array:
	var out: Array = []
	for w in LIST:
		if int(w.unlock_level) <= level:
			out.append(w.id)
	return out
