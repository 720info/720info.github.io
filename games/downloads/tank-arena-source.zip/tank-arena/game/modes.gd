extends RefCounted
## 模式表。规则参数 + 结算奖励都集中在这里，game.gd 按 id 取用。
##
## 三种模式的设计意图：
##   死斗  —— 最直白，给「我就想打一架」的场合。20 杀 / 3 分钟封顶。
##   占点  —— 逼玩家离开掩体去中央争夺，把「躲着打」变成「必须动」。
##   生存  —— 合作刷波次，唯一的无限模式，也是「再玩一局」的钩子：
##            共享 5 条命，全灭即结束，记录最高波次，逼你一直刷新纪录。
##
## rules 字段说明：
##   "ffa"  —— 人人互为敌人（死斗）
##   "zone" —— 人人互为敌人，但分数来自占据控制区（占点）
##   "coop" —— 所有真人一队，敌人由系统按波次刷（生存）

const LIST := [
	{
		"id": "deathmatch",
		"name": "死斗",
		"subtitle": "先到 20 杀",
		"desc": "没有队友，见谁打谁。先累计 20 次击杀获胜，或 3 分钟后比谁分高。",
		"rules": "ffa",
		"kill_score": 1,
		"score_limit": 20,
		"time_limit": 180.0,
		"show_zone": false,
		"show_waves": false,
		"ai_opponents": true,
		"xp": {"kill": 10, "win": 120, "lose": 25},
	},
	{
		"id": "king",
		"name": "占点",
		"subtitle": "控制中央区域",
		"desc": "站进中央控制区就开始持续得分，区内每秒 +2。先到 100 分获胜。",
		"rules": "zone",
		"kill_score": 3,            # 击杀也算分，但占住区才是主要得分来源
		"score_limit": 100,
		"time_limit": 240.0,
		"capture_rate": 2.0,        # 每秒得分
		"show_zone": true,
		"show_waves": false,
		"ai_opponents": true,
		"xp": {"kill": 10, "capture": 1, "win": 150, "lose": 30},
	},
	{
		"id": "survival",
		"name": "生存",
		"subtitle": "合作抵挡电脑",
		"desc": "所有真人一队，电脑一波比一波多、一波比一波强。共享 5 条命，全灭结束，记录你撑到第几波。",
		"rules": "coop",
		"kill_score": 0,            # 生存模式用波次计分，击杀不加分
		"score_limit": 0,
		"time_limit": 0.0,
		"lives": 5,
		"wave_gap": 8.0,            # 波次之间的间歇
		"wave_base": 2,             # 第 1 波敌人数
		"wave_growth": 0.8,         # 每波额外增加
		"show_zone": false,
		"show_waves": true,
		"ai_opponents": false,      # AI 不由开局生成，而是按波次刷
		"xp": {"kill": 6, "wave": 40, "win": 0, "lose": 0},
	},
]

static func ids() -> Array:
	var out: Array = []
	for m in LIST:
		out.append(m.id)
	return out

static func get_mode(id: String) -> Dictionary:
	for m in LIST:
		if m.id == id:
			return m
	return LIST[0]

static func index_of(id: String) -> int:
	for i in range(LIST.size()):
		if LIST[i].id == id:
			return i
	return 0

## 该模式是否需要刷 AI 对手（开局就摆好）
static func spawns_ai_opponents(id: String) -> bool:
	return bool(get_mode(id).get("ai_opponents", true))

## 该模式是否按波次刷敌人
static func is_wave_mode(id: String) -> bool:
	return str(get_mode(id).get("rules", "ffa")) == "coop"

## 某波次的敌人数量
static func wave_size(id: String, wave: int) -> int:
	var m := get_mode(id)
	var base := float(m.get("wave_base", 2))
	var growth := float(m.get("wave_growth", 0.8))
	return maxi(1, int(round(base + growth * float(maxi(wave - 1, 0)))))
