extends CharacterBody2D
## 玩家 / AI 坦克
##
## 权威划分（混合网络模型）：
##   位置 —— 谁操控谁算。真人由本机模拟后上报，AI 由权威端模拟后广播。
##   血量/死亡/计分 —— 一律权威端裁定，通过 server_health / kill_feed 广播。
##
## 武器：数值全在 weapons.gd。真人可以随时用 1-4 / Q / E 换枪（换枪要上报给房主登记）。
## 涂装：只改「图案 + 点缀色」，车体主色仍是各玩家的槽位色，保证混战里认得出谁是谁。

const SPEED := 250.0
const MAX_HEALTH := 3
const RESPAWN_DELAY := 2.5
const RADIUS := 17.0
const BODY_TURN := 14.0
const NET_RATE := 1.0 / 30.0

# --- 管理员模式（作弊开关，P 键切换）---
const ADMIN_SPEED_MUL := 1.85
const ADMIN_FIRE_MUL := 0.11

const BulletScript := preload("res://game/bullet.gd")
const Weapons := preload("res://game/weapons.gd")
const Progress := preload("res://game/progress.gd")
const Modes := preload("res://game/modes.gd")
const UiTheme := preload("res://ui/ui_theme.gd")

var peer_id: int = 0
var player_name: String = "Player"
var color: Color = Color.WHITE
var spawn_point: Vector2 = Vector2.ZERO
var is_ai: bool = false
## 生存模式的波次敌人：被打死就不再复活，由权威端从名单里摘掉
var is_wave_ai: bool = false
var wave_no: int = 0
## 阵营。死斗/占点里每个玩家各成一队；生存模式里真人 0 队、波次敌人 1 队。
var team: int = 0
## 教学关靶子：只缓慢转向玩家，不主动开火；dummy_patrol 为真时绕着出生点转圈。
## 这些是纯客户端本地节点，不参与网络同步，所以逻辑不受「只在权威端跑」的限制。
var is_dummy: bool = false
var dummy_patrol: bool = false
var dummy_orbit: float = 0.9
var dummy_radius: float = 70.0
var _dummy_t: float = 0.0

var weapon_id: String = "mg"
var skin_id: String = "standard"
var admin: bool = false

var health: int = MAX_HEALTH
var alive: bool = true
## 当前连杀（不死的情况下连续击毁数），用于「势不可挡」这类挑战
var streak: int = 0

# --- AI 行为参数 ---
var _ai_turn: float = 4.0
var _ai_spread: float = 0.12
var _ai_fire_scale: float = 2.4
var _ai_react_t: float = 0.5
var _ai_lost_t: float = 0.0
var _ai_seen: bool = false
var _ai_strafe: float = 1.0
var _ai_wander_dir: Vector2 = Vector2.RIGHT
var _ai_wander_t: float = 0.0
var _ai_respawn_left: float = 0.0

var _body_rot: float = 0.0
var _turret_rot: float = 0.0
var _t_pos: Vector2 = Vector2.ZERO
var _t_body_rot: float = 0.0
var _t_turret_rot: float = 0.0

var _fire_cd: float = 0.0
var _net_accum: float = 0.0
var _flash: float = 0.0
var _local_respawn_left: float = 0.0
var _admin_ping: float = 0.0
var _muzzle: float = 0.0

var _game_node: Node = null
var _hull: Node2D
var _turret: Node2D
var _muzzle_flash: Polygon2D
var _hp_bar: Polygon2D
var _label: Label
var _admin_ring: Line2D

# ---------------------------------------------------------------- 生命周期

func _ready() -> void:
	add_to_group("tank")
	position = spawn_point
	_t_pos = position
	collision_layer = 1
	collision_mask = 2
	_build()
	_refresh_hp()
	_game_node = get_tree().get_first_node_in_group("game")

func is_local() -> bool:
	return peer_id == NetworkManager.local_id()

func is_authority() -> bool:
	return NetworkManager.is_authority()

# ---------------------------------------------------------------- 每帧

func _physics_process(delta: float) -> void:
	if is_ai:
		# AI 只在权威端跑逻辑，其他端一律插值 —— 否则各端 randf 不一致，画面会各走各的
		if is_authority():
			_ai_step(delta)
		else:
			_remote_step(delta)
	elif is_local():
		_local_step(delta)
	else:
		_remote_step(delta)
	_apply_visual(delta)

func _local_step(delta: float) -> void:
	if _fire_cd > 0.0:
		_fire_cd -= delta

	if not alive:
		velocity = Vector2.ZERO
		_local_respawn_left = maxf(0.0, _local_respawn_left - delta)
		_net_accum += delta
		if _net_accum >= NET_RATE:
			_net_accum = 0.0
			_push_state()
		return

	var dir := Vector2.ZERO
	if Input.is_action_pressed("move_left"):
		dir.x -= 1.0
	if Input.is_action_pressed("move_right"):
		dir.x += 1.0
	if Input.is_action_pressed("move_up"):
		dir.y -= 1.0
	if Input.is_action_pressed("move_down"):
		dir.y += 1.0
	dir = dir.normalized()

	velocity = dir * SPEED * (ADMIN_SPEED_MUL if admin else 1.0)
	move_and_slide()

	if dir.length() > 0.01:
		_body_rot = lerp_angle(_body_rot, dir.angle(), minf(1.0, BODY_TURN * delta))

	var aim := get_global_mouse_position() - global_position
	if aim.length() > 1.0:
		_turret_rot = aim.angle()

	if Input.is_action_pressed("fire") and _fire_cd <= 0.0:
		_fire()

	_net_accum += delta
	if _net_accum >= NET_RATE:
		_net_accum = 0.0
		_push_state()

func _remote_step(delta: float) -> void:
	var t := minf(1.0, 16.0 * delta)
	position = position.lerp(_t_pos, t)
	_body_rot = lerp_angle(_body_rot, _t_body_rot, t)
	_turret_rot = lerp_angle(_turret_rot, _t_turret_rot, t)
	velocity = Vector2.ZERO

# ---------------------------------------------------------------- AI

func _ai_step(delta: float) -> void:
	if _fire_cd > 0.0:
		_fire_cd -= delta

	if not alive:
		velocity = Vector2.ZERO
		if is_wave_ai or is_dummy:
			return                                  # 波次敌人 / 靶子死了就死了，不重生
		_ai_respawn_left = maxf(0.0, _ai_respawn_left - delta)
		if _ai_respawn_left <= 0.0:
			if NetworkManager.is_networked() and _game_node != null:
				_game_node.rpc_to_ready("respawn_player", [peer_id])
			else:
				do_respawn()
		return

	if is_dummy:
		_dummy_step(delta)
		return

	_push_state_throttled(delta)

	var target := _ai_find_target()
	if target == null:
		_ai_wander(delta)
		return

	var to_t: Vector2 = target.global_position - global_position
	var dist := to_t.length()
	var los := _ai_los_clear(target.global_position)
	var w := Weapons.get_weapon(weapon_id)
	var want_range := float(w.get("ai_range", 300.0))

	# 炮塔瞄准：有视线就快速跟，没视线就慢慢转过去
	var aim := to_t.angle()
	var turn := _ai_turn if los else _ai_turn * 0.45
	_turret_rot = lerp_angle(_turret_rot, aim, minf(1.0, turn * delta))

	# 走位：太远贴近、太近后撤、中距离绕圈（基准距离随武器变，霰弹会主动贴脸）
	var dir := Vector2.ZERO
	if los:
		if dist > want_range * 1.25:
			dir = to_t.normalized()
		elif dist < want_range * 0.62:
			dir = -to_t.normalized()
		else:
			dir = to_t.normalized().rotated(PI * 0.5) * _ai_strafe
	else:
		dir = to_t.normalized()

	velocity = dir * SPEED * 0.85
	var before := global_position
	move_and_slide()
	if dir.length() > 0.01 and global_position.distance_to(before) < 0.6:
		_ai_strafe = -_ai_strafe
		velocity = dir.rotated(PI * 0.35 * _ai_strafe) * SPEED * 0.85
		move_and_slide()
	if velocity.length() > 1.0:
		_body_rot = lerp_angle(_body_rot, velocity.angle(), minf(1.0, BODY_TURN * delta))

	# 反应延迟：刚看到目标时先愣一下；短暂被障碍遮挡不算「丢失目标」，
	# 否则 AI 绕圈时视线反复断开，会一直重置延迟、永远开不出枪。
	if los:
		_ai_lost_t = 0.0
		if not _ai_seen:
			_ai_seen = true
			_ai_react_t = randf_range(0.35, 0.75)
		_ai_react_t = maxf(0.0, _ai_react_t - delta)
	else:
		_ai_lost_t += delta
		if _ai_lost_t > 1.2:
			_ai_seen = false

	# 开火：有视线 + 进射程 + 炮口对准 + 反应完毕；越近越准，越远越飘
	var max_range := minf(float(w.speed) * float(w.life) * 0.55, 640.0)
	if los and dist < max_range and _fire_cd <= 0.0 and _ai_react_t <= 0.0:
		var tol := 0.14 if int(w.get("pellets", 1)) <= 1 else 0.22
		if absf(angle_difference(_turret_rot, to_t.angle())) < tol:
			var spread := _ai_spread * clampf(dist / 420.0, 0.45, 1.0)
			_fire(to_t.angle() + randf_range(-spread, spread))

## 教学关靶子：转向玩家给一点「被盯着」的压迫感，但不开火；
## dummy_patrol 打开后绕出生点做圆周巡逻，用来教「打移动目标要预判」。
func _dummy_step(delta: float) -> void:
	_push_state_throttled(delta)
	var tgt := _ai_find_target()
	if tgt != null:
		var aim: float = (tgt.global_position - global_position).angle()
		_turret_rot = lerp_angle(_turret_rot, aim, minf(1.0, 1.6 * delta))
	if not dummy_patrol:
		velocity = Vector2.ZERO
		return
	_dummy_t += delta
	var ang := _dummy_t * dummy_orbit
	var want: Vector2 = spawn_point + Vector2(cos(ang), sin(ang)) * dummy_radius
	var to := want - global_position
	velocity = to.limit_length(150.0)
	move_and_slide()
	if velocity.length() > 4.0:
		_body_rot = lerp_angle(_body_rot, velocity.angle(), minf(1.0, BODY_TURN * delta))

## 选最近的活着的敌人（不分真人还是电脑），同阵营不打
func _ai_find_target() -> Node:
	var best: Node = null
	var best_d := INF
	for p in get_tree().get_nodes_in_group("tank"):
		if p == self or not p.alive or int(p.team) == team:
			continue
		var d: float = global_position.distance_to(p.global_position)
		if d < best_d:
			best_d = d
			best = p
	return best

func _ai_los_clear(to: Vector2) -> bool:
	var space := get_world_2d().direct_space_state
	var q := PhysicsRayQueryParameters2D.create(global_position, to)
	q.collision_mask = 2
	q.exclude = [get_rid()]
	return space.intersect_ray(q).is_empty()

func _ai_wander(delta: float) -> void:
	_push_state_throttled(delta)
	_ai_wander_t -= delta
	if _ai_wander_t <= 0.0:
		_ai_wander_t = randf_range(1.2, 2.8)
		_ai_wander_dir = Vector2.RIGHT.rotated(randf() * TAU)
	velocity = _ai_wander_dir * SPEED * 0.6
	var before := global_position
	move_and_slide()
	if global_position.distance_to(before) < 0.6:
		_ai_wander_t = 0.0
	if velocity.length() > 1.0:
		_body_rot = lerp_angle(_body_rot, velocity.angle(), minf(1.0, BODY_TURN * delta))
	_turret_rot = lerp_angle(_turret_rot, _body_rot, minf(1.0, 3.0 * delta))

## AI 由权威端模拟，所以它的位置也要按 30Hz 广播出去
func _push_state_throttled(delta: float) -> void:
	if not NetworkManager.is_networked():
		return
	_net_accum += delta
	if _net_accum >= NET_RATE:
		_net_accum = 0.0
		_push_state()

func _apply_visual(delta: float) -> void:
	if _hull:
		_hull.rotation = _body_rot
	if _turret:
		_turret.rotation = _turret_rot
	if _muzzle > 0.0:
		_muzzle = maxf(0.0, _muzzle - delta * 9.0)
		if _muzzle_flash != null:
			_muzzle_flash.modulate = Color(1, 1, 1, _muzzle)
			_muzzle_flash.visible = _muzzle > 0.01
	if _admin_ping > 0.0:
		_admin_ping = maxf(0.0, _admin_ping - delta * 2.4)
	if _admin_ring != null and _admin_ring.visible:
		var pulse := 0.86 + 0.14 * sin(Time.get_ticks_msec() / 240.0)
		var a := clampf(pulse + _admin_ping, 0.0, 1.0)
		_admin_ring.modulate = Color(1, 1, 1, a)
		_admin_ring.width = 3.0 + 2.6 * _admin_ping
	if _flash > 0.0:
		_flash = maxf(0.0, _flash - delta * 4.0)
		modulate = Color(1.0 + _flash * 3.0, 1.0 - _flash, 1.0 - _flash, 1.0)
	elif modulate != Color.WHITE:
		modulate = Color.WHITE

# ---------------------------------------------------------------- 武器

func set_weapon(id: String) -> void:
	weapon_id = id
	_fire_cd = 0.0

## 真人换枪：本地立刻生效，联机时再上报给房主登记（用于击杀播报和观战显示）
func switch_weapon(id: String) -> void:
	if not Profile.is_weapon_unlocked(id):
		return
	if id == weapon_id:
		return
	set_weapon(id)
	Sfx.play_switch(global_position)
	if _game_node != null and _game_node.has_method("on_local_weapon_changed"):
		_game_node.on_local_weapon_changed(id)

func cycle_weapon(step: int) -> void:
	var unlocked: Array = Profile.unlocked_weapons()
	if unlocked.size() <= 1:
		return
	var i := unlocked.find(weapon_id)
	if i < 0:
		i = 0
	var n := unlocked.size()
	switch_weapon(str(unlocked[((i + step) % n + n) % n]))

func fire_cooldown() -> float:
	var w := Weapons.get_weapon(weapon_id)
	return float(w.fire_cd) * (ADMIN_FIRE_MUL if admin else 1.0)

# ---------------------------------------------------------------- 网络上报

func _push_state() -> void:
	if not NetworkManager.is_networked() or _game_node == null:
		return
	if NetworkManager.is_authority():
		_game_node.rpc_to_ready("server_state", [peer_id, position, _body_rot, _turret_rot])
	else:
		_game_node.rpc_id(1, "client_state", position, _body_rot, _turret_rot)

## 由 game.gd 在收到同步数据后调用
func set_net_target(pos: Vector2, b_rot: float, t_rot: float) -> void:
	_t_pos = pos
	_t_body_rot = b_rot
	_t_turret_rot = t_rot

func set_net_health(hp: int, alv: bool) -> void:
	var was_alive := alive
	var prev_hp := health
	health = hp
	alive = alv
	visible = alv
	_refresh_hp()
	if not alv and was_alive:
		_flash = 1.0
		_local_respawn_left = RESPAWN_DELAY
		Sfx.play_death(global_position)
	elif hp < prev_hp:
		_flash = 1.0
		Sfx.play_hit(global_position)

# ---------------------------------------------------------------- 开火

## angle_override 用于 AI 加散布；真人则按当前炮塔朝向 + 武器散布
func _fire(angle_override: float = NAN) -> void:
	var base := _turret_rot
	if not is_nan(angle_override):
		base = angle_override

	var w := Weapons.get_weapon(weapon_id)
	var pellets := int(w.get("pellets", 1))
	var spread := float(w.get("spread", 0.0))
	var angles := PackedFloat32Array()

	for i in range(pellets):
		var a := base
		if pellets > 1:
			# 扇面均匀铺开，再加一点抖动，避免每发都长得一模一样
			var t := float(i) / float(pellets - 1) - 0.5
			a += t * spread * 2.0 + randf_range(-0.022, 0.022)
		elif spread > 0.0:
			a += randf_range(-1.0, 1.0) * spread
		angles.append(a)

	_fire_cd = fire_cooldown()
	_muzzle = 1.0
	# 后坐力：把车往后推一点点。重武器推得明显，是「这枪很重」的主要体感来源
	var kick := float(w.get("recoil", 0.0)) * 90.0
	if kick > 0.01:
		move_and_collide(Vector2.RIGHT.rotated(base) * -kick)

	var origin := global_position
	if not NetworkManager.is_networked():
		_spawn_bullets(peer_id, origin, angles)
		return
	if _game_node == null:
		return
	if NetworkManager.is_authority():
		_game_node.rpc_to_ready("spawn_bullet", [peer_id, origin, angles, weapon_id])
	else:
		_game_node.rpc_id(1, "request_fire", origin, angles, weapon_id)

func _spawn_bullets(shooter: int, origin: Vector2, angles: PackedFloat32Array) -> void:
	for a in angles:
		_spawn_one(shooter, origin, a)

func _spawn_one(shooter: int, origin: Vector2, angle: float) -> void:
	var b = BulletScript.new()
	b.shooter_id = shooter
	b.direction = Vector2.RIGHT.rotated(angle)
	b.position = origin + b.direction * 26.0
	b.authoritative = NetworkManager.is_authority()
	b.setup(weapon_id, color)
	var holder = null
	if _game_node != null:
		holder = _game_node.get_node_or_null("Bullets")
	if holder == null:
		holder = _game_node
	if holder == null:
		return
	holder.add_child(b)

# ---------------------------------------------------------------- 受击 / 死亡（权威端）

func take_damage(from_id: int, amount: int = 1, weapon: String = "mg") -> void:
	if not NetworkManager.is_authority() or not alive:
		return
	if admin:
		# 无敌：炮弹被吸收，不扣血。给一发护盾音反馈，但不播受击/死亡特效。
		Sfx.play_shield(global_position)
		_admin_ping = 1.0
		return
	health -= amount
	# 打中了但没打死，也要给射击者一个准星反馈
	if from_id != peer_id and from_id == NetworkManager.local_id() and health > 0:
		if _game_node != null and NetworkManager.is_networked():
			_game_node.rpc_id(from_id, "hit_confirm", amount, false)
	if health <= 0:
		health = 0
		alive = false
		streak = 0
		velocity = Vector2.ZERO
		_ai_respawn_left = RESPAWN_DELAY
		_local_respawn_left = RESPAWN_DELAY
		var st := _on_killed_by(from_id, weapon)
		if _game_node != null:
			if NetworkManager.is_networked():
				_game_node.rpc_to_ready("kill_feed", [from_id, peer_id, weapon, st])
			else:
				_game_node.kill_feed(from_id, peer_id, weapon, st)
		if not is_wave_ai and not is_dummy:
			_schedule_respawn()
	_broadcast_health()

## 权威端结算：加分 + 记档案，返回击杀者当前的连杀数（用于击杀播报）
func _on_killed_by(from_id: int, weapon: String) -> int:
	var mode := Modes.get_mode(NetworkManager.mode_id)
	NetworkManager.submit_score(from_id, int(mode.get("kill_score", 1)))

	# 教学关的靶子不算战绩，否则开一局教学就能刷「百人斩」
	var tutorial := _in_tutorial()
	if from_id == NetworkManager.local_id() and not tutorial:
		Profile.record_kill(weapon)
	if peer_id == NetworkManager.local_id() and not tutorial:
		Profile.record_death()

	var st := 0
	var g = get_tree().get_first_node_in_group("game")
	if g != null and g.has_method("note_kill"):
		st = int(g.note_kill(from_id))
	return st

func _in_tutorial() -> bool:
	var t := get_tree()
	return t != null and t.get_first_node_in_group("tutorial") != null

func _broadcast_health() -> void:
	if _game_node == null or not NetworkManager.is_networked():
		return
	_game_node.rpc_to_ready("server_health", [peer_id, health, alive])

func _schedule_respawn() -> void:
	if is_ai:
		return                       # AI 由 _ai_step 里的倒计时自行重生
	await get_tree().create_timer(RESPAWN_DELAY).timeout
	if not is_inside_tree() or alive:
		return
	if NetworkManager.is_networked() and _game_node != null:
		_game_node.rpc_to_ready("respawn_player", [peer_id])
	else:
		do_respawn()

## 所有端统一执行：把该玩家复位到出生点
func do_respawn() -> void:
	health = MAX_HEALTH
	alive = true
	position = spawn_point
	_t_pos = position
	visible = true
	_local_respawn_left = 0.0
	_refresh_hp()

## 生存模式换波时把玩家拉回出生点
func warp_to(p: Vector2) -> void:
	position = p
	_t_pos = p

# ---------------------------------------------------------------- 管理员模式

## 切换管理员模式，返回是否真的变化了（用来避免重复弹提示）
func set_admin(on: bool) -> bool:
	if admin == on:
		return false
	admin = on
	if _admin_ring != null:
		_admin_ring.visible = on
	_update_label()
	return true

# ---------------------------------------------------------------- 外观

func _build() -> void:
	var cs := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = RADIUS
	cs.shape = shape
	add_child(cs)

	_hull = Node2D.new()
	add_child(_hull)
	var hull_poly := PackedVector2Array([
		Vector2(-18, -13), Vector2(13, -13), Vector2(20, -7), Vector2(20, 7),
		Vector2(13, 13), Vector2(-18, 13),
	])
	var hull := Polygon2D.new()
	hull.polygon = hull_poly
	hull.color = color
	_hull.add_child(hull)

	_build_skin(hull_poly)

	var hull_edge := Line2D.new()
	hull_edge.points = PackedVector2Array([
		hull_poly[0], hull_poly[1], hull_poly[2], hull_poly[3], hull_poly[4], hull_poly[5], hull_poly[0]
	])
	hull_edge.width = 2.0
	hull_edge.default_color = color.lightened(0.45)
	_hull.add_child(hull_edge)

	_turret = Node2D.new()
	add_child(_turret)
	var dome := Polygon2D.new()
	dome.polygon = _circle_pts(9.0, 14)
	dome.color = color.darkened(0.18)
	_turret.add_child(dome)
	var barrel := Polygon2D.new()
	barrel.polygon = PackedVector2Array([
		Vector2(2, -4), Vector2(26, -4), Vector2(26, 4), Vector2(2, 4)
	])
	barrel.color = color.lightened(0.3)
	_turret.add_child(barrel)
	# 炮口焰：开火瞬间亮一下，是「打出去了」最直接的反馈
	_muzzle_flash = Polygon2D.new()
	_muzzle_flash.polygon = PackedVector2Array([
		Vector2(26, -7), Vector2(42, 0), Vector2(26, 7), Vector2(30, 0)
	])
	_muzzle_flash.color = Color(1.0, 0.93, 0.72, 0.9)
	_muzzle_flash.visible = false
	_turret.add_child(_muzzle_flash)

	# 管理员光环：画在最上层，开启时才显示
	_admin_ring = Line2D.new()
	var ring_pts := _circle_pts(RADIUS + 8.0, 28)
	ring_pts.append(ring_pts[0])
	_admin_ring.points = ring_pts
	_admin_ring.width = 3.0
	_admin_ring.default_color = Color(1.0, 0.835, 0.290)
	_admin_ring.visible = false
	add_child(_admin_ring)

	var hp_root := Node2D.new()
	hp_root.position = Vector2(0, -30)
	add_child(hp_root)
	var hp_bg := Polygon2D.new()
	hp_bg.polygon = PackedVector2Array([
		Vector2(-20, -4), Vector2(20, -4), Vector2(20, 4), Vector2(-20, 4)
	])
	hp_bg.color = Color(0, 0, 0, 0.6)
	hp_root.add_child(hp_bg)
	_hp_bar = Polygon2D.new()
	hp_root.add_child(_hp_bar)

	_label = Label.new()
	_label.position = Vector2(-70, -54)
	_label.size = Vector2(140, 20)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 13)
	_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_label.add_theme_constant_override("outline_size", 4)
	add_child(_label)
	# 名字标签挂在 CharacterBody2D 下，主题链断了，得自己补挂（见 ui/ui_theme.gd）
	UiTheme.attach(_label)
	_update_label()

## 涂装图案。全部按「一定落在车体轮廓内」来设计，所以不需要裁剪。
func _build_skin(hull_poly: PackedVector2Array) -> void:
	var sk := Progress.get_skin(skin_id)
	var pattern := str(sk.get("pattern", "solid"))
	var trim: Color = sk.get("trim", Color(1, 1, 1, 0.0))

	match pattern:
		"stripe":
			# 两道斜纹：向右上方剪切，端点都留在车体内
			for x0 in [-9.0, 2.0]:
				var p := Polygon2D.new()
				p.polygon = PackedVector2Array([
					Vector2(x0, -11), Vector2(x0 + 4.5, -11),
					Vector2(x0 + 4.5 + 6, 11), Vector2(x0 + 6, 11),
				])
				p.color = trim
				_hull.add_child(p)
		"camo":
			# 三块不规则斑块
			var blobs := [
				[Vector2(-14, -9), Vector2(-4, -11), Vector2(-2, -3), Vector2(-8, 1), Vector2(-15, -2)],
				[Vector2(0, 2), Vector2(9, -1), Vector2(14, 4), Vector2(10, 10), Vector2(2, 9)],
				[Vector2(-12, 5), Vector2(-4, 6), Vector2(-6, 12), Vector2(-13, 11)],
			]
			for b in blobs:
				var p := Polygon2D.new()
				p.polygon = PackedVector2Array(b)
				p.color = trim
				_hull.add_child(p)
		"hex":
			# 六边形网格覆层
			for gx in range(-2, 3):
				for gy in range(-1, 2):
					var pos := Vector2(gx * 8.0 + (4.0 if gy % 2 != 0 else 0.0), gy * 7.4)
					if absf(pos.x) > 14.0 or absf(pos.y) > 8.5:
						continue
					var p := Polygon2D.new()
					p.polygon = _circle_pts(4.2, 6)
					p.position = pos
					p.color = trim
					_hull.add_child(p)
		"neon":
			# 亮色描边，暗处也认得出
			var glow := Line2D.new()
			var pts := PackedVector2Array(hull_poly)
			pts.append(hull_poly[0])
			glow.points = pts
			glow.width = 3.4
			glow.default_color = Color(trim.r, trim.g, trim.b, 0.85)
			_hull.add_child(glow)
		"solid":
			if trim.a > 0.01:
				var p := Polygon2D.new()
				p.polygon = hull_poly
				p.color = Color(trim.r, trim.g, trim.b, trim.a * 0.5)
				_hull.add_child(p)
		_:
			pass

func set_player_name(n: String) -> void:
	player_name = n
	_update_label()

func _update_label() -> void:
	if _label == null:
		return
	_label.text = ("★ " if admin else "") + player_name
	_label.add_theme_color_override("font_color",
		Color(1.0, 0.835, 0.290) if admin else Color(1, 1, 1, 0.88))

func _refresh_hp() -> void:
	if _hp_bar == null:
		return
	var ratio := float(maxi(health, 0)) / float(MAX_HEALTH)
	var w := 40.0 * ratio
	_hp_bar.polygon = PackedVector2Array([
		Vector2(-20, -4), Vector2(-20 + w, -4), Vector2(-20 + w, 4), Vector2(-20, 4)
	])
	_hp_bar.color = Color(0.937, 0.267, 0.267).lerp(Color(0.290, 0.871, 0.502), ratio)

func _circle_pts(r: float, seg: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in range(seg):
		var a := TAU * float(i) / float(seg)
		pts.append(Vector2(cos(a), sin(a)) * r)
	return pts
