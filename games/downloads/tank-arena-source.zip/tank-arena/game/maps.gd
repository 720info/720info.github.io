extends RefCounted
## 地图表。每张图 = 障碍布局 + 视觉主题 + 出生点 + 模式锚点。
##
## 约定：
##  - 逻辑尺寸固定 1280x720，边界墙厚 24，可活动区域 x∈[24,1256] y∈[24,696]。
##  - 所有布局硬编码，各端完全一致，零同步成本（只有地图 id 需要同步）。
##  - 出生点 8 个，和玩家 id 取模对应；AI 波次默认复用同一组（见 arena.ai_spawn_for）。
##    出生点必须同时满足「不卡在障碍里」和「不被 HUD 面板压住」——
##    后者肉眼极难发现，靠 `--selftest` 的出生点遮挡检查守护，改地图后务必重跑。
##  - capture 是占点模式的控制区，位置要落在真正开阔的地方（别压在墙上）。
##
## 颜色一律用 Color(r,g,b) 浮点构造，这样整个字典能写成 const。

const W := 1280.0
const H := 720.0
const WALL := 24.0

const LIST := [
	{
		"id": "yard",
		"name": "训练场",
		"subtitle": "对称开阔 · 适合新手",
		"blocks": [
			Rect2(320, 236, 120, 34),
			Rect2(840, 236, 120, 34),
			Rect2(320, 450, 120, 34),
			Rect2(840, 450, 120, 34),
			Rect2(240, 330, 34, 60),
			Rect2(1006, 330, 34, 60),
			Rect2(596, 150, 88, 80),
			Rect2(596, 490, 88, 80),
			Rect2(556, 336, 168, 48),
		],
		"spawns": [
			Vector2(180, 200), Vector2(1100, 200), Vector2(180, 540), Vector2(1100, 540),
			Vector2(640, 255), Vector2(640, 465), Vector2(180, 360), Vector2(1100, 360),
		],
		"capture": Vector2(640, 360),
		"capture_r": 80.0,
		"theme": {
			"floor": Color(0.055, 0.078, 0.125),
			"floor_glow": Color(0.075, 0.125, 0.200),
			"grid": Color(1, 1, 1, 0.035),
			"grid_style": "grid",
			"block": Color(0.149, 0.208, 0.306),
			"block_top": Color(0.196, 0.271, 0.392),
			"edge": Color(0.271, 0.416, 0.612),
			"accent": Color(0.376, 0.647, 0.980),
		},
	},
	{
		"id": "crossroads",
		"name": "十字街区",
		"subtitle": "四角房间 · 中央路口",
		"blocks": [
			# 中央十字，中间留出一个 100x100 的开阔路口（占点区就放这）
			Rect2(608, 200, 64, 110),
			Rect2(608, 410, 64, 110),
			Rect2(360, 328, 180, 64),
			Rect2(740, 328, 180, 64),
			# 四角 L 形房间
			Rect2(140, 150, 170, 30), Rect2(140, 150, 30, 170),
			Rect2(970, 150, 170, 30), Rect2(1110, 150, 30, 170),
			Rect2(140, 540, 170, 30), Rect2(140, 400, 30, 170),
			Rect2(970, 540, 170, 30), Rect2(1110, 400, 30, 170),
			# 零散掩体
			Rect2(300, 250, 44, 44),
			Rect2(936, 250, 44, 44),
			Rect2(300, 426, 44, 44),
			Rect2(936, 426, 44, 44),
		],
		"spawns": [
			Vector2(200, 215), Vector2(1070, 215), Vector2(200, 515), Vector2(1070, 515),
			Vector2(640, 172), Vector2(640, 545), Vector2(200, 360), Vector2(1070, 360),
		],
		"capture": Vector2(640, 360),
		"capture_r": 50.0,
		"theme": {
			"floor": Color(0.098, 0.078, 0.063),
			"floor_glow": Color(0.180, 0.130, 0.086),
			"grid": Color(1, 0.85, 0.6, 0.045),
			"grid_style": "slabs",
			"block": Color(0.290, 0.220, 0.165),
			"block_top": Color(0.365, 0.278, 0.208),
			"edge": Color(0.541, 0.392, 0.251),
			"accent": Color(0.961, 0.620, 0.043),
		},
	},
	{
		"id": "hive",
		"name": "蜂巢",
		"subtitle": "密集掩体 · 短兵相接",
		"blocks": [
			Rect2(250, 190, 46, 46), Rect2(430, 190, 46, 46),
			Rect2(850, 190, 46, 46), Rect2(1030, 190, 46, 46),
			Rect2(250, 360, 46, 46), Rect2(430, 360, 46, 46),
			Rect2(850, 360, 46, 46), Rect2(1030, 360, 46, 46),
			Rect2(250, 530, 46, 46), Rect2(430, 530, 46, 46),
			Rect2(850, 530, 46, 46), Rect2(1030, 530, 46, 46),
			# 中央上下两块，把控制区夹成一条走廊
			Rect2(600, 250, 80, 36),
			Rect2(600, 434, 80, 36),
		],
		"spawns": [
			Vector2(180, 200), Vector2(1100, 200), Vector2(180, 540), Vector2(1100, 540),
			Vector2(640, 200), Vector2(640, 540), Vector2(180, 360), Vector2(1100, 360),
		],
		"capture": Vector2(640, 360),
		"capture_r": 60.0,
		"theme": {
			"floor": Color(0.071, 0.055, 0.118),
			"floor_glow": Color(0.130, 0.090, 0.210),
			"grid": Color(0.7, 0.6, 1.0, 0.05),
			"grid_style": "dots",
			"block": Color(0.227, 0.184, 0.337),
			"block_top": Color(0.294, 0.239, 0.427),
			"edge": Color(0.486, 0.416, 0.722),
			"accent": Color(0.655, 0.545, 0.980),
		},
	},
	{
		"id": "atoll",
		"name": "环礁",
		"subtitle": "中央堡垒 · 四门可破",
		"blocks": [
			# 中央方环，四个角是缺口（门）
			Rect2(540, 220, 200, 26),
			Rect2(540, 474, 200, 26),
			Rect2(480, 300, 26, 120),
			Rect2(774, 300, 26, 120),
			# 环外掩体
			Rect2(300, 140, 90, 30),
			Rect2(890, 140, 90, 30),
			Rect2(300, 550, 90, 30),
			Rect2(890, 550, 90, 30),
			Rect2(120, 330, 30, 80),
			Rect2(1130, 330, 30, 80),
			# 环内小掩体
			Rect2(600, 300, 30, 30),
			Rect2(650, 390, 30, 30),
		],
		"spawns": [
			Vector2(180, 200), Vector2(1100, 200), Vector2(180, 540), Vector2(1100, 540),
			Vector2(640, 190), Vector2(640, 540), Vector2(180, 360), Vector2(1100, 360),
		],
		"capture": Vector2(640, 360),
		"capture_r": 95.0,
		"theme": {
			"floor": Color(0.039, 0.102, 0.094),
			"floor_glow": Color(0.055, 0.180, 0.165),
			"grid": Color(0.5, 1.0, 0.9, 0.05),
			"grid_style": "diag",
			"block": Color(0.122, 0.290, 0.259),
			"block_top": Color(0.161, 0.361, 0.322),
			"edge": Color(0.247, 0.627, 0.557),
			"accent": Color(0.133, 0.827, 0.933),
		},
	},
]

const PLAYER_COLORS := [
	Color(1.000, 0.361, 0.361), Color(0.290, 0.871, 0.502),
	Color(0.376, 0.647, 0.980), Color(0.984, 0.749, 0.141),
	Color(0.957, 0.447, 0.714), Color(0.133, 0.827, 0.933),
	Color(0.984, 0.573, 0.235), Color(0.655, 0.545, 0.980),
]

static func ids() -> Array:
	var out: Array = []
	for m in LIST:
		out.append(m.id)
	return out

static func get_map(id: String) -> Dictionary:
	for m in LIST:
		if m.id == id:
			return m
	return LIST[0]

static func index_of(id: String) -> int:
	for i in range(LIST.size()):
		if LIST[i].id == id:
			return i
	return 0

static func random_id(rng: RandomNumberGenerator = null) -> String:
	if rng == null:
		return LIST[randi() % LIST.size()].id
	return LIST[rng.randi() % LIST.size()].id
