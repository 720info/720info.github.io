#!/usr/bin/env python3
"""用无头 Chrome + CDP 对 Web 版做真实交互验收。

为什么不用 agent-browser：它要另下一份 Chromium（约 500MB），
而本机已经有 Playwright 的 chrome-headless-shell，直接用更轻。

用法：
    # 1) 先起服务器（另起一个常驻任务）
    python3 build/web/godot_web_server.py 8791
    # 2) 跑验收（mode 省略 = basic）
    python3 tools/web_verify.py http://127.0.0.1:8791/index.html /tmp/webshots
    python3 tools/web_verify.py http://127.0.0.1:8791/index.html /tmp/webshots boss
    python3 tools/web_verify.py http://127.0.0.1:8791/index.html /tmp/webshots shot build/web

三种模式：
  basic —— 真按键/点击：等引擎起来 → 截图主菜单 → 点「开始游戏」→ 截图对局
           → 按 Q → 截图作弊面板。主要看中文有没有豆腐块、元素有没有跑出画布。
  boss  —— 借作弊面板把波次推到首领波，再连拍等首领出场（会开无敌模式，
           否则玩家站着挨打十几秒会死）。
  shot  —— 推荐。往临时 HTML 里注入 GODOT_CONFIG.args=["--","--shot"]，
           让游戏自己把 7 个调试布景依次摆出来（含首领对峙），我们从外面连拍。
           Web shell 不读 URL 查询参数，但 GODOT_CONFIG.args 是明文，可以改。

不管哪种模式，都把浏览器控制台里的 error 收集出来一起打印。
"""

import base64
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request

CHROME = os.path.expanduser(
    "~/Library/Caches/ms-playwright/chromium_headless_shell-1243/"
    "chrome-headless-shell-mac-arm64/chrome-headless-shell"
)
# 写死端口有个坑：上一次跑崩了、Chrome 还占着端口时，新进程绑不上，
# 而 http_json("/json") 会连到**旧的**那个实例上，于是截图一直超时。
# 每次挑一个当前空闲的端口，省掉这类幽灵故障。
PORT = 0


def pick_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# 启动参数集中放一处：下面两条坑都踩过，别再复制粘贴到第二个地方。
CHROME_FLAGS = [
    # 不加这条，websocket-client 带 Origin 头握手会被 403 拒掉
    "--remote-allow-origins=*",
    "--window-size=1280,720", "--hide-scrollbars",
    # ⚠️ 别再写 --use-gl=swiftshader（老写法）：当前 Chrome 会报
    # 「Requested GL implementation (gl=none,angle=none) not found」，
    # GPU 进程直接退出 → WebGL 上下文丢失（CONTEXT_LOST_WEBGL）→
    # 之后每次 captureScreenshot 都超时。必须用 ANGLE 的写法。
    "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
    "--no-sandbox", "--disable-dev-shm-usage",
]


def launch_chrome(url, out, port):
    """起一个无头 Chrome。stderr 留文件：中途崩了只有这里能看出原因。"""
    chrome_log = open(f"{out}/_chrome.log", "wb")
    return subprocess.Popen(
        [CHROME, "--headless=new", f"--remote-debugging-port={port}", *CHROME_FLAGS, url],
        stdout=chrome_log, stderr=subprocess.STDOUT)


def attach(port, tries=40):
    """等调试端口起来并连上第一个 page target。"""
    targets = None
    for _ in range(tries):
        try:
            targets = http_json("/json")
            break
        except Exception:
            time.sleep(0.5)
    if not targets:
        raise RuntimeError("调试端口没起来")
    page = next(t for t in targets if t["type"] == "page")
    c = Cdp(page["webSocketDebuggerUrl"])
    c.call("Page.enable")
    c.call("Runtime.enable")
    c.call("Log.enable")
    return c


def run_shot_mode(url, out, web_dir):
    """Web 版的「逐幕布景」验收：注入 --shot，把调试场景一个个拍下来。

    为什么走这条路：Web shell **不读 URL 查询参数**（index.js 里搜不到
    URLSearchParams / location.search），但 index.html 里的 GODOT_CONFIG.args
    是明文，复制一份改掉即可。main.gd 的 _run_shots() 会把场景依次摆成
    主菜单 → 对局 → 交火 → **首领** → 作弊面板 → 结算 → 暂停，每幕停 1~2.5 秒。

    _capture() 往 res:// 写 PNG 在 Web 上会失败，但它失败时只 printerr 再返回，
    不打断流程 —— 所以照样能把布景借过来，PNG 由我们从外面截。
    """
    tmp_name = "_shotcheck.html"
    tmp_path = os.path.join(web_dir, tmp_name)
    src = open(os.path.join(web_dir, "index.html"), encoding="utf-8").read()
    if '"args":[]' not in src:
        print('    index.html 里没找到 "args":[]，导出格式可能变了，跳过 shot 模式')
        return 1
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(src.replace('"args":[]', '"args":["--","--shot"]'))

    base = url.rsplit("/", 1)[0]
    tmp_url = f"{base}/{tmp_name}"
    proc = launch_chrome(tmp_url, out, PORT)
    try:
        c = attach(PORT)
        # 引擎启动（wasm 解码）耗时不定，从 5s 起每 0.8s 连拍，事后再挑。
        # 时间线：~2s 主菜单 → ~5.2s 对局 → ~6.8s 交火 → ~7~9.5s 首领 → ~10s 作弊面板
        print("[1] 注入 --shot，等引擎启动并连拍各幕 …")
        c.pump(5.0)
        boss_frame = None
        for i in range(48):
            p = f"{out}/shot_{i:02d}.png"
            c.shot(p)
            if boss_frame is None and has_boss_bar(p):
                boss_frame = p
                print(f"    第 {i:02d} 帧拍到首领（血条 + 模型）")
            c.pump(0.8)
        if boss_frame:
            shutil.copyfile(boss_frame, f"{out}/04_boss_web.png")
            print(f"    已存为 {out}/04_boss_web.png")
        else:
            print("    没拍到首领帧 —— 看图确认 _run_shots() 的时序是否变了")
        if c.errors:
            print(f"    浏览器控制台错误 {len(c.errors)} 条（前 3 条）：")
            for e in c.errors[:3]:
                print("      -", e[:160])
        return 0
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        if os.path.exists(tmp_path):
            os.remove(tmp_path)   # 临时 HTML 绝不能留在 build 目录里被发布出去


def http_json(path):
    with urllib.request.urlopen(f"http://127.0.0.1:{PORT}{path}", timeout=10) as r:
        return json.loads(r.read().decode())


class Cdp:
    """极简 CDP 客户端：只用到 Page/Runtime/Log/Input 四个域。"""

    def __init__(self, ws_url):
        import websocket  # websocket-client
        self.ws = websocket.create_connection(ws_url, timeout=60)
        self.n = 0
        self.errors = []

    def call(self, method, **params):
        self.n += 1
        mid = self.n
        # pump() 会把 socket 超时压到 0.3s，这里必须恢复，否则截图这种慢命令会超时。
        self.ws.settimeout(60)
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError(f"{method} -> {msg['error']}")
                return msg.get("result", {})
            self._note(msg)

    def _note(self, msg):
        m = msg.get("method")
        if m == "Log.entryAdded":
            e = msg["params"]["entry"]
            if e.get("level") == "error":
                self.errors.append(e.get("text", ""))
        elif m == "Runtime.exceptionThrown":
            d = msg["params"]["exceptionDetails"]
            self.errors.append(d.get("text", "") + " " + str(d.get("exception", {}).get("description", "")))

    def pump(self, secs):
        """在等待期间继续收消息，别把控制台错误漏掉。"""
        end = time.time() + secs
        self.ws.settimeout(0.3)
        while time.time() < end:
            try:
                self._note(json.loads(self.ws.recv()))
            except Exception:
                pass

    def shot(self, path, tries=3):
        # 软件渲染（swiftshader）偶尔会卡住一帧，captureScreenshot 一直不回。
        # 超时后重试即可，不必让整轮验收报废。
        err = None
        for _ in range(tries):
            try:
                r = self.call("Page.captureScreenshot", format="png")
                with open(path, "wb") as f:
                    f.write(base64.b64decode(r["data"]))
                return os.path.getsize(path)
            except Exception as e:
                err = e
                time.sleep(1.5)
        raise err

    def click(self, x, y):
        for t in ("mousePressed", "mouseReleased"):
            self.call("Input.dispatchMouseEvent", type=t, x=x, y=y,
                      button="left", clickCount=1, buttons=1 if t == "mousePressed" else 0)

    def key(self, code, key, vk):
        self.call("Input.dispatchKeyEvent", type="rawKeyDown", code=code, key=key,
                  windowsVirtualKeyCode=vk, nativeVirtualKeyCode=vk)
        self.call("Input.dispatchKeyEvent", type="keyUp", code=code, key=key,
                  windowsVirtualKeyCode=vk, nativeVirtualKeyCode=vk)


def has_boss_bar(path):
    """判断这一帧里有没有「首领血条」。

    血条填充色随血量插值：满血是**橙**（1.0,0.64,0.18 → 255,163,46），
    残血才偏红（0.95,0.20,0.16 → 242,51,41）。位置固定在屏幕上方正中
    （x 323..957, y 117..133）。

    ⚠️ 只放行「红」会漏掉满血的首领 —— 之前就是这样白跑了十几轮，
    最后靠人眼看图才发现血条其实一直在。现在放行到 g < 195。
    波次播报文字是黄橙（0.98,0.78,0.38 → g≈199），仍在阈值之外；
    再加一条「单行连续 ≥ 40 像素」把零散的文字边缘像素滤掉。
    """
    try:
        from PIL import Image
    except ImportError:
        return False
    im = Image.open(path).convert("RGB")
    if im.size != (1280, 720):
        return False
    for y in range(117, 134):
        run = 0
        for x in range(323, 958):
            r, g, b = im.getpixel((x, y))
            if r > 200 and g < 195 and b < 110:
                run += 1
                if run >= 40:      # 血条是实心长条，文字边缘凑不出 40 连像素
                    return True
            else:
                run = 0
    return False


def scan_boss_bars(out):
    """兜底：把目录里所有截图扫一遍，列出疑似有首领血条的帧。

    自动判定只用来**挑候选**，最终必须人眼看图确认，别把它当成验收结论。
    """
    import glob

    hits = []
    for p in sorted(glob.glob(f"{out}/*.png")):
        if has_boss_bar(p):
            hits.append(os.path.basename(p))
    if hits:
        print(f"    疑似出现首领血条的帧 {len(hits)} 张（待人工看图确认）：")
        for name in hits:
            print(f"      {name}")
    else:
        print("    没找到首领血条 —— 波次可能没推到 5 的倍数")


def main():
    global PORT
    url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8791/index.html"
    out = sys.argv[2] if len(sys.argv) > 2 else "/tmp/webshots"
    mode = sys.argv[3] if len(sys.argv) > 3 else "basic"
    web_dir = sys.argv[4] if len(sys.argv) > 4 else "build/web"
    os.makedirs(out, exist_ok=True)
    PORT = pick_port()

    if not os.path.exists(CHROME):
        print(f"找不到 chrome-headless-shell: {CHROME}")
        return 1

    # shot 模式：让游戏自己摆布景，比用作弊面板推波次可靠得多（首领在投放
    # 队列最后出场，推波次经常差几秒拍不到）。
    if mode == "shot":
        return run_shot_mode(url, out, web_dir)

    proc = launch_chrome(url, out, PORT)

    try:
        try:
            c = attach(PORT)
        except RuntimeError as e:
            print(e)
            return 1

        print("[1] 等引擎启动（wasm 解码 + 初始化）…")
        c.pump(18.0)
        n = c.shot(f"{out}/01_menu.png")
        print(f"    主菜单截图 {n} 字节")

        print("[2] 点「开始游戏」")
        c.click(640, 356)
        c.pump(6.0)
        n = c.shot(f"{out}/02_game.png")
        print(f"    对局截图 {n} 字节")

        print("[3] 按 Q 开作弊面板")
        c.key("KeyQ", "q", 81)
        c.pump(2.5)
        n = c.shot(f"{out}/03_cheats.png")
        print(f"    作弊面板截图 {n} 字节")

        if mode == "boss":
            # 作弊面板的按钮坐标（1280x720 逻辑坐标，实测校准过）：
            #   面板原点 (140,36)，第 2 列 COL_X=506，按钮 214x32
            #   秒杀全场 = 敌人组第 3 行 → (753, 274)
            #   立即下一波 = 敌人组第 5 行 → (753, 350)
            # 坐标验证办法：点完立刻截图，面板底部 toast 会显示「已击杀 N 名敌人」。
            print("[4] 借作弊面板把波次推到首领波（每 5 波一个首领）")
            # 注意：上一步的 Q 已经把面板打开了，所以循环体从「点击」开始，
            # 结尾才按 Q 关面板 —— 早先版本在这里又按一次 Q，导致面板被关掉、
            # 点击全落到游戏画布上（症状：得分一直是 0）。
            #
            # 一轮只稳推进 1 波：面板若开在「休整期」，「立即下一波」只是把
            # break_t 归零、并不会让 wave 自增，这一轮就白费了。
            # 首领在投放队列**最后**出场（第 10 波要 ~10s 才轮到它），
            # 所以不能推完就拍 —— 每轮关掉面板后连拍，直到拍到首领血条为止。
            #
            # 先开无敌：这一轮里玩家要站着挨打十几秒等首领出场，不开无敌会直接死。
            # 「无敌模式」= 战斗组第 1 行 → (281, 198)。
            c.click(281, 198)
            c.pump(0.8)
            c.shot(f"{out}/04_god_on.png")   # toast 应显示「无敌模式 已开启」
            KILL_ALL = (753, 274)
            NEXT_WAVE = (753, 350)
            FOUND = f"{out}/04_boss_web.png"
            ok = False
            for i in range(16):
                c.click(*KILL_ALL)          # 秒杀全场
                c.pump(0.5)
                c.click(*NEXT_WAVE)         # 立即下一波
                c.pump(0.5)
                c.key("KeyQ", "q", 81)      # 关面板（恢复运行）
                # 首领在投放队列**最后**出场：第 5 波 14 只 × 0.57s，要等
                # 开波后约 12s 才轮到它，而开波本身还要等 5s 休整。
                # 所以首领波必须拍满 ~24s，普通波快速过（一轮刚好推进 1 波，
                # 已用每轮末帧的状态栏核对过：r05_6=第5波、r10_6=第10波）。
                n_frames = 12 if (i + 1) % 5 == 0 else 3
                for k in range(n_frames):
                    c.pump(2.0)
                    f = f"{out}/r{i + 1:02d}_{k + 1}.png"   # 每帧都留证，便于回看推进到哪
                    c.shot(f)
                    if not ok and has_boss_bar(f):
                        shutil.copyfile(f, FOUND)
                        print(f"    第 {i + 1} 轮第 {k + 1} 帧拍到首领血条 → {FOUND}")
                        ok = True
                        # 不 break：首领是朝玩家走过来的，血条刚出现时它多半还在
                        # 视野外。继续拍完这一轮，后面几帧才可能拍到它的模型。
                if ok:
                    break
                print(f"    第 {i + 1} 轮没拍到首领，继续推进")
                c.key("KeyQ", "q", 81)      # 再开面板，准备下一轮
                c.pump(1.0)
            if not ok:
                c.key("KeyQ", "q", 81)
                c.pump(1.5)
                n = c.shot(FOUND)
                print(f"    没拍到首领血条，退回落帧（{n} 字节）")
            scan_boss_bars(out)

        if c.errors:
            print(f"\n浏览器控制台错误 {len(c.errors)} 条：")
            for e in c.errors[:10]:
                print("   -", e[:200])
        else:
            print("\n浏览器控制台无 error")
        return 0
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


if __name__ == "__main__":
    sys.exit(main())
