#!/usr/bin/env python3
"""为 Web 导出产物生成预压缩副本（.br / .gz）。

为什么需要：Godot 的 index.wasm 约 40MB。实测压缩收益极大 ——
    gzip -9 : 10.05MB（25.4%）
    brotli  :  6.90MB（17.5%）
不压缩的话首次加载要几分钟（实测部署环境约 212KB/s → 186 秒），
压缩后降到 30~50 秒。

配套的 `godot_web_server.py` 会在客户端 Accept-Encoding 允许时
自动返回这些预压缩文件（带 Content-Encoding 头）。

用法:
    python3 tools/compress_web.py [目录]        # 默认 build/web
"""
import gzip
import os
import pathlib
import shutil
import subprocess
import sys

COMPRESSIBLE = {".html", ".htm", ".js", ".mjs", ".wasm", ".pck", ".json", ".css", ".svg", ".txt"}
MIN_SIZE = 4096


def human(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return "%.2f %s" % (n, unit)
        n /= 1024.0
    return str(n)


def main() -> int:
    root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "build/web").resolve()
    if not root.is_dir():
        print("目录不存在: %s" % root)
        return 1

    has_brotli = shutil.which("brotli") is not None
    if not has_brotli:
        print("提示：本机没有 brotli 命令，只生成 .gz（浏览器仍可正常使用，只是压缩率低一些）")

    total_raw = 0
    total_gz = 0
    total_br = 0
    count = 0

    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        if p.suffix.lower() not in COMPRESSIBLE:
            continue
        # 别把压缩产物再压一遍
        if p.name.endswith((".br", ".gz")):
            continue
        size = p.stat().st_size
        if size < MIN_SIZE:
            continue

        count += 1
        total_raw += size
        rel = p.relative_to(root)

        # gzip（标准库，永远可用）
        gz_path = p.with_name(p.name + ".gz")
        with open(p, "rb") as src, gzip.open(gz_path, "wb", compresslevel=9) as dst:
            shutil.copyfileobj(src, dst, length=1 << 20)
        gz_size = gz_path.stat().st_size
        total_gz += gz_size

        # brotli（有就用）
        br_size = 0
        if has_brotli:
            br_path = p.with_name(p.name + ".br")
            with open(p, "rb") as src, open(br_path, "wb") as dst:
                subprocess.run(["brotli", "-q", "11", "-c"], stdin=src, stdout=dst, check=True)
            br_size = br_path.stat().st_size
            total_br += br_size

        print("  %-28s %10s → gz %9s%s" % (
            rel, human(size), human(gz_size),
            ("  br %9s" % human(br_size)) if br_size else ""))

    print()
    print("压缩 %d 个文件" % count)
    print("  原始:   %s" % human(total_raw))
    print("  gzip:   %s (%.1f%%)" % (human(total_gz), total_gz / max(total_raw, 1) * 100))
    if has_brotli:
        print("  brotli: %s (%.1f%%)" % (human(total_br), total_br / max(total_raw, 1) * 100))
    return 0


if __name__ == "__main__":
    sys.exit(main())
