#!/usr/bin/env python3
"""为 FPS Arena 的 Web 版生成中文字体子集。

为什么需要：Godot 的 SystemFont 在 Web 平台取不到系统字体
（OS.get_system_font_path() 未实现），中文会全渲染成豆腐块。
所以必须把中文字体打进包里 —— 但全量 Noto Sans SC 有 17.7MB，
子集化后约 1MB。

字符集 = GB2312 全集(6763 汉字 + 682 符号) ∪ 项目源码里出现的所有字符 ∪ ASCII
→ Noto Sans SC 可变字体实例化到 wght=400 → 输出 woff2

用法：
    # 1) 先下载可变字体到 /tmp/fontwork/vf.ttf
    curl -sL --noproxy '*' -o /tmp/fontwork/vf.ttf \
      "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf"
    # 2) 跑本脚本
    <venv>/bin/python tools/subset_font.py
    # 3) 把产物拷进 assets/fonts/
"""
import pathlib
import shutil
import subprocess

PROJ = pathlib.Path(__file__).resolve().parent.parent
WORK = pathlib.Path("/tmp/fontwork")
VENV = pathlib.Path("/Users/720coder/.workbuddy-ai/binaries/python/envs/default/bin")
PYFT = str(VENV / "pyftsubset")
FONTTOOLS = str(VENV / "fonttools")
OUT_DIR = PROJ / "assets" / "fonts"

chars: set[str] = set()

# --- 1. GB2312 全集：覆盖日常中文，动态拼出的字符串也不会缺字 ---
for hi in range(0xA1, 0xF8):
    for lo in range(0xA1, 0xFF):
        try:
            chars.add(bytes([hi, lo]).decode("gb2312"))
        except UnicodeDecodeError:
            pass

# --- 2. ASCII 可见字符 + 常用标点 ---
chars.update(chr(c) for c in range(0x20, 0x7F))
chars.update("　·—…‘’“”「」『』【】〈〉《》※→←↑↓★☆○●◆◇■□▲△▼▽×÷±°§¶†‡")

# --- 3. 项目源码里出现过的所有字符 ---
exts = {".gd", ".tscn", ".tres", ".cfg", ".godot", ".md", ".json", ".txt", ".svg"}
scanned = 0
for p in PROJ.rglob("*"):
    if not p.is_file() or p.suffix.lower() not in exts:
        continue
    if any(part in {"build", ".godot", "tools"} for part in p.parts):
        continue
    try:
        text = p.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        continue
    chars.update(text)
    scanned += 1

# 去掉控制字符与私用区
chars = {c for c in chars if c.isprintable() and not (0xE000 <= ord(c) <= 0xF8FF)}
chars.discard("\ufffd")

print(f"扫描源文件 {scanned} 个，字符集共 {len(chars)} 个码位")

WORK.mkdir(parents=True, exist_ok=True)
unicodes = sorted(ord(c) for c in chars)
(WORK / "unicodes.txt").write_text(
    "\n".join(f"U+{u:04X}" for u in unicodes), encoding="utf-8"
)

# --- 4. 可变字体实例化到 Regular ---
instanced = WORK / "NotoSansSC-Regular.ttf"
subprocess.run(
    [
        FONTTOOLS, "varLib.instancer",
        "-o", str(instanced), str(WORK / "vf.ttf"),
        "wght=400",
        # 不加 --update-name-table，name 表会残留 "Noto Sans SC Thin"
        "--update-name-table",
    ],
    check=True,
)
print("实例化完成:", instanced.stat().st_size, "bytes")

# --- 5. 子集化 + woff2 ---
out = WORK / "NotoSansSC-Regular.woff2"
subprocess.run(
    [
        PYFT,
        str(instanced),
        f"--unicodes-file={WORK / 'unicodes.txt'}",
        f"--output-file={out}",
        "--flavor=woff2",
        "--layout-features=kern,liga,vert,vrt2,palt,halt",
        # 不带 --name-IDs 会把名字表裁掉
        "--name-IDs=0,1,2,3,4,5,6",
        "--no-hinting",
        "--desubroutinize",
    ],
    check=True,
)
print("子集化完成:", out, out.stat().st_size, "bytes")

OUT_DIR.mkdir(parents=True, exist_ok=True)
shutil.copy2(out, OUT_DIR / out.name)
shutil.copy2(WORK / "OFL.txt", OUT_DIR / "OFL.txt")
print("已拷入:", OUT_DIR / out.name)
