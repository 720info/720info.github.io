#!/usr/bin/env bash
# FPS Arena 启动脚本
set -e
cd "$(dirname "$0")"

GODOT="${GODOT:-/Applications/Godot.app/Contents/MacOS/Godot}"
if [ ! -x "$GODOT" ]; then
  echo "找不到 Godot：$GODOT"
  echo "请设置环境变量，例如： export GODOT=/path/to/Godot"
  exit 1
fi

PYTHON="${PYTHON:-/Users/720coder/.workbuddy-ai/binaries/python/versions/3.13.12/bin/python3}"

case "${1:-play}" in
  play)     "$GODOT" --path . ;;
  test)     "$GODOT" --headless --path . -- --selftest ;;
  sim)      "$GODOT" --headless --path . -- --sim="${2:-40}" ;;
  simdie)   "$GODOT" --headless --path . -- --simdie="${2:-30}" ;;
  shots)    "$GODOT" --path . -- --shot ;;
  export)   mkdir -p build/windows build/macos
            "$GODOT" --headless --path . --export-release "Windows Desktop" build/windows/FPSArena.exe
            "$GODOT" --headless --path . --export-release "macOS" build/macos/FPSArena.zip ;;
  # Web 版：导出 → 生成 .br/.gz 预压缩副本（不做这步首屏要三分钟）
  web)      mkdir -p build/web
            "$GODOT" --headless --path . --export-release "Web" "$(pwd)/build/web/index.html"
            "$PYTHON" tools/compress_web.py build/web ;;
  compress) "$PYTHON" tools/compress_web.py "${2:-build/web}" ;;
  serve)    "$PYTHON" build/web/godot_web_server.py "${2:-8790}" ;;
  all)      mkdir -p build/windows build/macos build/web
            "$GODOT" --headless --path . --export-release "Windows Desktop" build/windows/FPSArena.exe
            "$GODOT" --headless --path . --export-release "macOS" build/macos/FPSArena.zip
            "$GODOT" --headless --path . --export-release "Web" "$(pwd)/build/web/index.html"
            "$PYTHON" tools/compress_web.py build/web ;;
  *) echo "用法: $0 [play|test|sim [秒]|simdie [秒]|shots|export|web|compress|serve [端口]|all]" ;;
esac
