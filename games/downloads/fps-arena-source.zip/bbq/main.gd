extends Node

## 启动入口：全局输入映射 + 主题 + 菜单↔对局切换 + 命令行测试钩子。

const UiTheme = preload("res://scripts/ui_theme.gd")
const MainMenuScript = preload("res://scripts/main_menu.gd")
const GameScript = preload("res://scripts/game.gd")

var menu = null
var game = null
var shot_mode := false
var _quit_notice = null


func _ready() -> void:
	randomize()
	_setup_input()
	_setup_theme()

	var args := OS.get_cmdline_user_args()

	# --autoquit / --wave 都要在参数分发之前解析（分支命中就 return，后面读不到）。
	var autoquit := 0.0
	var start_wave := 0
	for a in args:
		if a.begins_with("--autoquit="):
			autoquit = float(a.substr(11))
		elif a.begins_with("--wave="):
			start_wave = int(a.substr(7))
	if autoquit > 0.0:
		_autoquit(autoquit)

	for a in args:
		if a == "--selftest":
			_run_selftest()
			return
		if a == "--shot":
			_run_shots()
			return
		if a.begins_with("--sim="):
			_run_sim(float(a.substr(6)), true, start_wave)
			return
		if a.begins_with("--simdie="):
			_run_sim(float(a.substr(9)), false, start_wave)
			return

	_show_menu()


func _autoquit(secs: float) -> void:
	await get_tree().create_timer(secs).timeout
	print("[MAIN] autoquit 到时 %.1f 秒，退出" % secs)
	get_tree().quit()


# ---------------- 输入映射 ----------------

func _setup_input() -> void:
	_add_keys("move_forward", [KEY_W, KEY_UP])
	_add_keys("move_back", [KEY_S, KEY_DOWN])
	_add_keys("move_left", [KEY_A, KEY_LEFT])
	_add_keys("move_right", [KEY_D, KEY_RIGHT])
	_add_keys("jump", [KEY_SPACE])
	_add_keys("sprint", [KEY_SHIFT])
	_add_keys("reload", [KEY_R])
	_add_keys("pause", [KEY_ESCAPE, KEY_P])
	_add_keys("weapon_1", [KEY_1])
	_add_keys("weapon_2", [KEY_2])
	_add_keys("weapon_3", [KEY_3])
	_add_keys("weapon_4", [KEY_4])
	_add_keys("weapon_next", [KEY_E])
	_add_keys("cheat_panel", [KEY_Q])
	_add_mouse("fire", [MOUSE_BUTTON_LEFT])
	_add_mouse("aim", [MOUSE_BUTTON_RIGHT])
	_add_mouse("weapon_wheel", [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN])


func _add_keys(action: StringName, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)


func _add_mouse(action: StringName, buttons: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for b in buttons:
		var ev := InputEventMouseButton.new()
		ev.button_index = b
		InputMap.action_add_event(action, ev)


func _setup_theme() -> void:
	var w := get_window()
	if w != null:
		w.theme = UiTheme.build()


# ---------------- 菜单 / 对局 ----------------

func _show_menu() -> void:
	_teardown_game()
	get_tree().paused = false
	# 回主菜单清空作弊，下一局从干净状态开始（局内「重新开始」则保留，方便连续试）
	Cheats.reset()
	if menu == null:
		menu = MainMenuScript.new()
		menu.name = "MainMenu"
		add_child(menu)
		menu.start_requested.connect(_start_game)
		menu.quit_requested.connect(_quit_game)
	menu.open()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _teardown_game() -> void:
	if game != null and is_instance_valid(game):
		game.queue_free()
	game = null


func _start_game() -> void:
	_teardown_game()
	if menu != null and is_instance_valid(menu):
		menu.close()
	GameState.reset_run()
	game = GameScript.new()
	game.name = "Game"
	game.exit_to_menu.connect(_on_exit_to_menu)
	add_child(game)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if shot_mode else Input.MOUSE_MODE_CAPTURED


func _on_exit_to_menu() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_show_menu()


func _quit_game() -> void:
	# Web 平台：浏览器不允许脚本关闭不是它自己打开的标签页，而引擎 quit() 会让画面
	# 定格在最后一帧、看起来像卡死。所以改为显示一个明确的提示层。
	if OS.has_feature("web"):
		_show_web_quit_notice()
		return
	get_tree().quit()


func _show_web_quit_notice() -> void:
	if _quit_notice != null:
		return
	var layer := CanvasLayer.new()
	layer.layer = 200
	add_child(layer)

	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	layer.add_child(root)
	# 必须在入树之后调用：attach() 内部走 get_window()，节点不在树里会返回 null
	# 而静默失效（症状：中文全变豆腐块）。
	UiTheme.attach(root)

	var bg := ColorRect.new()
	bg.color = Color(0.035, 0.045, 0.075, 0.96)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(bg)

	var vp := get_viewport().get_visible_rect().size
	var title := Label.new()
	title.text = "已退出游戏"
	title.add_theme_font_size_override("font_size", 46)
	title.add_theme_color_override("font_color", Color(0.85, 0.92, 1.0))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.position = Vector2(0, vp.y * 0.34)
	title.size = Vector2(vp.x, 60)
	root.add_child(title)

	var hint := Label.new()
	hint.text = "可以关闭此页面了"
	hint.add_theme_font_size_override("font_size", 20)
	hint.add_theme_color_override("font_color", Color(0.62, 0.70, 0.80))
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.position = Vector2(0, vp.y * 0.34 + 68)
	hint.size = Vector2(vp.x, 30)
	root.add_child(hint)

	var again := Button.new()
	again.text = "重新开始"
	again.add_theme_font_size_override("font_size", 20)
	again.size = Vector2(260, 52)
	again.position = Vector2((vp.x - 260) * 0.5, vp.y * 0.34 + 130)
	again.pressed.connect(func() -> void: get_tree().reload_current_scene())
	root.add_child(again)

	_quit_notice = layer
	print("[UI] Web 平台不支持脚本关闭标签页，已显示退出提示层")


# ---------------- 命令行测试 ----------------

func _run_selftest() -> void:
	print("[TEST] ===== 自检开始 =====")
	var fails := 0

	# 1. 字体主题
	var w := get_window()
	var has_theme := w != null and w.theme != null
	print("[TEST] 主题已应用: %s" % has_theme)
	if not has_theme:
		fails += 1

	# 2. 中文可渲染
	if has_theme:
		var f: Font = w.theme.default_font
		var ok := f != null and f.has_char(0x5F00) and f.has_char(0x706B)
		print("[TEST] 中文字形（开/火）: %s (字体=%s)" % [ok, f.get_font_name() if f != null else "无"])
		if not ok:
			fails += 1

	# 3. 输入映射
	var missing := []
	for a in ["move_forward", "move_back", "move_left", "move_right", "jump", "sprint", "fire", "reload", "pause", "cheat_panel"]:
		if not InputMap.has_action(a):
			missing.append(a)
	print("[TEST] 输入映射缺失: %s" % [missing if missing.size() > 0 else "无"])
	if missing.size() > 0:
		fails += 1

	# 4. 音效可生成
	var s = Sfx._stream("shoot")
	var audio_ok := false
	if s != null:
		audio_ok = int(s.data.size()) > 100
	print("[TEST] 程序化音效: %s (%d 字节)" % [audio_ok, int(s.data.size()) if s != null else 0])
	if not audio_ok:
		fails += 1

	# 5. 建一局并跑逻辑
	GameState.reset_run()
	game = GameScript.new()
	game.name = "Game"
	add_child(game)
	await get_tree().process_frame
	await get_tree().physics_frame
	await get_tree().physics_frame

	# 触发第一波
	game.break_t = 0.05
	for i in 12:
		await get_tree().process_frame
	print("[TEST] 波次已启动: wave=%d, 待生成=%d" % [game.wave, game.spawn_queue.size()])
	if game.wave < 1:
		fails += 1

	var player = game.player
	print("[TEST] 玩家已生成: %s" % (player != null))
	if player == null:
		fails += 1
	else:
		# 移动测试
		var p0: Vector3 = player.global_position
		Input.action_press("move_forward")
		for i in 30:
			await get_tree().physics_frame
		Input.action_release("move_forward")
		var moved := p0.distance_to(player.global_position)
		print("[TEST] 前进 0.5s 位移: %.2f m" % moved)
		if moved < 0.5:
			fails += 1

		# 开火测试
		var w0 = player.weapon
		var ammo0: int = w0.ammo
		var fired: bool = w0.try_fire_once()
		print("[TEST] 开火成功: %s 弹药 %d → %d" % [fired, ammo0, w0.ammo])
		if not fired or w0.ammo != ammo0 - 1:
			fails += 1

	# 6. 敌人生成 + 伤害 + 死亡 + 计分
	var e = game.spawn_enemy_at(0, Vector3(0, 0.2, -8))
	if e == null:
		print("[TEST] 敌人生成: 失败")
		fails += 1
	else:
		await get_tree().physics_frame
		var hp0: float = e.hp
		e.take_damage(9999.0, Vector3.FORWARD)
		await get_tree().process_frame
		print("[TEST] 敌人受伤死亡: hp %.0f → %.0f, 击杀数=%d, 得分=%d" % [hp0, e.hp, GameState.kills, GameState.score])
		if GameState.kills < 1 or GameState.score < 1:
			fails += 1

	# 6.5 射击命中判定：放到空旷处，正面 10m 一个敌人，开一枪必须掉血
	player.global_position = Vector3(24.0, 0.3, 24.0)
	var tgt_e = game.spawn_enemy_at(0, Vector3(24.0, 0.2, 14.0))
	if tgt_e == null:
		print("[TEST] 射击命中: 敌人创建失败")
		fails += 1
	else:
		# 等出场缩放动画结束，否则碰撞体还是缩小的
		await get_tree().create_timer(0.5).timeout
		var eye: Vector3 = player.cam.global_position
		var aim: Vector3 = tgt_e.global_position + Vector3(0, 1.15, 0)
		var n := (aim - eye).normalized()
		player.yaw = atan2(-n.x, -n.z)
		player.pitch = clampf(asin(clampf(n.y, -1.0, 1.0)), -1.45, 1.45)
		player.rotation.y = player.yaw
		player.head.rotation.x = player.pitch
		player.head.rotation.y = 0.0
		player.weapon.ammo = 30
		player.weapon.reloading = false
		player.weapon.cooldown = 0.0
		var hp_before: float = tgt_e.hp
		var fired_ok: bool = player.weapon.try_fire_once()
		await get_tree().process_frame
		var hp_after: float = tgt_e.hp
		print("[TEST] 射击命中敌人: 开火=%s, 敌人 HP %.0f → %.0f (伤害 %.0f)" % [
			fired_ok, hp_before, hp_after, hp_before - hp_after])
		if not fired_ok or hp_after >= hp_before:
			fails += 1

	# 7. 波次系统
	print("[TEST] 当前波次: %d, 存活敌人: %d" % [game.wave, game.alive_enemy_count()])
	if game.wave < 1:
		fails += 1
	# 8. 出生点不卡在几何体里
	var bad := 0
	var blocked_names := []
	for sp in GameScript.SPAWN_POINTS:
		if game.is_point_blocked(sp + Vector3(0, 0.9, 0)):
			bad += 1
			blocked_names.append(str(sp))
	if game.is_point_blocked(GameScript.PLAYER_SPAWN + Vector3(0, 0.9, 0)):
		bad += 1
		blocked_names.append("玩家出生点")
	print("[TEST] 被几何体堵住的出生点: %d / %d %s" % [bad, GameScript.SPAWN_POINTS.size() + 1, blocked_names])
	if bad > 0:
		fails += 1

	# 9. 作弊面板：逐项断言，别只看「面板能打开」
	fails += await _test_cheats(game, player)

	# 10. 首领：类型 / 血条 / 狂暴 / 震荡波 / 击杀
	fails += await _test_boss(game, player)

	print("[TEST] ===== 自检结束，失败项: %d =====" % fails)
	print("[TEST] RESULT=%s" % ("PASS" if fails == 0 else "FAIL"))
	get_tree().quit(0 if fails == 0 else 1)


## 把视角对准目标（作弊与命中判定测试共用）。
func _aim_at(p, e) -> void:
	var eye: Vector3 = p.cam.global_position
	var aim: Vector3 = e.global_position + Vector3(0, 1.15, 0)
	var n := (aim - eye).normalized()
	p.yaw = atan2(-n.x, -n.z)
	p.pitch = clampf(asin(clampf(n.y, -1.0, 1.0)), -1.45, 1.45)
	p.rotation.y = p.yaw
	p.head.rotation.x = p.pitch
	p.head.rotation.y = 0.0


## 作弊系统自检：每个开关都要证明「真的改变了行为」，不能只看变量被赋值。
## 返回失败项数。
func _test_cheats(game, player) -> int:
	Cheats.reset()
	var f := 0
	print("[TEST] ---- 作弊系统 ----")

	# 9.1 面板可开可合，且开时暂停、关时恢复
	var panel = game.cheat_panel
	if panel == null:
		print("[TEST]   面板未创建 ✗")
		f += 1
	else:
		panel.open()
		var opened: bool = panel.is_open() and get_tree().paused
		panel.close()
		var closed: bool = (not panel.is_open()) and (not get_tree().paused)
		print("[TEST]   面板 开=%s 关=%s" % [opened, closed])
		if not opened or not closed:
			f += 1

	# 9.2 每个开关都能来回切换（防漏 match 分支）
	var bad_toggles := []
	for k in Cheats.TOGGLE_KEYS:
		var v1: bool = Cheats.toggle(k)
		var v2: bool = Cheats.toggle(k)
		if not v1 or v2 or Cheats.get_flag(k):
			bad_toggles.append(k)
	print("[TEST]   开关可切换: %s %s" % [Cheats.TOGGLE_KEYS.size(), "全部通过" if bad_toggles.is_empty() else bad_toggles])
	if not bad_toggles.is_empty():
		f += 1

	# 9.3 无敌：受伤不掉血；关掉后正常掉血
	player.hp = 100.0
	Cheats.god_mode = true
	player.take_damage(50.0, Vector3.FORWARD)
	var god_on: bool = is_equal_approx(player.hp, 100.0)
	Cheats.god_mode = false
	player.take_damage(10.0, Vector3.FORWARD)
	var god_off: bool = player.hp < 100.0
	print("[TEST]   无敌 开=%s 关=%s (HP=%.0f)" % [god_on, god_off, player.hp])
	if not god_on or not god_off:
		f += 1

	# 9.4 无限弹药：连开 10 枪弹匣不减
	player.hp = 100.0
	player.weapon.ammo = 5
	Cheats.infinite_ammo = true
	for i in 10:
		player.weapon.cooldown = 0.0
		player.weapon.reloading = false
		player.weapon.try_fire_once()
	var ammo_inf: int = player.weapon.ammo
	Cheats.infinite_ammo = false
	print("[TEST]   无限弹药 连开10枪后弹匣=%d (起始5, 期望不减)" % ammo_inf)
	if ammo_inf != 5:
		f += 1

	# 9.5 精准枪法：散布归零
	Cheats.no_spread = true
	var sp: float = player.weapon._current_spread()
	Cheats.no_spread = false
	print("[TEST]   精准枪法 散布=%.4f (期望 0)" % sp)
	if sp > 0.0001:
		f += 1

	# 9.6 一击必杀：满血重装兵一枪毙命
	player.global_position = Vector3(24.0, 0.3, 24.0)
	player.yaw = 0.0
	player.weapon.switch_to(0)
	player.weapon.refill_all()
	var heavy = game.spawn_enemy_at(2, Vector3(24.0, 0.2, 14.0))
	if heavy == null:
		print("[TEST]   一击必杀 敌人创建失败 ✗")
		f += 1
	else:
		await get_tree().create_timer(0.5).timeout   # 等出场缩放动画结束
		_aim_at(player, heavy)
		var hp_os: float = heavy.hp
		Cheats.one_shot = true
		player.weapon.cooldown = 0.0
		player.weapon.reloading = false
		player.weapon.try_fire_once()
		await get_tree().process_frame
		print("[TEST]   一击必杀 重装兵 HP %.0f → %.0f 存活=%s" % [hp_os, heavy.hp, heavy.alive])
		if heavy.alive:
			f += 1
		Cheats.one_shot = false

	# 9.7 疾风步：同样 0.5 秒输入，位移明显更大
	var p0 := Vector3(24.0, 0.3, 24.0)
	player.global_position = p0
	player.velocity = Vector3.ZERO
	player.yaw = 0.0
	player.rotation.y = 0.0
	Input.action_press("move_forward")
	for i in 30:
		await get_tree().physics_frame
	Input.action_release("move_forward")
	var d_normal := Vector2(player.global_position.x - p0.x, player.global_position.z - p0.z).length()
	player.global_position = p0
	player.velocity = Vector3.ZERO
	player.yaw = 0.0
	player.rotation.y = 0.0
	Cheats.super_speed = true
	Input.action_press("move_forward")
	for i in 30:
		await get_tree().physics_frame
	Input.action_release("move_forward")
	var d_fast := Vector2(player.global_position.x - p0.x, player.global_position.z - p0.z).length()
	Cheats.super_speed = false
	print("[TEST]   疾风步 位移 %.2fm → %.2fm (期望更大)" % [d_normal, d_fast])
	if d_fast <= d_normal * 1.15:
		f += 1

	# 9.8 冻结敌人：速度归零
	var fe = game.spawn_enemy_at(0, Vector3(-24.0, 0.2, -24.0))
	await get_tree().physics_frame
	Cheats.freeze_enemies = true
	for i in 20:
		await get_tree().physics_frame
	var fv := 0.0
	if fe != null and is_instance_valid(fe):
		fv = Vector2(fe.velocity.x, fe.velocity.z).length()
	Cheats.freeze_enemies = false
	print("[TEST]   冻结敌人 水平速度=%.2f (期望 <0.5)" % fv)
	if fv >= 0.5:
		f += 1

	# 9.9 弱化敌人：同样伤害扣血更多
	var we = game.spawn_enemy_at(0, Vector3(0.0, 0.2, -24.0))
	await get_tree().physics_frame
	if we == null:
		print("[TEST]   弱化敌人 敌人创建失败 ✗")
		f += 1
	else:
		var h0: float = we.hp
		we.take_damage(10.0, Vector3.FORWARD)
		var d_norm: float = h0 - we.hp
		Cheats.weak_enemies = true
		var h1: float = we.hp
		we.take_damage(10.0, Vector3.FORWARD)
		var d_weak: float = h1 - we.hp
		Cheats.weak_enemies = false
		print("[TEST]   弱化敌人 同 10 伤害扣血 %.0f → %.0f (期望 x8)" % [d_norm, d_weak])
		if d_weak <= d_norm * 4.0:
			f += 1

	# 9.10 秒杀全场
	game.spawn_enemy_at(0, Vector3(6.0, 0.2, -24.0))
	await get_tree().physics_frame
	var killed: int = game.kill_all_enemies()
	await get_tree().process_frame
	var left: int = game.alive_enemy_count()
	print("[TEST]   秒杀全场 击杀 %d 名, 剩余存活 %d" % [killed, left])
	if killed <= 0 or left != 0:
		f += 1

	# 9.11 清空敌人
	game.spawn_enemy_at(0, Vector3(-6.0, 0.2, -24.0))
	await get_tree().physics_frame
	var cleared: int = game.clear_all_enemies()
	print("[TEST]   清空敌人 移除 %d 名" % cleared)
	if cleared <= 0:
		f += 1

	# 9.12 立即下一波
	game.wave_active = false
	game.break_t = 5.0
	game.skip_break()
	print("[TEST]   立即下一波 break_t=%.2f (期望 0)" % game.break_t)
	if game.break_t > 0.0:
		f += 1

	# 9.13 回满生命 / 补满弹药 / 加分
	player.hp = 12.0
	game.heal_player_full()
	var healed: bool = is_equal_approx(player.hp, player.MAX_HP)
	player.weapon.ammo = 1
	player.weapon.reserve = 0
	game.refill_player_ammo()
	var mag: int = int(player.weapon.DATA[player.weapon.index]["mag"])
	var refilled: bool = player.weapon.ammo == mag and player.weapon.reserve > 0
	var s0: int = GameState.score
	game.add_cheat_score(1000)
	var scored: bool = GameState.score == s0 + 1000
	print("[TEST]   回满生命=%s 补满弹药=%s(%d/%d) 加分=%s" % [healed, refilled, player.weapon.ammo, player.weapon.reserve, scored])
	if not healed or not refilled or not scored:
		f += 1

	# 9.14 子弹时间能改又能还原时间流速
	Cheats.bullet_time = true
	var slow: float = Engine.time_scale
	Cheats.bullet_time = false
	var restored: float = Engine.time_scale
	print("[TEST]   子弹时间 time_scale 1.0 → %.2f → %.2f" % [slow, restored])
	if not is_equal_approx(slow, Cheats.SLOW_SCALE) or not is_equal_approx(restored, 1.0):
		f += 1

	# 9.15 全部关闭
	Cheats.reset()
	var clean: bool = not Cheats.any_active()
	print("[TEST]   全部关闭 生效项=%d" % Cheats.active_count())
	if not clean:
		f += 1

	# 9.16 真实按键派发：按 Q 弹出、按 Esc 只关面板（不该顺带弹出暂停菜单）
	#      只测 open()/close() 是测不到「同级/父子节点输入派发顺序」的，
	#      而顺序正是这个功能最容易翻车的地方 —— 所以合成真实按键跑一遍。
	_push_key(KEY_Q)
	await get_tree().process_frame
	await get_tree().process_frame
	var k_open: bool = panel.is_open() and get_tree().paused
	_push_key(KEY_ESCAPE)
	await get_tree().process_frame
	await get_tree().process_frame
	var k_closed: bool = (not panel.is_open()) and (not get_tree().paused) and (not game.is_paused)
	print("[TEST]   按键 Q 弹出=%s / Esc 关闭且未弹暂停=%s" % [k_open, k_closed])
	if not k_open or not k_closed:
		f += 1

	print("[TEST] ---- 作弊系统失败项: %d ----" % f)
	return f


## 合成一次真实按键（按下 + 抬起），走 InputMap 的物理键匹配。
func _push_key(code: Key) -> void:
	for pressed in [true, false]:
		var ev := InputEventKey.new()
		ev.keycode = code
		ev.physical_keycode = code
		ev.pressed = pressed
		Input.parse_input_event(ev)


## 首领自检：每一项都造「有/无」对照，证明机制真的接进了玩法。
func _test_boss(game, player) -> int:
	var f := 0
	print("[TEST] ---- 首领系统 ----")

	# 先冻结波次系统：否则 _process 会在我们测首领时偷偷刷怪，
	# 干扰 boss 引用和分数断言。break_t 设成天文数字即可。
	game.wave_active = false
	game.break_t = 99999.0
	game.spawn_queue.clear()

	# 10.1 只有 5 的倍数波才刷首领（不能波波都刷）
	var comp4: Array = game._wave_composition(4)
	var comp5: Array = game._wave_composition(5)
	var comp10: Array = game._wave_composition(10)
	var wave_ok: bool = (not comp4.has(3)) and comp5.has(3) and comp10.has(3) and comp5.size() <= 23
	print("[TEST]   波次构成 第4波首领=%s 第5波首领=%s 第10波首领=%s (第5波共 %d 名)" % [
		comp4.has(3), comp5.has(3), comp10.has(3), comp5.size()])
	if not wave_ok:
		f += 1

	# 10.2 生成：is_boss、血厚、HUD 血条出现且名字对
	game.clear_enemies()
	game.wave = 5
	await get_tree().process_frame
	var b = game.spawn_enemy_at(3, Vector3(0.0, 0.2, -20.0))
	var spawn_ok: bool = b != null and b.is_boss and b.max_hp >= 1000.0 and game.boss == b
	var bar_ok: bool = game.hud.boss_bar.visible and game.hud.boss_name.text == "首领"
	print("[TEST]   首领生成 is_boss=%s HP=%.0f 血条显示=%s" % [
		(b.is_boss if b != null else false), (b.max_hp if b != null else 0.0), bar_ok])
	if not spawn_ok or not bar_ok:
		f += 1

	# 10.3 受伤 → HUD 血条数值跟着掉
	b.take_damage(b.max_hp * 0.2, Vector3.FORWARD)
	game._update_boss_bar()
	var frac_shown: float = game.hud.boss_fill.size.x / 634.0
	var bar_tracks: bool = absf(frac_shown - 0.8) < 0.02
	print("[TEST]   血条跟随 受伤 20%% 后显示比例=%.2f (期望 0.80)" % frac_shown)
	if not bar_tracks:
		f += 1

	# 10.4 血量掉到 45% 以下自动狂暴
	var sp0: float = b.speed
	var dm0: float = b.dmg
	var cd0: float = b.fire_cd
	b.take_damage(b.max_hp * 0.45, Vector3.FORWARD)   # 此时约剩 35%
	var enr_ok: bool = b.enraged and b.speed > sp0 and b.dmg > dm0 and b.fire_cd < cd0
	print("[TEST]   狂暴 触发=%s 速度 %.1f→%.1f 伤害 %.1f→%.1f 射速 %.2f→%.2f" % [
		b.enraged, sp0, b.speed, dm0, b.dmg, cd0, b.fire_cd])
	if not enr_ok:
		f += 1

	# 10.5 狂暴只触发一次（继续挨打不会二次翻倍）
	var sp1: float = b.speed
	b.take_damage(10.0, Vector3.FORWARD)
	var once_ok: bool = is_equal_approx(b.speed, sp1)
	print("[TEST]   狂暴只触发一次 速度 %.1f→%.1f (期望不变)" % [sp1, b.speed])
	if not once_ok:
		f += 1

	# 10.6 震荡波：近处扣血、远处不扣。隔离掉普通射击（atk_range 置 0 + 冷却拉长），
	#      否则远处那一发会被「点射命中玩家」污染成假阳性。
	b.atk_range = 0.0
	b._burst_left = 0
	b._fire_t = 999.0
	Cheats.god_mode = false
	player.god_mode = false
	player.hp = 100.0
	player.global_position = b.global_position + Vector3(4.0, 0, 0)
	b._shock_t = 0.0
	b._combat(0.016, 4.0, true)
	var hurt_near: bool = player.hp < 100.0
	var took: float = 100.0 - player.hp
	player.hp = 100.0
	b._shock_t = 0.0
	b._combat(0.016, 30.0, true)
	var hurt_far: bool = is_equal_approx(player.hp, 100.0)
	print("[TEST]   震荡波 近处(4m)扣血=%.0f 远处(30m)扣血=%.0f (期望 0)" % [took, 100.0 - player.hp])
	if not hurt_near or not hurt_far:
		f += 1

	# 10.7 击杀：血条收起、boss 引用清空、计分
	player.god_mode = true
	var s0: int = GameState.score
	b.take_damage(1.0e9, Vector3.FORWARD)
	await get_tree().process_frame
	game._update_boss_bar()
	var kill_ok: bool = (not b.alive) and game.boss == null \
		and (not game.hud.boss_bar.visible) and GameState.score > s0
	print("[TEST]   击杀首领 存活=%s boss引用=%s 血条=%s 得分+%d" % [
		b.alive, game.boss, game.hud.boss_bar.visible, GameState.score - s0])
	if not kill_ok:
		f += 1

	# 10.8 普通火力就能打死首领（别只有「一击必杀」能秒它）——
	#      顺便量出「打死一只首领要多少发」，作为配平依据。
	var b2 = game.spawn_enemy_at(3, Vector3(24.0, 0.2, 14.0))
	player.global_position = Vector3(24.0, 0.3, 24.0)
	player.weapon.switch_to(0)
	player.weapon.refill_all()
	await get_tree().create_timer(0.4).timeout      # 等位置与出场动画落定
	Cheats.one_shot = false
	Cheats.no_spread = true        # 排除散布，保证逐发命中
	Cheats.infinite_ammo = true    # 排除换弹干扰，只量「要几发」
	var shots := 0
	while b2 != null and b2.alive and shots < 400:
		_aim_at(player, b2)
		player.weapon.cooldown = 0.0
		player.weapon.reloading = false
		player.weapon.try_fire_once()
		shots += 1
	var ttk_ok: bool = b2 != null and (not b2.alive) and shots > 10
	print("[TEST]   正常火力击杀首领 需 %d 发突击步枪 (HP %.0f)" % [
		shots, (b2.max_hp if b2 != null else 0.0)])
	if not ttk_ok:
		f += 1
	Cheats.infinite_ammo = false
	Cheats.no_spread = false

	# 10.9 结算时血条不许「复活」：_process 里 _update_boss_bar() 跑在 game_over
	#      判断之前，若不早退，下一帧就会把 show_gameover() 刚藏起来的血条
	#      又拉回来 —— 症状是结算面板上方挂着一条暗淡的首领血条。
	var b3 = game.spawn_enemy_at(3, Vector3(-24.0, 0.2, 14.0))
	await get_tree().create_timer(0.3).timeout
	var bar_before: bool = game.hud.boss_bar.visible
	game.debug_force_gameover()
	await get_tree().create_timer(0.5).timeout      # 多跑几帧 _process 才说明问题
	var bar_hidden: bool = not game.hud.boss_bar.visible
	print("[TEST]   结算时首领血条 结算前=%s 结算后隐藏=%s (首领仍存活=%s)" % [
		bar_before, bar_hidden, b3 != null and b3.alive])
	if not (bar_before and bar_hidden):
		f += 1
	# 收尾：把结算状态清掉，别把后面（或以后新增的用例）带进 game_over
	game.game_over = false
	game.hud.hide_gameover()
	game.clear_enemies()

	print("[TEST] ---- 首领系统失败项: %d ----" % f)
	return f


func _run_shots() -> void:
	shot_mode = true
	_autoquit(120.0)
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_ALWAYS_ON_TOP, true)
	DisplayServer.window_move_to_foreground()
	await get_tree().process_frame
	var shot_dir := "res://shots"
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(shot_dir))

	# 1) 主菜单
	_show_menu()
	await _settle(2.0)
	await _capture(shot_dir + "/01_menu.png")

	# 2) 对局：把玩家放到场地中央，面朝一组敌人
	_start_game()
	# ⚠️ 失焦自动暂停的保护要**紧跟** _start_game()：game 节点是它新建的，
	# 之前的写法隔了 1 秒才设 suppress_auto_pause，那 1 秒里窗口一旦失焦，
	# 暂停面板就弹出来并且一直挂着（踩过：02_gameplay / 03_combat 整张截成「已暂停」）。
	game.suppress_auto_pause = true
	if game.is_paused:
		game._resume()
	await _settle(1.0)
	var game_node = game
	game_node.debug_setup_shot_scene()
	await _settle(2.2)
	await _capture(shot_dir + "/02_gameplay.png")

	# 3) 换一个角度（贴近掩体 + 敌人更近）
	game_node.debug_setup_shot_scene2()
	await _settle(1.6)
	await _capture(shot_dir + "/03_combat.png")

	# 4) 首领对峙（大模型 + 顶部首领血条）
	game_node.debug_boss_shot()
	await _settle(2.0)
	await _capture(shot_dir + "/04_boss.png")

	# 5) 作弊面板：点亮若干开关，检查中文与状态标签排版
	game_node.debug_open_cheats()
	await _settle(1.2)
	await _capture(shot_dir + "/05_cheats.png")
	game_node.cheat_panel.close()
	Cheats.reset()   # 收工：清开关并还原时间流速，别影响后面两张图

	# 6) 结算面板
	game_node.debug_force_gameover()
	await _settle(1.2)
	await _capture(shot_dir + "/06_gameover.png")

	# 7) 暂停面板
	game_node.debug_force_gameover()
	game_node.hud.hide_gameover()
	game_node._pause()
	await _settle(1.0)
	await _capture(shot_dir + "/07_pause.png")

	print("[SHOT] 完成")
	get_tree().quit()


func _settle(secs: float) -> void:
	await get_tree().create_timer(secs).timeout


func _dump_enemies(game, p) -> void:
	var shots := 0
	var hit := 0
	for c in game.enemies_root.get_children():
		if c is CharacterBody3D:
			shots += int(c.shots_fired)
			hit += int(c.shots_hit)
	print("   [AI] 敌人累计开火=%d 命中=%d" % [shots, hit])
	print("   [PL] 玩家累计开火=%d 命中=%d 弹药=%d/%d 最近敌人=%s" % [
		GameState.total_shots, GameState.total_hits,
		p.weapon.ammo, p.weapon.reserve, _nearest_info(game, p)])


func _nearest_info(game, p) -> String:
	var best = null
	var best_d := 1.0e9
	for c in game.enemies_root.get_children():
		if c is CharacterBody3D and c.alive:
			var d: float = c.global_position.distance_to(p.global_position)
			if d < best_d:
				best_d = d
				best = c
	if best == null:
		return "无"
	var los := _los_ok(p, best)
	return "距离%.1fm HP%.0f 视线=%s | 敌see=%s 敌速=%.2f 卡住=%.2f 绕行=%.2f" % [
		best_d, best.hp, "通" if los else "挡",
		str(best.dbg_see), Vector2(best.velocity.x, best.velocity.z).length(),
		best.dbg_stuck, best._detour_t]


func _los_ok(p, e) -> bool:
	var space: PhysicsDirectSpaceState3D = p.get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(
		p.cam.global_position, e.global_position + Vector3(0, 1.15, 0))
	q.collision_mask = 1
	q.exclude = [p]
	return space.intersect_ray(q).is_empty()


## 让玩家自动瞄准最近的敌人并开火（用于无人值守的端到端模拟）。
func _auto_engage(game, p) -> void:
	# 只在「有视线」时才开火，否则逼近 —— 早先版本无条件朝最近敌人泼子弹，
	# 结果子弹全打在掩体上（实测 40 秒里命中率 6.3%、击杀数 20 秒后停滞）。
	var target = _pick_target(game, p, true)
	var los := false
	if target == null:
		# 没有任何敌人可直视 → 退而求其次，朝最近的逼近
		target = _pick_target(game, p, false)
	else:
		los = true
	if target == null:
		Input.action_release("move_forward")
		return

	var aim: Vector3 = target.global_position + Vector3(0, 1.15, 0)
	var v: Vector3 = aim - p.cam.global_position
	if v.length() > 0.1:
		var n := v.normalized()
		p.yaw = atan2(-n.x, -n.z)
		p.pitch = clampf(asin(clampf(n.y, -1.0, 1.0)), -1.45, 1.45)
		p.rotation.y = p.yaw
		p.head.rotation.x = p.pitch
		p.head.rotation.y = 0.0

	if los:
		Input.action_release("move_forward")
		p.weapon.update(0.033, false, false)
		if p.weapon.cooldown <= 0.0 and not p.weapon.reloading:
			p.weapon.try_fire_once()
	else:
		# 视线被挡：一边逼近一边换弹，别空着弹匣冲上去
		Input.action_press("move_forward")
		p.weapon.update(0.033, false, false)
		if p.weapon.ammo <= 0:
			p.weapon.start_reload()


func _pick_target(game, p, require_los: bool):
	var best = null
	var best_d := 1.0e9
	for c in game.enemies_root.get_children():
		if c is CharacterBody3D and c.alive:
			var d: float = c.global_position.distance_to(p.global_position)
			if d >= best_d:
				continue
			if require_los and not _los_ok(p, c):
				continue
			best_d = d
			best = c
	return best


## 端到端模拟：验证 波次推进 / AI 寻路 / 开火命中 / 伤害 / 死亡结算 全链路。
func _run_sim(secs: float, god: bool, start_wave: int = 0) -> void:
	Engine.time_scale = 3.0
	GameState.reset_run()
	game = GameScript.new()
	game.name = "Game"
	add_child(game)
	await get_tree().process_frame
	await get_tree().physics_frame

	# --wave=K：跳过前 K-1 波，直接从第 K 波开打（用于验证高波次 / 首领波）。
	if start_wave > 1:
		game.wave = start_wave - 1
		game.wave_active = false
		game.break_t = 0.05
		print("[SIM] 起始波次已设为 %d" % start_wave)

	var p = game.player
	p.god_mode = god
	var hits := [0]
	var total_dmg := [0.0]
	p.damaged.connect(func(a: float, _d: Vector3) -> void:
		hits[0] += 1
		total_dmg[0] += a)

	print("[SIM] 开始，时长 %.0f 秒（游戏内约 %.0f 秒），无敌=%s，自动交战=开" % [secs, secs * Engine.time_scale, god])
	var t0 := Time.get_ticks_msec()
	var last_report := 0.0
	var max_alive := 0
	while true:
		await get_tree().create_timer(0.07).timeout
		var el := float(Time.get_ticks_msec() - t0) / 1000.0
		max_alive = maxi(max_alive, game.alive_enemy_count())
		if p.alive:
			_auto_engage(game, p)
		if el - last_report >= 5.0:
			last_report = el
			print("[SIM] t=%4.1fs 波次=%d 存活=%2d 击杀=%3d 得分=%5d HP=%5.1f 受击=%3d次/%.0f" % [
				el, game.wave, game.alive_enemy_count(), GameState.kills,
				GameState.score, p.hp, hits[0], total_dmg[0]])
			_dump_enemies(game, p)
			if game.boss != null and is_instance_valid(game.boss):
				print("[SIM]   >> 首领在场 HP=%.0f/%.0f 狂暴=%s 剩余护卫=%d" % [
					game.boss.hp, game.boss.max_hp, game.boss.enraged, game.alive_enemy_count() - 1])
		if el >= secs:
			break

	print("[SIM] ===== 结束：波次=%d 击杀=%d 得分=%d 最大同屏敌人=%d 玩家受击=%d 次/%.0f 伤害 =====" % [
		game.wave, GameState.kills, GameState.score, max_alive, hits[0], total_dmg[0]])
	# 诊断：time_scale=3 时若物理帧远少于理论值，说明引擎跟不上（每帧物理步数被 clamp），
	# 游戏内时间会明显慢于「真实秒 × 3」，模拟结果就不能按真实秒来解读。
	print("[SIM] 物理帧=%d  理论≈%d  实际FPS=%.0f  time_scale=%.1f" % [
		Engine.get_physics_frames(), int(secs * 60.0 * Engine.time_scale),
		Engine.get_frames_per_second(), Engine.time_scale])
	print("[SIM] 玩家存活=%s  结算面板=%s  游戏结束=%s  命中率=%.1f%%" % [
		p.alive, game.hud.over_panel.visible, game.game_over, GameState.accuracy()])
	var ok = false
	if god:
		ok = int(game.wave) >= 2 and GameState.kills > 0
	else:
		ok = (not p.alive) and bool(game.hud.over_panel.visible) and hits[0] > 0
	print("[SIM] RESULT=%s" % ("PASS" if ok else "FAIL"))
	get_tree().quit()


func _capture(path: String) -> void:
	# 窗口被遮挡时渲染线程可能停止出帧，get_image() 会拿到过期内容。
	# 对策：force_draw 强制出帧 + 与超时赛跑，最多重试 6 轮。
	var img: Image = null
	for attempt in 6:
		var arrived := [false]
		var cb := func() -> void:
			arrived[0] = true
		RenderingServer.frame_post_draw.connect(cb, CONNECT_ONE_SHOT)
		RenderingServer.force_draw(true)
		var waited := 0.0
		while not arrived[0] and waited < 0.6:
			await get_tree().process_frame
			waited += get_process_delta_time()
		if not arrived[0] and RenderingServer.frame_post_draw.is_connected(cb):
			RenderingServer.frame_post_draw.disconnect(cb)
		if arrived[0]:
			img = get_viewport().get_texture().get_image()
			break
		printerr("[SHOT] 第 %d 次等待渲染帧超时，重试" % (attempt + 1))
	if img == null:
		printerr("[SHOT] 无法取得渲染帧: %s" % path)
		return
	var err := img.save_png(path)
	print("[SHOT] %s size=%s err=%d" % [path, str(img.get_size()), err])
