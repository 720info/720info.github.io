extends CanvasLayer

## HUD：准星 / 血量 / 弹药 / 波次 / 击杀播报 / 受伤红屏 / 暂停 / 结算。

signal resume_pressed()
signal restart_pressed()
signal menu_pressed()

const W := 1280.0
const H := 720.0

const UiTheme = preload("res://scripts/ui_theme.gd")

const VIGNETTE_SHADER := """
shader_type canvas_item;
uniform float damage = 0.0;
uniform float lowhp = 0.0;
uniform vec3 tint : source_color = vec3(0.85, 0.06, 0.07);
void fragment() {
	vec2 uv = UV;
	float d = distance(uv, vec2(0.5));
	float edge = smoothstep(0.26, 0.60, d);
	float a = edge * (damage * 0.80 + lowhp * 0.50);
	COLOR = vec4(tint, a);
}
"""

var root: Control
var player = null
var game = null

var hp_fill: ColorRect
var hp_text: Label
var ammo_text: Label
var weapon_text: Label
var score_text: Label
var cheat_text: Label
var wave_text: Label
var enemy_text: Label
var boss_bar: Control
var boss_fill: ColorRect
var boss_name: Label
var boss_hp_text: Label
var banner: Label
var banner_sub: Label
var feed_box: VBoxContainer
var vignette: ColorRect
var vignette_mat: ShaderMaterial

var pause_panel: Control
var over_panel: Control
var over_title: Label
var over_stats: Label
var over_hint: Label

var _spread_px := 7.0
var _hit_t := 0.0
var _hit_head := false
var _dmg := 0.0
var _lowhp := 0.0
var _banner_t := 0.0
var _banner_hold := 2.2
var _center := Vector2(W * 0.5, H * 0.5)


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	UiTheme.attach(root)
	root.draw.connect(_on_draw)
	_build()
	_build_pause()
	_build_over()


func setup(p, g) -> void:
	player = p
	game = g


# ---------------- 构建 ----------------

func _build() -> void:
	vignette = ColorRect.new()
	vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vignette_mat = ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = VIGNETTE_SHADER
	vignette_mat.shader = sh
	vignette.material = vignette_mat
	root.add_child(vignette)

	# 左上：分数
	score_text = _label("得分 0", 22, Color(0.92, 0.96, 1.0), Vector2(32, 24), Vector2(400, 30), HORIZONTAL_ALIGNMENT_LEFT)

	# 左上：作弊状态提示（无作弊时是暗色的入口提示）
	cheat_text = _label("", 15, Color(0.85, 0.72, 0.42), Vector2(32, 56), Vector2(440, 22), HORIZONTAL_ALIGNMENT_LEFT)

	# 顶部中间：波次
	wave_text = _label("第 1 波", 26, Color(1.0, 0.86, 0.45), Vector2(W * 0.5 - 200.0, 22), Vector2(400, 34), HORIZONTAL_ALIGNMENT_CENTER)
	enemy_text = _label("剩余敌人 0", 17, Color(0.72, 0.80, 0.90), Vector2(W * 0.5 - 200.0, 58), Vector2(400, 24), HORIZONTAL_ALIGNMENT_CENTER)

	_build_boss_bar()

	# 右上：击杀播报
	feed_box = VBoxContainer.new()
	feed_box.position = Vector2(W - 340.0, 26.0)
	feed_box.size = Vector2(310, 300)
	feed_box.alignment = BoxContainer.ALIGNMENT_BEGIN
	feed_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	feed_box.add_theme_constant_override("separation", 4)
	root.add_child(feed_box)

	# 左下：血量
	var hp_bg := ColorRect.new()
	hp_bg.color = Color(0.06, 0.07, 0.10, 0.85)
	hp_bg.position = Vector2(36, H - 84.0)
	hp_bg.size = Vector2(316, 30)
	hp_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hp_bg)
	var hp_border := _frame(Vector2(36, H - 84.0), Vector2(316, 30), Color(0.30, 0.42, 0.55, 0.9))
	root.add_child(hp_border)

	hp_fill = ColorRect.new()
	hp_fill.color = Color(0.30, 0.88, 0.46)
	hp_fill.position = Vector2(39, H - 81.0)
	hp_fill.size = Vector2(310, 24)
	hp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hp_fill)

	hp_text = _label("100", 17, Color(1, 1, 1), Vector2(36, H - 84.0), Vector2(316, 30), HORIZONTAL_ALIGNMENT_CENTER)
	hp_text.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	hp_text.add_theme_constant_override("shadow_offset_y", 1)
	hp_text.add_theme_constant_override("shadow_outline_size", 4)

	_label("生命", 14, Color(0.55, 0.66, 0.78), Vector2(36, H - 108.0), Vector2(200, 20), HORIZONTAL_ALIGNMENT_LEFT)

	# 右下：弹药
	ammo_text = _label("30 / 240", 40, Color(1.0, 0.93, 0.72), Vector2(W - 396.0, H - 92.0), Vector2(360, 48), HORIZONTAL_ALIGNMENT_RIGHT)
	weapon_text = _label("突击步枪", 18, Color(0.68, 0.82, 0.95), Vector2(W - 396.0, H - 122.0), Vector2(360, 24), HORIZONTAL_ALIGNMENT_RIGHT)

	# 波次横幅
	banner = _label("", 54, Color(1.0, 0.88, 0.5), Vector2(0, 150), Vector2(W, 66), HORIZONTAL_ALIGNMENT_CENTER)
	banner.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	banner.add_theme_constant_override("shadow_offset_y", 3)
	banner.add_theme_constant_override("shadow_outline_size", 8)
	banner.modulate.a = 0.0

	banner_sub = _label("", 20, Color(0.80, 0.88, 0.96), Vector2(0, 220), Vector2(W, 30), HORIZONTAL_ALIGNMENT_CENTER)
	banner_sub.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	banner_sub.add_theme_constant_override("shadow_outline_size", 6)
	banner_sub.modulate.a = 0.0


## 首领血条：顶部中央，仅在首领在场时显示。
func _build_boss_bar() -> void:
	boss_bar = Control.new()
	boss_bar.position = Vector2(W * 0.5 - 320.0, 86.0)
	boss_bar.size = Vector2(640.0, 52.0)
	boss_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_bar.visible = false
	root.add_child(boss_bar)

	boss_name = _mk_label("首领", 20, Color(1.0, 0.52, 0.30), Vector2(0, 0), Vector2(640.0, 24), HORIZONTAL_ALIGNMENT_CENTER)
	boss_name.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	boss_name.add_theme_constant_override("shadow_outline_size", 5)
	boss_bar.add_child(boss_name)

	var bbg := ColorRect.new()
	bbg.color = Color(0.05, 0.02, 0.03, 0.86)
	bbg.position = Vector2(0, 28)
	bbg.size = Vector2(640.0, 22)
	bbg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_bar.add_child(bbg)

	boss_fill = ColorRect.new()
	boss_fill.color = Color(0.95, 0.24, 0.18)
	boss_fill.position = Vector2(3, 31)
	boss_fill.size = Vector2(634.0, 16)
	boss_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_bar.add_child(boss_fill)

	boss_bar.add_child(_frame(Vector2(0, 28), Vector2(640.0, 22), Color(0.95, 0.42, 0.24, 0.95)))

	boss_hp_text = _mk_label("", 15, Color(1, 1, 1), Vector2(0, 28), Vector2(640.0, 22), HORIZONTAL_ALIGNMENT_CENTER)
	boss_hp_text.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	boss_hp_text.add_theme_constant_override("shadow_outline_size", 4)
	boss_bar.add_child(boss_hp_text)


func _build_pause() -> void:
	pause_panel = _overlay_panel()
	pause_panel.visible = false

	var t := _mk_label("已 暂 停", 44, Color(0.92, 0.97, 1.0), Vector2(0, 190), Vector2(W, 56), HORIZONTAL_ALIGNMENT_CENTER)
	pause_panel.add_child(t)

	var b1 := _panel_button("继 续 游 戏", true)
	b1.position = Vector2(W * 0.5 - 150.0, 300.0)
	b1.pressed.connect(func() -> void:
		Sfx.play("ui")
		resume_pressed.emit())
	pause_panel.add_child(b1)

	var b2 := _panel_button("重 新 开 始", false)
	b2.position = Vector2(W * 0.5 - 150.0, 372.0)
	b2.pressed.connect(func() -> void:
		Sfx.play("ui")
		restart_pressed.emit())
	pause_panel.add_child(b2)

	var b3 := _panel_button("返 回 菜 单", false)
	b3.position = Vector2(W * 0.5 - 150.0, 444.0)
	b3.pressed.connect(func() -> void:
		Sfx.play("ui")
		menu_pressed.emit())
	pause_panel.add_child(b3)


func _build_over() -> void:
	over_panel = _overlay_panel()
	over_panel.visible = false

	over_title = _mk_label("任 务 失 败", 52, Color(1.0, 0.42, 0.40), Vector2(0, 130), Vector2(W, 66), HORIZONTAL_ALIGNMENT_CENTER)
	over_title.add_theme_color_override("font_shadow_color", Color(0.3, 0, 0, 0.8))
	over_title.add_theme_constant_override("shadow_outline_size", 8)
	over_panel.add_child(over_title)

	over_stats = _mk_label("", 22, Color(0.88, 0.93, 1.0), Vector2(0, 220), Vector2(W, 180), HORIZONTAL_ALIGNMENT_CENTER)
	over_stats.add_theme_constant_override("line_spacing", 12)
	over_panel.add_child(over_stats)

	var b1 := _panel_button("再 来 一 局", true)
	b1.position = Vector2(W * 0.5 - 150.0, 470.0)
	b1.pressed.connect(func() -> void:
		Sfx.play("ui")
		restart_pressed.emit())
	over_panel.add_child(b1)

	var b2 := _panel_button("返 回 菜 单", false)
	b2.position = Vector2(W * 0.5 - 150.0, 542.0)
	b2.pressed.connect(func() -> void:
		Sfx.play("ui")
		menu_pressed.emit())
	over_panel.add_child(b2)

	over_hint = _mk_label("按 Enter 再来一局", 16, Color(0.55, 0.62, 0.72), Vector2(0, 616), Vector2(W, 24), HORIZONTAL_ALIGNMENT_CENTER)
	over_panel.add_child(over_hint)


func _overlay_panel() -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02, 0.03, 0.05, 0.78)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	c.add_child(dim)
	root.add_child(c)
	return c


func _label(text: String, size: int, col: Color, pos: Vector2, sz: Vector2, align: int) -> Label:
	var l := _mk_label(text, size, col, pos, sz, align)
	root.add_child(l)
	return l


func _mk_label(text: String, size: int, col: Color, pos: Vector2, sz: Vector2, align: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.position = pos
	l.size = sz
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _frame(pos: Vector2, sz: Vector2, col: Color) -> Panel:
	var p := Panel.new()
	p.position = pos
	p.size = sz
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0)
	sb.border_color = col
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(3)
	p.add_theme_stylebox_override("panel", sb)
	return p


func _panel_button(text: String, primary: bool) -> Button:
	var b := Button.new()
	b.text = text
	b.size = Vector2(300, 56)
	b.add_theme_font_size_override("font_size", 21)
	var normal_bg := Color(0.10, 0.42, 0.66, 0.96) if primary else Color(0.10, 0.13, 0.19, 0.94)
	var hover_bg := Color(0.15, 0.56, 0.85, 1.0) if primary else Color(0.17, 0.23, 0.32, 1.0)
	var border := Color(0.35, 0.78, 1.0, 0.95) if primary else Color(0.30, 0.40, 0.52, 0.9)
	b.add_theme_stylebox_override("normal", _sb(normal_bg, border))
	b.add_theme_stylebox_override("hover", _sb(hover_bg, Color(0.55, 0.9, 1.0)))
	b.add_theme_stylebox_override("pressed", _sb(normal_bg.darkened(0.25), border))
	b.add_theme_stylebox_override("focus", _sb(Color(0, 0, 0, 0), Color(0, 0, 0, 0)))
	b.add_theme_color_override("font_color", Color(0.94, 0.97, 1.0))
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	return b


func _sb(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(8)
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


# ---------------- 运行时更新 ----------------

func _process(delta: float) -> void:
	root.queue_redraw()

	if _hit_t > 0.0:
		_hit_t = maxf(0.0, _hit_t - delta * 3.4)
	_dmg = maxf(0.0, _dmg - delta * 1.6)
	if _banner_t > 0.0:
		_banner_t -= delta
		# 淡入 0.25s → 保持 → 最后 0.6s 淡出。
		# 注意：不要在这里写死 hold 的数值（早先版本把 2.2 写进公式，
		# 导致传 hold=6.0 时横幅前 3.8 秒完全不可见、只在末尾闪一下）。
		var el := _banner_hold - _banner_t
		var a := clampf(el * 4.0, 0.0, 1.0) * clampf(_banner_t * 1.6, 0.0, 1.0)
		banner.modulate.a = a
		banner_sub.modulate.a = a * 0.9

	if player != null and is_instance_valid(player):
		var frac := clampf(player.hp / player.MAX_HP, 0.0, 1.0)
		hp_fill.size.x = 310.0 * frac
		hp_text.text = "%d" % int(ceil(player.hp))
		if frac > 0.55:
			hp_fill.color = Color(0.30, 0.88, 0.46)
		elif frac > 0.28:
			hp_fill.color = Color(0.95, 0.78, 0.25)
		else:
			hp_fill.color = Color(0.95, 0.28, 0.26)
		_lowhp = clampf((0.35 - frac) / 0.35, 0.0, 1.0)
		if _lowhp > 0.0:
			_lowhp *= 0.6 + 0.4 * sin(Time.get_ticks_msec() / 220.0)
		var w = player.weapon
		if w != null:
			var d = w.DATA[w.index]
			weapon_text.text = "%s  ·  %s" % [d["name"], d["tag"]]
			if Cheats.infinite_ammo:
				ammo_text.text = "∞ / ∞"
				ammo_text.add_theme_color_override("font_color", Color(0.55, 0.95, 1.0))
			elif w.reloading:
				ammo_text.text = "换弹中…"
				ammo_text.add_theme_color_override("font_color", Color(0.95, 0.65, 0.30))
			else:
				ammo_text.text = "%d / %d" % [w.ammo, w.reserve]
				ammo_text.add_theme_color_override("font_color", Color(1.0, 0.93, 0.72) if w.ammo > 0 else Color(0.95, 0.35, 0.30))
			var sp: float = w._current_spread()
			_spread_px = lerpf(_spread_px, 6.0 + sp * 9.0, 1.0 - exp(-12.0 * delta))

	if cheat_text != null:
		var cn := Cheats.active_count()
		if cn > 0:
			cheat_text.text = "作弊 %d 项生效　·　按 Q 打开面板" % cn
			cheat_text.add_theme_color_override("font_color", Color(1.0, 0.74, 0.32))
		else:
			cheat_text.text = "按 Q 打开作弊面板"
			cheat_text.add_theme_color_override("font_color", Color(0.40, 0.46, 0.56))

	if vignette_mat != null:
		vignette_mat.set_shader_parameter("damage", _dmg)
		vignette_mat.set_shader_parameter("lowhp", _lowhp)


func _unhandled_input(event: InputEvent) -> void:
	# 作弊面板打开时由它独占按键，HUD 不要抢
	# （否则按 Esc 会既关掉面板、又顺手把游戏恢复成进行中）
	if game != null and is_instance_valid(game) and game.cheat_panel != null \
			and game.cheat_panel.is_open():
		return
	if over_panel != null and over_panel.visible:
		if event.is_action_pressed("jump") or (event is InputEventKey and event.pressed and event.keycode == KEY_ENTER):
			restart_pressed.emit()
			get_viewport().set_input_as_handled()
		return
	if pause_panel != null and pause_panel.visible:
		if event.is_action_pressed("pause"):
			resume_pressed.emit()
			get_viewport().set_input_as_handled()


func set_wave(n: int, remaining: int) -> void:
	wave_text.text = "第 %d 波" % n
	enemy_text.text = "剩余敌人 %d" % remaining


func set_score(v: int) -> void:
	score_text.text = "得分 %d" % v


func set_remaining(remaining: int) -> void:
	enemy_text.text = "剩余敌人 %d" % remaining


# ---------------- 首领血条 ----------------

func show_boss(boss_name_text: String, hp: float, max_hp: float) -> void:
	if boss_bar == null:
		return
	boss_bar.visible = true
	boss_name.text = boss_name_text
	set_boss_hp(hp, max_hp)


func set_boss_hp(hp: float, max_hp: float) -> void:
	if boss_bar == null or not boss_bar.visible:
		return
	var f := clampf(hp / maxf(max_hp, 1.0), 0.0, 1.0)
	boss_fill.size.x = 634.0 * f
	# 血越少越偏红，狂暴阶段基本就是红的
	boss_fill.color = Color(0.95, 0.20, 0.16).lerp(Color(1.0, 0.64, 0.18), f)
	# hp / max_hp 都是浮点：ceil(hp) 会比 int(max_hp) 大 1，
	# 于是满血时显示成「1608 / 1607」。把显示的当前值夹进显示的上限。
	var mx := int(max_hp)
	boss_hp_text.text = "%d / %d" % [mini(int(ceil(maxf(hp, 0.0))), mx), mx]


func hide_boss() -> void:
	if boss_bar != null:
		boss_bar.visible = false


func show_banner(text: String, sub: String, hold: float = 2.2) -> void:
	banner.text = text
	banner_sub.text = sub
	_banner_hold = hold
	_banner_t = hold


func hide_banner() -> void:
	_banner_t = 0.0
	banner.modulate.a = 0.0
	banner_sub.modulate.a = 0.0


func flash_hit(headshot: bool) -> void:
	_hit_t = 1.0
	_hit_head = headshot


func flash_damage(amount: float) -> void:
	_dmg = minf(1.0, _dmg + clampf(amount / 26.0, 0.25, 0.9))


func add_feed(text: String, col: Color) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 16)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("shadow_offset_y", 1)
	l.add_theme_constant_override("shadow_outline_size", 4)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	feed_box.add_child(l)
	while feed_box.get_child_count() > 6:
		feed_box.get_child(0).free()
	var t := l.create_tween()
	t.tween_interval(2.6)
	t.tween_property(l, "modulate:a", 0.0, 0.7)
	t.tween_callback(l.queue_free)


func show_pause(on: bool) -> void:
	pause_panel.visible = on


func show_gameover(stats: Dictionary) -> void:
	over_panel.visible = true
	hide_boss()
	over_title.text = "任 务 失 败"
	over_stats.text = "存活波次    %d\n击杀敌人    %d\n爆头击杀    %d\n命中率      %.1f%%\n本局得分    %d\n最高分      %d" % [
		stats.get("wave", 0), stats.get("kills", 0), stats.get("headshots", 0),
		stats.get("accuracy", 0.0), stats.get("score", 0), stats.get("best", 0),
	]
	_banner_t = 0.0
	banner.modulate.a = 0.0
	banner_sub.modulate.a = 0.0


func hide_gameover() -> void:
	over_panel.visible = false


# ---------------- 绘制 ----------------

func _on_draw() -> void:
	if player == null or not is_instance_valid(player) or not player.alive:
		return
	if pause_panel != null and pause_panel.visible:
		return

	var c := _center
	var gap := _spread_px
	var ln := 10.0
	var col := Color(0.92, 1.0, 0.96, 0.92)
	var w := 2.0

	root.draw_line(c + Vector2(gap, 0), c + Vector2(gap + ln, 0), col, w)
	root.draw_line(c - Vector2(gap, 0), c - Vector2(gap + ln, 0), col, w)
	root.draw_line(c + Vector2(0, gap), c + Vector2(0, gap + ln), col, w)
	root.draw_line(c - Vector2(0, gap), c - Vector2(0, gap + ln), col, w)
	root.draw_circle(c, 1.6, Color(1, 1, 1, 0.95))

	if _hit_t > 0.0:
		var a := clampf(_hit_t, 0.0, 1.0)
		var hc := Color(1.0, 0.45, 0.35, a) if _hit_head else Color(1.0, 1.0, 1.0, a)
		var d0 := 7.0
		var d1 := 17.0
		for sx in [-1.0, 1.0]:
			for sy in [-1.0, 1.0]:
				root.draw_line(c + Vector2(sx * d0, sy * d0), c + Vector2(sx * d1, sy * d1), hc, 2.4)
