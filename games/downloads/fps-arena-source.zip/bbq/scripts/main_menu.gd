extends CanvasLayer

## 主菜单：动态网格背景 + 标题 + 按钮 + 操作说明。

signal start_requested()
signal quit_requested()

const W := 1280.0
const H := 720.0

const UiTheme = preload("res://scripts/ui_theme.gd")

const BG_SHADER := """
shader_type canvas_item;
uniform vec3 top_color : source_color = vec3(0.05, 0.07, 0.12);
uniform vec3 bot_color : source_color = vec3(0.015, 0.02, 0.035);
uniform vec3 line_color : source_color = vec3(0.20, 0.55, 0.78);
uniform float speed = 0.35;
void fragment() {
	vec2 uv = UV;
	vec3 col = mix(top_color, bot_color, uv.y);
	float horizon = 0.60;
	float d = uv.y - horizon;
	if (d > 0.0) {
		float z = 0.06 / d;
		float x = (uv.x - 0.5) * z * 1.6;
		float lz = abs(fract(z * 0.6 - TIME * speed) - 0.5);
		float lx = abs(fract(x * 1.2) - 0.5);
		float w = 0.06 * (1.0 + z * 0.12);
		float line = clamp((1.0 - smoothstep(0.0, w, lz)) + (1.0 - smoothstep(0.0, w, lx)), 0.0, 1.0);
		float fade = smoothstep(0.0, 0.30, d);
		col = mix(col, line_color, line * fade * 0.45);
	}
	float vig = 1.0 - 0.6 * distance(uv, vec2(0.5)) ;
	COLOR = vec4(col * clamp(vig, 0.0, 1.0), 1.0);
}
"""

var root: Control
var help_panel: Control
var best_label: Label


func _ready() -> void:
	layer = 20
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	UiTheme.attach(root)
	_build()
	_build_help()


func _build() -> void:
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = BG_SHADER
	mat.shader = sh
	bg.material = mat
	root.add_child(bg)

	var title := Label.new()
	title.text = "FPS  ARENA"
	title.add_theme_font_size_override("font_size", 76)
	title.add_theme_color_override("font_color", Color(0.92, 0.96, 1.0))
	title.add_theme_color_override("font_shadow_color", Color(0.1, 0.6, 0.9, 0.85))
	title.add_theme_constant_override("shadow_offset_x", 0)
	title.add_theme_constant_override("shadow_offset_y", 4)
	title.add_theme_constant_override("shadow_outline_size", 10)
	title.position = Vector2(0, 118)
	title.size = Vector2(W, 96)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(title)

	var sub := Label.new()
	sub.text = "3D 第一人称竞技射击  ·  单机生存模式"
	sub.add_theme_font_size_override("font_size", 21)
	sub.add_theme_color_override("font_color", Color(0.55, 0.78, 0.92))
	sub.position = Vector2(0, 218)
	sub.size = Vector2(W, 32)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(sub)

	var y := 330.0
	var b1 := _make_button("开 始 游 戏", true)
	b1.position = Vector2(W * 0.5 - 150.0, y)
	b1.pressed.connect(func() -> void:
		Sfx.play("ui")
		start_requested.emit())
	root.add_child(b1)

	var b2 := _make_button("操 作 说 明", false)
	b2.position = Vector2(W * 0.5 - 150.0, y + 70.0)
	b2.pressed.connect(func() -> void:
		Sfx.play("ui")
		help_panel.visible = not help_panel.visible)
	root.add_child(b2)

	var b3 := _make_button("退 出 游 戏", false)
	b3.position = Vector2(W * 0.5 - 150.0, y + 140.0)
	b3.pressed.connect(func() -> void:
		Sfx.play("ui")
		quit_requested.emit())
	root.add_child(b3)

	best_label = Label.new()
	best_label.add_theme_font_size_override("font_size", 16)
	best_label.add_theme_color_override("font_color", Color(0.62, 0.70, 0.80))
	best_label.position = Vector2(0, H - 52.0)
	best_label.size = Vector2(W, 24)
	best_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(best_label)

	var hint := Label.new()
	hint.text = "点击按钮后鼠标将被锁定，按 Esc 可暂停"
	hint.add_theme_font_size_override("font_size", 14)
	hint.add_theme_color_override("font_color", Color(0.42, 0.48, 0.56))
	hint.position = Vector2(0, H - 30.0)
	hint.size = Vector2(W, 20)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(hint)


func _build_help() -> void:
	help_panel = Control.new()
	help_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	help_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	help_panel.visible = false
	root.add_child(help_panel)

	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02, 0.03, 0.05, 0.82)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	help_panel.add_child(dim)

	var panel := Panel.new()
	panel.position = Vector2(W * 0.5 - 340.0, 120.0)
	panel.size = Vector2(680, 470)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.09, 0.13, 0.96)
	sb.border_color = Color(0.25, 0.60, 0.85, 0.9)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(10)
	panel.add_theme_stylebox_override("panel", sb)
	help_panel.add_child(panel)

	var title := Label.new()
	title.text = "操作说明"
	title.add_theme_font_size_override("font_size", 30)
	title.add_theme_color_override("font_color", Color(0.85, 0.94, 1.0))
	title.position = Vector2(32, 22)
	title.size = Vector2(616, 44)
	panel.add_child(title)

	var rows := [
		["W A S D", "移动"],
		["鼠标", "转向瞄准"],
		["鼠标左键", "射击（按住连发）"],
		["鼠标右键", "机瞄（缩小准星、降低散布）"],
		["空格", "跳跃"],
		["Shift", "冲刺"],
		["R", "换弹"],
		["1 / 2 / 3 / 4", "切换武器"],
		["E / 滚轮", "切换下一把武器"],
		["Esc", "暂停 / 继续"],
	]
	var y := 84.0
	for r in rows:
		var k := Label.new()
		k.text = r[0]
		k.add_theme_font_size_override("font_size", 17)
		k.add_theme_color_override("font_color", Color(0.45, 0.85, 1.0))
		k.position = Vector2(36, y)
		k.size = Vector2(240, 26)
		panel.add_child(k)

		var v := Label.new()
		v.text = r[1]
		v.add_theme_font_size_override("font_size", 17)
		v.add_theme_color_override("font_color", Color(0.82, 0.86, 0.92))
		v.position = Vector2(286, y)
		v.size = Vector2(360, 26)
		panel.add_child(v)
		y += 38.0

	var tip := Label.new()
	tip.text = "目标：守住场地，击退一波又一波敌人。\n击杀敌人有概率掉落医疗包与弹药箱。"
	tip.add_theme_font_size_override("font_size", 15)
	tip.add_theme_color_override("font_color", Color(0.60, 0.68, 0.78))
	tip.position = Vector2(36, y + 8.0)
	tip.size = Vector2(616, 60)
	panel.add_child(tip)

	var close := _make_button("关 闭", false)
	close.position = Vector2(W * 0.5 - 80.0, 520.0)
	close.size = Vector2(160, 46)
	close.pressed.connect(func() -> void:
		Sfx.play("ui")
		help_panel.visible = false)
	help_panel.add_child(close)


func _make_button(text: String, primary: bool) -> Button:
	var b := Button.new()
	b.text = text
	b.size = Vector2(300, 54)
	b.add_theme_font_size_override("font_size", 20)

	var normal_bg := Color(0.10, 0.42, 0.66, 0.95) if primary else Color(0.10, 0.13, 0.19, 0.92)
	var hover_bg := Color(0.14, 0.55, 0.84, 1.0) if primary else Color(0.16, 0.22, 0.31, 1.0)
	var border := Color(0.35, 0.78, 1.0, 0.95) if primary else Color(0.30, 0.40, 0.52, 0.9)

	b.add_theme_stylebox_override("normal", _sb(normal_bg, border, 2))
	b.add_theme_stylebox_override("hover", _sb(hover_bg, Color(0.55, 0.9, 1.0), 2))
	b.add_theme_stylebox_override("pressed", _sb(normal_bg.darkened(0.2), border, 2))
	b.add_theme_stylebox_override("focus", _sb(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 0))
	b.add_theme_color_override("font_color", Color(0.94, 0.97, 1.0))
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	return b


func _sb(bg: Color, border: Color, bw: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(8)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


func open() -> void:
	visible = true
	help_panel.visible = false
	best_label.text = "最高分 %d      最远波次 %d" % [GameState.best_score, GameState.best_wave]


func close() -> void:
	visible = false
