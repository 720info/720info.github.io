extends Area3D

## 掉落物：医疗包 / 弹药箱。玩家走近自动拾取。

var kind := "health"
var amount := 25.0
var base_y := 1.0
var _t := 0.0
var _taken := false
var _core: MeshInstance3D


func setup(k: String, amt: float) -> void:
	kind = k
	amount = amt


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitoring = true

	var cs := CollisionShape3D.new()
	var s := SphereShape3D.new()
	s.radius = 1.25
	cs.shape = s
	add_child(cs)

	var col := Color(0.30, 0.95, 0.45) if kind == "health" else Color(1.0, 0.72, 0.22)

	_core = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.42, 0.42, 0.42)
	_core.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.emission_enabled = true
	m.emission = col
	m.emission_energy_multiplier = 2.2
	m.metallic = 0.4
	_core.material_override = m
	add_child(_core)

	# 外圈光环
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.36
	tm.outer_radius = 0.44
	tm.rings = 12
	tm.ring_segments = 6
	ring.mesh = tm
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = col
	rm.emission_enabled = true
	rm.emission = col
	rm.emission_energy_multiplier = 3.0
	ring.material_override = rm
	add_child(ring)

	var l := OmniLight3D.new()
	l.light_color = col
	l.light_energy = 1.6
	l.omni_range = 4.0
	add_child(l)

	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_t += delta
	rotate_y(delta * 2.4)
	if _core != null:
		_core.rotation.x += delta * 1.6
	position.y = base_y + sin(_t * 3.2) * 0.14


func _on_body_entered(body: Node3D) -> void:
	if _taken:
		return
	if body == null or not body.has_method("heal"):
		return
	_taken = true
	if kind == "health":
		body.heal(amount)
	else:
		var w = body.weapon
		if w != null:
			w.add_ammo(int(amount))
	Sfx.play("pickup", -4.0, 1.0 if kind == "health" else 1.25)
	_burst()


func _burst() -> void:
	var parent := get_parent()
	if parent == null:
		queue_free()
		return
	var col := Color(0.30, 0.95, 0.45) if kind == "health" else Color(1.0, 0.72, 0.22)
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.3
	sm.height = 0.6
	mi.mesh = sm
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = col
	m.emission_enabled = true
	m.emission = col
	m.emission_energy_multiplier = 5.0
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = m
	parent.add_child(mi)
	mi.global_position = global_position
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3.ONE * 3.5, 0.3)
	t.tween_property(m, "albedo_color:a", 0.0, 0.3)
	t.chain().tween_callback(mi.queue_free)
	queue_free()
