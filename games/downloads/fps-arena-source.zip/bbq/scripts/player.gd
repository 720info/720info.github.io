extends CharacterBody3D

## 玩家：FPS 控制器（移动 / 视角 / 跳跃 / 冲刺 / 头部晃动 / 受伤死亡）。

signal health_changed(hp: float, max_hp: float)
signal died()
signal damaged(amount: float, dir: Vector3)

const SPEED := 6.4
const SPRINT_SPEED := 9.4
const ACCEL := 16.0
const AIR_ACCEL := 4.5
const JUMP_VELOCITY := 5.6
const GRAVITY := 20.0
const MOUSE_SENS := 0.0022
const MAX_HP := 100.0
const HEAD_HEIGHT := 1.62
const BODY_HEIGHT := 1.8
const BODY_RADIUS := 0.4
const PITCH_LIMIT := 1.45
const BASE_FOV := 82.0
const AIM_FOV := 58.0
const REGEN_DELAY := 5.0
const REGEN_RATE := 9.0

var hp := MAX_HP
var alive := true
var aiming := false
var god_mode := false

var yaw := 0.0
var pitch := 0.0
var recoil_pitch := 0.0
var recoil_yaw := 0.0

var head: Node3D
var cam: Camera3D
var weapon = null
var game = null
var effects: Node3D = null

var _bob_time := 0.0
var _bob := Vector3.ZERO
var _foot_t := 0.0
var _hurt_t := 0.0
var _dead_t := 0.0
var _no_dmg_t := 0.0
var _last_regen_int := -1
var _spawn_pos := Vector3.ZERO


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1 | 4
	floor_max_angle = deg_to_rad(52.0)
	floor_snap_length = 0.5
	_build_body()
	health_changed.emit(hp, MAX_HP)


func setup(g, fx: Node3D) -> void:
	game = g
	effects = fx
	if weapon != null:
		weapon.effects = fx


func _build_body() -> void:
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = BODY_RADIUS
	cap.height = BODY_HEIGHT
	cs.shape = cap
	cs.position = Vector3(0, BODY_HEIGHT * 0.5, 0)
	add_child(cs)

	head = Node3D.new()
	head.name = "Head"
	head.position = Vector3(0, HEAD_HEIGHT, 0)
	add_child(head)

	cam = Camera3D.new()
	cam.name = "Camera"
	cam.fov = BASE_FOV
	cam.near = 0.05
	cam.far = 400.0
	cam.current = true
	head.add_child(cam)

	weapon = preload("res://scripts/weapon.gd").new()
	weapon.name = "Weapon"
	weapon.player = self
	cam.add_child(weapon)


func _unhandled_input(event: InputEvent) -> void:
	if not alive:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var mm: InputEventMouseMotion = event
		yaw -= mm.relative.x * MOUSE_SENS
		pitch -= mm.relative.y * MOUSE_SENS
		pitch = clampf(pitch, -PITCH_LIMIT, PITCH_LIMIT)


func _physics_process(delta: float) -> void:
	if not alive:
		velocity = velocity.lerp(Vector3.ZERO, 1.0 - exp(-6.0 * delta))
		move_and_slide()
		return

	rotation.y = yaw

	var on_floor := is_on_floor()
	var flying := Cheats.fly_mode
	if flying:
		# 飞行：关掉重力，空格上升 / Shift 下降。仍然和墙体碰撞（不做穿墙），
		# 免得飞出地图或卡进几何体。
		var vy := 0.0
		if Input.is_action_pressed("jump"):
			vy += Cheats.FLY_SPEED
		if Input.is_action_pressed("sprint"):
			vy -= Cheats.FLY_SPEED
		velocity.y = vy
	elif on_floor:
		if Input.is_action_just_pressed("jump"):
			velocity.y = JUMP_VELOCITY * (Cheats.JUMP_MUL if Cheats.super_jump else 1.0)
			Sfx.play("step", -14.0, 1.35)
	else:
		velocity.y -= GRAVITY * delta
		velocity.y = maxf(velocity.y, -45.0)

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var wish := transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)
	wish.y = 0.0
	if wish.length() > 1.0:
		wish = wish.normalized()

	var sprinting := Input.is_action_pressed("sprint") and input_dir.y < -0.1 and on_floor and not aiming
	var target_speed := SPRINT_SPEED if sprinting else SPEED
	if aiming:
		target_speed *= 0.55
	if flying:
		target_speed *= Cheats.FLY_MOVE_MUL
	if Cheats.super_speed:
		target_speed *= Cheats.SPEED_MUL
	var target := wish * target_speed
	var accel := ACCEL if (on_floor or flying) else AIR_ACCEL
	var hv := Vector3(velocity.x, 0.0, velocity.z)
	hv = hv.lerp(target, 1.0 - exp(-accel * delta))
	velocity.x = hv.x
	velocity.z = hv.z

	move_and_slide()
	_update_bob(delta, on_floor)


func _process(delta: float) -> void:
	if not alive:
		_dead_t += delta
		return

	# 后坐力回复
	recoil_pitch = lerpf(recoil_pitch, 0.0, 1.0 - exp(-11.0 * delta))
	recoil_yaw = lerpf(recoil_yaw, 0.0, 1.0 - exp(-11.0 * delta))
	head.rotation.x = clampf(pitch + recoil_pitch, -PITCH_LIMIT, PITCH_LIMIT)
	head.rotation.y = recoil_yaw

	# 机瞄
	var want_aim := Input.is_action_pressed("aim") and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
	aiming = want_aim
	cam.fov = lerpf(cam.fov, AIM_FOV if aiming else BASE_FOV, 1.0 - exp(-14.0 * delta))

	_hurt_t = maxf(0.0, _hurt_t - delta)

	# 脱战回血：5 秒未受伤后缓慢恢复
	_no_dmg_t += delta
	if _hurt_t <= 0.0 and _no_dmg_t > REGEN_DELAY and hp < MAX_HP:
		hp = minf(MAX_HP, hp + REGEN_RATE * delta)
		var hi := int(ceil(hp))
		if hi != _last_regen_int:
			_last_regen_int = hi
			health_changed.emit(hp, MAX_HP)

	# 武器输入
	if weapon != null and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		weapon.update(delta, Input.is_action_pressed("fire"), Input.is_action_just_pressed("fire"))
		if Input.is_action_just_pressed("reload"):
			weapon.start_reload()
		if Input.is_action_just_pressed("weapon_1"):
			weapon.switch_to(0)
		if Input.is_action_just_pressed("weapon_2"):
			weapon.switch_to(1)
		if Input.is_action_just_pressed("weapon_3"):
			weapon.switch_to(2)
		if Input.is_action_just_pressed("weapon_4"):
			weapon.switch_to(3)
		if Input.is_action_just_pressed("weapon_next"):
			weapon.switch_to((weapon.index + 1) % weapon.DATA.size())


func _update_bob(delta: float, on_floor: bool) -> void:
	var spd := Vector2(velocity.x, velocity.z).length()
	if on_floor and spd > 0.6:
		_bob_time += delta * (4.0 + spd * 1.15)
		var amp := 0.032 * clampf(spd / SPEED, 0.45, 1.5)
		_bob = Vector3(cos(_bob_time) * amp * 0.8, -absf(sin(_bob_time)) * amp, 0.0)
		_foot_t -= delta * (1.0 + spd * 0.35)
		if _foot_t <= 0.0:
			_foot_t = 3.2
			Sfx.play("step", -24.0, randf_range(0.88, 1.12))
	else:
		_bob = _bob.lerp(Vector3.ZERO, 1.0 - exp(-9.0 * delta))
	head.position = Vector3(_bob.x, HEAD_HEIGHT + _bob.y, 0.0)


func add_recoil(amount: float) -> void:
	recoil_pitch += amount * 0.016
	recoil_yaw += randf_range(-1.0, 1.0) * amount * 0.004


func take_damage(amount: float, dir: Vector3 = Vector3.ZERO) -> void:
	if not alive or god_mode or Cheats.god_mode:
		return
	hp = maxf(0.0, hp - amount)
	_hurt_t = 0.4
	_no_dmg_t = 0.0
	_last_regen_int = -1
	health_changed.emit(hp, MAX_HP)
	damaged.emit(amount, dir)
	if hp <= 0.0:
		_die()


func heal(amount: float) -> void:
	if not alive:
		return
	hp = minf(MAX_HP, hp + amount)
	health_changed.emit(hp, MAX_HP)
	Sfx.play("pickup", -6.0)


func is_hurt_recent() -> bool:
	return _hurt_t > 0.0


func _die() -> void:
	alive = false
	velocity = Vector3.ZERO
	aiming = false
	Sfx.play("die", -4.0)
	if weapon != null:
		weapon.visible = false
	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(head, "position", Vector3(0.0, 0.42, 0.0), 0.85).set_ease(Tween.EASE_OUT)
	t.tween_property(head, "rotation", Vector3(deg_to_rad(-16.0), head.rotation.y, deg_to_rad(74.0)), 0.85)
	died.emit()


func respawn(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	hp = MAX_HP
	alive = true
	recoil_pitch = 0.0
	recoil_yaw = 0.0
	pitch = 0.0
	_no_dmg_t = 0.0
	_hurt_t = 0.0
	_last_regen_int = -1
	if weapon != null:
		weapon.visible = true
		weapon.reset_ammo()
	head.rotation = Vector3.ZERO
	health_changed.emit(hp, MAX_HP)
