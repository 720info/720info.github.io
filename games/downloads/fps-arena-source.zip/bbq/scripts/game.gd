extends Node3D

## 对局主控：关卡 / 玩家 / HUD / 波次 / 掉落 / 暂停 / 结算。

signal exit_to_menu()

const LevelScript = preload("res://scripts/level.gd")
const PlayerScript = preload("res://scripts/player.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const HudScript = preload("res://scripts/hud.gd")
const PickupScript = preload("res://scripts/pickup.gd")
const CheatPanelScript = preload("res://scripts/cheat_panel.gd")

const PLAYER_SPAWN := Vector3(0.0, 0.3, 20.0)

const SPAWN_POINTS := [
	Vector3(-33.0, 0.2, -33.0), Vector3(33.0, 0.2, -33.0),
	Vector3(-33.0, 0.2, 33.0), Vector3(33.0, 0.2, 33.0),
	Vector3(0.0, 0.2, -33.0), Vector3(0.0, 0.2, 33.0),
	Vector3(-33.0, 0.2, 0.0), Vector3(33.0, 0.2, 0.0),
	Vector3(-22.0, 0.2, -22.0), Vector3(22.0, 0.2, -22.0),
	Vector3(-22.0, 0.2, 22.0), Vector3(22.0, 0.2, 22.0),
	Vector3(-33.0, 0.2, -12.0), Vector3(33.0, 0.2, 12.0),
	Vector3(-15.0, 0.2, 30.0), Vector3(15.0, 0.2, -30.0),
]

const BREAK_TIME := 5.0

var level: Node3D
var player = null
var hud = null
var cheat_panel = null
var boss = null            # 当前在场的首领（没有则为 null），HUD 血条靠它刷新
var enemies_root: Node3D
var effects: Node3D
var pickups_root: Node3D

var wave := 0
var wave_active := false
var break_t := 0.0
var spawn_queue: Array = []
var spawn_t := 0.0
var is_paused := false
var game_over := false
var _over_t := 0.0
var suppress_auto_pause := false   # 截图流程用：禁止失焦自动暂停


func _ready() -> void:
	GameState.reset_run()
	_build_world()
	_build_player()
	_build_hud()
	_build_cheats()
	wave = 0
	wave_active = false
	break_t = 2.2
	_announce("准备战斗", "敌人即将来袭")


func _build_world() -> void:
	level = LevelScript.new()
	level.name = "Level"
	add_child(level)
	level.build()

	effects = Node3D.new()
	effects.name = "Effects"
	add_child(effects)

	enemies_root = Node3D.new()
	enemies_root.name = "Enemies"
	add_child(enemies_root)

	pickups_root = Node3D.new()
	pickups_root.name = "Pickups"
	add_child(pickups_root)


func _build_player() -> void:
	player = PlayerScript.new()
	player.name = "Player"
	add_child(player)
	player.global_position = PLAYER_SPAWN
	player.setup(self, effects)
	player.health_changed.connect(_on_health_changed)
	player.died.connect(_on_player_died)
	player.damaged.connect(_on_player_damaged)
	var w = player.weapon
	if w != null:
		w.hit_confirmed.connect(_on_hit_confirmed)
		w.ammo_changed.connect(_on_ammo_changed)


func _build_hud() -> void:
	hud = HudScript.new()
	hud.name = "HUD"
	add_child(hud)
	hud.setup(player, self)
	hud.resume_pressed.connect(_resume)
	hud.restart_pressed.connect(_restart)
	hud.menu_pressed.connect(_to_menu)
	hud.set_wave(0, 0)
	hud.set_score(0)


func _build_cheats() -> void:
	# 必须加在 hud 之后：同级节点里后加入的更靠后，未处理输入会先到它手上，
	# 这样按 Q / Esc 时作弊面板能先消费掉，不会同时弹出暂停菜单。
	cheat_panel = CheatPanelScript.new()
	cheat_panel.name = "CheatPanel"
	add_child(cheat_panel)
	cheat_panel.setup(self)


# ---------------- 作弊动作 ----------------

## 秒杀全场：走正常伤害流程，所以会计分、掉落、播报。
func kill_all_enemies() -> int:
	var n := 0
	for c in enemies_root.get_children():
		if c is CharacterBody3D and c.alive:
			c.take_damage(1.0e9, Vector3.FORWARD)
			n += 1
	return n


## 清空敌人：直接移除，不计分、不掉落（和「秒杀全场」区分开）。
func clear_all_enemies() -> int:
	var n := alive_enemy_count()
	clear_enemies()
	spawn_queue.clear()
	if hud != null:
		hud.set_remaining(0)
	return n


func skip_break() -> void:
	if wave_active:
		# 波次进行中：把还没投放的敌人清掉，让本波尽快结束
		spawn_queue.clear()
		if alive_enemy_count() == 0:
			_end_wave()
	else:
		break_t = 0.0


func heal_player_full() -> void:
	if player == null or not is_instance_valid(player) or not player.alive:
		return
	player.hp = player.MAX_HP
	player.health_changed.emit(player.hp, player.MAX_HP)
	Sfx.play("pickup", -6.0)


func refill_player_ammo() -> void:
	if player == null or not is_instance_valid(player) or player.weapon == null:
		return
	player.weapon.refill_all()
	Sfx.play("reload", -6.0, 1.1)


func add_cheat_score(n: int) -> void:
	GameState.add_score(n)
	if hud != null:
		hud.set_score(GameState.score)


# ---------------- 波次 ----------------

func _process(delta: float) -> void:
	_update_boss_bar()

	if game_over:
		_over_t += delta
		return

	if not wave_active:
		break_t -= delta
		if break_t <= 0.0:
			_start_wave()
		return

	# 分批投放
	if spawn_queue.size() > 0:
		spawn_t -= delta
		if spawn_t <= 0.0:
			spawn_t = maxf(0.16, 0.72 - wave * 0.03)
			var item = spawn_queue.pop_front()
			_spawn_with_effect(item[0], item[1])

	var alive := alive_enemy_count()
	if alive > 0:
		hud.set_remaining(alive + spawn_queue.size())
	elif spawn_queue.size() == 0:
		_end_wave()


func _start_wave() -> void:
	wave += 1
	GameState.wave = wave
	wave_active = true
	var comp := _wave_composition(wave)
	spawn_queue.clear()
	var pts := SPAWN_POINTS.duplicate()
	pts.shuffle()
	var i := 0
	for c in comp:
		var p: Vector3 = pts[i % pts.size()]
		spawn_queue.append([c, p])
		i += 1
	spawn_t = 0.05
	hud.set_wave(wave, comp.size())
	Sfx.play("wave", -6.0)
	if wave == 1:
		_announce("第 1 波", "共 %d 名敌人" % comp.size())
	elif wave % 5 == 0:
		_announce("第 %d 波" % wave, "首领来袭 · 击破它！")
	else:
		_announce("第 %d 波" % wave, "共 %d 名敌人" % comp.size())


func _wave_composition(w: int) -> Array:
	var out := []
	var grunts := 3 + w
	var rushers := maxi(0, w - 1)
	var heavies := maxi(0, (w - 2) / 2)
	if w >= 6:
		grunts += 2
	if w >= 9:
		rushers += 2
	for i in grunts:
		out.append(0)
	for i in rushers:
		out.append(1)
	for i in heavies:
		out.append(2)
	# 总数上限，避免卡顿。先裁杂兵 —— 首领在裁剪之后才追加，
	# 否则高波次（杂兵数量多）会把首领一起裁掉。
	while out.size() > 22:
		out.pop_back()
	if w % 5 == 0:
		out.append(EnemyScript.BOSS_KIND)
	return out


func _end_wave() -> void:
	wave_active = false
	break_t = BREAK_TIME
	hud.set_remaining(0)
	# 波次奖励
	GameState.add_score(50 * wave)
	player.heal(22.0)
	var w = player.weapon
	if w != null:
		w.add_ammo(60)
	_announce("第 %d 波 已肃清" % wave, "补给已投放 · 下一波 %d 秒后" % int(BREAK_TIME))
	Sfx.play("wave", -4.0, 1.2)


func _announce(text: String, sub: String) -> void:
	if hud != null:
		hud.show_banner(text, sub)


# ---------------- 敌人生成 ----------------

func _spawn_with_effect(kind: int, pos: Vector3) -> void:
	_spawn_marker(pos)
	var e = spawn_enemy_at(kind, pos)
	if e != null:
		Sfx.play_at("spawn", pos, -10.0)


func _spawn_marker(pos: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.75
	cyl.bottom_radius = 0.75
	cyl.height = 4.0
	cyl.radial_segments = 16
	cyl.rings = 0
	mi.mesh = cyl
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(1.0, 0.45, 0.20, 0.5)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.45, 0.20)
	mat.emission_energy_multiplier = 3.0
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	mi.position = pos + Vector3(0, 2.0, 0)
	effects.add_child(mi)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3(1.6, 1.0, 1.6), 0.45)
	t.tween_property(mat, "albedo_color:a", 0.0, 0.45)
	t.chain().tween_callback(mi.queue_free)


func spawn_enemy_at(kind: int, pos: Vector3):
	kind = clampi(kind, 0, EnemyScript.TYPES.size() - 1)
	var e = EnemyScript.new()
	e.name = "Enemy"
	enemies_root.add_child(e)
	e.player = player
	e.game = self
	e.effects = effects
	e.configure(kind, 1.0 + maxf(0.0, wave - 1) * 0.10)
	e.set_colors(EnemyScript.TYPES[kind]["body"], EnemyScript.TYPES[kind]["accent"])
	e.global_position = pos
	e.died.connect(_on_enemy_died)
	if e.is_boss:
		boss = e
		if hud != null:
			hud.show_boss(EnemyScript.TYPES[kind]["name"], e.hp, e.max_hp)
	hud.set_remaining(alive_enemy_count())
	return e


func alive_enemy_count() -> int:
	var n := 0
	for c in enemies_root.get_children():
		if c is CharacterBody3D and c.alive:
			n += 1
	return n


func clear_enemies() -> void:
	for c in enemies_root.get_children():
		c.queue_free()
	for c in pickups_root.get_children():
		c.queue_free()
	# 首领被清掉时血条也要跟着收，否则会留一条空血条挂在屏幕顶上
	boss = null
	if hud != null:
		hud.hide_boss()


## 每帧同步首领血条。首领死掉或被移除时自动收起血条。
func _update_boss_bar() -> void:
	if hud == null:
		return
	# 结算面板已经盖满屏幕，血条不该再冒出来。show_gameover() 里刚 hide_boss() 过，
	# 这里若不早退，下一帧就会因为「boss 还活着且血条隐藏」又把它拉回来
	# —— 症状：结算界面上方挂着一条暗淡的首领血条。
	if game_over:
		return
	if boss != null and is_instance_valid(boss) and boss.alive:
		if not hud.boss_bar.visible:
			# 血条被别处收起来过（例如结算面板）就重新点亮 ——
			# set_boss_hp() 在 visible=false 时会直接 return，只刷数值拉不回来。
			hud.show_boss(EnemyScript.TYPES[boss.kind]["name"], boss.hp, boss.max_hp)
		else:
			hud.set_boss_hp(boss.hp, boss.max_hp)
	elif boss != null:
		boss = null
		hud.hide_boss()


# ---------------- 事件 ----------------

func _on_enemy_died(e, score_value: int) -> void:
	GameState.add_kill()
	GameState.add_score(score_value)
	hud.set_score(GameState.score)
	Sfx.play("hit", -12.0, 1.4)
	if e.is_boss:
		hud.add_feed("击破 首领  +%d" % score_value, Color(1.0, 0.60, 0.32))
		_on_boss_died(e)
	else:
		hud.add_feed("击杀 %s  +%d" % [EnemyScript.TYPES[e.kind]["name"], score_value], Color(0.95, 0.85, 0.55))
		_maybe_drop(e.global_position, e.kind)
	hud.set_remaining(alive_enemy_count())


func _on_boss_died(e) -> void:
	boss = null
	if hud != null:
		hud.hide_boss()
	_announce("首 领 已 击 破", "战场暂时安静了")
	Sfx.play("wave", -2.0, 0.82)
	# 首领必掉补给 —— 打完一场硬仗不该让玩家空手走
	_drop(e.global_position + Vector3(1.5, 0, 0.7), "health")
	_drop(e.global_position + Vector3(-1.5, 0, 0.7), "ammo")


## 首领血量掉到阈值以下时由 enemy.gd 回调：播报 + 召唤两名护卫。
func on_boss_enraged(e) -> void:
	if hud != null:
		hud.add_feed("首领狂暴！", Color(1.0, 0.35, 0.25))
	_announce("首 领 暴 怒", "速度与火力大幅提升 · 还叫来了护卫")
	Sfx.play("wave", -3.0, 0.62)
	var p: Vector3 = e.global_position
	_spawn_with_effect(0, p + Vector3(2.9, 0.2, 1.4))
	_spawn_with_effect(1, p + Vector3(-2.9, 0.2, 1.4))


func _maybe_drop(pos: Vector3, kind: int) -> void:
	var r := randf()
	if kind == 2:
		_drop(pos, "ammo" if r < 0.6 else "health")
	elif r < 0.16:
		_drop(pos, "health")
	elif r < 0.34:
		_drop(pos, "ammo")


func _drop(pos: Vector3, kind: String) -> void:
	var p = PickupScript.new()
	p.setup(kind, 30.0 if kind == "health" else 40.0)
	var y := 0.9
	p.base_y = y
	p.position = Vector3(pos.x, y, pos.z)
	pickups_root.add_child(p)


func _on_hit_confirmed(headshot: bool) -> void:
	if hud != null:
		hud.flash_hit(headshot)
	if headshot:
		GameState.add_headshot()


func _on_ammo_changed(_cur: int, _reserve: int) -> void:
	pass


func _on_health_changed(_hp: float, _max_hp: float) -> void:
	pass


func _on_player_damaged(amount: float, _dir: Vector3) -> void:
	if hud != null:
		hud.flash_damage(amount)


func _on_player_died() -> void:
	if game_over:
		return
	game_over = true
	_over_t = 0.0
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	GameState.finish_run()
	await get_tree().create_timer(1.6).timeout
	if hud != null:
		hud.show_gameover({
			"wave": wave,
			"kills": GameState.kills,
			"headshots": GameState.headshots,
			"accuracy": GameState.accuracy(),
			"score": GameState.score,
			"best": GameState.best_score,
		})


# ---------------- 暂停 / 重开 ----------------

func _unhandled_input(event: InputEvent) -> void:
	if game_over:
		return
	# 作弊面板开着时它自己处理按键，这里不能再弹暂停菜单（否则会叠两层）
	if cheat_panel != null and cheat_panel.is_open():
		return
	if event.is_action_pressed("pause"):
		_toggle_pause()
		get_viewport().set_input_as_handled()


func _toggle_pause() -> void:
	if is_paused:
		_resume()
	else:
		_pause()


func _pause() -> void:
	is_paused = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if hud != null:
		hud.show_pause(true)


func _resume() -> void:
	is_paused = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if hud != null:
		hud.show_pause(false)


func _restart() -> void:
	get_tree().paused = false
	if hud != null:
		hud.hide_gameover()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	clear_enemies()
	game_over = false
	is_paused = false
	wave = 0
	wave_active = false
	spawn_queue.clear()
	break_t = 2.0
	GameState.reset_run()
	player.respawn(PLAYER_SPAWN)
	player.yaw = 0.0
	if hud != null:
		hud.set_score(0)
		hud.set_wave(0, 0)
		hud.set_remaining(0)
	_announce("准备战斗", "敌人即将来袭")


func _to_menu() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	exit_to_menu.emit()


func _notification(what: int) -> void:
	# 截图流程里窗口必然会被遮挡/失焦，此时自动暂停会污染画面（踩过：
	# 03_combat 截成了暂停面板）。
	if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT \
			and not suppress_auto_pause and not game_over and not is_paused \
			and (cheat_panel == null or not cheat_panel.is_open()):
		_pause()


# ---------------- 工具 / 测试 ----------------

func is_point_blocked(pos: Vector3) -> bool:
	var space := get_world_3d().direct_space_state
	var ps := PhysicsShapeQueryParameters3D.new()
	var sph := SphereShape3D.new()
	sph.radius = 0.55
	ps.shape = sph
	ps.transform = Transform3D(Basis(), pos)
	ps.collision_mask = 1
	return space.intersect_shape(ps, 1).size() > 0


func _hold(e) -> void:
	if e != null:
		e.set_physics_process(false)
		e.velocity = Vector3.ZERO


func debug_setup_shot_scene() -> void:
	clear_enemies()
	player.god_mode = true
	wave = 3
	wave_active = true
	spawn_queue.clear()
	player.global_position = Vector3(0.0, 0.3, 16.0)
	player.yaw = 0.0
	player.pitch = -0.02
	player.hp = 68.0
	player.health_changed.emit(player.hp, player.MAX_HP)
	player.weapon.ammo = 21
	player.weapon.ammo_changed.emit(21, player.weapon.reserve)
	_hold(spawn_enemy_at(0, Vector3(-4.2, 0.2, 11.5)))
	_hold(spawn_enemy_at(0, Vector3(4.6, 0.2, 10.5)))
	_hold(spawn_enemy_at(1, Vector3(-6.6, 0.2, 7.5)))
	_hold(spawn_enemy_at(2, Vector3(7.4, 0.2, 6.2)))
	_hold(spawn_enemy_at(0, Vector3(0.0, 2.45, 0.5)))
	hud.set_wave(wave, 5)
	hud.set_remaining(5)
	hud.set_score(1420)
	hud.show_banner("第 3 波", "共 9 名敌人", 6.0)
	hud.flash_hit(false)


func debug_setup_shot_scene2() -> void:
	player.global_position = Vector3(-8.0, 0.3, 12.0)
	player.yaw = 0.10
	player.pitch = -0.05
	player.hp = 34.0
	player.health_changed.emit(player.hp, player.MAX_HP)
	player.weapon.ammo = 6
	player.weapon.ammo_changed.emit(6, player.weapon.reserve)
	_hold(spawn_enemy_at(1, Vector3(-7.2, 0.2, 5.0)))
	_hold(spawn_enemy_at(0, Vector3(-11.0, 0.2, 2.5)))
	_hold(spawn_enemy_at(2, Vector3(-9.6, 0.2, -3.0)))
	_hold(spawn_enemy_at(0, Vector3(-13.5, 0.2, 7.0)))
	hud.add_feed("击杀 重装兵  +260", Color(0.95, 0.85, 0.55))
	hud.add_feed("击杀 步兵  +100", Color(0.95, 0.85, 0.55))
	hud.hide_banner()   # 交火图里不要留波次横幅的淡出残影
	hud.flash_hit(true)
	hud.flash_damage(30.0)


func debug_force_gameover() -> void:
	# 先确保脱离暂停态，否则结算面板会叠在暂停面板上。
	if is_paused:
		_resume()
	get_tree().paused = false
	game_over = true
	hud.show_gameover({
		"wave": 5,
		"kills": 42,
		"headshots": 11,
		"accuracy": 63.8,
		"score": 7860,
		"best": 9120,
	})


## 截图用：打开作弊面板并点亮若干开关，让状态标签有内容可看。
func debug_open_cheats() -> void:
	Cheats.god_mode = true
	Cheats.infinite_ammo = true
	Cheats.one_shot = true
	Cheats.no_spread = true
	Cheats.fly_mode = true
	Cheats.freeze_enemies = true
	Cheats.bullet_time = true
	Cheats.changed.emit()
	if cheat_panel != null:
		cheat_panel.open()


## 截图用：摆一个首领 + 两名杂兵的对峙场面，首领血条显示成残血。
func debug_boss_shot() -> void:
	clear_enemies()
	player.god_mode = true
	wave = 5
	wave_active = true
	spawn_queue.clear()
	player.global_position = Vector3(0.0, 0.3, 18.5)
	player.yaw = 0.0
	player.pitch = 0.10
	player.hp = 76.0
	player.health_changed.emit(player.hp, player.MAX_HP)
	player.weapon.ammo = 17
	player.weapon.ammo_changed.emit(17, player.weapon.reserve)

	var b = spawn_enemy_at(EnemyScript.BOSS_KIND, Vector3(0.0, 0.2, 6.5))
	if b != null:
		b.rotation.y = PI          # 面朝玩家（physics 被停掉后不会再自己转向）
		b.hp = b.max_hp * 0.62
		b._set_hp_visual(0.62)
		if hud != null:
			hud.set_boss_hp(b.hp, b.max_hp)
	_hold(spawn_enemy_at(0, Vector3(-6.2, 0.2, 10.0)))
	_hold(spawn_enemy_at(1, Vector3(6.6, 0.2, 9.4)))
	_hold(b)

	hud.set_wave(5, 3)
	hud.set_remaining(3)
	hud.set_score(5240)
	hud.hide_banner()
