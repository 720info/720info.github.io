extends CanvasLayer

## 作弊面板（按 Q 开关）。
##
## 数据驱动：所有条目写在 GROUPS 里，改作弊只需要改这张表 + cheats.gd。
## 两类条目：
##   toggle —— 开关型，点一下切换 Cheats 里的对应开关，右侧显示「开启 / 关闭」
##   action —— 动作型，点一下立刻执行一次，右侧显示「执行」
##
## 打开时暂停游戏并释放鼠标（否则玩家一边看面板一边被打）。
## 关闭时如果暂停面板还开着就保持暂停，否则恢复。

const W := 1280.0
const H := 720.0

const UiTheme = preload("res://scripts/ui_theme.gd")

const PANEL_POS := Vector2(140.0, 36.0)
const PANEL_SIZE := Vector2(1000.0, 648.0)
const COL_W := 460.0
const COL_X := [34.0, 506.0]
const BODY_Y := 116.0
const ROW_H := 38.0
const HEAD_H := 30.0
const GROUP_GAP := 12.0
const BTN_W := 214.0
const BTN_H := 32.0

## 每行： [类型, key, 名称, 说明]
const GROUPS := [
	{
		"col": 0, "title": "战 斗",
		"items": [
			["toggle", "god_mode", "无敌模式", "免疫一切伤害"],
			["toggle", "infinite_ammo", "无限弹药", "不消耗子弹、免换弹"],
			["toggle", "one_shot", "一击必杀", "命中即击杀"],
			["toggle", "rapid_fire", "极速射击", "射速提升约 5 倍"],
			["toggle", "no_spread", "精准枪法", "零散布、无后坐力"],
			["toggle", "full_auto", "全自动", "所有武器按住连发"],
		],
	},
	{
		"col": 0, "title": "移 动",
		"items": [
			["toggle", "super_speed", "疾风步", "移动速度 x2.2"],
			["toggle", "super_jump", "超级跳", "起跳高度 x2.1"],
			["toggle", "fly_mode", "飞行模式", "空格上升 / Shift 下降"],
		],
	},
	{
		"col": 1, "title": "敌 人",
		"items": [
			["toggle", "freeze_enemies", "冻结敌人", "AI 停止移动与开火"],
			["toggle", "weak_enemies", "弱化敌人", "受到伤害 x8"],
			["action", "kill_all", "秒杀全场", "击杀所有敌人并计分"],
			["action", "clear_enemies", "清空敌人", "直接移除，不计分"],
			["action", "next_wave", "立即下一波", "跳过当前休整时间"],
		],
	},
	{
		"col": 1, "title": "角 色",
		"items": [
			["action", "heal_full", "回满生命", "生命值补满"],
			["action", "refill_ammo", "补满弹药", "所有武器弹匣拉满"],
			["action", "add_score", "加分 +1000", "直接加 1000 分"],
		],
	},
	{
		"col": 1, "title": "世 界",
		"items": [
			["toggle", "bullet_time", "子弹时间", "时间流速 x0.35"],
			["action", "reset_all", "全部关闭", "清空所有作弊开关"],
		],
	},
]

var game = null

var root: Control
var _panel: Panel
var _open := false
var _prev_paused := false
var _rows := {}          # key -> {"btn": Button, "state": Label, "kind": String}
var _col_y := {}         # 列号 -> 下一个分组的起始 y（同列分组依次往下排）
var _toast: Label
var _toast_t := 0.0


func _ready() -> void:
	layer = 50
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false

	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)
	# attach 必须在入树之后：内部走 get_window()，不在树里会拿到 null 静默失效。
	UiTheme.attach(root)

	_build()
	Cheats.changed.connect(_refresh)


func setup(g) -> void:
	game = g
	_refresh()


# ---------------- 构建 ----------------

func _build() -> void:
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02, 0.03, 0.05, 0.72)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(dim)

	_panel = Panel.new()
	_panel.position = PANEL_POS
	_panel.size = PANEL_SIZE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.055, 0.070, 0.105, 0.97)
	sb.border_color = Color(0.30, 0.72, 0.95, 0.9)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(10)
	_panel.add_theme_stylebox_override("panel", sb)
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(_panel)

	var title := _mk_label("作 弊 面 板", 34, Color(0.55, 0.92, 1.0), Vector2(0, 14), Vector2(PANEL_SIZE.x, 42), HORIZONTAL_ALIGNMENT_CENTER)
	_panel.add_child(title)

	var hint := _mk_label("按 Q 或 Esc 关闭　·　点击开关立即生效　·　打开面板时游戏暂停", 14,
		Color(0.52, 0.62, 0.74), Vector2(0, 58), Vector2(PANEL_SIZE.x, 22), HORIZONTAL_ALIGNMENT_CENTER)
	_panel.add_child(hint)

	var rule := ColorRect.new()
	rule.color = Color(0.22, 0.34, 0.46, 0.85)
	rule.position = Vector2(28, 88)
	rule.size = Vector2(PANEL_SIZE.x - 56.0, 1)
	rule.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(rule)

	_col_y.clear()
	for g in GROUPS:
		_build_group(g)

	_toast = _mk_label("", 15, Color(0.60, 0.95, 0.70), Vector2(0, PANEL_SIZE.y - 34.0),
		Vector2(PANEL_SIZE.x, 26), HORIZONTAL_ALIGNMENT_CENTER)
	_panel.add_child(_toast)


func _build_group(g: Dictionary) -> void:
	var col: int = int(g["col"])
	var x: float = COL_X[col]
	# 同一列可能有多个分组，必须接着上一个分组的尾巴往下排。
	# 早先这里写死 BODY_Y，导致同列分组全部从同一 y 起画、层层叠在一起。
	var y: float = _col_y.get(col, BODY_Y)

	var head := _mk_label(g["title"], 17, Color(0.98, 0.78, 0.38), Vector2(x, y), Vector2(COL_W, HEAD_H), HORIZONTAL_ALIGNMENT_LEFT)
	_panel.add_child(head)
	y += HEAD_H

	for it in g["items"]:
		var kind: String = it[0]
		var key: String = it[1]
		var btn := _mk_button(it[2], kind == "toggle")
		btn.position = Vector2(x, y)
		btn.size = Vector2(BTN_W, BTN_H)
		btn.pressed.connect(_on_row_pressed.bind(kind, key))
		_panel.add_child(btn)

		var st := _mk_label("", 15, Color(0.6, 0.6, 0.6), Vector2(x + BTN_W + 8.0, y),
			Vector2(54, BTN_H), HORIZONTAL_ALIGNMENT_CENTER)
		_panel.add_child(st)

		var desc := _mk_label(it[3], 13, Color(0.56, 0.64, 0.74), Vector2(x + BTN_W + 68.0, y),
			Vector2(COL_W - BTN_W - 68.0, BTN_H), HORIZONTAL_ALIGNMENT_LEFT)
		_panel.add_child(desc)

		_rows[key] = {"btn": btn, "state": st, "kind": kind}
		y += ROW_H

	_col_y[col] = y + GROUP_GAP


func _mk_label(text: String, size: int, col: Color, pos: Vector2, sz: Vector2, align: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.position = pos
	l.size = sz
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _mk_button(text: String, is_toggle: bool) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", 16)
	var base := Color(0.11, 0.145, 0.205, 0.95) if is_toggle else Color(0.10, 0.175, 0.20, 0.95)
	var bord := Color(0.28, 0.38, 0.50, 0.9) if is_toggle else Color(0.25, 0.55, 0.62, 0.9)
	b.add_theme_stylebox_override("normal", _sb(base, bord))
	b.add_theme_stylebox_override("hover", _sb(base.lightened(0.16), Color(0.55, 0.9, 1.0)))
	b.add_theme_stylebox_override("pressed", _sb(base.darkened(0.22), bord))
	b.add_theme_stylebox_override("focus", _sb(Color(0, 0, 0, 0), Color(0, 0, 0, 0)))
	b.add_theme_color_override("font_color", Color(0.90, 0.95, 1.0))
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	return b


func _sb(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(6)
	s.content_margin_left = 14
	s.content_margin_right = 10
	s.content_margin_top = 6
	s.content_margin_bottom = 6
	return s


# ---------------- 交互 ----------------

func is_open() -> bool:
	return _open


func _can_open() -> bool:
	if game == null or not is_instance_valid(game):
		return true
	return not game.game_over


func open() -> void:
	if _open:
		return
	_open = true
	_prev_paused = get_tree().paused
	visible = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh()


func close() -> void:
	if not _open:
		return
	_open = false
	visible = false
	# 暂停面板还开着的话，关掉作弊面板不应该顺手把游戏也恢复了。
	var keep := _prev_paused
	if game != null and is_instance_valid(game) and game.is_paused:
		keep = true
	get_tree().paused = keep
	if not keep:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _on_row_pressed(kind: String, key: String) -> void:
	Sfx.play("ui")
	if kind == "toggle":
		var on := Cheats.toggle(key)
		_toast_text("%s 已%s" % [_row_name(key), "开启" if on else "关闭"])
	else:
		var msg := _run_action(key)
		_toast_text(msg)
	_refresh()


func _row_name(key: String) -> String:
	for g in GROUPS:
		for it in g["items"]:
			if it[1] == key:
				return it[2]
	return key


func _run_action(key: String) -> String:
	if game == null or not is_instance_valid(game):
		return "没有进行中的对局"
	match key:
		"kill_all":
			# game 是无类型引用，返回值是 Variant，这里必须显式标注，
			# 用 := 会报「Cannot infer the type」。
			var n: int = game.kill_all_enemies()
			return "已击杀 %d 名敌人" % n
		"clear_enemies":
			var n2: int = game.clear_all_enemies()
			return "已清空 %d 名敌人" % n2
		"next_wave":
			game.skip_break()
			return "已跳到下一波"
		"heal_full":
			game.heal_player_full()
			return "生命值已补满"
		"refill_ammo":
			game.refill_player_ammo()
			return "弹药已补满"
		"add_score":
			game.add_cheat_score(1000)
			return "得分 +1000"
		"reset_all":
			Cheats.reset()
			return "所有作弊已关闭"
	return "未知操作"


func _toast_text(msg: String) -> void:
	if _toast != null:
		_toast.text = msg
		_toast_t = 2.4


# ---------------- 刷新 ----------------

func _refresh() -> void:
	for key in _rows:
		var r: Dictionary = _rows[key]
		var btn: Button = r["btn"]
		var st: Label = r["state"]
		if r["kind"] == "toggle":
			var on := Cheats.get_flag(key)
			st.text = "开启" if on else "关闭"
			st.add_theme_color_override("font_color",
				Color(0.42, 0.95, 0.52) if on else Color(0.46, 0.52, 0.60))
			var sb := _sb(
				Color(0.13, 0.34, 0.22, 0.95) if on else Color(0.11, 0.145, 0.205, 0.95),
				Color(0.40, 0.92, 0.55) if on else Color(0.28, 0.38, 0.50, 0.9))
			btn.add_theme_stylebox_override("normal", sb)
		else:
			st.text = "执行"
			st.add_theme_color_override("font_color", Color(0.42, 0.82, 0.95))


func _process(delta: float) -> void:
	if _toast_t > 0.0:
		_toast_t -= delta
		if _toast_t <= 0.0 and _toast != null:
			_toast.text = ""


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("cheat_panel"):
		if _open:
			close()
		elif _can_open():
			open()
		get_viewport().set_input_as_handled()
		return

	# 打开时 Esc 只关面板，不要再弹暂停菜单
	if _open and event is InputEventKey:
		var k: InputEventKey = event
		if k.pressed and not k.echo and k.keycode == KEY_ESCAPE:
			close()
			get_viewport().set_input_as_handled()
