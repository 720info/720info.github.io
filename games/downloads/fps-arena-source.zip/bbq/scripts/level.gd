extends Node3D

## 竞技场关卡：全程序化生成，零外部资源。

const HALF := 36.0

const GROUND_SHADER := """
shader_type spatial;
render_mode cull_disabled, specular_schlick_ggx;
uniform vec3 base_color : source_color = vec3(0.075, 0.085, 0.11);
uniform vec3 line_color : source_color = vec3(0.20, 0.48, 0.68);
uniform vec3 glow_color : source_color = vec3(0.15, 0.75, 0.85);
uniform float cells = 20.0;
void fragment() {
	vec2 g = UV * cells;
	vec2 gr = abs(fract(g - 0.5) - 0.5) / fwidth(g);
	float line = 1.0 - min(min(gr.x, gr.y), 1.0);
	// 中心环
	float ring = 1.0 - smoothstep(0.0, 0.02, abs(distance(UV, vec2(0.5)) - 0.26));
	ALBEDO = mix(base_color, line_color, line * 0.65);
	ALBEDO = mix(ALBEDO, glow_color, ring * 0.5);
	ROUGHNESS = 0.78;
	METALLIC = 0.05;
}
"""

# 掩体 / 箱子：{p: 中心位置, s: 尺寸}
const COVER := [
	{"p": Vector3(-17.0, 0.9, -14.0), "s": Vector3(3.4, 1.8, 3.4)},
	{"p": Vector3(-17.0, 2.7, -14.0), "s": Vector3(2.4, 1.8, 2.4)},
	{"p": Vector3(-12.0, 0.7, -20.0), "s": Vector3(3.0, 1.4, 3.0)},
	{"p": Vector3(-21.0, 0.6, -8.0), "s": Vector3(2.6, 1.2, 2.6)},
	{"p": Vector3(17.0, 0.9, 14.0), "s": Vector3(3.4, 1.8, 3.4)},
	{"p": Vector3(17.0, 2.7, 14.0), "s": Vector3(2.4, 1.8, 2.4)},
	{"p": Vector3(12.0, 0.7, 20.0), "s": Vector3(3.0, 1.4, 3.0)},
	{"p": Vector3(21.0, 0.6, 8.0), "s": Vector3(2.6, 1.2, 2.6)},
	{"p": Vector3(-17.0, 0.9, 14.0), "s": Vector3(3.4, 1.8, 3.4)},
	{"p": Vector3(17.0, 0.9, -14.0), "s": Vector3(3.4, 1.8, 3.4)},
	{"p": Vector3(-12.0, 0.7, 20.0), "s": Vector3(3.0, 1.4, 3.0)},
	{"p": Vector3(12.0, 0.7, -20.0), "s": Vector3(3.0, 1.4, 3.0)},
	{"p": Vector3(0.0, 1.1, -25.0), "s": Vector3(10.0, 2.2, 2.2)},
	{"p": Vector3(0.0, 1.1, 25.0), "s": Vector3(10.0, 2.2, 2.2)},
	{"p": Vector3(-25.0, 1.1, 0.0), "s": Vector3(2.2, 2.2, 10.0)},
	{"p": Vector3(25.0, 1.1, 0.0), "s": Vector3(2.2, 2.2, 10.0)},
	{"p": Vector3(-28.0, 1.2, -28.0), "s": Vector3(4.4, 2.4, 4.4)},
	{"p": Vector3(28.0, 1.2, 28.0), "s": Vector3(4.4, 2.4, 4.4)},
	{"p": Vector3(-28.0, 1.2, 28.0), "s": Vector3(4.4, 2.4, 4.4)},
	{"p": Vector3(28.0, 1.2, -28.0), "s": Vector3(4.4, 2.4, 4.4)},
	{"p": Vector3(-8.0, 0.6, -30.0), "s": Vector3(2.4, 1.2, 2.4)},
	{"p": Vector3(8.0, 0.6, 30.0), "s": Vector3(2.4, 1.2, 2.4)},
	{"p": Vector3(30.0, 0.6, -8.0), "s": Vector3(2.4, 1.2, 2.4)},
	{"p": Vector3(-30.0, 0.6, 8.0), "s": Vector3(2.4, 1.2, 2.4)},
]

const PILLARS := [
	Vector3(-12.0, 4.0, -12.0),
	Vector3(12.0, 4.0, 12.0),
	Vector3(-12.0, 4.0, 12.0),
	Vector3(12.0, 4.0, -12.0),
]

const CRATE_COLORS := [
	Color(0.30, 0.33, 0.40),
	Color(0.42, 0.30, 0.20),
	Color(0.24, 0.34, 0.42),
	Color(0.36, 0.28, 0.38),
]

var _mat_cache := {}


func build() -> void:
	_build_environment()
	_build_ground()
	_build_walls()
	_build_center_platform()
	_build_cover()
	_build_pillars()
	_build_lights()


func _build_environment() -> void:
	var we := WorldEnvironment.new()
	we.name = "WorldEnvironment"
	var env := Environment.new()

	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.10, 0.14, 0.24)
	sm.sky_horizon_color = Color(0.30, 0.34, 0.42)
	sm.ground_bottom_color = Color(0.05, 0.06, 0.08)
	sm.ground_horizon_color = Color(0.16, 0.18, 0.22)
	sm.sun_angle_max = 8.0
	sky.sky_material = sm
	env.sky = sky

	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_sky_contribution = 0.85
	env.ambient_light_energy = 1.0

	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	env.glow_enabled = true
	env.glow_intensity = 0.55
	env.glow_bloom = 0.12
	env.glow_hdr_threshold = 1.05

	env.ssao_enabled = true
	env.ssao_radius = 1.4
	env.ssao_intensity = 1.2

	env.fog_enabled = true
	env.fog_light_color = Color(0.18, 0.22, 0.30)
	env.fog_density = 0.0075
	env.fog_sky_affect = 0.25

	we.environment = env
	add_child(we)


func _build_ground() -> void:
	var body := StaticBody3D.new()
	body.name = "Ground"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)

	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(HALF * 2.0, 2.0, HALF * 2.0)
	cs.shape = box
	cs.position = Vector3(0, -1.0, 0)
	body.add_child(cs)

	var mesh := PlaneMesh.new()
	mesh.size = Vector2(HALF * 2.0, HALF * 2.0)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	var mat := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = GROUND_SHADER
	mat.shader = sh
	mi.material_override = mat
	body.add_child(mi)


func _build_walls() -> void:
	var h := 9.0
	var t := 2.0
	var defs := [
		{"p": Vector3(0, h * 0.5, -HALF - t * 0.5), "s": Vector3(HALF * 2.0 + t * 2.0, h, t)},
		{"p": Vector3(0, h * 0.5, HALF + t * 0.5), "s": Vector3(HALF * 2.0 + t * 2.0, h, t)},
		{"p": Vector3(-HALF - t * 0.5, h * 0.5, 0), "s": Vector3(t, h, HALF * 2.0)},
		{"p": Vector3(HALF + t * 0.5, h * 0.5, 0), "s": Vector3(t, h, HALF * 2.0)},
	]
	var mat := _material(Color(0.14, 0.16, 0.21), 0.05)
	for d in defs:
		var body := StaticBody3D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		add_child(body)
		var cs := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = d["s"]
		cs.shape = box
		body.add_child(cs)
		body.position = d["p"]

		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = d["s"]
		mi.mesh = bm
		mi.material_override = mat
		body.add_child(mi)

		# 墙顶发光条，增强轮廓
		var strip := MeshInstance3D.new()
		var sm := BoxMesh.new()
		sm.size = Vector3(d["s"].x, 0.16, d["s"].z)
		strip.mesh = sm
		strip.material_override = _emissive(Color(0.20, 0.62, 0.85), 2.2)
		strip.position = Vector3(0, h * 0.5 + 0.1, 0)
		body.add_child(strip)


func _build_center_platform() -> void:
	var ph := 2.4
	_add_box_static(Vector3(0, ph * 0.5, 0), Vector3(11.0, ph, 11.0), Color(0.20, 0.24, 0.30))

	# 四条坡道（坡度约 17°，CharacterBody3D 可直接走上去）
	var ramp_mat := Color(0.26, 0.30, 0.37)
	var ang := 16.7
	var rl := 8.4
	var d := 5.5 + rl * 0.5 - 0.4
	_add_ramp(Vector3(0, ph * 0.5, -d), Vector3(4.6, 0.4, rl), -ang, ramp_mat)
	_add_ramp(Vector3(0, ph * 0.5, d), Vector3(4.6, 0.4, rl), ang, ramp_mat)
	_add_ramp(Vector3(-d, ph * 0.5, 0), Vector3(rl, 0.4, 4.6), ang, ramp_mat, true)
	_add_ramp(Vector3(d, ph * 0.5, 0), Vector3(rl, 0.4, 4.6), -ang, ramp_mat, true)

	# 平台边缘发光带
	for i in 4:
		var strip := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(11.2, 0.1, 0.18) if i < 2 else Vector3(0.18, 0.1, 11.2)
		strip.mesh = bm
		strip.material_override = _emissive(Color(0.15, 0.70, 0.85), 2.6)
		strip.position = Vector3(0, ph + 0.05, (-5.6 if i == 0 else 5.6)) if i < 2 else Vector3((-5.6 if i == 2 else 5.6), ph + 0.05, 0)
		add_child(strip)


func _build_cover() -> void:
	var i := 0
	for c in COVER:
		var col: Color = CRATE_COLORS[i % CRATE_COLORS.size()]
		_add_box_static(c["p"], c["s"], col)
		# 顶面小发光点，让掩体更好辨认
		if c["s"].y >= 1.4:
			var dot := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(c["s"].x * 0.55, 0.06, c["s"].z * 0.55)
			dot.mesh = bm
			dot.material_override = _emissive(Color(0.95, 0.62, 0.20), 1.6)
			dot.position = c["p"] + Vector3(0, c["s"].y * 0.5 + 0.03, 0)
			add_child(dot)
		i += 1


func _build_pillars() -> void:
	var mat := Color(0.17, 0.20, 0.26)
	for p in PILLARS:
		_add_box_static(p, Vector3(1.8, 8.0, 1.8), mat)
		var strip := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(1.95, 7.4, 0.08)
		strip.mesh = bm
		strip.material_override = _emissive(Color(0.25, 0.75, 0.95), 1.8)
		strip.position = p + Vector3(0, 0, 0.95)
		add_child(strip)


func _build_lights() -> void:
	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.light_color = Color(1.0, 0.96, 0.88)
	sun.light_energy = 1.35
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 120.0
	sun.directional_shadow_blend_splits = true
	sun.rotation_degrees = Vector3(-48, 38, 0)
	add_child(sun)

	var accent := OmniLight3D.new()
	accent.name = "CenterGlow"
	accent.light_color = Color(0.25, 0.80, 1.0)
	accent.light_energy = 3.0
	accent.omni_range = 22.0
	accent.position = Vector3(0, 5.0, 0)
	add_child(accent)

	for p in PILLARS:
		var l := OmniLight3D.new()
		l.light_color = Color(0.95, 0.60, 0.25)
		l.light_energy = 2.2
		l.omni_range = 14.0
		l.position = p + Vector3(0, 3.2, 0)
		add_child(l)


# ---------------- 工具 ----------------

func _add_box_static(pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos
	add_child(body)

	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	cs.shape = box
	body.add_child(cs)

	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _material(color, 0.06)
	body.add_child(mi)
	return body


func _add_ramp(pos: Vector3, size: Vector3, ang_deg: float, color: Color, along_x: bool = false) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos
	if along_x:
		body.rotation.z = deg_to_rad(ang_deg)
	else:
		body.rotation.x = deg_to_rad(ang_deg)
	add_child(body)

	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	cs.shape = box
	body.add_child(cs)

	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _material(color, 0.05)
	body.add_child(mi)


func _material(c: Color, metallic: float) -> StandardMaterial3D:
	var key := "%s_%.2f" % [c.to_html(false), metallic]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metallic
	m.roughness = 0.72
	_mat_cache[key] = m
	return m


func _emissive(c: Color, energy: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m
