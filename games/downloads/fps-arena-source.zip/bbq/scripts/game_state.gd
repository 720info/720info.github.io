extends Node

## 跨场景保存的战绩数据（autoload）。

signal score_changed(score: int)
signal kills_changed(kills: int)

const SAVE_PATH := "user://fps_arena_save.cfg"

var score := 0
var kills := 0
var wave := 0
var headshots := 0
var best_score := 0
var best_wave := 0
var total_shots := 0
var total_hits := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_data()


func reset_run() -> void:
	score = 0
	kills = 0
	wave = 0
	headshots = 0
	total_shots = 0
	total_hits = 0
	score_changed.emit(score)
	kills_changed.emit(kills)


func add_score(n: int) -> void:
	score += n
	score_changed.emit(score)


func add_kill() -> void:
	kills += 1
	kills_changed.emit(kills)


func add_headshot() -> void:
	headshots += 1


func register_shot() -> void:
	total_shots += 1


func register_hit() -> void:
	total_hits += 1


func accuracy() -> float:
	if total_shots <= 0:
		return 0.0
	return float(total_hits) / float(total_shots) * 100.0


func finish_run() -> void:
	var dirty := false
	if score > best_score:
		best_score = score
		dirty = true
	if wave > best_wave:
		best_wave = wave
		dirty = true
	if dirty:
		save_data()


func save_data() -> void:
	var cf := ConfigFile.new()
	cf.set_value("stats", "best_score", best_score)
	cf.set_value("stats", "best_wave", best_wave)
	cf.save(SAVE_PATH)


func load_data() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		best_score = int(cf.get_value("stats", "best_score", 0))
		best_wave = int(cf.get_value("stats", "best_wave", 0))
