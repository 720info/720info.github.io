extends RefCounted
class_name UiTheme

## 中文显示的关键：必须把内置默认主题里所有字体条目全部覆写，
## 只设 default_font 是打不过内置主题的（内置主题里 Label/font 等都有显式条目）。
## 另外控件必须挂在 Control/Window 祖先链下才能继承主题，见 attach()。

const FONT_NAMES := [
	"Hiragino Sans GB", "Heiti SC", "STHeiti",
	"Songti SC", "STSong",
	"PingFang SC",
	"Microsoft YaHei", "SimHei",
	"Noto Sans CJK SC", "Noto Sans SC",
	"WenQuanYi Micro Hei",
	"sans-serif",
]

## 打进包里的中文字体子集（GB2312 全集 + 项目用到的字符，约 1MB）。
## Web 平台取不到系统字体（SystemFont 依赖 OS.get_system_font_path()，Web 未实现），
## 不内置的话中文会全渲染成豆腐块。生成方式见 tools/subset_font.py。
const BUNDLED_FONT := "res://assets/fonts/NotoSansSC-Regular.woff2"


static func build() -> Theme:
	var f := _make_font()

	var t := Theme.new()
	t.default_font = f
	t.default_font_size = 16

	var def := ThemeDB.get_default_theme()
	if def != null:
		for ty in def.get_font_type_list():
			for item in def.get_font_list(ty):
				t.set_font(item, ty, f)
			for item in def.get_font_size_list(ty):
				t.set_font_size(item, ty, def.get_font_size(item, ty))
	return t


## 内置字体为主，系统字体作兜底（桌面端遇到 GB2312 之外的生僻字还能救一下；
## Web 端系统字体解析不到，但主字体已经覆盖了全部用到的字符，无害）。
static func _make_font() -> Font:
	var sys := SystemFont.new()
	sys.font_names = PackedStringArray(FONT_NAMES)
	sys.subpixel_positioning = TextServer.SUBPIXEL_POSITIONING_AUTO
	sys.antialiasing = TextServer.FONT_ANTIALIASING_GRAY

	if not ResourceLoader.exists(BUNDLED_FONT):
		printerr("[UI] 未找到内置中文字体 %s，Web 端中文会变豆腐块" % BUNDLED_FONT)
		return sys

	var base := load(BUNDLED_FONT)
	if base == null or not (base is Font):
		printerr("[UI] 内置中文字体加载失败: %s" % BUNDLED_FONT)
		return sys

	var fv := FontVariation.new()
	fv.base_font = base
	fv.fallbacks = [sys]
	# 注意：subpixel_positioning / antialiasing 是 FontFile / SystemFont 的属性，
	# FontVariation 没有，设了会报 Invalid assignment。
	return fv


## 把 Window 上的主题补挂到挂在 Node3D / Node2D 下的 Control 上。
## 必须在构建子节点之前调用，否则控件会按旧字体算错尺寸。
## 也必须在节点**入树之后**调用 —— 不在树里时 get_window() 返回 null，
## 早先版本会静默失效（症状：中文全变豆腐块，且没有任何报错）。
static func attach(c: Control) -> void:
	if not c.is_inside_tree():
		printerr("[UI] UiTheme.attach() 在节点入树前调用，主题未生效（中文会变豆腐块）。" +
			"请先 add_child() 再 attach()。")
		return
	var w := c.get_window()
	if w == null:
		printerr("[UI] UiTheme.attach() 拿不到 Window，主题未生效。")
		return
	if w.theme == null:
		printerr("[UI] Window 上没有主题，请先调用 UiTheme.build() 并赋给 window.theme。")
		return
	c.theme = w.theme
