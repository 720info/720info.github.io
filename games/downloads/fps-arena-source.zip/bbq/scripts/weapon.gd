extends Node3D

## 武器：命中扫描（hitscan）射击、弹匣/备弹、换弹、后坐力、枪口火光、曳光弹。

signal ammo_changed(cur: int, reserve: int)
signal fired()
signal reload_started(duration: float)
signal reload_finished()
signal hit_confirmed(headshot: bool)
signal recoil(amount: float)
signal weapon_changed(index: int, name: String)

const DATA := [
	{
		"name": "突击步枪", "tag": "AR", "auto": true,
		"cd": 0.095, "dmg": 22.0, "mag": 30, "reserve": 240, "max_reserve": 240,
		"spread": 0.55, "move_spread": 2.4, "recoil": 0.62, "pellets": 1,
		"range": 130.0, "reload": 1.85, "color": Color(0.72, 0.75, 0.80),
	},
	{
		"name": "霰弹枪", "tag": "SG", "auto": false,
		"cd": 0.72, "dmg": 13.0, "mag": 8, "reserve": 56, "max_reserve": 56,
		"spread": 3.6, "move_spread": 3.0, "recoil": 2.6, "pellets": 9,
		"range": 45.0, "reload": 2.5, "color": Color(0.62, 0.44, 0.28),
	},
	{
		"name": "冲锋枪", "tag": "SMG", "auto": true,
		"cd": 0.062, "dmg": 14.0, "mag": 40, "reserve": 320, "max_reserve": 320,
		"spread": 1.15, "move_spread": 2.0, "recoil": 0.42, "pellets": 1,
		"range": 90.0, "reload": 1.6, "color": Color(0.45, 0.55, 0.62),
	},
	{
		"name": "精准手枪", "tag": "DMR", "auto": false,
		"cd": 0.24, "dmg": 46.0, "mag": 12, "reserve": 96, "max_reserve": 96,
		"spread": 0.12, "move_spread": 3.2, "recoil": 1.5, "pellets": 1,
		"range": 160.0, "reload": 1.45, "color": Color(0.85, 0.80, 0.55),
	},
]

var index := 0
var ammo := 30
var reserve := 240
var cooldown := 0.0
var reloading := false
var reload_t := 0.0
var player = null
var effects: Node3D = null

var _muzzle: Node3D
var _flash_mesh: MeshInstance3D
var _flash_light: OmniLight3D
var _flash_t := 0.0
var _kick := 0.0
var _kick_rot := 0.0
var _reload_swing := 0.0
var _sway := Vector2.ZERO
var _body_mat: StandardMaterial3D
var _accent_mat: StandardMaterial3D
var _base_pos := Vector3(0.25, -0.21, -0.52)
var _hit_marker_t := 0.0


func _ready() -> void:
	_build_model()
	_apply_weapon_look()
	ammo = DATA[index]["mag"]
	reserve = DATA[index]["reserve"]


func reset_ammo() -> void:
	index = 0
	reloading = false
	ammo = DATA[index]["mag"]
	reserve = DATA[index]["reserve"]
	_apply_weapon_look()
	ammo_changed.emit(ammo, reserve)


func _build_model() -> void:
	_body_mat = StandardMaterial3D.new()
	_body_mat.metallic = 0.75
	_body_mat.roughness = 0.35
	_accent_mat = StandardMaterial3D.new()
	_accent_mat.metallic = 0.3
	_accent_mat.roughness = 0.6

	var root := Node3D.new()
	root.name = "Rig"
	add_child(root)

	# 机匣
	root.add_child(_box(Vector3(0.085, 0.115, 0.44), Vector3(0, 0, -0.02), _body_mat))
	# 枪管
	var barrel := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.021
	cyl.bottom_radius = 0.021
	cyl.height = 0.40
	cyl.radial_segments = 10
	barrel.mesh = cyl
	barrel.rotation.x = deg_to_rad(90.0)
	barrel.position = Vector3(0, 0.012, -0.42)
	barrel.material_override = _body_mat
	root.add_child(barrel)

	# 弹匣
	root.add_child(_box(Vector3(0.055, 0.19, 0.10), Vector3(0, -0.14, 0.03), _accent_mat))
	# 握把
	var grip := _box(Vector3(0.055, 0.15, 0.07), Vector3(0, -0.11, 0.19), _accent_mat)
	grip.rotation.x = deg_to_rad(-14.0)
	root.add_child(grip)
	# 准星
	root.add_child(_box(Vector3(0.03, 0.045, 0.03), Vector3(0, 0.08, -0.14), _accent_mat))
	root.add_child(_box(Vector3(0.05, 0.035, 0.03), Vector3(0, 0.075, 0.14), _accent_mat))
	# 战术导轨
	root.add_child(_box(Vector3(0.05, 0.018, 0.30), Vector3(0, 0.062, 0.0), _accent_mat))

	_muzzle = Node3D.new()
	_muzzle.name = "Muzzle"
	_muzzle.position = Vector3(0, 0.012, -0.63)
	root.add_child(_muzzle)

	_flash_mesh = MeshInstance3D.new()
	var fm := SphereMesh.new()
	fm.radius = 0.055
	fm.height = 0.11
	fm.radial_segments = 8
	fm.rings = 4
	_flash_mesh.mesh = fm
	var fmat := StandardMaterial3D.new()
	fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.albedo_color = Color(1.0, 0.85, 0.45)
	fmat.emission_enabled = true
	fmat.emission = Color(1.0, 0.80, 0.40)
	fmat.emission_energy_multiplier = 8.0
	_flash_mesh.material_override = fmat
	_flash_mesh.visible = false
	_muzzle.add_child(_flash_mesh)

	_flash_light = OmniLight3D.new()
	_flash_light.light_color = Color(1.0, 0.82, 0.45)
	_flash_light.light_energy = 4.0
	_flash_light.omni_range = 7.0
	_flash_light.visible = false
	_muzzle.add_child(_flash_light)


func _box(size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	return mi


func _apply_weapon_look() -> void:
	var c: Color = DATA[index]["color"]
	_body_mat.albedo_color = c
	_accent_mat.albedo_color = c.darkened(0.45)
	position = _base_pos


func switch_to(i: int) -> void:
	if i == index or i < 0 or i >= DATA.size() or reloading:
		return
	index = i
	reloading = false
	ammo = DATA[index]["mag"]
	reserve = DATA[index]["reserve"]
	_apply_weapon_look()
	_kick = 0.14
	Sfx.play("reload", -6.0, 1.3)
	ammo_changed.emit(ammo, reserve)
	weapon_changed.emit(index, DATA[index]["name"])


# ---------------- 主循环 ----------------

func update(delta: float, fire_pressed: bool, fire_just: bool) -> void:
	cooldown = maxf(0.0, cooldown - delta)

	if reloading:
		reload_t -= delta
		_reload_swing = lerpf(_reload_swing, 1.0, 1.0 - exp(-14.0 * delta))
		if reload_t <= 0.0:
			_finish_reload()
	else:
		_reload_swing = lerpf(_reload_swing, 0.0, 1.0 - exp(-12.0 * delta))
		var w = DATA[index]
		# 全自动作弊：让半自动武器也变成按住连发
		var want: bool = fire_pressed if (bool(w["auto"]) or Cheats.full_auto) else fire_just
		if want and cooldown <= 0.0:
			try_fire_once()

	_update_visual(delta)


func try_fire_once() -> bool:
	var inf: bool = Cheats.infinite_ammo
	if reloading:
		if inf:
			# 无限弹药下换弹是多余的，直接打断，否则会被换弹动画卡住射不出来
			reloading = false
			reload_t = 0.0
		else:
			return false
	if ammo <= 0 and not inf:
		Sfx.play("empty", -12.0)
		start_reload()
		return false

	var w = DATA[index]
	# 无限弹药下弹匣不消耗、也不重置 —— 保持原值，HUD 那边显示 ∞。
	# （早先写成 ammo = mag 会把 5 顶成 30，等于偷偷白送弹药。）
	if not inf:
		ammo -= 1
	cooldown = float(w["cd"]) * (Cheats.RAPID_MUL if Cheats.rapid_fire else 1.0)

	var spread := _current_spread()
	var pellets := int(w["pellets"])
	var dmg := float(w["dmg"])
	if Cheats.one_shot:
		dmg = Cheats.ONE_SHOT_DMG
	var rng := float(w["range"])

	var origin: Vector3 = player.cam.global_position if player != null else global_position
	var fwd: Vector3 = -player.cam.global_transform.basis.z if player != null else -global_transform.basis.z
	var muzzle_pos := _muzzle.global_position

	var any_hit := false
	var any_head := false
	for i in pellets:
		var dir := _spread_dir(fwd, spread)
		var res := _hitscan(origin, dir, dmg, rng, muzzle_pos)
		if res[0]:
			any_hit = true
			if res[1]:
				any_head = true

	GameState.register_shot()
	if any_hit:
		GameState.register_hit()

	# 枪口火光
	_flash_t = 0.045
	_flash_mesh.visible = true
	_flash_mesh.scale = Vector3.ONE * randf_range(0.85, 1.3)
	_flash_light.visible = true
	_flash_light.light_energy = randf_range(3.0, 5.0)

	# 后坐力（精准枪法作弊下不抖镜头，但保留枪身动效）
	var r := float(w["recoil"])
	_kick = minf(0.12, 0.035 + r * 0.02)
	_kick_rot = minf(0.22, r * 0.035)
	if player != null and not Cheats.no_spread:
		player.add_recoil(r * (0.55 if player.aiming else 1.0))

	Sfx.play("shotgun" if pellets > 3 else "shoot", -3.0, randf_range(0.95, 1.06))
	ammo_changed.emit(ammo, reserve)
	fired.emit()
	if any_hit:
		hit_confirmed.emit(any_head)
	return true


func start_reload() -> void:
	if reloading or Cheats.infinite_ammo:
		return
	var w = DATA[index]
	if ammo >= int(w["mag"]) or reserve <= 0:
		return
	reloading = true
	reload_t = float(w["reload"])
	Sfx.play("reload", -5.0)
	reload_started.emit(reload_t)


func _finish_reload() -> void:
	var w = DATA[index]
	var need := int(w["mag"]) - ammo
	var take := mini(need, reserve)
	ammo += take
	reserve -= take
	reloading = false
	reload_t = 0.0
	Sfx.play("reload", -4.0, 0.85)
	ammo_changed.emit(ammo, reserve)
	reload_finished.emit()


func add_ammo(amount: int) -> void:
	var w = DATA[index]
	var maxr := int(w["max_reserve"])
	# 所有武器都补一点
	for i in DATA.size():
		if i == index:
			reserve = mini(int(DATA[i]["max_reserve"]), reserve + amount)
	ammo_changed.emit(ammo, reserve)


## 作弊用：当前武器弹匣与备弹全部拉满。
func refill_all() -> void:
	var w = DATA[index]
	reloading = false
	reload_t = 0.0
	ammo = int(w["mag"])
	reserve = int(w["max_reserve"])
	ammo_changed.emit(ammo, reserve)


func _current_spread() -> float:
	if Cheats.no_spread:
		return 0.0
	var w = DATA[index]
	var spd := 0.0
	if player != null:
		spd = Vector2(player.velocity.x, player.velocity.z).length()
	var f := clampf(spd / 8.5, 0.0, 1.0)
	var s := float(w["spread"]) + float(w["move_spread"]) * f
	if player != null:
		if not player.is_on_floor():
			s *= 2.0
		if player.aiming:
			s *= 0.35
	return s


func _spread_dir(dir: Vector3, deg: float) -> Vector3:
	if deg <= 0.001:
		return dir
	var a := deg_to_rad(deg)
	var ang := randf() * TAU
	var r := sqrt(randf()) * a
	var ref := Vector3.UP if absf(dir.dot(Vector3.UP)) < 0.98 else Vector3.RIGHT
	var right := dir.cross(ref).normalized()
	var up := right.cross(dir).normalized()
	var t := tan(r)
	return (dir + right * t * cos(ang) + up * t * sin(ang)).normalized()


## 返回 [是否命中敌人, 是否爆头]
func _hitscan(origin: Vector3, dir: Vector3, dmg: float, rng: float, muzzle_pos: Vector3) -> Array:
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * rng)
	q.collision_mask = 1 | 4
	var res := space.intersect_ray(q)
	var end := origin + dir * rng
	var hit_enemy := false
	var headshot := false

	if not res.is_empty():
		end = res["position"]
		var col = res["collider"]
		if col != null and col.has_method("take_damage"):
			hit_enemy = true
			if col.has_method("is_headshot"):
				headshot = col.is_headshot(end)
			var falloff := clampf(1.0 - origin.distance_to(end) / (rng * 1.8), 0.5, 1.0)
			col.take_damage(dmg * falloff * (2.2 if headshot else 1.0), dir)
			Sfx.play("hit_head" if headshot else "hit", -9.0, 1.0 if not headshot else 1.2)
		else:
			_spawn_impact(end, res["normal"])

	_spawn_tracer(muzzle_pos, end, hit_enemy)
	return [hit_enemy, headshot]


func _spawn_tracer(a: Vector3, b: Vector3, hot: bool) -> void:
	if effects == null:
		return
	var dist := a.distance_to(b)
	if dist < 0.15:
		return
	var col := Color(1.0, 0.92, 0.6) if hot else Color(0.85, 0.9, 1.0, 0.55)
	var mi := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.012
	cyl.bottom_radius = 0.012
	cyl.height = 1.0
	cyl.radial_segments = 4
	cyl.rings = 0
	mi.mesh = cyl
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 5.0
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat

	var dir := (b - a).normalized()
	var ref := Vector3.UP if absf(dir.dot(Vector3.UP)) < 0.98 else Vector3.RIGHT
	var x := dir.cross(ref).normalized()
	var z := x.cross(dir).normalized()
	mi.transform = Transform3D(Basis(x, dir * dist, z), (a + b) * 0.5)
	effects.add_child(mi)

	var t := mi.create_tween()
	t.tween_property(mat, "albedo_color:a", 0.0, 0.09)
	t.tween_callback(mi.queue_free)


func _spawn_impact(pos: Vector3, normal: Vector3) -> void:
	if effects == null:
		return
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.07
	sm.height = 0.14
	sm.radial_segments = 6
	sm.rings = 3
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(1.0, 0.78, 0.35)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.7, 0.25)
	mat.emission_energy_multiplier = 6.0
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	mi.position = pos + normal * 0.02
	effects.add_child(mi)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3.ONE * 2.6, 0.16)
	t.tween_property(mat, "albedo_color:a", 0.0, 0.16)
	t.chain().tween_callback(mi.queue_free)


func _update_visual(delta: float) -> void:
	if _flash_t > 0.0:
		_flash_t -= delta
		if _flash_t <= 0.0:
			_flash_mesh.visible = false
			_flash_light.visible = false

	_kick = lerpf(_kick, 0.0, 1.0 - exp(-16.0 * delta))
	_kick_rot = lerpf(_kick_rot, 0.0, 1.0 - exp(-16.0 * delta))

	# 呼吸 / 走动摆动
	var t := Time.get_ticks_msec() / 1000.0
	var sway_x := sin(t * 1.3) * 0.004
	var sway_y := sin(t * 2.1) * 0.003
	if player != null:
		var spd := Vector2(player.velocity.x, player.velocity.z).length()
		sway_x += sin(t * 8.0) * 0.006 * clampf(spd / 6.0, 0.0, 1.0)
		sway_y += absf(sin(t * 8.0)) * 0.005 * clampf(spd / 6.0, 0.0, 1.0)

	var target_pos := _base_pos + Vector3(sway_x, sway_y, _kick)
	var target_rot := Vector3(_kick_rot, sway_x * 3.0, 0.0)
	if _reload_swing > 0.01:
		target_pos += Vector3(0.02, -0.14, 0.06) * _reload_swing
		target_rot += Vector3(-0.85, 0.25, 0.2) * _reload_swing

	position = position.lerp(target_pos, 1.0 - exp(-18.0 * delta))
	rotation = rotation.lerp(target_rot, 1.0 - exp(-18.0 * delta))
