extends Node

## 作弊状态（autoload）。
##
## 所有作弊开关集中在这里，player / weapon / enemy / game 直接读 `Cheats.xxx`，
## 不用层层传引用。面板只负责改这里的值并刷新显示。
##
## 约定：
## - 开关型（toggle）是**持续生效**的布尔量，读取点在各个系统的热路径上。
## - 动作型（action）不进这里，由 cheat_panel 直接调用 game 上的方法（一次性）。
## - `reset()` 只清开关，不动动作。

signal changed()

# ---------------- 战斗 ----------------

var god_mode := false          # 无敌：免疫一切伤害
var infinite_ammo := false     # 无限弹药：不消耗、无需换弹
var one_shot := false          # 一击必杀：任何命中都直接打死
var rapid_fire := false        # 极速射击：射击间隔大幅缩短
var no_spread := false         # 精准枪法：零散布 + 无后坐力
var full_auto := false         # 全自动：所有武器按住即连发

# ---------------- 移动 ----------------

var super_speed := false       # 疾风步：移动速度倍率
var super_jump := false        # 超级跳：起跳初速倍率
var fly_mode := false          # 飞行：关重力，空格上升 / Shift 下降

# ---------------- 敌人 ----------------

var freeze_enemies := false    # 冻结敌人：AI 停止移动与开火
var weak_enemies := false      # 弱化敌人：受到的伤害放大

# ---------------- 世界 ----------------

var bullet_time := false:       # 子弹时间：降低时间流速
	set(v):
		# 用 setter 兜住「谁写都得同步时间流速」这件事：
		# 无论面板走 toggle()、还是别处直接 `Cheats.bullet_time = true`，
		# 都会经过这里，不会出现「变量开了、时间没慢」的半吊子状态。
		if bullet_time == v:
			return
		bullet_time = v
		_apply_time_scale()

# ---------------- 数值 ----------------

const SPEED_MUL := 2.2
const JUMP_MUL := 2.1
const FLY_SPEED := 9.0
const FLY_MOVE_MUL := 1.7
const RAPID_MUL := 0.18        # 射击间隔倍率（越小越快）
const WEAK_MUL := 8.0          # 敌人受伤倍率
const ONE_SHOT_DMG := 99999.0
const SLOW_SCALE := 0.35

## 所有开关型作弊的键名，顺序即面板显示顺序。
const TOGGLE_KEYS := [
	"god_mode", "infinite_ammo", "one_shot", "rapid_fire", "no_spread", "full_auto",
	"super_speed", "super_jump", "fly_mode",
	"freeze_enemies", "weak_enemies",
	"bullet_time",
]

var _saved_time_scale := 1.0
var _time_scale_held := false


## 读取某个开关（面板和自检都用它，避免到处写 if/match）。
func get_flag(key: String) -> bool:
	match key:
		"god_mode": return god_mode
		"infinite_ammo": return infinite_ammo
		"one_shot": return one_shot
		"rapid_fire": return rapid_fire
		"no_spread": return no_spread
		"full_auto": return full_auto
		"super_speed": return super_speed
		"super_jump": return super_jump
		"fly_mode": return fly_mode
		"freeze_enemies": return freeze_enemies
		"weak_enemies": return weak_enemies
		"bullet_time": return bullet_time
	return false


## 切换一个开关，返回切换后的值。
func toggle(key: String) -> bool:
	var v := not get_flag(key)
	match key:
		"god_mode": god_mode = v
		"infinite_ammo": infinite_ammo = v
		"one_shot": one_shot = v
		"rapid_fire": rapid_fire = v
		"no_spread": no_spread = v
		"full_auto": full_auto = v
		"super_speed": super_speed = v
		"super_jump": super_jump = v
		"fly_mode": fly_mode = v
		"freeze_enemies": freeze_enemies = v
		"weak_enemies": weak_enemies = v
		"bullet_time": bullet_time = v   # setter 里已负责 _apply_time_scale()
		_:
			return false
	changed.emit()
	return v


## 全部关掉。只清开关，不碰一次性动作。
func reset() -> void:
	god_mode = false
	infinite_ammo = false
	one_shot = false
	rapid_fire = false
	no_spread = false
	full_auto = false
	super_speed = false
	super_jump = false
	fly_mode = false
	freeze_enemies = false
	weak_enemies = false
	bullet_time = false
	_apply_time_scale()
	changed.emit()


func any_active() -> bool:
	return active_count() > 0


func active_count() -> int:
	var n := 0
	for k in TOGGLE_KEYS:
		if get_flag(k):
			n += 1
	return n


## 当前生效的作弊名（给 HUD 指示器用）。
func active_names() -> Array:
	var out := []
	for k in TOGGLE_KEYS:
		if get_flag(k):
			out.append(k)
	return out


# ---------------- 时间流速 ----------------

## 子弹时间会改 Engine.time_scale，而 --sim 用 3.0 做加速，两边会打架。
## 所以进入子弹时间时先把当前值存下来，退出时还原 —— 而不是硬写 1.0。
func _apply_time_scale() -> void:
	if bullet_time:
		if not _time_scale_held:
			_saved_time_scale = Engine.time_scale
			_time_scale_held = true
		Engine.time_scale = SLOW_SCALE
	elif _time_scale_held:
		Engine.time_scale = _saved_time_scale
		_time_scale_held = false
