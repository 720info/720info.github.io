extends CharacterBody3D

## AI 敌人：视线检测 + 掩体绕行 + 反应延迟开火 + 受击闪白 + 死亡倒地。

signal died(enemy, score_value)

const TYPES := [
	{
		"name": "步兵", "hp": 70.0, "speed": 3.6, "dmg": 8.0, "cd": 1.55, "range": 36.0,
		"preferred": 16.0, "melee": false, "burst": 2, "reaction": 0.78, "score": 100,
		"scale": 1.0, "body": Color(0.78, 0.42, 0.20), "accent": Color(1.0, 0.62, 0.25),
	},
	{
		"name": "突击兵", "hp": 48.0, "speed": 6.6, "dmg": 13.0, "cd": 1.15, "range": 2.4,
		"preferred": 0.0, "melee": true, "burst": 0, "reaction": 0.45, "score": 140,
		"scale": 0.94, "body": Color(0.80, 0.20, 0.24), "accent": Color(1.0, 0.30, 0.30),
	},
	{
		"name": "重装兵", "hp": 210.0, "speed": 2.4, "dmg": 15.0, "cd": 2.2, "range": 30.0,
		"preferred": 13.0, "melee": false, "burst": 3, "reaction": 0.98, "score": 260,
		"scale": 1.38, "body": Color(0.55, 0.32, 0.82), "accent": Color(0.80, 0.55, 1.0),
	},
	{
		# 首领：体型大、血厚、慢，但有震荡波和狂暴阶段。每 5 波出现一次。
		"name": "首领", "hp": 1200.0, "speed": 2.3, "dmg": 20.0, "cd": 1.9, "range": 44.0,
		"preferred": 12.0, "melee": false, "burst": 5, "reaction": 0.62, "score": 2000,
		"scale": 2.10, "body": Color(0.30, 0.09, 0.13), "accent": Color(1.0, 0.42, 0.16),
	},
]

## 首领（TYPES 下标）。game.gd 用 EnemyScript.BOSS_KIND 引用，别写魔数。
const BOSS_KIND := 3
const BOSS_ENRAGE_FRAC := 0.45    # 血量低于此比例进入狂暴
const BOSS_ENRAGE_SPEED := 1.45
const BOSS_ENRAGE_DMG := 1.30
const BOSS_ENRAGE_CD := 0.60      # 射击间隔倍率（越小越快）
const BOSS_SHOCK_CD := 7.5        # 震荡波冷却
const BOSS_SHOCK_TRIGGER := 12.0  # 玩家进到这么近就放
const BOSS_SHOCK_RADIUS := 10.0   # 实际伤害半径
const BOSS_SHOCK_DMG := 26.0

var kind := 0
var hp := 100.0
var max_hp := 100.0
var alive := true
var player = null
var game = null
var effects: Node3D = null
var diff := 1.0

var speed := 3.5
var dmg := 9.0
var fire_cd := 1.2
var atk_range := 30.0
var preferred := 14.0
var is_melee := false
var burst := 2
var reaction := 0.6
var score_value := 100
var body_scale := 1.0
var is_boss := false
var enraged := false

var _fire_t := 0.0
var _see_t := 0.0
var _lost_t := 0.0
var _burst_left := 0
var _burst_t := 0.0
var _strafe_dir := 1.0
var _strafe_t := 0.0
var _stuck_t := 0.0
var _stuck_hits := 0
var _free_t := 0.0
var _detour_t := 0.0
var _detour_side := true
var _detour_start_dist := 0.0
var _flash := 0.0
var _dead_t := 0.0
var _spawn_t := 0.0
var _shock_t := 0.0
var shots_fired := 0
var shots_hit := 0
var dbg_see := false        # 诊断用：当前帧是否有视线
var dbg_stuck := 0.0        # 诊断用：卡住计时

var _body_mat: StandardMaterial3D
var _accent_mat: StandardMaterial3D
var _hp_mat: StandardMaterial3D
var _hp_quad: QuadMesh
var _hp_bg_quad: QuadMesh
var _hp_fill: MeshInstance3D
var _hp_bg: MeshInstance3D
var _hp_base_w := 0.66
var _hp_base_h := 0.075
var _muzzle: Node3D
var _torso: Node3D
var _base_emission := 0.0
var _accent_base := 0.9    # accent 自发光基准（受击闪白时在这个基准上叠加，狂暴会调高它）


func _ready() -> void:
	collision_layer = 4
	collision_mask = 1 | 2 | 4
	floor_max_angle = deg_to_rad(52.0)
	floor_snap_length = 0.5
	_build()
	_spawn_t = 0.0


func configure(type_id: int, difficulty: float) -> void:
	kind = clampi(type_id, 0, TYPES.size() - 1)
	var d = TYPES[kind]
	diff = difficulty
	max_hp = float(d["hp"]) * (1.0 + (difficulty - 1.0) * 0.85)
	hp = max_hp
	speed = float(d["speed"]) * (1.0 + (difficulty - 1.0) * 0.12)
	dmg = float(d["dmg"]) * (1.0 + (difficulty - 1.0) * 0.30)
	fire_cd = float(d["cd"])
	atk_range = float(d["range"])
	preferred = float(d["preferred"])
	is_melee = bool(d["melee"])
	burst = int(d["burst"])
	reaction = maxf(0.22, float(d["reaction"]) - (difficulty - 1.0) * 0.06)
	score_value = int(d["score"])
	body_scale = float(d["scale"])
	is_boss = (kind == BOSS_KIND)
	if is_boss:
		_build_boss_extras()
	if is_melee:
		atk_range = 2.6
	_fire_t = randf_range(0.4, 1.2)
	_strafe_dir = 1.0 if randf() < 0.5 else -1.0
	if is_boss:
		# 首波进场别立刻放波，给玩家一点反应时间
		_shock_t = randf_range(3.5, 5.5)
	_apply_bar_scale()
	# 出场动画：从地面弹出
	scale = Vector3.ONE * 0.01
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector3.ONE * body_scale, 0.30).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)


func _build() -> void:
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.42
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	add_child(cs)

	_torso = Node3D.new()
	_torso.name = "Torso"
	add_child(_torso)

	_body_mat = StandardMaterial3D.new()
	_body_mat.albedo_color = Color(0.78, 0.42, 0.20)
	_body_mat.roughness = 0.6
	_body_mat.emission_enabled = true
	_body_mat.emission = Color(1, 1, 1)
	_body_mat.emission_energy_multiplier = 0.0

	_accent_mat = StandardMaterial3D.new()
	_accent_mat.albedo_color = Color(1.0, 0.62, 0.25)
	_accent_mat.roughness = 0.4
	_accent_mat.metallic = 0.5
	_accent_mat.emission_enabled = true
	_accent_mat.emission = Color(1.0, 0.62, 0.25)
	_accent_mat.emission_energy_multiplier = 0.9

	# 躯干
	_torso.add_child(_box(Vector3(0.72, 0.78, 0.42), Vector3(0, 1.18, 0), _body_mat))
	# 胸甲发光条
	_torso.add_child(_box(Vector3(0.30, 0.10, 0.04), Vector3(0, 1.32, -0.22), _accent_mat))
	_torso.add_child(_box(Vector3(0.10, 0.30, 0.04), Vector3(-0.20, 1.16, -0.22), _accent_mat))
	_torso.add_child(_box(Vector3(0.10, 0.30, 0.04), Vector3(0.20, 1.16, -0.22), _accent_mat))

	# 头（爆头判定区）
	_torso.add_child(_sphere(0.20, Vector3(0, 1.70, 0), _body_mat))
	_torso.add_child(_box(Vector3(0.34, 0.06, 0.20), Vector3(0, 1.74, -0.10), _accent_mat))

	# 肩 / 臂
	_torso.add_child(_box(Vector3(0.16, 0.44, 0.16), Vector3(-0.44, 1.18, 0), _body_mat))
	_torso.add_child(_box(Vector3(0.16, 0.44, 0.16), Vector3(0.44, 1.18, 0), _body_mat))
	# 腿
	_torso.add_child(_box(Vector3(0.20, 0.78, 0.22), Vector3(-0.20, 0.40, 0), _accent_mat))
	_torso.add_child(_box(Vector3(0.20, 0.78, 0.22), Vector3(0.20, 0.40, 0), _accent_mat))

	# 武器
	var gun := _box(Vector3(0.10, 0.12, 0.52), Vector3(0.30, 1.10, -0.36), _accent_mat)
	_torso.add_child(gun)

	_muzzle = Node3D.new()
	_muzzle.name = "Muzzle"
	_muzzle.position = Vector3(0.30, 1.10, -0.68)
	_torso.add_child(_muzzle)

	# 血条：StandardMaterial3D 的 billboard + 动态 QuadMesh 尺寸
	# （Godot 4.7 的 spatial shader 不支持 billboard 渲染模式，只能用材质属性）
	var bar_bg := MeshInstance3D.new()
	_hp_bg = bar_bg
	var qbg := QuadMesh.new()
	_hp_bg_quad = qbg
	qbg.size = Vector2(0.78, 0.145)
	bar_bg.mesh = qbg
	var mbg := StandardMaterial3D.new()
	mbg.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mbg.albedo_color = Color(0.03, 0.035, 0.05, 0.88)
	mbg.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mbg.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mbg.disable_receive_shadows = true
	mbg.render_priority = 0
	bar_bg.material_override = mbg
	bar_bg.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	bar_bg.position = Vector3(0, 2.14, 0)
	_torso.add_child(bar_bg)

	_hp_fill = MeshInstance3D.new()
	_hp_quad = QuadMesh.new()
	_hp_quad.size = Vector2(0.66, 0.075)
	_hp_fill.mesh = _hp_quad
	_hp_mat = StandardMaterial3D.new()
	_hp_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_hp_mat.albedo_color = Color(0.30, 0.95, 0.42)
	_hp_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	_hp_mat.disable_receive_shadows = true
	_hp_mat.render_priority = 1
	_hp_fill.material_override = _hp_mat
	_hp_fill.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_hp_fill.position = Vector3(0, 2.14, 0)
	_torso.add_child(_hp_fill)


func _box(size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	return mi


func _sphere(r: float, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	mi.mesh = sm
	mi.position = pos
	mi.material_override = mat
	return mi


## 圆锥（尖刺 / 犄角）。CylinderMesh 顶半径为 0 就是锥体。
func _cone(r: float, h: float, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = r
	cm.height = h
	cm.radial_segments = 8
	cm.rings = 0
	mi.mesh = cm
	mi.position = pos
	mi.material_override = mat
	return mi


## 首领专属外观：肩甲尖刺 + 头冠犄角 + 重炮 + 红光环。
## 与普通敌人共用同一套材质，所以 set_colors() 之后颜色会一起变。
func _build_boss_extras() -> void:
	if _torso == null:
		return
	for sx in [-1.0, 1.0]:
		var pauldron := _box(Vector3(0.30, 0.20, 0.34), Vector3(sx * 0.48, 1.46, 0), _accent_mat)
		_torso.add_child(pauldron)
		var spike := _cone(0.15, 0.50, Vector3(sx * 0.50, 1.72, 0), _accent_mat)
		spike.rotation.z = deg_to_rad(-20.0 * sx)
		_torso.add_child(spike)

	# 头冠：中间一根长角 + 两侧短角
	_torso.add_child(_cone(0.085, 0.46, Vector3(0.0, 1.98, 0.0), _accent_mat))
	for sx in [-1.0, 1.0]:
		var horn := _cone(0.065, 0.34, Vector3(sx * 0.15, 1.94, -0.02), _accent_mat)
		horn.rotation.z = deg_to_rad(-28.0 * sx)
		_torso.add_child(horn)

	# 重炮（比普通枪大一圈）
	_torso.add_child(_box(Vector3(0.18, 0.20, 0.78), Vector3(0.34, 1.04, -0.44), _accent_mat))
	_torso.add_child(_box(Vector3(0.26, 0.26, 0.16), Vector3(0.34, 1.04, -0.10), _body_mat))

	# 红光环：首领走到哪都自带一圈压迫感
	var aura := OmniLight3D.new()
	aura.light_color = Color(1.0, 0.34, 0.16)
	aura.light_energy = 2.6
	aura.omni_range = 7.0
	aura.position = Vector3(0, 1.4, 0)
	_torso.add_child(aura)

	# 血条抬高，别被头冠尖角顶穿
	if _hp_bg != null:
		_hp_bg.position.y = 2.62
	if _hp_fill != null:
		_hp_fill.position.y = 2.62


func set_colors(body: Color, accent: Color) -> void:
	_body_mat.albedo_color = body
	_accent_mat.albedo_color = accent
	_accent_mat.emission = accent


# ---------------- 主循环 ----------------

func _physics_process(delta: float) -> void:
	if not alive:
		_dead_t += delta
		velocity = velocity.lerp(Vector3.ZERO, 1.0 - exp(-4.0 * delta))
		move_and_slide()
		return

	if Cheats.freeze_enemies:
		# 冻结：原地刹停并直接 return —— _combat() 在函数末尾，提前返回等于连开火也停。
		velocity.x = lerpf(velocity.x, 0.0, 1.0 - exp(-10.0 * delta))
		velocity.z = lerpf(velocity.z, 0.0, 1.0 - exp(-10.0 * delta))
		if not is_on_floor():
			velocity.y -= 20.0 * delta
		else:
			velocity.y = 0.0
		move_and_slide()
		return

	if not is_on_floor():
		velocity.y -= 20.0 * delta
	else:
		velocity.y = 0.0

	if player == null or not player.alive or player.global_position.y < -5.0:
		velocity.x = lerpf(velocity.x, 0.0, 1.0 - exp(-6.0 * delta))
		velocity.z = lerpf(velocity.z, 0.0, 1.0 - exp(-6.0 * delta))
		move_and_slide()
		return

	var to_p: Vector3 = player.global_position - global_position
	to_p.y = 0.0
	var dist := to_p.length()
	var dir := to_p.normalized() if dist > 0.01 else Vector3.FORWARD
	var see := _los()
	dbg_see = see

	if see:
		_see_t += delta
		_lost_t = 0.0
	else:
		_lost_t += delta
		if _lost_t > 1.2:
			_see_t = 0.0

	var move_dir := Vector3.ZERO
	var speed_mul := 1.0

	if is_melee:
		if dist > 1.9:
			move_dir = dir
			speed_mul = 1.15
	else:
		if not see:
			move_dir = dir
			speed_mul = 1.18
		elif dist > preferred * 1.18:
			move_dir = dir
		elif dist < preferred * 0.60:
			move_dir = -dir
			speed_mul = 0.85
		else:
			_strafe_t -= delta
			if _strafe_t <= 0.0:
				_strafe_t = randf_range(1.1, 2.4)
				if randf() < 0.45:
					_strafe_dir = -_strafe_dir
			move_dir = dir.cross(Vector3.UP).normalized() * _strafe_dir

	# 破局：连续卡住三次说明「朝玩家推 → 撞掩体 → 转 70° → 又朝玩家推」在振荡，
	# 靠小角度微调永远绕不过去。改为横向强制绕行 —— 而且要**坚持到有进展为止**，
	# 固定时长一到就重新瞄准会让它回到同一个死角（实测绕中央高台时反复来回）。
	if _detour_t > 0.0:
		_detour_t -= delta
		if dist < _detour_start_dist - 0.8:
			_detour_t = 0.0          # 距离真的缩短了 → 提前结束绕行
		else:
			move_dir = dir.cross(Vector3.UP).normalized() * (1.0 if _detour_side else -1.0)
			speed_mul = 1.0

	move_dir = _avoid(move_dir)

	# 卡住检测
	var hv := Vector2(velocity.x, velocity.z)
	if move_dir.length() > 0.1 and hv.length() < speed * 0.3:
		_stuck_t += delta
		_free_t = 0.0
	else:
		_stuck_t = 0.0
		# 注意：不能一「没卡住」就把计数清零。贴着掩体时敌人会一帧抖出 1.5m/s 的速度，
		# 立刻清零会让卡住计数永远攒不到 3，强制绕行形同虚设（实测绕行从未触发）。
		# 必须「持续通畅」一段时间才认为真的脱困。
		_free_t += delta
		if _free_t > 1.5:
			_stuck_hits = 0
	if _stuck_t > 0.6:
		_stuck_t = -0.4
		_strafe_dir = -_strafe_dir
		_stuck_hits += 1
		if _stuck_hits >= 3:
			_stuck_hits = 0
			_detour_t = 3.0
			_detour_start_dist = dist
			_detour_side = not _detour_side   # 交替探索两侧，别老往同一边钻
		else:
			move_dir = move_dir.rotated(Vector3.UP, deg_to_rad(70.0 * _strafe_dir))

	var target := move_dir * speed * speed_mul
	dbg_stuck = _stuck_t
	velocity.x = lerpf(velocity.x, target.x, 1.0 - exp(-9.0 * delta))
	velocity.z = lerpf(velocity.z, target.z, 1.0 - exp(-9.0 * delta))

	move_and_slide()

	if dist > 0.5:
		var look := atan2(-to_p.x, -to_p.z)
		rotation.y = lerp_angle(rotation.y, look, 1.0 - exp(-10.0 * delta))

	_combat(delta, dist, see)


func _combat(delta: float, dist: float, see: bool) -> void:
	_fire_t = maxf(0.0, _fire_t - delta)

	# 首领震荡波：玩家贴近就放一发范围冲击，逼他拉开距离而不是站桩对枪
	if is_boss:
		_shock_t = maxf(0.0, _shock_t - delta)
		if _shock_t <= 0.0 and see and dist <= BOSS_SHOCK_TRIGGER \
				and player != null and player.alive:
			_shock_t = BOSS_SHOCK_CD
			_shockwave(dist)

	if is_melee:
		if see and dist <= atk_range and _see_t >= reaction and _fire_t <= 0.0:
			_fire_t = fire_cd * randf_range(0.9, 1.15)
			if player.alive:
				player.take_damage(dmg, (player.global_position - global_position).normalized())
			Sfx.play_at("melee", global_position, -3.0)
			_punch()
		return

	var can_shoot := see and dist <= atk_range and _see_t >= reaction
	if _burst_left > 0:
		_burst_t -= delta
		if _burst_t <= 0.0 and can_shoot:
			_shoot()
			_burst_left -= 1
			_burst_t = 0.14
	elif can_shoot and _fire_t <= 0.0:
		_burst_left = maxi(1, burst)
		_burst_t = 0.0
		_fire_t = fire_cd * randf_range(0.85, 1.2)


func _punch() -> void:
	var t := create_tween()
	t.tween_property(_torso, "position", Vector3(0, 0.0, -0.25), 0.08)
	t.tween_property(_torso, "position", Vector3.ZERO, 0.16)


## 震荡波：以自身为圆心扩散。半径内的玩家吃一发重击 + 镜头后坐，
## 目的是逼玩家拉开距离，而不是贴着首领站桩对枪。
func _shockwave(dist: float) -> void:
	_shock_ring()
	Sfx.play_at("wave", global_position, -2.0, 0.72)
	if player == null or not player.alive:
		return
	if dist > BOSS_SHOCK_RADIUS:
		return
	var dir: Vector3 = player.global_position - global_position
	dir.y = 0.0
	if dir.length() < 0.01:
		dir = Vector3.FORWARD
	player.take_damage(BOSS_SHOCK_DMG * diff, dir.normalized())
	if player.has_method("add_recoil"):
		player.add_recoil(2.6)


func _shock_ring() -> void:
	if effects == null:
		return
	var mi := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.95
	tm.outer_radius = 1.0
	tm.rings = 48
	tm.ring_segments = 8
	mi.mesh = tm
	var col := Color(1.0, 0.52, 0.16)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 4.5
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	mi.position = global_position + Vector3(0, 0.22, 0)
	effects.add_child(mi)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3(BOSS_SHOCK_RADIUS, 0.7, BOSS_SHOCK_RADIUS), 0.42).set_ease(Tween.EASE_OUT)
	t.tween_property(mat, "albedo_color:a", 0.0, 0.42)
	t.chain().tween_callback(mi.queue_free)

	var l := OmniLight3D.new()
	l.light_color = col
	l.light_energy = 5.5
	l.omni_range = 13.0
	l.position = global_position + Vector3(0, 1.0, 0)
	effects.add_child(l)
	var tl := l.create_tween()
	tl.tween_property(l, "light_energy", 0.0, 0.35)
	tl.tween_callback(l.queue_free)


func _shoot() -> void:
	if effects == null or player == null:
		return
	var origin := _muzzle.global_position
	var target: Vector3 = player.global_position + Vector3(0, 1.15, 0)
	var base := (target - origin).normalized()
	var dist := global_position.distance_to(player.global_position)
	var spread := 4.2 * clampf(dist / 30.0, 0.60, 1.0)
	var dir := _spread_dir(base, spread)

	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * 110.0)
	q.collision_mask = 1 | 2 | 4
	q.exclude = [get_rid()]
	var res := space.intersect_ray(q)
	var end := origin + dir * 110.0
	var hit_player := false
	if not res.is_empty():
		end = res["position"]
		var col = res["collider"]
		if col == player and player.alive:
			hit_player = true
			shots_hit += 1
			player.take_damage(dmg, dir)

	shots_fired += 1

	Sfx.play_at("shoot_enemy", global_position, -5.0, randf_range(0.9, 1.1))
	_tracer(origin, end, hit_player)
	_muzzle_flash()


func _muzzle_flash() -> void:
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.72, 0.35)
	l.light_energy = 2.4
	l.omni_range = 5.0
	_muzzle.add_child(l)
	var t := l.create_tween()
	t.tween_property(l, "light_energy", 0.0, 0.07)
	t.tween_callback(l.queue_free)


func _tracer(a: Vector3, b: Vector3, hot: bool) -> void:
	var dist := a.distance_to(b)
	if dist < 0.2:
		return
	var mi := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.010
	cyl.bottom_radius = 0.010
	cyl.height = 1.0
	cyl.radial_segments = 4
	cyl.rings = 0
	mi.mesh = cyl
	var col := Color(1.0, 0.55, 0.25) if hot else Color(1.0, 0.75, 0.45, 0.5)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 4.0
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	var d := (b - a).normalized()
	var ref := Vector3.UP if absf(d.dot(Vector3.UP)) < 0.98 else Vector3.RIGHT
	var x := d.cross(ref).normalized()
	var z := x.cross(d).normalized()
	mi.transform = Transform3D(Basis(x, d * dist, z), (a + b) * 0.5)
	effects.add_child(mi)
	var t := mi.create_tween()
	t.tween_property(mat, "albedo_color:a", 0.0, 0.09)
	t.tween_callback(mi.queue_free)


func _los() -> bool:
	if player == null:
		return false
	var space := get_world_3d().direct_space_state
	var a := global_position + Vector3(0, 1.45 * body_scale, 0)
	var b: Vector3 = player.global_position + Vector3(0, 1.15, 0)
	var q := PhysicsRayQueryParameters3D.create(a, b)
	q.collision_mask = 1
	q.exclude = [get_rid()]
	return space.intersect_ray(q).is_empty()


func _avoid(dir: Vector3) -> Vector3:
	if dir.length() < 0.01:
		return dir
	var d := dir.normalized()
	var space := get_world_3d().direct_space_state
	var origin := global_position + Vector3(0, 0.95, 0)
	var probe := 2.6
	if _clear(space, origin, d, probe):
		return d
	for ang in [38.0, 76.0, 118.0]:
		var l := d.rotated(Vector3.UP, deg_to_rad(ang))
		if _clear(space, origin, l, probe):
			return l
		var r := d.rotated(Vector3.UP, deg_to_rad(-ang))
		if _clear(space, origin, r, probe):
			return r
	return -d


func _clear(space: PhysicsDirectSpaceState3D, origin: Vector3, dir: Vector3, dist: float) -> bool:
	var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * dist)
	q.collision_mask = 1
	q.exclude = [get_rid()]
	return space.intersect_ray(q).is_empty()


func _spread_dir(dir: Vector3, deg: float) -> Vector3:
	if deg <= 0.001:
		return dir
	var a := deg_to_rad(deg)
	var ang := randf() * TAU
	var r := sqrt(randf()) * a
	var ref := Vector3.UP if absf(dir.dot(Vector3.UP)) < 0.98 else Vector3.RIGHT
	var right := dir.cross(ref).normalized()
	var up := right.cross(dir).normalized()
	var t := tan(r)
	return (dir + right * t * cos(ang) + up * t * sin(ang)).normalized()


func _set_hp_visual(frac: float) -> void:
	if _hp_quad == null or _hp_mat == null:
		return
	var f := clampf(frac, 0.0, 1.0)
	_hp_quad.size = Vector2(maxf(_hp_base_w * f, 0.001), _hp_base_h)
	_hp_mat.albedo_color = Color(0.95, 0.22, 0.18).lerp(Color(0.30, 0.95, 0.42), f)


func _apply_bar_scale() -> void:
	# ⚠️ billboard 会**丢弃节点缩放**（Godot 把模型基向量整个换成相机基向量），
	# 所以「大个子血条更大」只能靠这里手动乘 body_scale —— 节点 scale 指望不上。
	# 实测：首领节点 scale=2.1，但头顶血条仍是 1.638 世界单位（= 手动算出的值）。
	var wmul := 1.5 if is_boss else 1.0   # 首领肩更宽，血条再放宽一点才压得住
	_hp_base_w = 0.66 * body_scale * wmul
	_hp_base_h = 0.075 * body_scale
	if _hp_bg_quad != null:
		_hp_bg_quad.size = Vector2(_hp_base_w + 0.12 * body_scale * wmul, _hp_base_h + 0.07 * body_scale)
	_set_hp_visual(1.0)


func _process(delta: float) -> void:
	if _flash > 0.0:
		_flash = maxf(0.0, _flash - delta * 6.0)
	# 受击闪白叠加在基准自发光上；狂暴时基准值会脉动，所以每帧都算一遍。
	var k := _flash / 0.16
	_body_mat.emission_energy_multiplier = k * 3.5
	var ab := _accent_base
	if enraged:
		ab = 2.2 + 0.7 * sin(Time.get_ticks_msec() / 140.0)
	_accent_mat.emission_energy_multiplier = ab + k * 3.0
	if alive and _hp_fill != null:
		# 血条始终朝向相机（billboard），距离越远越淡
		var dist := 0.0
		if player != null:
			dist = global_position.distance_to(player.global_position)
		var alpha := clampf(1.0 - (dist - 26.0) / 34.0, 0.0, 1.0)
		_hp_fill.visible = alpha > 0.05


func is_headshot(pos: Vector3) -> bool:
	return pos.y > global_position.y + 1.45 * body_scale


func take_damage(amount: float, dir: Vector3 = Vector3.ZERO) -> void:
	if not alive:
		return
	if Cheats.weak_enemies:
		amount *= Cheats.WEAK_MUL
	hp -= amount
	_flash = 0.16
	_set_hp_visual(hp / maxf(max_hp, 1.0))
	if is_boss and not enraged and hp > 0.0 and hp <= max_hp * BOSS_ENRAGE_FRAC:
		_enter_enrage()
	if hp <= 0.0:
		_die(dir)


## 狂暴：血量掉到阈值以下后提速提伤提射速，并通知 game 召唤护卫。
func _enter_enrage() -> void:
	enraged = true
	speed *= BOSS_ENRAGE_SPEED
	dmg *= BOSS_ENRAGE_DMG
	fire_cd *= BOSS_ENRAGE_CD
	reaction = maxf(0.18, reaction * 0.7)
	_accent_base = 2.8
	Sfx.play_at("wave", global_position, 1.0, 0.5)
	if game != null and game.has_method("on_boss_enraged"):
		game.on_boss_enraged(self)


func _die(dir: Vector3) -> void:
	alive = false
	collision_layer = 0
	collision_mask = 1
	set_physics_process(false)
	if _hp_fill != null:
		_hp_fill.visible = false
	if _hp_bg != null:
		_hp_bg.visible = false
	Sfx.play_at("kill", global_position, -4.0, randf_range(0.92, 1.08))
	_death_effect()
	# 向后倒地
	var tilt := deg_to_rad(randf_range(78.0, 96.0))
	var axis := dir.cross(Vector3.UP).normalized() if dir.length() > 0.1 else Vector3.RIGHT
	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(_torso, "rotation:x", tilt, 0.42).set_ease(Tween.EASE_IN)
	t.tween_property(_torso, "position:y", -0.35, 0.42)
	t.tween_property(self, "scale", Vector3.ONE * body_scale * 0.86, 1.1)
	var t2 := create_tween()
	t2.tween_interval(1.3)
	t2.tween_property(self, "scale", Vector3.ONE * 0.01, 0.45)
	t2.tween_callback(queue_free)
	died.emit(self, score_value)


func _death_effect() -> void:
	if effects == null:
		return
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.4 * body_scale
	sm.height = 0.8 * body_scale
	sm.radial_segments = 10
	sm.rings = 6
	mi.mesh = sm
	var col: Color = TYPES[kind]["accent"]
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 5.0
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	mi.position = global_position + Vector3(0, 1.0 * body_scale, 0)
	effects.add_child(mi)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3.ONE * 4.2 * body_scale, 0.42)
	t.tween_property(mat, "albedo_color:a", 0.0, 0.42)
	t.chain().tween_callback(mi.queue_free)

	var l := OmniLight3D.new()
	l.light_color = col
	l.light_energy = 6.0 * body_scale
	l.omni_range = 9.0 * body_scale
	l.position = global_position + Vector3(0, 1.2 * body_scale, 0)
	effects.add_child(l)
	var tl := l.create_tween()
	tl.tween_property(l, "light_energy", 0.0, 0.4)
	tl.tween_callback(l.queue_free)
