extends Node

## 全程序化音效：零素材依赖，直接用 PackedByteArray 合成 AudioStreamWAV。

const RATE := 22050

var _pool: Array[AudioStreamPlayer] = []
var _idx := 0
var _cache := {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 16:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_pool.append(p)


func play(name: String, vol_db: float = 0.0, pitch: float = 1.0) -> void:
	var s = _stream(name)
	if s == null:
		return
	var p := _pool[_idx]
	_idx = (_idx + 1) % _pool.size()
	p.stream = s
	p.volume_db = vol_db
	p.pitch_scale = pitch
	p.play()


## 世界空间音效：按与当前相机的距离做简单衰减。
func play_at(name: String, pos: Vector3, vol_db: float = 0.0, pitch: float = 1.0) -> void:
	var att := 0.0
	var cam := get_viewport().get_camera_3d()
	if cam != null:
		var d := cam.global_position.distance_to(pos)
		att = -clampf(d, 0.0, 70.0) * 0.30
	play(name, vol_db + att, pitch)


func _stream(name: String):
	if _cache.has(name):
		return _cache[name]
	var s = null
	match name:
		"shoot":
			s = _gunshot(0.13, 420.0, 90.0, 0.55, 1.0)
		"shoot_heavy":
			s = _gunshot(0.22, 240.0, 55.0, 0.75, 1.0)
		"shoot_enemy":
			s = _gunshot(0.11, 620.0, 180.0, 0.40, 0.85)
		"shotgun":
			s = _gunshot(0.28, 300.0, 60.0, 1.0, 1.0)
		"hit":
			s = _click(0.05, 1500.0, 900.0, 0.5)
		"hit_head":
			s = _click(0.08, 2400.0, 1200.0, 0.6)
		"kill":
			s = _sweep(0.30, 700.0, 120.0, 0.5)
		"hurt":
			s = _sweep(0.20, 200.0, 70.0, 0.7)
		"reload":
			s = _click(0.06, 900.0, 500.0, 0.35)
		"empty":
			s = _click(0.04, 1800.0, 1400.0, 0.25)
		"melee":
			s = _sweep(0.16, 320.0, 90.0, 0.6)
		"wave":
			s = _sweep(0.55, 300.0, 900.0, 0.4)
		"pickup":
			s = _sweep(0.22, 700.0, 1500.0, 0.4)
		"die":
			s = _sweep(0.90, 400.0, 60.0, 0.6)
		"step":
			s = _noise(0.045, 0.35, 0.30)
		"ui":
			s = _click(0.05, 1100.0, 1600.0, 0.3)
		"spawn":
			s = _sweep(0.35, 120.0, 700.0, 0.4)
		_:
			s = null
	_cache[name] = s
	return s


# ---------------- 合成器 ----------------

func _wav(data: PackedByteArray) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	return w


func _buf(n: int) -> PackedByteArray:
	var d := PackedByteArray()
	d.resize(n * 2)
	return d


func _pack(d: PackedByteArray, i: int, v: float) -> void:
	d.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 32000.0))


## 枪声：下滑正弦 + 低通噪声，指数衰减包络
func _gunshot(dur: float, f0: float, f1: float, noise_amt: float, tone_amt: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var d := _buf(n)
	var phase := 0.0
	var lp := 0.0
	var rng := RandomNumberGenerator.new()
	rng.seed = 7717
	for i in n:
		var u := float(i) / float(n)
		var env := pow(1.0 - u, 2.6)
		var f := lerpf(f0, f1, u)
		phase += TAU * f / RATE
		var tone := sin(phase)
		lp += 0.28 * ((rng.randf() * 2.0 - 1.0) - lp)
		_pack(d, i, (tone * tone_amt + lp * noise_amt * 2.2) * env * 0.9)
	return _wav(d)


## 短促点击：两个高频正弦叠加
func _click(dur: float, f0: float, f1: float, amt: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var d := _buf(n)
	var p1 := 0.0
	var p2 := 0.0
	for i in n:
		var u := float(i) / float(n)
		var env := pow(1.0 - u, 4.0)
		p1 += TAU * f0 / RATE
		p2 += TAU * f1 / RATE
		_pack(d, i, (sin(p1) * 0.6 + sin(p2) * 0.4) * env * amt * 1.6)
	return _wav(d)


## 扫频：用于提示音、击杀音、受伤音
func _sweep(dur: float, f0: float, f1: float, amt: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var d := _buf(n)
	var phase := 0.0
	for i in n:
		var u := float(i) / float(n)
		var env := sin(PI * clampf(u * 1.0, 0.0, 1.0))
		var f := lerpf(f0, f1, u)
		phase += TAU * f / RATE
		_pack(d, i, sin(phase) * env * amt * 1.5)
	return _wav(d)


## 噪声：脚步等
func _noise(dur: float, amt: float, lp_amt: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var d := _buf(n)
	var lp := 0.0
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	for i in n:
		var u := float(i) / float(n)
		var env := pow(1.0 - u, 2.0)
		lp += lp_amt * ((rng.randf() * 2.0 - 1.0) - lp)
		_pack(d, i, lp * env * amt * 3.0)
	return _wav(d)
