# FPS Arena

Godot 4.7 引擎做的 **3D 第一人称竞技射击**游戏，单机生存模式，对抗一波波 AI 敌人。
全程序化生成 —— 关卡、模型、音效、UI 全部由代码构建，**不依赖任何外部素材**。

![主菜单](shots/01_menu.png)

## 运行

### 方式一：直接跑导出包

| 平台 | 文件 | 说明 |
| --- | --- | --- |
| Windows | `build/windows/FPSArena.exe` | 单文件，内嵌资源包，双击即玩。同目录的 `README.txt` 是给收件人看的（SmartScreen 怎么过、存档在哪、SHA-256），`RESOURCE-MANIFEST.txt` 是包内文件清单 |
| macOS | `build/macos/FPSArena.zip` | 解压得 `FPS Arena.app` |
| 网页 | `build/web/` | 双击 `start-mac.command` / `start-windows.bat`，浏览器里玩 |

> macOS 未签名，首次运行需右键 → 打开，或执行 `xattr -cr "FPS Arena.app"`。
> Windows 首次运行可能被防火墙询问，允许「专用网络」即可（本游戏为单机，不需要联网）。

![对局](shots/02_gameplay.png)

### 方式二：用 Godot 编辑器打开

用 Godot 4.7 打开本目录，按 F5 运行。

### 方式三：命令行

```bash
GODOT="/Applications/Godot.app/Contents/MacOS/Godot"
"$GODOT" --path .              # 直接启动游戏
```

## 网页版

### 在线链接

**https://738765b8552647f5955f0f44a5373985.sg2.agentos-app.run**

> 首次打开要下载约 6.9MB 的引擎（已 brotli 压缩），慢的时候要等一两分钟，
> 之后走浏览器缓存会快很多。这是沙箱出口带宽的限制，不是站点的问题。

### 本地运行

`build/web/` 是导出好的 Web 版，也可以在本地起服务玩。

**不要直接双击 `index.html`** —— 浏览器禁止 `file://` 页面读取 `.wasm` / `.pck`，
会黑屏。必须通过 HTTP 服务器访问：

| 系统 | 做法 |
| --- | --- |
| macOS | 双击 `build/web/start-mac.command` |
| Windows | 双击 `build/web/start-windows.bat` |
| 手动 | `./run.sh serve` 然后开 `http://127.0.0.1:8790/index.html` |

> 别用 `python3 -m http.server`：它既不认 `.wasm` 的 MIME（旧版 Python），
> **也不会压缩**。自带的 `godot_web_server.py` 两个问题都解决了。

![网页版](shots/web_02_ingame.png)

### ⚠️ 一定要做压缩，否则首屏要三分钟

Godot 4 的 `index.wasm` 有 **39.5MB**。实测：

| | 大小 | 相对原始 |
| --- | --- | --- |
| 原始 | 39.51 MB | 100% |
| gzip -9 | 10.05 MB | 25.4% |
| **brotli** | **6.90 MB** | **17.5%** |

部署环境实测出口带宽只有 ~200 KB/s，不压缩要 **186 秒**，压缩后约 **35 秒**。

```bash
./run.sh web          # 导出 + 自动生成 .br/.gz 预压缩副本
# 或者只补压缩：
./run.sh compress
```

`godot_web_server.py` 会在客户端 `Accept-Encoding` 允许时自动返回 `.br` / `.gz`，
并带上正确的 `Content-Encoding`、`Vary` 和长缓存头。

验收压缩是否真生效（别只看本地文件存在）：

```bash
curl -sI -H "Accept-Encoding: br,gzip" "<站点>/index.wasm" | grep -iE "content-encoding|content-length"
# 期望 content-encoding: br / content-length: 6902599（而不是 39514754）
```

### 网页版的已知限制

1. **画质比桌面版低。** Godot 的 Web 导出只支持 Compatibility（WebGL 2.0）后端，
   不支持桌面版用的 Forward+ 特性 —— 体积雾、SSAO、辉光、Filmic 色调映射都没有，
   场景看起来更平。这是引擎限制，不是 bug。
2. **"退出游戏"不会关闭标签页**，会显示一个提示层。浏览器不允许脚本关闭不是它自己
   打开的标签页，直接关掉页面即可。
3. **首次加载慢**（见上），之后走缓存。

### 中文为什么不会变豆腐块

桌面版用 `SystemFont` 找系统字体就行，但 **Web 平台没实现 `OS.get_system_font_path()`**，
`SystemFont` 解析不到任何字体，中文会全渲染成豆腐块（方框里写着十六进制码位）。

所以项目内置了一份中文字体子集 `assets/fonts/NotoSansSC-Regular.woff2`（约 1MB，
从 17.7MB 的 Noto Sans SC 子集化而来，字符集 = GB2312 全集 ∪ 源码里出现过的字符 ∪ ASCII）。
改了中文文案后要重跑：

```bash
curl -sL --noproxy '*' -o /tmp/fontwork/vf.ttf \
  "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf"
/Users/720coder/.workbuddy-ai/binaries/python/envs/default/bin/python tools/subset_font.py
"$GODOT" --headless --path . --import
```

## 验证状态

区分「真跑过」和「只能静态看」，不含糊。

### 真跑过的

| 项 | 怎么验的 | 结果 |
| --- | --- | --- |
| 逻辑自检 | `--selftest`（源码 + 导出后的 macOS app 各跑一次） | 0 失败 |
| 作弊系统 | `--selftest` 9.1~9.16，逐项「开/关对照实验」 | 16 项全过（含合成真实按键 Q/Esc） |
| 首领系统 | `--selftest` 10.1~10.9，逐项断言 | 9 项全过（狂暴 / 震荡波近远对照 / 77 发打死 / 结算时血条不复活） |
| 端到端模拟（无敌） | `--sim=40`，3× 时间加速 | 波次 5、击杀 36~40、命中率 91~93%、PASS |
| 首领实战 | `--sim=70 --wave=5` | 首领 1608→0，中途狂暴并召唤 2 护卫，波次推进到 6、最终到 7、PASS |
| 端到端模拟（会死） | `--simdie=30` | 25s 阵亡、结算面板正常、PASS |
| 桌面渲染 | 抽帧 7 张（菜单/对局/交战/首领/作弊面板/结算/暂停） | 逐张看过 |
| 网页版可玩 | 无头 Chrome + WebGL 2.0，真点击进对局 | 敌人 AI 会移动开火（血量 100→76） |
| 网页版首领 | 无头 Chrome + WebGL 2.0，注入 `--shot` 借游戏自己的首领布景 | 首领模型 + 尖角冠/肩甲/脚下光环 + 血条 `997/1607` 全部正常 |
| 网页版退出提示 | 无头 Chrome 点"退出游戏" | 提示层中文正常，无豆腐块 |
| `start-mac.command` | 真执行（`open` 换桩，不弹窗） | 选端口 / 起服务 / 开浏览器全通 |
| `server.ps1` | PowerShell 7.6.6 真执行 + 浏览器加载 | `.wasm`→`application/wasm`、穿越→403、缺文件→404 |
| 在线链接 | 公网无头 Chrome 实访 | 加载正常，`content-encoding: br` |

### 只能静态验的

| 项 | 为什么 | 做了什么 |
| --- | --- | --- |
| `start-windows.bat` | `cmd.exe` 脚本，macOS 无解释器能跑 | 字节级：无 BOM / 纯 ASCII / CRLF；逻辑人工复核 |
| `FPSArena.exe` | Windows 二进制，macOS 无法执行 | PE 结构、内嵌 pck 与 web 版逐条对账、中文字体与文案字节存在性 |

> `server.ps1` 之所以能真跑：它是纯 .NET 逻辑（`TcpListener` / `File` / `Path`），
> 只有「打开浏览器」和「控制台编码」两处与平台相关。用自包含的 PowerShell 7.6.6
> 在本机执行，HTTP 行为与 Windows 一致 —— 不必靠读代码猜。

## 操作

| 按键 | 功能 |
| --- | --- |
| `W` `A` `S` `D` | 移动 |
| 鼠标 | 转向瞄准 |
| 鼠标左键 | 射击（按住连发） |
| 鼠标右键 | 机瞄（缩小准星、大幅降低散布） |
| `空格` | 跳跃 |
| `Shift` | 冲刺 |
| `R` | 换弹 |
| `1` `2` `3` `4` | 切换武器 |
| `E` / 滚轮 | 切换下一把武器 |
| `Q` | 打开 / 关闭 **作弊面板** |
| `Esc` | 暂停 / 继续（作弊面板开着时只关面板） |

## 玩法

守住竞技场，击退一波又一波敌人。每波结束后自动补给（回血 + 补弹），
击杀敌人有概率掉落 **医疗包**（绿色）与 **弹药箱**（橙色）。
脱战 5 秒后生命会自动缓慢回复。

### 敌人

| 类型 | 特点 |
| --- | --- |
| 步兵（橙） | 保持中距离对射，会绕圈走位、找掩体 |
| 突击兵（红） | 高速冲锋近战，逼迫你后撤换位 |
| 重装兵（紫） | 血厚、伤害高，移动慢，是移动掩体 |
| **首领（暗红 + 金角）** | 每 **5 波**出现一次。体型 2.1 倍、血量约 1600，顶部有专属血条 |

### 首领机制

- **震荡波**：玩家贴近到 12 米内会放出扩散冲击环，10 米内造成重击并踢镜头 ——
  逼你拉开距离，而不是贴着站桩对枪
- **狂暴**：血量掉到 **45%** 以下自动进入狂暴，速度 ×1.45、伤害 ×1.30、射速 ×1.7，
  全身发光脉动，并**召唤两名护卫**（一名步兵 + 一名突击兵）
- **击破奖励**：2000 分，必掉一个医疗包 + 一个弹药箱
- 配平实测：突击步枪约 **77 发**（约 2.6 个弹匣）打死一只

### 武器

| 武器 | 弹匣 | 伤害 | 特点 |
| --- | --- | --- | --- |
| 突击步枪 AR | 30 | 22 | 全自动，均衡 |
| 霰弹枪 SG | 8 | 13 × 9 弹丸 | 近距离爆发，散布大 |
| 冲锋枪 SMG | 40 | 14 | 射速极快，弹道飘 |
| 精准手枪 DMR | 12 | 46 | 半自动，极低散布，远距离点名 |

命中头部有 **2.2 倍** 伤害加成。

## 作弊面板（`Q`）

按 `Q` 打开，面板打开时游戏自动暂停、鼠标释放。**12 个持续开关 + 7 个立即动作**：

| 分组 | 内容 |
| --- | --- |
| 战斗 | 无敌模式、无限弹药、一击必杀、极速射击（射速 ×5）、精准枪法（零散布无后坐力）、全自动 |
| 移动 | 疾风步（×2.2）、超级跳（×2.1）、飞行模式（空格升 / `Shift` 降） |
| 敌人 | 冻结敌人（连开火一起停）、弱化敌人（受伤 ×8）、秒杀全场（计分）、清空敌人（不计分）、立即下一波 |
| 角色 | 回满生命、补满弹药、加分 +1000 |
| 世界 | 子弹时间（时间流速 ×0.35）、全部关闭 |

- 开关型条目点一下立刻生效，右侧显示「开启 / 关闭」，开启时按钮变绿
- 动作型条目右侧显示「执行」，点一下立即执行并弹出提示
- 左上角 HUD 会显示「作弊 N 项生效」；无作弊时显示「按 Q 打开作弊面板」
- 作弊在返回主菜单时自动清空；对局内「重新开始」会保留
- 实现是**数据驱动**的：条目全写在 `cheat_panel.gd` 的 `GROUPS` 常量表里，
  状态集中在 autoload `Cheats`（`cheats.gd`），各系统直接读 `Cheats.xxx`

## 已实现的系统

- **玩家控制器**：加速度式移动、跳跃、冲刺、机瞄变焦、头部晃动、脚步音、死亡倒地镜头
- **射击系统**：射线命中扫描、距离衰减、散布锥（随移动/跳跃/机瞄动态变化）、
  后坐力、枪口火光、曳光弹、弹着火花、换弹动画
- **AI 敌人**：视线遮挡检测、掩体绕行（多方向探针）、卡墙自解、
  连续卡死强制横向绕行（避免在掩体两侧与玩家形成死循环）、反应延迟、
  点射节奏、走位（贴近 / 后撤 / 绕圈）、受击闪白、血条 billboard、死亡倒地
- **首领**：第 4 种敌人，专属模型（肩甲尖刺 / 头冠犄角 / 重炮 / 红光环）、
  周期性震荡波范围攻击（带扩散光环 + 冲击灯）、血量过半自动狂暴（提速提伤提射速 +
  召唤两名护卫）、顶部专属血条、击破必掉补给
- **作弊面板**：`Q` 键开关，12 开关 + 7 动作，数据驱动，打开时暂停游戏
- **关卡**：程序化竞技场（地面网格着色器、围墙、中央高台 + 四条坡道、掩体箱、立柱、
  天空盒、体积雾、SSAO、辉光）
- **HUD**：动态准星、命中标记（爆头变红）、血量条、弹药、波次、首领血条、
  击杀播报、受伤红屏、低血脉动、波次横幅、暂停面板、结算面板
- **音效**：全部用 `PackedByteArray` 实时合成 `AudioStreamWAV`（枪声、命中、击杀、
  受伤、换弹、脚步、拾取…），零音频素材
- **中文字体**：覆写内置主题的全部字体条目 + 系统字体链，彻底解决「豆腐块」
- **进度**：最高分 / 最远波次存档（`user://fps_arena_save.cfg`）

## 目录结构

```
project.godot            引擎配置（自动加载、渲染、物理层）
main.tscn                唯一场景：一个 Node + main.gd
main.gd                  入口：输入映射、主题、菜单↔对局切换、测试钩子
export_presets.cfg       Windows / macOS / Web 导出配置
assets/fonts/            内置中文字体子集（Web 版必需）
tools/
  subset_font.py         重新生成字体子集
  compress_web.py        为 Web 产物生成 .br / .gz 预压缩副本
scripts/
  ui_theme.gd            中文字体主题构建
  game_state.gd          战绩与存档（autoload）
  sfx.gd                 程序化音效合成（autoload）
  cheats.gd              作弊状态集中层（autoload）
  cheat_panel.gd         作弊面板 UI（Q 键，数据驱动）
  main_menu.gd           主菜单（着色器动态背景）
  level.gd               程序化竞技场
  player.gd              FPS 玩家控制器
  weapon.gd              武器与射击
  enemy.gd               AI 敌人（含首领：狂暴 / 震荡波）
  pickup.gd              掉落物
  hud.gd                 战斗 HUD 与各种面板（含首领血条）
  game.gd                对局主控：波次、掉落、暂停、结算
shots/                   自动抽帧生成的截图（含 web_* 网页版截图）
build/                   导出的可执行包（windows / macos / web）
```

## 自动化测试

全部无需人工干预，用命令行参数驱动：

```bash
./run.sh test        # 逻辑自检
./run.sh sim 40      # 端到端模拟（无敌）
./run.sh simdie 30   # 端到端模拟（会死 → 结算面板）
./run.sh shots       # 渲染抽帧 → shots/
./run.sh web         # 导出网页版 + 压缩
./run.sh all         # 三平台全量导出
```

等价于直接调引擎：

```bash
GODOT="/Applications/Godot.app/Contents/MacOS/Godot"

# 1) 逻辑自检：字体/输入/音效/移动/开火/命中伤害/敌人死亡计分/波次/出生点遮挡
#    + 作弊系统逐项断言（9.1~9.16）+ 首领系统逐项断言（10.1~10.9）
"$GODOT" --headless --path . -- --selftest
#    → 期望输出 [TEST] RESULT=PASS

# 2) 端到端模拟（无敌模式）：验证波次推进 + AI 寻路 + 敌人开火
"$GODOT" --headless --path . -- --sim=40
#    加 --wave=5 可直接从第 5 波开打（验证首领波）
"$GODOT" --headless --path . -- --sim=70 --wave=5

# 3) 端到端模拟（会死）：验证受伤 → 死亡 → 结算面板
"$GODOT" --headless --path . -- --simdie=30

# 4) 渲染抽帧：菜单 / 对局 / 交战 / 首领 / 作弊面板 / 结算 / 暂停 七张 → shots/
"$GODOT" --path . -- --shot
```

### 网页版验收（无头 Chrome + CDP）

```bash
python3 build/web/godot_web_server.py 8791     # 常驻（用 run_in_background）
python3 tools/web_verify.py http://127.0.0.1:8791/index.html /tmp/webshots shot build/web
```

`tools/web_verify.py` 三种模式：

| 模式 | 做什么 |
| --- | --- |
| `basic` | 真按键/点击：主菜单 → 点「开始游戏」→ 对局 → 按 Q → 作弊面板。看中文豆腐块、元素越界 |
| `boss` | 借作弊面板把波次推到首领波，连拍等首领出场（会先开无敌，否则玩家站着挨打会死） |
| `shot` | **推荐**。往临时 HTML 注入 `GODOT_CONFIG.args=["--","--shot"]`，让游戏自己把 7 个调试布景依次摆出来，外面连拍并按「首领血条」挑帧 |

> Web shell **不读 URL 查询参数**（`index.js` 里搜不到 `URLSearchParams`），
> 但 `index.html` 里的 `GODOT_CONFIG.args` 是明文，复制一份改掉即可 —— `shot` 模式就走这条路。
> 它比 `boss` 模式可靠得多：首领在投放队列**最后**出场，靠推波次经常差几秒拍不到。
> 临时 HTML 用完即删，别留在 `build/web/` 里被发布出去。

> `--sim=N` 的 N 是**真实秒**（不是游戏内秒）。引擎内 `time_scale=3.0`，
> 所以 45 真实秒 ≈ 135 游戏内秒。模拟结果**波动很大**（出生点随机），
> 单次跑得慢不代表有 bug —— 判断回归要看多次运行的区间。

抽帧是发现「HUD 排版错位、元素跑出屏幕、字体豆腐块」这类问题的唯一可靠手段 ——
无头模式不会报这些错。

> **验收截图必须逐张打开看。** 核对 `md5` 去重数量只能证明「不是同一帧」，
> **不能证明内容对** —— 背景网格着色器一直在动，哪怕截到的都是同一块暂停面板，
> 每张的 md5 也各不相同。本项目就靠 md5 得到「5 张全不同」而误判通过，
> 实际有两张内容重复。

## 重新导出

```bash
mkdir -p build/windows build/macos build/web
"$GODOT" --headless --path . --export-release "Windows Desktop" build/windows/FPSArena.exe
"$GODOT" --headless --path . --export-release "macOS"          build/macos/FPSArena.zip
"$GODOT" --headless --path . --export-release "Web"            "$(pwd)/build/web/index.html"
```

> Web 导出只覆盖 `index.*` 那几个文件，`start-mac.command` / `start-windows.bat` /
> `server.ps1` / `godot_web_server.py` / `README.txt` 是手工放进去的，不会被覆盖，
> 也不需要每次重新拷。

> ⚠️ **重新导出后 `build/windows/README.txt` 里的 SHA-256 就失效了**（exe 变了）。
> 必须重算，否则交付说明里的校验值对不上，收件人校验会以为文件损坏：
>
> ```bash
> PY=/Users/720coder/.workbuddy-ai/binaries/python/versions/3.13.12/bin/python3
> "$PY" /Users/720coder/.workbuddy-ai/skills/godot-web-export/scripts/pck_inspect.py \
>   build/windows/FPSArena.exe \
>   --manifest build/windows/RESOURCE-MANIFEST.txt \
>   --diff build/web/index.pck
> shasum -a 256 build/windows/FPSArena.exe     # 把新值填回 README.txt
> ```
>
> 清单和 README 都必须存成 **UTF-8 BOM + CRLF**，否则老版 Windows 记事本会乱码。

导出后建议真跑一遍验收：

```bash
cd build/macos && unzip -q FPSArena.zip
"./FPS Arena.app/Contents/MacOS/FPS Arena" --headless -- --selftest
```

注意 `--` 分隔符不能省，否则 `--selftest` 不会进入 `OS.get_cmdline_user_args()`。

> 导出会在 `build/macos/` 留下解压出来的 `FPS Arena.app`（中间产物）。
> 重新导出后记得删掉旧的 app 再解压，否则**旧的 app 配新的 zip**，
> 用户可能跑到过期的那份。
