# bbq — FPS Arena

Godot 4.7 的 3D 第一人称射击游戏（单机生存，打 AI 敌人波次）。
全程序化生成：关卡、模型、材质、音效、UI 全部代码构建，零外部素材
（唯一例外是 Web 版必须内置的中文字体子集，见下）。

## 环境与命令

```bash
GODOT="/Applications/Godot.app/Contents/MacOS/Godot"   # 本机 4.7.2.stable
cd /Users/720coder/workbuddy-ai/bbq
./run.sh play            # 启动游戏
./run.sh test            # 逻辑自检 → 期望 RESULT=PASS
./run.sh sim 40          # 端到端模拟（无敌，自动交战）
./run.sh simdie 30       # 端到端模拟（会死 → 结算面板）
./run.sh shots           # 抽帧 5 张 → shots/
./run.sh export          # 导出 Windows + macOS
```

## 项目约定

- **主场景极简**：`main.tscn` 只有一个 Node + `main.gd`，其余全部代码构建。
  不手写 3D `.tscn`（Transform3D 是 12 个浮点数，改一个就歪）。
- **所有测试钩子集中在 `main.gd`**，读 `OS.get_cmdline_user_args()`。
  `--autoquit=` 必须在参数分发循环**之前**解析。
- **物理层**：1=world，2=player，3=enemy。射线 mask 打错是最常见的「打不中」原因。
- **改同一个文件的多个位置必须串行 Edit** —— 并行写会互相覆盖，两边都报 success。
- **验收截图必须逐张打开看**，`md5` 去重只能证明「不是同一帧」，不能证明内容对。
- **随机复现的 bug 要连跑 3 次以上**才算验证通过（如 AI 卡死）。
- 源码改动后**必须重新导出**，产物要与源码一致。

## 三个平台的导出

| 平台 | 预设名 | 产物 |
|---|---|---|
| Windows | `Windows Desktop` | `build/windows/FPSArena.exe`（单文件内嵌 PCK） |
| macOS | `macOS` | `build/macos/FPSArena.zip`（universal） |
| Web | `Web` | `build/web/index.html`（nothreads，免 COOP/COEP） |

**线上链接**：https://738765b8552647f5955f0f44a5373985.sg2.agentos-app.run
（重新发布同一目录会复用同一链接，内容会被覆盖）

**⚠️ 导出 Web 后必须跑压缩**，否则首屏要三分钟（本地看不出来，用户那边就是白屏）：

```bash
./run.sh web        # 导出 + 生成 .br/.gz 预压缩副本
```

wasm 39.5MB → brotli 6.9MB（17.5%）。`godot_web_server.py` 会按 `Accept-Encoding`
返回预压缩文件。发布时要用 `startCmd: "python3 godot_web_server.py"` 覆盖
默认的 `python3 -m http.server`（后者不压缩、也不认 .wasm 的 MIME）。

导出后**必须真跑一遍**：`--` 分隔符不能省，否则参数进不了 `OS.get_cmdline_user_args()`。

`build/macos/` 会留下解压出的 `FPS Arena.app`（中间产物）—— 重新导出后要删掉旧 app
再解压，否则旧的 app 配新的 zip，用户可能跑到过期那份。

## 中文字体（Web 版的关键）

`scripts/ui_theme.gd` 用**内置字体子集** `assets/fonts/NotoSansSC-Regular.woff2`（约 1MB）
作主字体，`SystemFont` 作 fallback。

原因：`SystemFont` 依赖 `OS.get_system_font_path()`，**Web 平台未实现**，
不内置的话中文全变豆腐块。

重新生成子集（改了中文文案后要重跑）：

```bash
curl -sL --noproxy '*' -o /tmp/fontwork/vf.ttf \
  "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf"
/Users/720coder/.workbuddy-ai/binaries/python/envs/default/bin/python tools/subset_font.py
"$GODOT" --headless --path . --import
```

字符集 = GB2312 全集 ∪ 项目源码里出现过的字符 ∪ ASCII，所以动态拼出的字符串也不缺字。

**坑**：`UiTheme.attach()` 必须在 `add_child()` **之后**调用 —— 不在树里时
`get_window()` 返回 null，会静默失效（症状：主菜单中文正常，只有新加的浮层是豆腐块）。
`attach()` 已改为失败时 `printerr`。

**坑**：`FontVariation` 没有 `subpixel_positioning` / `antialiasing` 属性
（那是 `FontFile` / `SystemFont` 的），设了会在运行时炸。

## 验证状态（区分「真跑过」和「只能静态看」）

**真跑过的**：`--selftest`（源码 + 导出后的 app 各一次）、`--sim=40`（波次 5 / 击杀 40 /
命中率 92.8%）、`--simdie=30`、桌面抽帧 5 张、网页版无头 Chrome 真点击进对局
（敌人 AI 会开火，血量 100→76）、网页版退出提示层、`start-mac.command` 真执行、
`server.ps1`（用 PowerShell 7.6.6 真执行）、线上链接公网实访。

**只能静态验的**：`start-windows.bat`（`cmd.exe` 脚本，macOS 无解释器能跑）、
`FPSArena.exe`（Windows 二进制）。两处都在 README / README.txt 里如实标注，不含糊。

**本机其实有 Windows 虚拟机的退路**（用户 2026-10-04 明确选择「不用，就此收尾」）：
Parallels Desktop 20.4 + 两个已装好的 Windows 11 VM（`~/Parallels/Windows 11.pvm` 55G、
`Windows 11 (1).pvm` 32G，均**挂起**状态）。要用它跑这两项的话：
启动 Parallels Desktop 应用（`prlctl list` 现在报 `Login failed`，服务没起）
→ 恢复 VM → 用 `prlctl exec` 跑。**属于要动用户环境的操作，必须先问。**

**`server.ps1` 为什么能真跑**：它是纯 .NET 逻辑（`TcpListener` / `File` / `Path`），
只有「打开浏览器」和「控制台编码」两处平台相关 → 拿自包含 pwsh 在本机执行即可，
不必靠读代码猜。实测 `.wasm`→`application/wasm`、`/%2e%2e/...`→403、缺文件→404。

**测启动器脚本的办法**：把要弹窗的命令（`open` / `Start-Process`）换成同名桩塞到前面，
其余逻辑原样跑。`open` 桩用 `PATH=/tmp/shimbin:$PATH ./start-mac.command`；
`Start-Process` 桩在包装 .ps1 里定义同名函数（函数解析优先级高于 cmdlet）。
验桩是否生效用 **atime**，别用 stdout（后台任务 + `exec` 会吞掉那行输出）。

## 本机网络 / 工具环境（实测数据）

| 用途 | 途径 | 实测速度 |
|---|---|---|
| GitHub Release 大文件 | 直连 | ~22 KB/s |
| 同上 | `ghproxy.net` | ~41 KB/s |
| 同上 | `gh-proxy.com` | ~307 KB/s |
| 同上 | **`ghfast.top`** | **~930 KB/s** |

**先花 30 秒测速再决定要不要下** —— 同一个 67MB 文件，最快 74 秒，最慢 52 分钟。

- 本机**没有** pwsh / Docker / Wine / 虚拟机。需要 pwsh 时下自包含 tarball 解到 `/tmp`
  （**别用 brew**：会拖 `dotnet` ~300MB 依赖并改动系统，为验一个辅助脚本不值得）。
- 无头浏览器用 Playwright 已下好的 shell：
  `~/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell`
  - **必须用 `--use-gl=angle --use-angle=swiftshader`**。老写法 `--use-gl=swiftshader`
    在当前 Chrome 上会让 GPU 进程退出 → `CONTEXT_LOST_WEBGL` → 之后每次
    `Page.captureScreenshot` 都超时（看着像 CDP 客户端写错了）。
  - `tools/web_verify.py` 三种模式：`basic`（真点按走主菜单/对局/作弊面板）、
    `boss`（借作弊面板推波次，会开无敌）、**`shot`（推荐）**——
    往临时 HTML 注入 `GODOT_CONFIG.args=["--","--shot"]`，让游戏自己把 7 个调试布景
    摆出来再连拍。Web shell 不读 URL 查询参数，但 `GODOT_CONFIG.args` 是明文。
- 沙箱里 `ps` 不可用；curl 测本地端口**必须 `--noproxy '*'`**，否则拿到代理的 502。
- `build/windows/README.txt` 和 `RESOURCE-MANIFEST.txt` 必须是 **UTF-8 BOM + CRLF**。
  重导 exe 后要重跑 `pck_inspect.py --manifest` 并回填新的 SHA-256，否则校验值对不上。

## 相关技能

- `godot-3d-fps` —— 本项目的工作流与全部踩坑记录
- `godot-web-export` —— Web 导出的坑（字体子集、file:// 打不开、wasm MIME、CDP 截图验收）
- `godot-lan-multiplayer` —— 2D 俯视 + ENet 联机（另一套，不通用）
