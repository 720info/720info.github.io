## ============================================================
## 怪物刷新点
## 在固定点位定时刷新怪物，保持存活数量不超过 max_alive；
## 怪物等级跟随玩家等级（可能低 1 级），刷新位置避开障碍物。
## 生成的怪物通过 EventBus.spawn_enemy_requested 交给主场景放进 Enemies 容器。
## ============================================================
extends Marker2D

@export var enemy_scene: PackedScene
@export var max_alive: int = 2
@export var respawn_interval: float = 8.0
@export var first_spawn_delay: float = 0.5
@export var spawn_radius: float = 40.0
@export var safe_distance_to_player: float = 220.0   ## 玩家太近时不刷新
@export var spawn_effect_scene: PackedScene
@export var level_offset: int = 0   ## 怪物等级加成（后期地图更强）

var alive_count := 0
var spawn_timer := 0.0
var player_ref: Node2D = null


func _ready() -> void:
	spawn_timer = first_spawn_delay


func _physics_process(delta: float) -> void:
	if enemy_scene == null or alive_count >= max_alive:
		return
	spawn_timer -= delta
	if spawn_timer > 0.0:
		return
	if _player_too_close():
		spawn_timer = 1.0
		return
	var spawn_position := _find_free_position()
	if spawn_position == Vector2.INF:
		spawn_timer = 1.0
		return
	_spawn_enemy(spawn_position)
	spawn_timer = respawn_interval


func _spawn_enemy(spawn_position: Vector2) -> void:
	var enemy := ObjectPool.acquire(enemy_scene) as Node2D
	enemy.position = spawn_position
	if enemy.has_method("setup_level"):
		enemy.call("setup_level", maxi(GameState.player_level - randi_range(0, 1) + level_offset, 1))
	# 一次性连接：怪物被回收（移出场景树）时计数减一，复用时不会重复连接
	enemy.tree_exited.connect(_on_enemy_removed, CONNECT_ONE_SHOT)
	alive_count += 1
	EventBus.spawn_enemy_requested.emit(enemy)
	if spawn_effect_scene:
		var effect := ObjectPool.acquire(spawn_effect_scene) as Node2D
		effect.position = spawn_position
		effect.set("max_radius", 36.0)
		effect.set("color", Color(0.35, 0.3, 0.45, 0.9))
		EventBus.spawn_effect_requested.emit(effect)


## 在刷新半径内找一个不与障碍物/其他怪物重叠的位置，找不到返回 Vector2.INF
func _find_free_position() -> Vector2:
	var shape := CircleShape2D.new()
	shape.radius = 16.0
	var params := PhysicsShapeQueryParameters2D.new()
	params.shape = shape
	params.collision_mask = GameDB.LAYER_OBSTACLE | GameDB.LAYER_ENEMY
	var space := get_world_2d().direct_space_state
	for attempt in 8:
		var candidate := global_position + Vector2.from_angle(randf() * TAU) * randf_range(0.0, spawn_radius)
		params.transform = Transform2D(0.0, candidate)
		if space.intersect_shape(params, 1).is_empty():
			return candidate
	return Vector2.INF


func _on_enemy_removed() -> void:
	alive_count = maxi(alive_count - 1, 0)


func _player_too_close() -> bool:
	if player_ref == null or not is_instance_valid(player_ref):
		player_ref = get_tree().get_first_node_in_group("player") as Node2D
	return player_ref != null and player_ref.global_position.distance_to(global_position) < safe_distance_to_player
