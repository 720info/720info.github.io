## ============================================================
## 存档点（驿站石碑）
## 玩家靠近时提示「按 E 存档」；按下后：回满状态、设为复活点、写入存档。
## 通过 EventBus 通知 HUD 显示/隐藏交互提示。
## ============================================================
extends Area2D

@export var point_name: String = "驿站石碑"
@export var respawn_offset: Vector2 = Vector2(0, 46)   ## 复活位置相对石碑的偏移
@export var ring_effect_scene: PackedScene

@onready var rune: Polygon2D = $Visual/Rune
@onready var name_label: Label = $NameLabel

var player_inside: Node2D = null
var glow_time := 0.0
var _interact_pressed := false


func _ready() -> void:
	name_label.text = point_name
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


func _unhandled_input(event: InputEvent) -> void:
	if player_inside and is_instance_valid(player_inside) \
			and event.is_action_pressed("interact"):
		_interact_pressed = true


func _process(delta: float) -> void:
	glow_time += delta
	rune.modulate.a = 0.55 + sin(glow_time * 3.0) * 0.35
	if _interact_pressed:
		_interact_pressed = false
		_activate()


func _activate() -> void:
	if player_inside.has_method("is_alive") and not player_inside.call("is_alive"):
		return
	player_inside.call("restore_full")
	player_inside.call("set_checkpoint", global_position + respawn_offset)
	if SaveManager.save_game():
		EventBus.toast("已在【%s】存档，状态已回满" % point_name)
	else:
		EventBus.toast("存档失败，请检查磁盘权限")
	EventBus.show_text("调息完毕", global_position + Vector2(0, -80), Color(0.6, 1.0, 0.9), 20)
	if ring_effect_scene:
		var ring := ObjectPool.acquire(ring_effect_scene) as Node2D
		ring.position = global_position
		ring.set("max_radius", 90.0)
		ring.set("color", Color(0.55, 0.95, 1.0))
		EventBus.spawn_effect_requested.emit(ring)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and body.has_method("set_checkpoint"):
		player_inside = body
		EventBus.interact_prompt_changed.emit("按 E 在【%s】存档并调息" % point_name)


func _on_body_exited(body: Node2D) -> void:
	if body == player_inside:
		player_inside = null
		EventBus.interact_prompt_changed.emit("")
