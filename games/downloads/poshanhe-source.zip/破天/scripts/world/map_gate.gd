## ============================================================
## 通关传送阵
## 本图击杀数达标（有首领的图还需先灭首领）后，靠近按 E 进入下一图；
## 第五图（最终图）达成条件后按 E 视为通关，弹出通关画面。
## ============================================================
extends Area2D

@export var kill_goal: int = 15
@export var requires_boss: bool = false
@export var boss_name: String = ""
@export var is_final: bool = false

@onready var rune: Polygon2D = $Visual/Rune
@onready var name_label: Label = $NameLabel

var player_inside: Node2D = null
var boss_defeated := false
var glow_time := 0.0
var _interact_pressed := false


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	_refresh_name()
	_sync_boss_signal()


func configure(new_kill_goal: int, new_is_final: bool, new_requires_boss: bool, new_boss_name: String = "") -> void:
	kill_goal = new_kill_goal
	is_final = new_is_final
	requires_boss = new_requires_boss
	boss_name = new_boss_name
	boss_defeated = false
	_refresh_name()
	_sync_boss_signal()


func _unhandled_input(event: InputEvent) -> void:
	if player_inside and is_instance_valid(player_inside) \
			and event.is_action_pressed("interact"):
		_interact_pressed = true


func _process(delta: float) -> void:
	glow_time += delta
	rune.rotation = glow_time * 0.6
	rune.modulate.a = 0.6 + sin(glow_time * 2.5) * 0.3
	if _interact_pressed:
		_interact_pressed = false
		_try_activate()


func _refresh_name() -> void:
	name_label.text = "通 关 之 门" if is_final else "下 一 图"


func _sync_boss_signal() -> void:
	var is_connected_to_enemy_killed := EventBus.enemy_killed.is_connected(_on_enemy_killed)
	if requires_boss and not is_connected_to_enemy_killed:
		EventBus.enemy_killed.connect(_on_enemy_killed)
	elif not requires_boss and is_connected_to_enemy_killed:
		EventBus.enemy_killed.disconnect(_on_enemy_killed)


func _on_enemy_killed(enemy_type: String, _exp_reward: int, _world_position: Vector2) -> void:
	if enemy_type == boss_name:
		boss_defeated = true


func _condition_met() -> bool:
	if GameState.map_kill_count < kill_goal:
		return false
	if requires_boss and not boss_defeated:
		return false
	return true


func _try_activate() -> void:
	if not _condition_met():
		var reasons: Array[String] = []
		if GameState.map_kill_count < kill_goal:
			reasons.append("击杀 %d / %d" % [GameState.map_kill_count, kill_goal])
		if requires_boss and not boss_defeated:
			reasons.append("尚未击败【%s】" % boss_name)
		EventBus.toast("尚未满足通关条件：%s" % "，".join(reasons))
		return
	if is_final:
		GameState.complete_game()
	else:
		GameState.advance_to_next_map()


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		player_inside = body
		EventBus.interact_prompt_changed.emit(
			"按 E 通关，一统江湖" if is_final else "按 E 前往下一图"
		)


func _on_body_exited(body: Node2D) -> void:
	if body == player_inside:
		player_inside = null
		EventBus.interact_prompt_changed.emit("")
