## ============================================================
## 地面装饰（草丛、野花、碎石）
## 用固定随机种子程序化绘制，纯装饰、无碰撞。
## 配色/数量由 WorldBuilder 按地图数据设置；后续可替换为 TileMapLayer 或贴图。
## ============================================================
@tool
extends Node2D

@export var area_size: Vector2 = Vector2(4800, 3200)
@export var tuft_count: int = 1400
@export var flower_count: int = 300
@export var pebble_count: int = 240
@export var random_seed: int = 7

@export var grass_dark := Color(0.2, 0.3, 0.18)
@export var grass_light := Color(0.38, 0.5, 0.3)
@export var flower_colors: Array[Color] = [Color(0.9, 0.85, 0.6), Color(0.85, 0.5, 0.45), Color(0.75, 0.75, 0.9)]
@export var pebble_color := Color(0.5, 0.52, 0.5)


func _draw() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = random_seed
	for i in tuft_count:
		var base := Vector2(rng.randf_range(40, area_size.x - 40), rng.randf_range(40, area_size.y - 40))
		var color := grass_dark if rng.randf() < 0.6 else grass_light
		for blade in 3:
			var tip := base + Vector2(rng.randf_range(-5, 5), rng.randf_range(-9, -5))
			draw_line(base + Vector2(blade * 2 - 2, 0), tip, color, 1.5)
	for i in flower_count:
		var pos := Vector2(rng.randf_range(40, area_size.x - 40), rng.randf_range(40, area_size.y - 40))
		draw_circle(pos, 2.5, flower_colors[rng.randi() % flower_colors.size()])
	for i in pebble_count:
		var pos := Vector2(rng.randf_range(40, area_size.x - 40), rng.randf_range(40, area_size.y - 40))
		draw_circle(pos, rng.randf_range(1.5, 3.5), pebble_color)
