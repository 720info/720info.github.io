## ============================================================
## 地图构建器（挂在 World 节点上）
## 地图一沿用手工搭建的既有内容（本脚本直接跳过）；
## 地图二~五按 MapDB 数据表程序化生成：地面/边界/障碍/刷新点/驿站/传送阵，
## 最后一图额外生成首领，击败后传送阵才允许触发通关。
## ============================================================
extends Node2D

const TREE_SCENE := preload("res://scenes/world/tree.tscn")
const ROCK_SCENE := preload("res://scenes/world/rock.tscn")
const SAVE_POINT_SCENE := preload("res://scenes/world/save_point.tscn")
const BANDIT_SCENE := preload("res://scenes/enemies/bandit.tscn")
const BEAST_SCENE := preload("res://scenes/enemies/beast.tscn")
const CIRCLE_SCRIPT := preload("res://scripts/common/circle_polygon.gd")
const SPAWN_POINT_SCRIPT := preload("res://scripts/world/spawn_point.gd")
const DECOR_SCRIPT := preload("res://scripts/world/ground_decor.gd")
const GROUND_TEXTURE := preload("res://assets/art/world/ground_wuxia.svg")

const CLEARING_RADIUS := 160.0
const MARGIN := 120.0
const GROUND_TEXTURE_ALPHA := 0.22

@onready var ground: Node2D = $Ground
@onready var boundary: StaticBody2D = $Boundary
@onready var obstacles: Node2D = $Obstacles
@onready var spawn_points: Node2D = $SpawnPoints
@onready var save_points: Node2D = $SavePoints
@onready var map_gate: Area2D = $MapGate


func _ready() -> void:
	if GameState.current_map == 1:
		return
	var map: Dictionary = MapDB.get_map(GameState.current_map)
	var size: Vector2 = map["size"]
	var rng := RandomNumberGenerator.new()
	rng.seed = int(map["seed"])
	_clear_baked_content()
	_build_ground(map, size, rng)
	_build_boundary(size, map["edge"])
	_build_obstacles(map, size, rng)
	_build_spawn_points(map, size, rng)
	_build_save_points(map, size)
	_build_gate(map, size)


func _clear_baked_content() -> void:
	for container in [ground, boundary, obstacles, spawn_points, save_points]:
		for child in container.get_children():
			container.remove_child(child)
			child.queue_free()


func _build_ground(map: Dictionary, size: Vector2, rng: RandomNumberGenerator) -> void:
	var base := ColorRect.new()
	base.color = map["ground"]
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	base.offset_right = size.x
	base.offset_bottom = size.y
	ground.add_child(base)
	var ground_texture := TextureRect.new()
	ground_texture.texture = GROUND_TEXTURE
	ground_texture.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	ground_texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ground_texture.stretch_mode = TextureRect.STRETCH_TILE
	ground_texture.offset_right = size.x
	ground_texture.offset_bottom = size.y
	ground_texture.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ground_texture.modulate = Color(1, 1, 1, GROUND_TEXTURE_ALPHA)
	ground.add_child(ground_texture)

	var patches: Array = map["patch"]
	for i in 5:
		var patch := Polygon2D.new()
		patch.set_script(CIRCLE_SCRIPT)
		patch.color = patches[i % patches.size()]
		patch.set("radius", rng.randf_range(150.0, 230.0))
		patch.set("segments", 28)
		patch.position = Vector2(rng.randf_range(MARGIN, size.x - MARGIN), rng.randf_range(MARGIN, size.y - MARGIN))
		patch.scale = Vector2(rng.randf_range(1.4, 2.2), rng.randf_range(1.0, 1.3))
		ground.add_child(patch)

	var road_h := Polygon2D.new()
	road_h.color = map["road"]
	road_h.polygon = PackedVector2Array([
		Vector2(0, size.y / 2 - 60), Vector2(size.x, size.y / 2 - 60),
		Vector2(size.x, size.y / 2 + 60), Vector2(0, size.y / 2 + 60),
	])
	ground.add_child(road_h)

	var clearing := Polygon2D.new()
	clearing.set_script(CIRCLE_SCRIPT)
	clearing.color = map["road"]
	clearing.set("radius", CLEARING_RADIUS)
	clearing.set("segments", 32)
	clearing.position = size / 2.0
	clearing.scale = Vector2(1.3, 1.0)
	ground.add_child(clearing)

	var decor := Node2D.new()
	decor.set_script(DECOR_SCRIPT)
	decor.set("area_size", size)
	decor.set("tuft_count", int(size.x * size.y / 11000.0))
	decor.set("flower_count", int(size.x * size.y / 50000.0))
	decor.set("pebble_count", int(size.x * size.y / 65000.0))
	decor.set("random_seed", int(map["seed"]))
	decor.set("grass_dark", map["tuft_dark"])
	decor.set("grass_light", map["tuft_light"])
	decor.set("flower_colors", map["flowers"])
	ground.add_child(decor)


func _build_boundary(size: Vector2, edge_color: Color) -> void:
	boundary.collision_layer = 8
	boundary.collision_mask = 0
	var thickness := 40.0
	var walls := [
		["WallTop", Vector2(size.x / 2, thickness / 2), Vector2(size.x, thickness)],
		["WallBottom", Vector2(size.x / 2, size.y - thickness / 2), Vector2(size.x, thickness)],
		["WallLeft", Vector2(thickness / 2, size.y / 2), Vector2(thickness, size.y)],
		["WallRight", Vector2(size.x - thickness / 2, size.y / 2), Vector2(thickness, size.y)],
	]
	for w in walls:
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = w[2]
		shape.shape = rect
		shape.position = w[1]
		shape.name = w[0]
		boundary.add_child(shape)

	var cliffs := [
		["CliffTop", Rect2(0, 0, size.x, thickness)],
		["CliffBottom", Rect2(0, size.y - thickness, size.x, thickness)],
		["CliffLeft", Rect2(0, 0, thickness, size.y)],
		["CliffRight", Rect2(size.x - thickness, 0, thickness, size.y)],
	]
	for c in cliffs:
		var rect_node := ColorRect.new()
		rect_node.name = c[0]
		var r: Rect2 = c[1]
		rect_node.offset_left = r.position.x
		rect_node.offset_top = r.position.y
		rect_node.offset_right = r.position.x + r.size.x
		rect_node.offset_bottom = r.position.y + r.size.y
		rect_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
		rect_node.color = edge_color
		boundary.add_child(rect_node)


func _is_clear(pos: Vector2, size: Vector2) -> bool:
	if pos.distance_to(size / 2.0) < CLEARING_RADIUS + 40.0:
		return false
	if absf(pos.y - size.y / 2.0) < 90.0:
		return false
	return true


func _random_free_position(size: Vector2, rng: RandomNumberGenerator) -> Vector2:
	for attempt in 12:
		var pos := Vector2(rng.randf_range(MARGIN, size.x - MARGIN), rng.randf_range(MARGIN, size.y - MARGIN))
		if _is_clear(pos, size):
			return pos
	return Vector2(MARGIN, MARGIN)


func _build_obstacles(map: Dictionary, size: Vector2, rng: RandomNumberGenerator) -> void:
	for i in int(map["tree_count"]):
		var tree := TREE_SCENE.instantiate() as Node2D
		tree.position = _random_free_position(size, rng)
		tree.modulate = map["tree_tint"]
		obstacles.add_child(tree)
	for i in int(map["rock_count"]):
		var rock := ROCK_SCENE.instantiate() as Node2D
		rock.position = _random_free_position(size, rng)
		obstacles.add_child(rock)


func _build_spawn_points(map: Dictionary, size: Vector2, rng: RandomNumberGenerator) -> void:
	for i in int(map["bandit_spawns"]):
		_make_spawn_point(BANDIT_SCENE, map, size, rng, "BanditSpawn%d" % (i + 1))
	for i in int(map["beast_spawns"]):
		_make_spawn_point(BEAST_SCENE, map, size, rng, "BeastSpawn%d" % (i + 1))


func _make_spawn_point(enemy_scene: PackedScene, map: Dictionary, size: Vector2, rng: RandomNumberGenerator, node_name: String) -> void:
	var marker := Marker2D.new()
	marker.name = node_name
	marker.set_script(SPAWN_POINT_SCRIPT)
	marker.set("enemy_scene", enemy_scene)
	marker.set("max_alive", int(map["max_alive"]))
	marker.set("respawn_interval", float(map["respawn"]))
	marker.set("level_offset", int(map["level_offset"]))
	marker.position = _random_free_position(size, rng)
	spawn_points.add_child(marker)


func _build_save_points(map: Dictionary, size: Vector2) -> void:
	var names: Array = map["save_names"]
	var positions := [
		size / 2.0 + Vector2(0, -220),
		Vector2(size.x * 0.15, size.y * 0.75),
		Vector2(size.x * 0.85, size.y * 0.3),
	]
	for i in names.size():
		var point := SAVE_POINT_SCENE.instantiate()
		point.position = positions[i % positions.size()]
		point.set("point_name", str(names[i]))
		save_points.add_child(point)


func _build_gate(map: Dictionary, size: Vector2) -> void:
	var final_map: bool = GameState.current_map >= MapDB.MAP_COUNT
	var requires_boss: bool = map.has("boss")
	var boss_name := str(map["boss"]["name"]) if requires_boss else ""
	map_gate.position = Vector2(size.x - MARGIN, size.y / 2.0)
	map_gate.call("configure", int(map["kill_goal"]), final_map, requires_boss, boss_name)
	if requires_boss:
		call_deferred("_spawn_boss", map, size)


func _spawn_boss(map: Dictionary, size: Vector2) -> void:
	var boss_data: Dictionary = map["boss"]
	var boss := BANDIT_SCENE.instantiate() as CharacterBody2D
	boss.set("enemy_type", str(boss_data.get("name", "首领")))
	boss.set("max_hp", 42.0 * float(boss_data.get("hp_scale", 6.0)))
	boss.set("attack_damage", 8.0 * float(boss_data.get("damage_scale", 1.5)))
	boss.set("exp_reward", int(12 * float(boss_data.get("exp_scale", 8.0))))
	boss.modulate = boss_data.get("tint", Color.WHITE)
	boss.scale = Vector2.ONE * float(boss_data.get("body_scale", 1.5))
	boss.position = size / 2.0 + Vector2(0, -260)
	EventBus.spawn_enemy_requested.emit(boss)
