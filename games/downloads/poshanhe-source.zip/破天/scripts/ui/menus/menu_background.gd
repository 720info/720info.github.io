## ============================================================
## 主菜单背景（程序化绘制的水墨山水：天空、明月、三层远山、薄雾、飘落的叶子）
## 根据控件尺寸绘制，窗口缩放时自动适配。可整体替换为一张背景图（TextureRect）。
## ============================================================
extends Control

const SKY_TOP := Color(0.1, 0.13, 0.14)
const SKY_BOTTOM := Color(0.24, 0.3, 0.29)
const MOUNTAIN_COLORS := [Color(0.2, 0.26, 0.26), Color(0.14, 0.19, 0.19), Color(0.08, 0.11, 0.11)]
const LEAF_COUNT := 26

var leaves: Array[Dictionary] = []
var time := 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)
	var rng := RandomNumberGenerator.new()
	rng.seed = 42
	for i in LEAF_COUNT:
		leaves.append({
			"x": rng.randf(), "y": rng.randf(),
			"speed": rng.randf_range(0.03, 0.08), "sway": rng.randf_range(0.5, 2.0),
			"size": rng.randf_range(3.0, 6.0), "phase": rng.randf() * TAU,
		})


func _process(delta: float) -> void:
	time += delta
	for leaf in leaves:
		leaf["y"] += leaf["speed"] * delta
		if leaf["y"] > 1.05:
			leaf["y"] = -0.05
	queue_redraw()


func _draw() -> void:
	var w := size.x
	var h := size.y
	# 天空渐变
	var bands := 24
	for i in bands:
		var t := float(i) / bands
		draw_rect(Rect2(0, h * t, w, h / bands + 1.0), SKY_TOP.lerp(SKY_BOTTOM, t))
	# 明月
	var moon := Vector2(w * 0.78, h * 0.2)
	draw_circle(moon, h * 0.09, Color(0.95, 0.9, 0.75, 0.12))
	draw_circle(moon, h * 0.065, Color(0.96, 0.93, 0.8, 0.9))
	# 三层远山
	for layer in 3:
		var base_y := h * (0.55 + layer * 0.12)
		var amplitude := h * (0.16 - layer * 0.03)
		var points := PackedVector2Array([Vector2(0, h)])
		var steps := 48
		for i in steps + 1:
			var x := w * float(i) / steps
			var y := base_y - amplitude * (0.5 + 0.5 * sin(x / w * (5.0 + layer * 2.0) + layer * 1.7)) \
				* (0.6 + 0.4 * sin(x / w * 13.0 + layer))
			points.append(Vector2(x, y))
		points.append(Vector2(w, h))
		draw_colored_polygon(points, MOUNTAIN_COLORS[layer])
		# 山间薄雾
		draw_rect(Rect2(0, base_y - h * 0.02, w, h * 0.05), Color(0.8, 0.85, 0.8, 0.04))
	# 飘落的叶子
	for leaf in leaves:
		var pos := Vector2(
			(leaf["x"] + sin(time * 0.8 + leaf["phase"]) * 0.02 * leaf["sway"]) * w,
			leaf["y"] * h)
		draw_circle(pos, leaf["size"], Color(0.75, 0.35, 0.25, 0.7))
