## ============================================================
## 通关画面
## 五图全部通关（最终图击败首领并进入传送阵）后弹出，暂停游戏。
## ============================================================
extends CanvasLayer

const PANEL_NAME := "victory"

@onready var info_label: Label = %InfoLabel
@onready var menu_button: Button = %MenuButton


func _ready() -> void:
	visible = false
	menu_button.pressed.connect(func() -> void: GameState.return_to_main_menu())
	EventBus.game_completed.connect(_show)


func _show() -> void:
	var minutes := int(GameState.play_time) / 60
	info_label.text = "总用时 %d 分钟 · 总击杀 %d" % [minutes, GameState.kill_total]
	visible = true
	get_tree().paused = true
	GameState.set_panel_open(PANEL_NAME, true)
	menu_button.grab_focus()
