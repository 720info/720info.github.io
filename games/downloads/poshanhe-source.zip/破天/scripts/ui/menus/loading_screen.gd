## ============================================================
## 启动加载画面（项目主场景）
## 使用 ResourceLoader 多线程预加载主菜单与游戏场景，显示进度条与提示语；
## 加载完成后交给 GameState 缓存，之后进入游戏无需再次读盘。
## ============================================================
extends Control

const SCENES_TO_LOAD: Array[String] = [GameState.MAIN_MENU_SCENE, GameState.GAME_SCENE]
const MIN_DISPLAY_TIME := 1.2   # 最短显示时间，避免一闪而过
const TIPS: Array[String] = [
	"按住鼠标左键可以连续施展三段剑招",
	"轻功冲刺期间刀枪不入，可穿过妖兽的毒球",
	"飞身斩突进时同样无敌，是脱困的好手段",
	"靠近驿站石碑按 E，可存档并调息回满",
	"升级获得属性点，按 C 分配到生命、内力或体力",
	"按 B 打开行囊，服用丹药或更换神兵",
	"怪物追出领地太远会放弃追击，回到巢穴",
]

@onready var progress_bar: ProgressBar = %ProgressBar
@onready var percent_label: Label = %PercentLabel
@onready var tip_label: Label = %TipLabel

var elapsed := 0.0
var tip_timer := 0.0
var shown_progress := 0.0
var finished := false
var load_index := 0   # 依次加载，避免两个场景并发编译脚本导致的引擎线程竞争


func _ready() -> void:
	ResourceLoader.load_threaded_request(SCENES_TO_LOAD[0])
	tip_label.text = TIPS[randi() % TIPS.size()]


func _process(delta: float) -> void:
	if finished:
		return
	elapsed += delta
	tip_timer += delta
	if tip_timer > 2.5:
		tip_timer = 0.0
		tip_label.text = TIPS[randi() % TIPS.size()]

	var in_progress_fraction := 0.0
	if load_index < SCENES_TO_LOAD.size():
		var path := SCENES_TO_LOAD[load_index]
		var progress: Array = []
		var status := ResourceLoader.load_threaded_get_status(path, progress)
		match status:
			ResourceLoader.THREAD_LOAD_LOADED:
				GameState.cache_scene(path, ResourceLoader.load_threaded_get(path) as PackedScene)
				load_index += 1
				if load_index < SCENES_TO_LOAD.size():
					ResourceLoader.load_threaded_request(SCENES_TO_LOAD[load_index])
			ResourceLoader.THREAD_LOAD_IN_PROGRESS:
				in_progress_fraction = float(progress[0]) if not progress.is_empty() else 0.0
			_:
				# 加载失败：跳过该场景，切场景时会走普通读盘（控制台可看到具体错误）
				push_error("预加载失败：%s" % path)
				load_index += 1
				if load_index < SCENES_TO_LOAD.size():
					ResourceLoader.load_threaded_request(SCENES_TO_LOAD[load_index])

	# 进度平滑增长，并受最短显示时间限制
	var total := float(load_index) + in_progress_fraction
	var target := minf(total / SCENES_TO_LOAD.size(), elapsed / MIN_DISPLAY_TIME)
	shown_progress = move_toward(shown_progress, target, delta * 1.5)
	progress_bar.value = shown_progress * 100.0
	percent_label.text = "%d%%" % int(shown_progress * 100.0)

	if load_index >= SCENES_TO_LOAD.size() and shown_progress >= 1.0:
		finished = true
		GameState.change_scene(GameState.MAIN_MENU_SCENE)
