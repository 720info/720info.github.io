## ============================================================
## 设置面板（主菜单与暂停菜单共用）
## 音量：主音量 / 音乐 / 音效；显示：窗口模式、分辨率、垂直同步。
## 修改立即生效并保存（由 SettingsManager 负责应用与持久化）。
## ============================================================
class_name SettingsPanel
extends Control

signal closed

@onready var master_slider: HSlider = %MasterSlider
@onready var master_value: Label = %MasterValue
@onready var bgm_slider: HSlider = %BgmSlider
@onready var bgm_value: Label = %BgmValue
@onready var sfx_slider: HSlider = %SfxSlider
@onready var sfx_value: Label = %SfxValue
@onready var mode_option: OptionButton = %ModeOption
@onready var resolution_option: OptionButton = %ResolutionOption
@onready var vsync_check: CheckButton = %VsyncCheck
@onready var back_button: Button = %BackButton

var _syncing := false   # 同步界面时不触发保存


func _ready() -> void:
	visible = false
	for mode_name in SettingsManager.WINDOW_MODE_NAMES:
		mode_option.add_item(mode_name)
	for resolution in SettingsManager.RESOLUTIONS:
		resolution_option.add_item("%d × %d" % [resolution.x, resolution.y])
	master_slider.value_changed.connect(_on_volume_changed.bind(SettingsManager.BUS_MASTER, master_value))
	bgm_slider.value_changed.connect(_on_volume_changed.bind(SettingsManager.BUS_BGM, bgm_value))
	sfx_slider.value_changed.connect(_on_volume_changed.bind(SettingsManager.BUS_SFX, sfx_value))
	mode_option.item_selected.connect(_on_mode_selected)
	resolution_option.item_selected.connect(_on_resolution_selected)
	vsync_check.toggled.connect(_on_vsync_toggled)
	back_button.pressed.connect(close)


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		close()


func open() -> void:
	_syncing = true
	master_slider.value = SettingsManager.master_volume * 100.0
	bgm_slider.value = SettingsManager.bgm_volume * 100.0
	sfx_slider.value = SettingsManager.sfx_volume * 100.0
	master_value.text = "%d" % int(master_slider.value)
	bgm_value.text = "%d" % int(bgm_slider.value)
	sfx_value.text = "%d" % int(sfx_slider.value)
	mode_option.select(SettingsManager.window_mode)
	resolution_option.select(SettingsManager.resolution_index)
	resolution_option.disabled = SettingsManager.window_mode != 0
	vsync_check.button_pressed = SettingsManager.vsync_enabled
	_syncing = false
	visible = true
	back_button.grab_focus()


func close() -> void:
	visible = false
	closed.emit()


func _on_volume_changed(value: float, bus_name: String, value_label: Label) -> void:
	value_label.text = "%d" % int(value)
	if not _syncing:
		SettingsManager.set_volume(bus_name, value / 100.0)


func _on_mode_selected(index: int) -> void:
	resolution_option.disabled = index != 0
	if not _syncing:
		SettingsManager.set_window_mode(index)


func _on_resolution_selected(index: int) -> void:
	if not _syncing:
		SettingsManager.set_resolution(index)


func _on_vsync_toggled(enabled: bool) -> void:
	if not _syncing:
		SettingsManager.set_vsync(enabled)
