## ============================================================
## 游戏结束界面
## 玩家死亡 1 秒后弹出并暂停游戏：复活（回到最近存档点，损失部分经验）/ 返回主菜单。
## ============================================================
extends CanvasLayer

const PANEL_NAME := "game_over"

@onready var revive_button: Button = %ReviveButton
@onready var menu_button: Button = %MenuButton
@onready var info_label: Label = %InfoLabel


func _ready() -> void:
	visible = false
	info_label.text = "复活后将回到最近的存档点，并损失 %d%% 当前经验" % roundi(GameDB.DEATH_EXP_PENALTY * 100.0)
	revive_button.pressed.connect(_on_revive_pressed)
	menu_button.pressed.connect(func() -> void: GameState.return_to_main_menu())
	EventBus.player_died.connect(_on_player_died)


func _on_player_died() -> void:
	# 使用连接而不是 await：场景切换释放本节点时连接会自动断开
	get_tree().create_timer(1.0, false).timeout.connect(_show)


func _show() -> void:
	visible = true
	get_tree().paused = true
	GameState.set_panel_open(PANEL_NAME, true)
	revive_button.grab_focus()


func _on_revive_pressed() -> void:
	visible = false
	get_tree().paused = false
	GameState.set_panel_open(PANEL_NAME, false)
	EventBus.player_respawn_requested.emit()
