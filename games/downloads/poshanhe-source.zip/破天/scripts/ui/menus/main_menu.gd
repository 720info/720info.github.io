## ============================================================
## 主菜单
## 开始游戏（有存档时二次确认覆盖）/ 继续游戏（显示存档摘要）/ 设置 / 退出游戏
## ============================================================
extends Control

@onready var start_button: Button = %StartButton
@onready var continue_button: Button = %ContinueButton
@onready var save_info: Label = %SaveInfo
@onready var settings_button: Button = %SettingsButton
@onready var quit_button: Button = %QuitButton
@onready var menu_box: Control = %MenuBox
@onready var settings_panel: SettingsPanel = %SettingsPanel
@onready var version_label: Label = %VersionLabel

var confirm_dialog: ConfirmationDialog


func _ready() -> void:
	EventBus.bgm_requested.emit("menu")
	version_label.text = "v%s" % ProjectSettings.get_setting("application/config/version", "1.0.0")
	var has_save := SaveManager.has_save()
	continue_button.disabled = not has_save
	save_info.text = SaveManager.get_save_summary()

	start_button.pressed.connect(_on_start_pressed)
	continue_button.pressed.connect(func() -> void: GameState.continue_game())
	settings_button.pressed.connect(_open_settings)
	quit_button.pressed.connect(func() -> void: GameState.quit_game())
	settings_panel.closed.connect(_on_settings_closed)

	confirm_dialog = ConfirmationDialog.new()
	confirm_dialog.title = "开始新游戏"
	confirm_dialog.dialog_text = "已有存档，开始新游戏将覆盖原存档。\n确定要重新开始吗？"
	confirm_dialog.ok_button_text = "确定"
	confirm_dialog.cancel_button_text = "取消"
	confirm_dialog.confirmed.connect(_start_new_game)
	add_child(confirm_dialog)

	(continue_button if has_save else start_button).grab_focus()


func _on_start_pressed() -> void:
	if SaveManager.has_save():
		confirm_dialog.popup_centered()
	else:
		_start_new_game()


func _start_new_game() -> void:
	SaveManager.delete_save()
	GameState.start_new_game()


func _open_settings() -> void:
	menu_box.visible = false
	settings_panel.open()


func _on_settings_closed() -> void:
	menu_box.visible = true
	settings_button.grab_focus()
