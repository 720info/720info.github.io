## ============================================================
## 暂停菜单（ESC）
## 暂停整个场景树（玩家、怪物、计时器全部停止），本界面 process_mode = ALWAYS。
## ESC 优先级：设置子面板 → 已打开的背包/加点面板 → 暂停/继续。
## ============================================================
extends CanvasLayer

const PANEL_NAME := "pause"

@onready var main_box: PanelContainer = %MainBox
@onready var resume_button: Button = %ResumeButton
@onready var settings_button: Button = %SettingsButton
@onready var achievement_button: Button = %AchievementButton
@onready var menu_button: Button = %MenuButton
@onready var quit_button: Button = %QuitButton
@onready var settings_panel: SettingsPanel = %SettingsPanel


func _ready() -> void:
	visible = false
	resume_button.pressed.connect(resume)
	settings_button.pressed.connect(_open_settings)
	achievement_button.pressed.connect(func() -> void:
		resume()
		EventBus.achievement_panel_requested.emit())
	menu_button.pressed.connect(func() -> void: GameState.return_to_main_menu())
	quit_button.pressed.connect(func() -> void: GameState.quit_game())
	settings_panel.closed.connect(_on_settings_closed)


func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("pause"):
		return
	get_viewport().set_input_as_handled()
	if visible:
		resume()
	elif GameState.is_panel_open("game_over"):
		return
	elif GameState.is_panel_open():
		EventBus.close_panels_requested.emit()   # 先关闭背包 / 加点面板
	else:
		pause()


func pause() -> void:
	visible = true
	main_box.visible = true
	get_tree().paused = true
	GameState.set_panel_open(PANEL_NAME, true)
	resume_button.grab_focus()


func resume() -> void:
	settings_panel.visible = false
	visible = false
	get_tree().paused = false
	GameState.set_panel_open(PANEL_NAME, false)


func _open_settings() -> void:
	main_box.visible = false
	settings_panel.open()


func _on_settings_closed() -> void:
	main_box.visible = true
	settings_button.grab_focus()
