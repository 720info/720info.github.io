## ============================================================
## 技能冷却遮罩：顺时针扫过的扇形暗色遮罩（冷却动画）
## 多边形直接投影到矩形边缘，无需裁剪。
## ============================================================
extends Control

@export var overlay_color: Color = Color(0, 0, 0, 0.62)

var ratio := 0.0   # 剩余冷却比例 0~1


func set_ratio(value: float) -> void:
	value = clampf(value, 0.0, 1.0)
	if is_equal_approx(value, ratio):
		return
	ratio = value
	queue_redraw()


func _draw() -> void:
	if ratio <= 0.0:
		return
	var center := size * 0.5
	var points := PackedVector2Array([center])
	var start := -PI * 0.5 + TAU * (1.0 - ratio)
	var end := -PI * 0.5 + TAU
	var steps := maxi(int(48 * ratio), 2)
	for i in steps + 1:
		var angle := lerpf(start, end, float(i) / steps)
		var direction := Vector2(cos(angle), sin(angle))
		# 射线与矩形边界求交
		var tx := center.x / absf(direction.x) if absf(direction.x) > 0.0001 else INF
		var ty := center.y / absf(direction.y) if absf(direction.y) > 0.0001 else INF
		points.append(center + direction * minf(tx, ty))
	draw_colored_polygon(points, overlay_color)
