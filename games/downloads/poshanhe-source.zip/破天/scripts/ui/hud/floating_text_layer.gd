## ============================================================
## 飘字层（世界坐标）
## 监听 EventBus.floating_text_requested，在指定位置生成上浮渐隐的文字：
## 伤害数字、暴击、拾取、升级、技能名、提示等。
## 性能：Label 节点循环复用（不反复创建销毁），同屏上限 MAX_TEXTS 条。
## ============================================================
extends Node2D

const LABEL_WIDTH := 240.0
const MAX_TEXTS := 48   # 同屏飘字上限，超出时复用最早的一条

var _idle: Array[Node2D] = []     # 空闲的飘字节点
var _active: Array[Node2D] = []   # 正在播放的飘字节点（按时间顺序）


func _ready() -> void:
	EventBus.floating_text_requested.connect(_on_floating_text_requested)


func _on_floating_text_requested(text: String, world_position: Vector2, color: Color, font_size: int) -> void:
	var holder := _take_holder()
	var label := holder.get_child(0) as Label
	label.text = text
	label.size = Vector2(LABEL_WIDTH, font_size + 10)
	label.position = Vector2(-LABEL_WIDTH * 0.5, -(font_size + 10) * 0.5)
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	holder.position = world_position + Vector2(randf_range(-6, 6), 0)
	holder.scale = Vector2(0.5, 0.5)
	holder.modulate.a = 1.0
	holder.visible = true

	var tween := holder.create_tween().set_parallel()
	holder.set_meta("tween", tween)
	tween.tween_property(holder, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(holder, "position:y", holder.position.y - 42.0, 0.9) \
		.set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	tween.tween_property(holder, "modulate:a", 0.0, 0.4).set_delay(0.5)
	tween.chain().tween_callback(_recycle.bind(holder))


func _take_holder() -> Node2D:
	var holder: Node2D
	if not _idle.is_empty():
		holder = _idle.pop_back()
	elif _active.size() >= MAX_TEXTS:
		holder = _active.pop_front()   # 达到上限：直接复用最早的一条
		var old_tween: Tween = holder.get_meta("tween", null)
		if old_tween and old_tween.is_valid():
			old_tween.kill()
	else:
		holder = _create_holder()
	_active.append(holder)
	return holder


func _create_holder() -> Node2D:
	var holder := Node2D.new()
	var label := Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	label.add_theme_constant_override("outline_size", 5)
	holder.add_child(label)
	add_child(holder)
	return holder


func _recycle(holder: Node2D) -> void:
	holder.visible = false
	_active.erase(holder)
	_idle.append(holder)
