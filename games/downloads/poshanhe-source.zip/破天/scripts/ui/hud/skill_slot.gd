## ============================================================
## 快捷栏格子（武功 / 轻功）
## 显示按键、名称、内力消耗；冷却时顺时针扇形遮罩 + 倒计时，
## 冷却结束闪一下；内力不足时图标变红。
## 美术替换：给 ArtIcon（TextureRect）设置图标贴图即可覆盖色块占位。
## ============================================================
class_name SkillSlot
extends Panel

@onready var icon: ColorRect = $Icon
@onready var art_icon: TextureRect = $ArtIcon
@onready var glyph_label: Label = $Glyph
@onready var key_label: Label = $KeyLabel
@onready var name_label: Label = $NameLabel
@onready var cost_label: Label = $CostLabel
@onready var cooldown_pie: Control = $CooldownPie
@onready var cooldown_label: Label = $CooldownLabel
@onready var ready_flash: ColorRect = $ReadyFlash

var base_color := Color.WHITE
var was_cooling := false


func setup(key_text: String, slot_name: String, glyph: String, color: Color, cost_text: String = "") -> void:
	key_label.text = key_text
	name_label.text = slot_name
	glyph_label.text = glyph
	base_color = color
	icon.color = color.darkened(0.5)
	glyph_label.add_theme_color_override("font_color", color.lightened(0.3))
	cost_label.text = cost_text
	art_icon.visible = art_icon.texture != null
	glyph_label.visible = art_icon.texture == null
	set_cooldown(0.0, 1.0)


func set_cooldown(remaining: float, total: float) -> void:
	var cooling := remaining > 0.0 and total > 0.0
	cooldown_pie.call("set_ratio", remaining / total if cooling else 0.0)
	if cooling:
		cooldown_label.text = ("%.1f" % remaining) if remaining < 10.0 else str(ceili(remaining))
	else:
		cooldown_label.text = ""
		if was_cooling:
			_flash_ready()
	was_cooling = cooling


## 内力不足时图标变红
func set_usable(usable: bool) -> void:
	var tint := Color.WHITE if usable else Color(1.0, 0.35, 0.35)
	glyph_label.modulate = tint
	art_icon.modulate = tint


## 释放技能时高亮
func pulse() -> void:
	icon.color = base_color
	create_tween().tween_property(icon, "color", base_color.darkened(0.5), 0.35)


func _flash_ready() -> void:
	ready_flash.color.a = 0.7
	create_tween().tween_property(ready_flash, "color:a", 0.0, 0.3)
