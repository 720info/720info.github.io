## ============================================================
## 主界面 HUD（仿《破天一剑》布局，全部使用锚点适配分辨率）
##   左上：头像 + 等级 + 生命/内力/体力条（带掉血残影）+ 可加点提示
##   右上：击杀计数（总数 + 分类）
##   底部：4 格武功 + 轻功（扇形冷却动画）、底边经验条、按键提示
##   其他：中上方提示条、交互提示、低血量红色警示
## 只监听 EventBus 信号，不引用玩家节点。
## ============================================================
extends CanvasLayer

@onready var hp_bar: StatBar = %HpBar
@onready var mp_bar: StatBar = %MpBar
@onready var stamina_bar: StatBar = %StaminaBar
@onready var exp_bar: StatBar = %ExpBar
@onready var exp_label: Label = %ExpLabel
@onready var level_label: Label = %LevelLabel
@onready var points_badge: Label = %PointsBadge
@onready var kill_label: Label = %KillLabel
@onready var kill_detail: Label = %KillDetail
@onready var toast_label: Label = %Toast
@onready var prompt_panel: PanelContainer = %PromptPanel
@onready var prompt_label: Label = %PromptLabel
@onready var low_hp_vignette: ColorRect = %LowHpVignette
@onready var skill_slots: Array[SkillSlot] = [%Skill1, %Skill2, %Skill3, %Skill4, %DashSlot]
@onready var cheat_label: Label = %CheatLabel

var hp_ratio := 1.0
var vignette_time := 0.0
var toast_tween: Tween


var _cheat_panel: Window = null

func _ready() -> void:
	for i in GameDB.SKILLS.size():
		var data: Dictionary = GameDB.SKILLS[i]
		skill_slots[i].setup(str(i + 1), data["name"], data["glyph"], data["color"], "%d" % int(data["mp_cost"]))
	skill_slots[4].setup("空格", "轻功", "轻", Color(0.75, 0.9, 0.95))
	toast_label.modulate.a = 0.0
	prompt_panel.visible = false
	points_badge.visible = false
	cheat_label.visible = GameState.is_cheated

	EventBus.player_hp_changed.connect(_on_hp_changed)
	EventBus.player_mp_changed.connect(_on_mp_changed)
	EventBus.player_stamina_changed.connect(func(c: float, m: float) -> void: stamina_bar.set_values(c, m))
	EventBus.player_exp_changed.connect(_on_exp_changed)
	EventBus.player_stats_changed.connect(_on_stats_changed)
	EventBus.skill_cooldowns_updated.connect(_on_cooldowns_updated)
	EventBus.skill_cast.connect(func(index: int) -> void: skill_slots[index].pulse())
	EventBus.kill_count_changed.connect(_on_kill_count_changed)
	EventBus.toast_requested.connect(_show_toast)
	EventBus.interact_prompt_changed.connect(_on_interact_prompt_changed)
	GameState.cheat_status_changed.connect(_on_cheat_status_changed)
	_on_kill_count_changed(GameState.kill_total, GameState.kills_by_type)


func _unhandled_input(event: InputEvent) -> void:
	if not GameState.in_game:
		return
	if event.is_action_pressed("cheat_panel"):
		if GameState.is_panel_open("cheat"):
			_close_cheat_panel()
		elif not GameState.is_panel_open():
			_open_cheat_panel()


func _on_cheat_status_changed(_is_cheated: bool) -> void:
	cheat_label.visible = _is_cheated
	if _is_cheated:
		_show_toast("警告：此存档已被标记为作弊存档")


func _open_cheat_panel() -> void:
	if _cheat_panel != null:
		return
	GameState.set_panel_open("cheat", true)
	get_tree().paused = true

	_cheat_panel = Window.new()
	_cheat_panel.title = "开发者调试面板"
	_cheat_panel.unresizable = true
	_cheat_panel.size = Vector2i(520, 560)
	_cheat_panel.position = Vector2i(
		int(get_viewport().get_visible_rect().size.x / 2.0 - 260),
		int(get_viewport().get_visible_rect().size.y / 2.0 - 280)
	)
	_cheat_panel.close_requested.connect(_close_cheat_panel)

	var root := MarginContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("margin_left", 20)
	root.add_theme_constant_override("margin_right", 20)
	root.add_theme_constant_override("margin_top", 16)
	root.add_theme_constant_override("margin_bottom", 16)
	_cheat_panel.add_child(root)

	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.follow_focus = true
	root.add_child(scroll)

	var vbox := VBoxContainer.new()
	vbox.custom_minimum_size = Vector2(440, 0)
	vbox.add_theme_constant_override("separation", 14)
	scroll.add_child(vbox)

	var warn_title := Label.new()
	warn_title.text = "⚠ 道德伦理警告 ⚠"
	warn_title.add_theme_color_override("font_color", Color(1.0, 0.4, 0.4))
	warn_title.add_theme_font_size_override("font_size", 22)
	warn_title.add_theme_constant_override("outline_size", 4)
	warn_title.add_theme_color_override("font_outline_color", Color.BLACK)
	warn_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(warn_title)

	var warn_box := PanelContainer.new()
	var warn_style := StyleBoxFlat.new()
	warn_style.bg_color = Color(0.15, 0.08, 0.08, 0.9)
	warn_style.border_color = Color(1.0, 0.3, 0.3, 0.8)
	warn_style.set_border_width_all(2)
	warn_style.corner_radius_top_left = 10
	warn_style.corner_radius_top_right = 10
	warn_style.corner_radius_bottom_right = 10
	warn_style.corner_radius_bottom_left = 10
	warn_style.content_margin_left = 12.0
	warn_style.content_margin_right = 12.0
	warn_style.content_margin_top = 10.0
	warn_style.content_margin_bottom = 10.0
	warn_box.add_theme_stylebox_override("panel", warn_style)
	vbox.add_child(warn_box)

	var warn_vbox := VBoxContainer.new()
	warn_vbox.add_theme_constant_override("separation", 6)
	warn_box.add_child(warn_vbox)

	var warn_lines := [
		"此按钮仅供开发测试使用，使用后：",
		"  • 当前存档将被永久打上「作弊」标签",
		"  • 游戏左上角会一直显示红色「作弊」字样",
		"  • 作弊存档无法参与正式成就排名",
		"使用作弊功能不符合游戏道德伦理，请谨慎！",
	]
	for line in warn_lines:
		var lbl := Label.new()
		lbl.text = line
		lbl.add_theme_color_override("font_color", Color(1.0, 0.85, 0.7))
		lbl.add_theme_font_size_override("font_size", 14)
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		warn_vbox.add_child(lbl)

	var sep1 := HSeparator.new()
	vbox.add_child(sep1)

	var attack_label := Label.new()
	attack_label.text = "攻击力倍率（当前 ×%.1f）" % GameState.cheat_attack_multiplier
	attack_label.add_theme_color_override("font_color", Color(0.95, 0.9, 0.75))
	attack_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(attack_label)

	var attack_hbox := HBoxContainer.new()
	attack_hbox.add_theme_constant_override("separation", 8)
	vbox.add_child(attack_hbox)

	var attack_slider := HSlider.new()
	attack_slider.min_value = 1.0
	attack_slider.max_value = 20.0
	attack_slider.step = 0.5
	attack_slider.value = GameState.cheat_attack_multiplier
	attack_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	attack_hbox.add_child(attack_slider)

	var attack_val := Label.new()
	attack_val.text = "×%.1f" % attack_slider.value
	attack_val.custom_minimum_size = Vector2(60, 0)
	attack_val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	attack_val.add_theme_color_override("font_color", Color(1.0, 0.85, 0.4))
	attack_val.add_theme_font_size_override("font_size", 16)
	attack_hbox.add_child(attack_val)

	attack_slider.value_changed.connect(func(v: float) -> void:
		attack_val.text = "×%.1f" % v
		attack_label.text = "攻击力倍率（当前 ×%.1f）" % v
	)

	var apply_attack_btn := Button.new()
	apply_attack_btn.text = "应用攻击力倍率（打作弊标签）"
	apply_attack_btn.add_theme_font_size_override("font_size", 15)
	apply_attack_btn.pressed.connect(func() -> void:
		GameState.set_cheat_attack_multiplier(attack_slider.value)
		attack_label.text = "攻击力倍率（当前 ×%.1f）" % GameState.cheat_attack_multiplier
		_show_toast("攻击力已设为 ×%.1f，存档已标记作弊" % GameState.cheat_attack_multiplier)
	)
	vbox.add_child(apply_attack_btn)

	var sep2 := HSeparator.new()
	vbox.add_child(sep2)

	var survival_label := Label.new()
	survival_label.text = "生存作弊"
	survival_label.add_theme_color_override("font_color", Color(0.95, 0.9, 0.75))
	survival_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(survival_label)

	var survival_hint := Label.new()
	survival_hint.text = "开启后会立刻回满；关闭后恢复正常。只要使用过，存档仍保留作弊标记。"
	survival_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	survival_hint.add_theme_color_override("font_color", Color(0.82, 0.82, 0.86))
	survival_hint.add_theme_font_size_override("font_size", 13)
	vbox.add_child(survival_hint)

	var survival_hbox := HBoxContainer.new()
	survival_hbox.add_theme_constant_override("separation", 12)
	vbox.add_child(survival_hbox)

	var infinite_hp_toggle := CheckButton.new()
	infinite_hp_toggle.text = "无限生命"
	infinite_hp_toggle.button_pressed = GameState.cheat_infinite_hp
	infinite_hp_toggle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	infinite_hp_toggle.toggled.connect(func(enabled: bool) -> void:
		GameState.set_cheat_infinite_hp(enabled)
		_show_toast("无限生命已%s" % ("开启" if enabled else "关闭"))
	)
	survival_hbox.add_child(infinite_hp_toggle)

	var infinite_stamina_toggle := CheckButton.new()
	infinite_stamina_toggle.text = "无限体力"
	infinite_stamina_toggle.button_pressed = GameState.cheat_infinite_stamina
	infinite_stamina_toggle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	infinite_stamina_toggle.toggled.connect(func(enabled: bool) -> void:
		GameState.set_cheat_infinite_stamina(enabled)
		_show_toast("无限体力已%s" % ("开启" if enabled else "关闭"))
	)
	survival_hbox.add_child(infinite_stamina_toggle)

	var infinite_mp_toggle := CheckButton.new()
	infinite_mp_toggle.text = "无限内力"
	infinite_mp_toggle.button_pressed = GameState.cheat_infinite_mp
	infinite_mp_toggle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	infinite_mp_toggle.toggled.connect(func(enabled: bool) -> void:
		GameState.set_cheat_infinite_mp(enabled)
		_show_toast("无限内力已%s" % ("开启" if enabled else "关闭"))
	)
	survival_hbox.add_child(infinite_mp_toggle)

	var combat_hbox := HBoxContainer.new()
	combat_hbox.add_theme_constant_override("separation", 12)
	vbox.add_child(combat_hbox)

	var no_cooldown_toggle := CheckButton.new()
	no_cooldown_toggle.text = "技能无冷却"
	no_cooldown_toggle.button_pressed = GameState.cheat_no_cooldown
	no_cooldown_toggle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	no_cooldown_toggle.toggled.connect(func(enabled: bool) -> void:
		GameState.set_cheat_no_cooldown(enabled)
		_show_toast("技能无冷却已%s" % ("开启" if enabled else "关闭"))
	)
	combat_hbox.add_child(no_cooldown_toggle)

	var sep3 := HSeparator.new()
	vbox.add_child(sep3)

	var speed_label := Label.new()
	speed_label.text = "速度作弊"
	speed_label.add_theme_color_override("font_color", Color(0.95, 0.9, 0.75))
	speed_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(speed_label)

	var speed_hint := Label.new()
	speed_hint.text = "移动速度作用于玩家，游戏速度作用于全局流程；顿帧结束和切场景后会自动恢复到当前设定。"
	speed_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	speed_hint.add_theme_color_override("font_color", Color(0.82, 0.82, 0.86))
	speed_hint.add_theme_font_size_override("font_size", 13)
	vbox.add_child(speed_hint)

	var move_speed_label := Label.new()
	move_speed_label.text = "移动速度倍率（当前 ×%.1f）" % GameState.cheat_speed_multiplier
	move_speed_label.add_theme_color_override("font_color", Color(0.8, 0.92, 1.0))
	move_speed_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(move_speed_label)

	var move_speed_hbox := HBoxContainer.new()
	move_speed_hbox.add_theme_constant_override("separation", 8)
	vbox.add_child(move_speed_hbox)

	var move_speed_slider := HSlider.new()
	move_speed_slider.min_value = 1.0
	move_speed_slider.max_value = 3.0
	move_speed_slider.step = 0.1
	move_speed_slider.value = GameState.cheat_speed_multiplier
	move_speed_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	move_speed_hbox.add_child(move_speed_slider)

	var move_speed_val := Label.new()
	move_speed_val.text = "×%.1f" % move_speed_slider.value
	move_speed_val.custom_minimum_size = Vector2(60, 0)
	move_speed_val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	move_speed_val.add_theme_color_override("font_color", Color(1.0, 0.85, 0.4))
	move_speed_val.add_theme_font_size_override("font_size", 16)
	move_speed_hbox.add_child(move_speed_val)

	move_speed_slider.value_changed.connect(func(v: float) -> void:
		move_speed_val.text = "×%.1f" % v
		move_speed_label.text = "移动速度倍率（设为 ×%.1f）" % v
	)

	var apply_move_speed_btn := Button.new()
	apply_move_speed_btn.text = "应用移动速度倍率"
	apply_move_speed_btn.add_theme_font_size_override("font_size", 15)
	apply_move_speed_btn.pressed.connect(func() -> void:
		GameState.set_cheat_speed_multiplier(move_speed_slider.value)
		move_speed_slider.value = GameState.cheat_speed_multiplier
		move_speed_label.text = "移动速度倍率（当前 ×%.1f）" % GameState.cheat_speed_multiplier
		_show_toast("移动速度已设为 ×%.1f" % GameState.cheat_speed_multiplier)
	)
	vbox.add_child(apply_move_speed_btn)

	var time_scale_label := Label.new()
	time_scale_label.text = "游戏速度（当前 ×%.1f）" % GameState.cheat_time_scale
	time_scale_label.add_theme_color_override("font_color", Color(0.8, 0.92, 1.0))
	time_scale_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(time_scale_label)

	var time_scale_hbox := HBoxContainer.new()
	time_scale_hbox.add_theme_constant_override("separation", 8)
	vbox.add_child(time_scale_hbox)

	var time_scale_slider := HSlider.new()
	time_scale_slider.min_value = 0.5
	time_scale_slider.max_value = 3.0
	time_scale_slider.step = 0.1
	time_scale_slider.value = GameState.cheat_time_scale
	time_scale_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	time_scale_hbox.add_child(time_scale_slider)

	var time_scale_val := Label.new()
	time_scale_val.text = "×%.1f" % time_scale_slider.value
	time_scale_val.custom_minimum_size = Vector2(60, 0)
	time_scale_val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	time_scale_val.add_theme_color_override("font_color", Color(1.0, 0.85, 0.4))
	time_scale_val.add_theme_font_size_override("font_size", 16)
	time_scale_hbox.add_child(time_scale_val)

	time_scale_slider.value_changed.connect(func(v: float) -> void:
		time_scale_val.text = "×%.1f" % v
		time_scale_label.text = "游戏速度（设为 ×%.1f）" % v
	)

	var apply_time_scale_btn := Button.new()
	apply_time_scale_btn.text = "应用游戏速度"
	apply_time_scale_btn.add_theme_font_size_override("font_size", 15)
	apply_time_scale_btn.pressed.connect(func() -> void:
		GameState.set_cheat_time_scale(time_scale_slider.value)
		time_scale_slider.value = GameState.cheat_time_scale
		time_scale_label.text = "游戏速度（当前 ×%.1f）" % GameState.cheat_time_scale
		_show_toast("游戏速度已设为 ×%.1f" % GameState.cheat_time_scale)
	)
	vbox.add_child(apply_time_scale_btn)

	var sep4 := HSeparator.new()
	vbox.add_child(sep4)

	var growth_label := Label.new()
	growth_label.text = "成长作弊"
	growth_label.add_theme_color_override("font_color", Color(0.95, 0.9, 0.75))
	growth_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(growth_label)

	var growth_hint := Label.new()
	growth_hint.text = "经验会立刻结算升级和属性点，适合快速验证升级、加点和自动存档链路。"
	growth_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	growth_hint.add_theme_color_override("font_color", Color(0.82, 0.82, 0.86))
	growth_hint.add_theme_font_size_override("font_size", 13)
	vbox.add_child(growth_hint)

	var growth_hbox := HBoxContainer.new()
	growth_hbox.add_theme_constant_override("separation", 8)
	vbox.add_child(growth_hbox)

	var exp_100_btn := Button.new()
	exp_100_btn.text = "+100 经验"
	exp_100_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	exp_100_btn.pressed.connect(func() -> void:
		GameState.cheat_add_exp(100)
		_show_toast("已增加 100 点经验")
	)
	growth_hbox.add_child(exp_100_btn)

	var exp_1000_btn := Button.new()
	exp_1000_btn.text = "+1000 经验"
	exp_1000_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	exp_1000_btn.pressed.connect(func() -> void:
		GameState.cheat_add_exp(1000)
		_show_toast("已增加 1000 点经验")
	)
	growth_hbox.add_child(exp_1000_btn)

	var level_up_btn := Button.new()
	level_up_btn.text = "直接升 1 级"
	level_up_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	level_up_btn.pressed.connect(func() -> void:
		GameState.cheat_level_up()
		_show_toast("已直接提升 1 级")
	)
	growth_hbox.add_child(level_up_btn)

	var sep5 := HSeparator.new()
	vbox.add_child(sep5)

	var item_label := Label.new()
	item_label.text = "物品作弊"
	item_label.add_theme_color_override("font_color", Color(0.95, 0.9, 0.75))
	item_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(item_label)

	var item_hint := Label.new()
	item_hint.text = "礼包会按背包剩余空间发放，背包满时只会放入能塞下的部分。"
	item_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	item_hint.add_theme_color_override("font_color", Color(0.82, 0.82, 0.86))
	item_hint.add_theme_font_size_override("font_size", 13)
	vbox.add_child(item_hint)

	var item_hbox := HBoxContainer.new()
	item_hbox.add_theme_constant_override("separation", 8)
	vbox.add_child(item_hbox)

	var gift_pack_btn := Button.new()
	gift_pack_btn.text = "药品大礼包"
	gift_pack_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gift_pack_btn.pressed.connect(func() -> void:
		var hp_added := GameState.cheat_give_item("hp_potion", 10)
		var mp_added := GameState.cheat_give_item("mp_potion", 10)
		var big_added := GameState.cheat_give_item("big_potion", 5)
		var total_added := hp_added + mp_added + big_added
		if total_added <= 0:
			_show_toast("背包已满，药品礼包未放入")
			return
		_show_toast("已发放药品礼包：金创药 ×%d / 内力丹 ×%d / 大还丹 ×%d" % [hp_added, mp_added, big_added])
	)
	item_hbox.add_child(gift_pack_btn)

	var potian_sword_btn := Button.new()
	potian_sword_btn.text = "获得破天剑"
	potian_sword_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	potian_sword_btn.pressed.connect(func() -> void:
		var added := GameState.cheat_give_item("potian_sword", 1)
		if added > 0:
			_show_toast("神兵「破天剑」已入包")
		else:
			_show_toast("背包已满，破天剑未放入")
	)
	item_hbox.add_child(potian_sword_btn)

	var sep6 := HSeparator.new()
	vbox.add_child(sep6)

	var progress_label := Label.new()
	progress_label.text = "进程作弊"
	progress_label.add_theme_color_override("font_color", Color(0.95, 0.9, 0.75))
	progress_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(progress_label)

	var progress_hint := Label.new()
	progress_hint.text = "秒杀全屏敌人会按正常逻辑结算掉落、经验和击杀；设置总击杀时，差额也会同步计入当前地图进度。"
	progress_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	progress_hint.add_theme_color_override("font_color", Color(0.82, 0.82, 0.86))
	progress_hint.add_theme_font_size_override("font_size", 13)
	vbox.add_child(progress_hint)

	var kill_total_label := Label.new()
	kill_total_label.add_theme_color_override("font_color", Color(0.8, 0.92, 1.0))
	kill_total_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(kill_total_label)

	var map_kill_label := Label.new()
	map_kill_label.add_theme_color_override("font_color", Color(0.8, 0.92, 1.0))
	map_kill_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(map_kill_label)

	var refresh_progress_labels := func() -> void:
		var map_data := MapDB.get_map(GameState.current_map)
		kill_total_label.text = "击杀总数（当前 %d）" % GameState.kill_total
		map_kill_label.text = "当前地图：第 %d 图 %s · 击杀 %d / %d" % [
			GameState.current_map,
			MapDB.map_name(GameState.current_map),
			GameState.map_kill_count,
			int(map_data.get("kill_goal", 0)),
		]

	refresh_progress_labels.call()

	var kill_hbox := HBoxContainer.new()
	kill_hbox.add_theme_constant_override("separation", 8)
	vbox.add_child(kill_hbox)

	var kill_spin := SpinBox.new()
	kill_spin.min_value = 0
	kill_spin.max_value = 999999
	kill_spin.step = 1
	kill_spin.value = GameState.kill_total
	kill_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	kill_hbox.add_child(kill_spin)

	var add_100_btn := Button.new()
	add_100_btn.text = "+100"
	add_100_btn.pressed.connect(func() -> void:
		kill_spin.value = int(kill_spin.value) + 100
		kill_total_label.text = "击杀总数（设为 %d）" % int(kill_spin.value)
	)
	kill_hbox.add_child(add_100_btn)

	var add_1000_btn := Button.new()
	add_1000_btn.text = "+1000"
	add_1000_btn.pressed.connect(func() -> void:
		kill_spin.value = int(kill_spin.value) + 1000
		kill_total_label.text = "击杀总数（设为 %d）" % int(kill_spin.value)
	)
	kill_hbox.add_child(add_1000_btn)

	kill_spin.value_changed.connect(func(v: float) -> void:
		kill_total_label.text = "击杀总数（设为 %d）" % int(v)
	)

	var apply_kill_btn := Button.new()
	apply_kill_btn.text = "设置击杀数（打作弊标签）"
	apply_kill_btn.add_theme_font_size_override("font_size", 15)
	apply_kill_btn.pressed.connect(func() -> void:
		GameState.cheat_set_kill_total(int(kill_spin.value))
		kill_spin.value = GameState.kill_total
		refresh_progress_labels.call()
		_show_toast("击杀总数已设为 %d，本图击杀同步为 %d" % [GameState.kill_total, GameState.map_kill_count])
	)
	vbox.add_child(apply_kill_btn)

	var action_row_1 := HBoxContainer.new()
	action_row_1.add_theme_constant_override("separation", 8)
	vbox.add_child(action_row_1)

	var kill_all_btn := Button.new()
	kill_all_btn.text = "秒杀全屏敌人"
	kill_all_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	kill_all_btn.pressed.connect(func() -> void:
		var count := GameState.cheat_kill_all_enemies()
		refresh_progress_labels.call()
		kill_spin.value = GameState.kill_total
		if count > 0:
			_show_toast("已清除 %d 个敌人" % count)
		else:
			_show_toast("当前场景没有可秒杀的敌人")
	)
	action_row_1.add_child(kill_all_btn)

	var fill_map_btn := Button.new()
	fill_map_btn.text = "本图击杀一键达标"
	fill_map_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fill_map_btn.pressed.connect(func() -> void:
		GameState.cheat_fill_map_kills()
		refresh_progress_labels.call()
		kill_spin.value = GameState.kill_total
		_show_toast("当前地图击杀已补到通关要求")
	)
	action_row_1.add_child(fill_map_btn)

	var action_row_2 := HBoxContainer.new()
	action_row_2.add_theme_constant_override("separation", 8)
	vbox.add_child(action_row_2)

	var restore_btn := Button.new()
	restore_btn.text = "状态全满 / 原地复活"
	restore_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	restore_btn.pressed.connect(func() -> void:
		_show_toast(GameState.cheat_restore_or_revive())
	)
	action_row_2.add_child(restore_btn)

	var map_jump_box := HBoxContainer.new()
	map_jump_box.add_theme_constant_override("separation", 8)
	vbox.add_child(map_jump_box)

	var map_select := OptionButton.new()
	map_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for i in MapDB.MAP_COUNT:
		var map_index := i + 1
		map_select.add_item("第 %d 图：%s" % [map_index, MapDB.map_name(map_index)], map_index)
	map_select.select(GameState.current_map - 1)
	map_jump_box.add_child(map_select)

	var jump_btn := Button.new()
	jump_btn.text = "跳转到选中地图"
	jump_btn.pressed.connect(func() -> void:
		var selected_idx := map_select.selected
		var target_map: int = selected_idx + 1
		var sid = map_select.get_selected_id()
		if sid is int and int(sid) >= 1 and int(sid) <= MapDB.MAP_COUNT:
			target_map = int(sid)
		target_map = clampi(target_map, 1, MapDB.MAP_COUNT)
		_show_toast("正在跳转到第 %d 图：%s" % [target_map, MapDB.map_name(target_map)])
		_close_cheat_panel()
		call_deferred("_deferred_jump_map", target_map)
	)
	map_jump_box.add_child(jump_btn)

	var sep7 := HSeparator.new()
	vbox.add_child(sep7)

	var btn_hbox := HBoxContainer.new()
	btn_hbox.add_theme_constant_override("separation", 10)
	vbox.add_child(btn_hbox)

	var close_btn := Button.new()
	close_btn.text = "关闭 [P / ESC]"
	close_btn.add_theme_font_size_override("font_size", 16)
	close_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	close_btn.pressed.connect(_close_cheat_panel)
	btn_hbox.add_child(close_btn)

	add_child(_cheat_panel)
	_cheat_panel.grab_focus()


func _close_cheat_panel() -> void:
	if _cheat_panel != null:
		_cheat_panel.queue_free()
		_cheat_panel = null
	GameState.set_panel_open("cheat", false)
	get_tree().paused = false


func _deferred_jump_map(target_map: int) -> void:
	GameState.cheat_jump_to_map(clampi(target_map, 1, MapDB.MAP_COUNT))


func _process(delta: float) -> void:
	# 低血量（<30%）时屏幕边缘红色呼吸警示
	if hp_ratio < 0.3 and hp_ratio > 0.0:
		vignette_time += delta * 4.0
		low_hp_vignette.color.a = 0.08 + (sin(vignette_time) * 0.5 + 0.5) * 0.14
	else:
		low_hp_vignette.color.a = move_toward(low_hp_vignette.color.a, 0.0, delta)


func _on_hp_changed(current: float, maximum: float) -> void:
	hp_bar.set_values(current, maximum)
	hp_ratio = current / maxf(maximum, 1.0)


func _on_mp_changed(current: float, maximum: float) -> void:
	mp_bar.set_values(current, maximum)
	for i in GameDB.SKILLS.size():
		skill_slots[i].set_usable(current >= float(GameDB.SKILLS[i]["mp_cost"]))


func _on_exp_changed(level: int, current_exp: int, need_exp: int) -> void:
	level_label.text = "Lv.%d" % level
	exp_bar.set_values(current_exp, need_exp)
	exp_label.text = "经验 %d / %d" % [current_exp, need_exp]


func _on_stats_changed(stats: Dictionary) -> void:
	var points := int(stats.get("unspent_points", 0))
	points_badge.visible = points > 0
	points_badge.text = "可加点 %d [C]" % points


func _on_cooldowns_updated(remaining: Array, totals: Array) -> void:
	for i in mini(remaining.size(), skill_slots.size()):
		skill_slots[i].set_cooldown(remaining[i], totals[i])


func _on_kill_count_changed(total: int, by_type: Dictionary) -> void:
	kill_label.text = str(total)
	var parts: PackedStringArray = []
	for enemy_type in by_type:
		parts.append("%s %d" % [enemy_type, by_type[enemy_type]])
	kill_detail.text = " · ".join(parts) if not parts.is_empty() else "尚未击杀"


func _on_interact_prompt_changed(text: String) -> void:
	prompt_panel.visible = not text.is_empty()
	prompt_label.text = text


func _show_toast(text: String) -> void:
	if toast_tween and toast_tween.is_valid():
		toast_tween.kill()
	toast_label.text = text
	toast_label.modulate.a = 1.0
	toast_tween = create_tween()
	toast_tween.tween_interval(1.8)
	toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.5)
