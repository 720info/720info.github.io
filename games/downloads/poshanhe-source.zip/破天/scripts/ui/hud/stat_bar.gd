## ============================================================
## 状态条（生命 / 内力 / 体力 / 经验通用）
## 数值下降时，白色「残影条」延迟后缓慢追上，表现掉血量；上方带高光。
## 尺寸完全由父容器决定，适配任意分辨率。
## ============================================================
class_name StatBar
extends Control

@export var fill_color: Color = Color(0.78, 0.15, 0.13)
@export var show_value: bool = true
@export var value_font_size: int = 12

@onready var trail: ColorRect = $Trail
@onready var fill: ColorRect = $Fill
@onready var shine: ColorRect = $Fill/Shine
@onready var value_label: Label = $ValueLabel

var ratio := 1.0
var trail_ratio := 1.0
var trail_delay := 0.0


func _ready() -> void:
	fill.color = fill_color
	value_label.visible = show_value
	value_label.add_theme_font_size_override("font_size", value_font_size)
	resized.connect(_layout)
	_layout()
	set_process(false)   # 只有残影条需要追赶时才开启逐帧更新


func set_values(current: float, maximum: float) -> void:
	var new_ratio := clampf(current / maxf(maximum, 0.001), 0.0, 1.0)
	if new_ratio < ratio - 0.001:
		trail_delay = 0.35
		set_process(true)
	elif new_ratio > trail_ratio:
		trail_ratio = new_ratio
	ratio = new_ratio
	value_label.text = "%d / %d" % [ceili(current), int(maximum)]
	_layout()


func _process(delta: float) -> void:
	if trail_ratio <= ratio:
		set_process(false)
		return
	if trail_delay > 0.0:
		trail_delay -= delta
		return
	trail_ratio = move_toward(trail_ratio, ratio, delta * 0.9)
	_layout()


func _layout() -> void:
	if fill == null:
		return
	var inner := size - Vector2(4, 4)
	fill.position = Vector2(2, 2)
	fill.size = Vector2(maxf(inner.x * ratio, 0.0), maxf(inner.y, 0.0))
	trail.position = Vector2(2, 2)
	trail.size = Vector2(maxf(inner.x * trail_ratio, 0.0), maxf(inner.y, 0.0))
	shine.size = Vector2(fill.size.x, fill.size.y * 0.4)
