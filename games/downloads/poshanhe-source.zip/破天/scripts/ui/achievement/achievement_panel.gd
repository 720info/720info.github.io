## ============================================================
## 成就面板（H 键开关）
## 列表在 _ready() 按 AchievementDB.ACHIEVEMENTS 生成一次；
## 已达成/进度只在面板打开时随相关信号刷新，关闭时不消耗性能。
## ============================================================
extends CanvasLayer

const PANEL_NAME := "achievements"
const LOCKED_COLOR := Color(0.75, 0.72, 0.65, 1)
const UNLOCKED_COLOR := Color(1, 0.85, 0.3, 1)

@onready var summary_label: Label = %SummaryLabel
@onready var list_box: VBoxContainer = %ListBox
@onready var close_button: Button = %CloseButton

var _status_labels: Dictionary = {}   # id -> Label


func _ready() -> void:
	visible = false
	close_button.pressed.connect(close)
	_build_rows()
	EventBus.achievement_unlocked.connect(func(_id: String) -> void: _refresh())
	EventBus.kill_count_changed.connect(func(_t, _b) -> void: _refresh())
	EventBus.player_exp_changed.connect(func(_l, _c, _n) -> void: _refresh())
	EventBus.close_panels_requested.connect(close)
	EventBus.player_died.connect(close)
	EventBus.achievement_panel_requested.connect(open)
	_refresh()


func _process(_delta: float) -> void:
	if visible:
		_refresh()   # 面板打开时才刷新，覆盖时长类成就的实时进度


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("achievements"):
		get_viewport().set_input_as_handled()
		if visible:
			close()
		else:
			open()


func open() -> void:
	visible = true
	GameState.set_panel_open(PANEL_NAME, true)
	_refresh()


func close() -> void:
	visible = false
	GameState.set_panel_open(PANEL_NAME, false)


func _build_rows() -> void:
	for entry in AchievementDB.ACHIEVEMENTS:
		var row := PanelContainer.new()
		var style := StyleBoxFlat.new()
		style.bg_color = Color(0.1, 0.11, 0.1, 0.55)
		style.content_margin_left = 10.0
		style.content_margin_right = 10.0
		style.content_margin_top = 6.0
		style.content_margin_bottom = 6.0
		style.corner_radius_top_left = 8
		style.corner_radius_top_right = 8
		style.corner_radius_bottom_left = 8
		style.corner_radius_bottom_right = 8
		row.add_theme_stylebox_override("panel", style)

		var hbox := HBoxContainer.new()
		hbox.add_theme_constant_override("separation", 10)
		row.add_child(hbox)

		var glyph := Label.new()
		glyph.text = str(entry.get("glyph", "成"))
		glyph.custom_minimum_size = Vector2(30, 0)
		glyph.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		glyph.add_theme_font_size_override("font_size", 20)
		glyph.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5, 1))
		hbox.add_child(glyph)

		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		info.add_theme_constant_override("separation", 0)
		hbox.add_child(info)

		var name_label := Label.new()
		name_label.text = str(entry.get("name", ""))
		name_label.add_theme_font_size_override("font_size", 16)
		info.add_child(name_label)

		var desc_label := Label.new()
		desc_label.text = str(entry.get("desc", ""))
		desc_label.add_theme_font_size_override("font_size", 12)
		desc_label.add_theme_color_override("font_color", Color(0.72, 0.7, 0.65, 1))
		info.add_child(desc_label)

		var status_label := Label.new()
		status_label.custom_minimum_size = Vector2(90, 0)
		status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		status_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		status_label.add_theme_font_size_override("font_size", 14)
		hbox.add_child(status_label)

		list_box.add_child(row)
		_status_labels[entry["id"]] = status_label


func _refresh() -> void:
	var unlocked_count := 0
	for entry in AchievementDB.ACHIEVEMENTS:
		var id: String = entry["id"]
		var label: Label = _status_labels[id]
		if AchievementManager.is_unlocked(id):
			unlocked_count += 1
			label.text = "已达成"
			label.add_theme_color_override("font_color", UNLOCKED_COLOR)
		else:
			label.text = _progress_text(entry)
			label.add_theme_color_override("font_color", LOCKED_COLOR)
	summary_label.text = "已达成 %d / %d" % [unlocked_count, AchievementDB.ACHIEVEMENTS.size()]


func _progress_text(entry: Dictionary) -> String:
	var current: Variant = AchievementManager.get_current_value(entry)
	if current == null:
		return "未达成"
	if str(entry.get("condition", "")) == "play_time":
		return "%d / %d 分钟" % [floori(float(current) / 60.0), floori(float(entry["target"]) / 60.0)]
	return "%s / %s" % [str(current), str(entry["target"])]
