## ============================================================
## 背包面板（B / I 键开关）
## 左侧：当前武器 + 角色属性；右侧：道具格子（点击使用药品 / 更换武器）；
## 底部：悬停道具说明。
## 数据来源：EventBus.inventory_changed / player_stats_changed；
## 操作请求：EventBus.item_use_requested。
## ============================================================
extends CanvasLayer

const PANEL_NAME := "inventory"

@export var item_slot_scene: PackedScene

@onready var grid: GridContainer = %Grid
@onready var weapon_slot: ItemSlot = %WeaponSlot
@onready var weapon_name: Label = %WeaponName
@onready var stats_label: Label = %StatsLabel
@onready var desc_label: Label = %DescLabel
@onready var close_button: Button = %CloseButton

var slot_nodes: Array[ItemSlot] = []
var items: Array = []


func _ready() -> void:
	visible = false
	weapon_slot.disabled = true
	close_button.pressed.connect(close)
	EventBus.inventory_changed.connect(_on_inventory_changed)
	EventBus.player_stats_changed.connect(_on_stats_changed)
	EventBus.close_panels_requested.connect(close)
	EventBus.player_died.connect(close)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("inventory"):
		get_viewport().set_input_as_handled()
		if visible:
			close()
		else:
			open()


func open() -> void:
	visible = true
	GameState.set_panel_open(PANEL_NAME, true)
	desc_label.text = "将鼠标移到道具上查看说明"


func close() -> void:
	visible = false
	GameState.set_panel_open(PANEL_NAME, false)


func _on_inventory_changed(new_items: Array, capacity: int) -> void:
	items = new_items
	_ensure_slot_count(capacity)
	for i in slot_nodes.size():
		slot_nodes[i].set_item(items[i] if i < items.size() else {})


func _ensure_slot_count(capacity: int) -> void:
	if item_slot_scene == null:
		return
	while slot_nodes.size() < capacity:
		var slot := item_slot_scene.instantiate() as ItemSlot
		slot.index = slot_nodes.size()
		grid.add_child(slot)
		slot.slot_pressed.connect(_on_slot_pressed)
		slot.slot_hovered.connect(_on_slot_hovered)
		slot_nodes.append(slot)


func _on_slot_pressed(index: int) -> void:
	EventBus.item_use_requested.emit(index)
	_on_slot_hovered(index)


func _on_slot_hovered(index: int) -> void:
	var data: Dictionary = items[index] if index < items.size() else {}
	if data.is_empty():
		desc_label.text = "空"
		return
	var info := GameDB.get_item(str(data["id"]))
	var action := "左键装备" if info["type"] == "weapon" else "左键服用"
	desc_label.text = "【%s】%s（%s）" % [info["name"], str(info["desc"]).replace("\n", " · "), action]


func _on_stats_changed(stats: Dictionary) -> void:
	var weapon_id := str(stats.get("weapon_id", ""))
	weapon_slot.set_item({"id": weapon_id, "count": 1})
	weapon_name.text = GameDB.get_item(weapon_id).get("name", "无")
	var multiplier := float(stats.get("damage_multiplier", 1.0))
	stats_label.text = "\n".join([
		"等级：%d" % int(stats.get("level", 1)),
		"攻击：%d（伤害加成 +%d%%）" % [int(float(stats.get("attack", 0)) * multiplier), roundi((multiplier - 1.0) * 100.0)],
		"攻速：%d%%　暴击：%d%%" % [roundi(float(stats.get("attack_speed", 1)) * 100.0), roundi(float(stats.get("crit", 0)) * 100.0)],
		"生命上限：%d" % int(stats.get("max_hp", 0)),
		"内力上限：%d" % int(stats.get("max_mp", 0)),
		"体力上限：%d" % int(stats.get("max_stamina", 0)),
	])
