## ============================================================
## 背包格子（按钮）
## 显示道具色块/图标、文字、数量；点击发出 slot_pressed，悬停发出 slot_hovered。
## 美术替换：GameDB.ITEMS 中配置 icon 路径后自动显示图标。
## ============================================================
class_name ItemSlot
extends Button

signal slot_pressed(index: int)
signal slot_hovered(index: int)

const EMPTY_COLOR := Color(0.12, 0.13, 0.13, 1)

@onready var icon_rect: ColorRect = $Icon
@onready var art_icon: TextureRect = $ArtIcon
@onready var glyph_label: Label = $Glyph
@onready var count_label: Label = $CountLabel

var index := -1


func _ready() -> void:
	pressed.connect(func() -> void: slot_pressed.emit(index))
	mouse_entered.connect(func() -> void: slot_hovered.emit(index))
	set_item({})


func set_item(data: Dictionary) -> void:
	if data.is_empty() or GameDB.get_item(str(data.get("id", ""))).is_empty():
		icon_rect.color = EMPTY_COLOR
		art_icon.texture = null
		glyph_label.text = ""
		count_label.text = ""
		tooltip_text = ""
		return
	var item_id := str(data["id"])
	var info := GameDB.get_item(item_id)
	var color: Color = info["color"]
	icon_rect.color = color.darkened(0.45)
	art_icon.texture = GameDB.load_item_icon(item_id)
	glyph_label.visible = art_icon.texture == null
	glyph_label.text = info["glyph"]
	glyph_label.add_theme_color_override("font_color", color.lightened(0.4))
	var count := int(data.get("count", 1))
	count_label.text = "×%d" % count if count > 1 else ""
	tooltip_text = "%s\n%s" % [info["name"], info["desc"]]
