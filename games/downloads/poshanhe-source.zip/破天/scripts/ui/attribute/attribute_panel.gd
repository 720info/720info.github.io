## ============================================================
## 属性加点面板（C 键开关）
## 升级获得属性点，点击「+」分配到 生命 / 内力 / 体力。
## 数据来源：EventBus.player_stats_changed；操作请求：EventBus.attribute_point_requested。
## ============================================================
extends CanvasLayer

const PANEL_NAME := "attributes"

@onready var points_label: Label = %PointsLabel
@onready var info_label: Label = %InfoLabel
@onready var close_button: Button = %CloseButton
@onready var rows := {
	"hp": {"value": %HpValue, "button": %HpAdd, "desc": %HpDesc},
	"mp": {"value": %MpValue, "button": %MpAdd, "desc": %MpDesc},
	"stamina": {"value": %StaminaValue, "button": %StaminaAdd, "desc": %StaminaDesc},
}


func _ready() -> void:
	visible = false
	close_button.pressed.connect(close)
	for stat in rows:
		var button: Button = rows[stat]["button"]
		button.pressed.connect(func() -> void: EventBus.attribute_point_requested.emit(stat))
		(rows[stat]["desc"] as Label).text = GameDB.ATTRIBUTES[stat]["desc"]
	EventBus.player_stats_changed.connect(_on_stats_changed)
	EventBus.close_panels_requested.connect(close)
	EventBus.player_died.connect(close)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("attributes"):
		get_viewport().set_input_as_handled()
		if visible:
			close()
		else:
			open()


func open() -> void:
	visible = true
	GameState.set_panel_open(PANEL_NAME, true)


func close() -> void:
	visible = false
	GameState.set_panel_open(PANEL_NAME, false)


func _on_stats_changed(stats: Dictionary) -> void:
	var points := int(stats.get("unspent_points", 0))
	points_label.text = "等级 %d　·　可用属性点 %d" % [int(stats.get("level", 1)), points]
	var spent: Dictionary = stats.get("attribute_points", {})
	var values := {
		"hp": stats.get("max_hp", 0),
		"mp": stats.get("max_mp", 0),
		"stamina": stats.get("max_stamina", 0),
	}
	for stat in rows:
		(rows[stat]["value"] as Label).text = "%d　(+%d点)" % [int(values[stat]), int(spent.get(stat, 0))]
		(rows[stat]["button"] as Button).disabled = points <= 0
	info_label.text = "每级获得 %d 点属性点　·　等级伤害加成 +%d%%" % [
		GameDB.POINTS_PER_LEVEL, roundi((float(stats.get("damage_multiplier", 1.0)) - 1.0) * 100.0)]
