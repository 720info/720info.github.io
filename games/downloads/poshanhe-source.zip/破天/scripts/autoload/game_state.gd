## ============================================================
## 游戏全局状态（Autoload：GameState）
## 负责：场景切换（带淡入淡出）、新游戏/继续游戏流程、
##       击杀记录、游戏时长、UI 面板打开状态、全局顿帧、关窗自动存档。
## ============================================================
extends Node

const MAIN_MENU_SCENE := "res://scenes/ui/menus/main_menu.tscn"
const GAME_SCENE := "res://scenes/main.tscn"

var in_game := false                 # 当前是否处于游戏场景
var load_save_on_start := false      # 进入游戏场景时是否读取存档
var play_time := 0.0                 # 累计游戏时长（秒）
var player_level := 1                # 供刷新点计算怪物等级
var kill_total := 0
var kills_by_type: Dictionary = {}   # 怪物名 → 击杀数

var current_map := 1                 # 当前地图序号（1~MapDB.MAP_COUNT）
var map_kill_count := 0              # 本图击杀数（用于传送阵通关条件）
var map_transition := false          # 由 advance_to_next_map 设置：下次进场景需重置玩家出生位置
var game_completed := false          # 五图已全部通关

var is_cheated := false              # 作弊标签：存档是否被作弊修改过
var cheat_attack_multiplier := 1.0   # 作弊攻击力倍率（默认 1.0 = 无加成）
var cheat_infinite_hp := false       # 作弊：无限生命
var cheat_infinite_stamina := false  # 作弊：无限体力
var cheat_infinite_mp := false       # 作弊：无限内力
var cheat_no_cooldown := false       # 作弊：技能无冷却
var cheat_speed_multiplier := 1.0    # 作弊：移动速度倍率（默认 1.0 = 原速）
var cheat_time_scale := 1.0          # 作弊：游戏速度倍率（默认 1.0 = 原速）
signal cheat_status_changed(_is_cheated: bool)

var _open_panels: Dictionary = {}    # 已打开的面板名 → true
var _cached_scenes: Dictionary = {}  # 加载画面预加载好的场景（路径 → PackedScene）
var _hit_stop_active := false
var _changing_scene := false
var _fade_layer: CanvasLayer
var _fade_rect: ColorRect


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().auto_accept_quit = false   # 由我们处理关窗，先存档再退出
	_build_fade_layer()
	EventBus.enemy_killed.connect(_on_enemy_killed)
	EventBus.player_exp_changed.connect(_on_player_exp_changed)
	EventBus.hit_stop_requested.connect(_on_hit_stop_requested)


func _process(delta: float) -> void:
	if in_game and not get_tree().paused:
		play_time += delta


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		quit_game()


# ============================================================
# 流程控制
# ============================================================

func start_new_game() -> void:
	_reset_session()
	load_save_on_start = false
	change_scene(GAME_SCENE)


func continue_game() -> void:
	_reset_session()
	var data := SaveManager.read_save()
	current_map = int(data.get("current_map", 1))
	map_kill_count = int(data.get("map_kill_count", 0))
	load_save_on_start = true
	change_scene(GAME_SCENE)


## 传送阵调用：本图未通关但已达标，进入下一图（保留玩家等级/背包，重置出生点）
func advance_to_next_map() -> void:
	if current_map >= MapDB.MAP_COUNT:
		complete_game()
		return
	current_map += 1
	map_kill_count = 0
	map_transition = true
	load_save_on_start = true
	SaveManager.save_game()
	change_scene(GAME_SCENE)


## 传送阵调用：最后一图达标（含首领已灭），视为通关
func complete_game() -> void:
	game_completed = true
	SaveManager.save_game()
	EventBus.game_completed.emit()


func return_to_main_menu() -> void:
	if in_game:
		SaveManager.save_game()
	change_scene(MAIN_MENU_SCENE)


func quit_game() -> void:
	if in_game:
		SaveManager.save_game()
	get_tree().quit()


func change_scene(path: String) -> void:
	if _changing_scene:
		return
	_changing_scene = true
	var tween := create_tween()
	tween.tween_property(_fade_rect, "color:a", 1.0, 0.25)
	await tween.finished
	# 切场景前恢复全局状态，避免暂停/慢放残留
	get_tree().paused = false
	Engine.time_scale = 1.0
	_open_panels.clear()
	in_game = path == GAME_SCENE
	ObjectPool.clear()
	if _cached_scenes.has(path):
		get_tree().change_scene_to_packed(_cached_scenes[path])
	else:
		get_tree().change_scene_to_file(path)
	tween = create_tween()
	tween.tween_property(_fade_rect, "color:a", 0.0, 0.3)
	await tween.finished
	_changing_scene = false


## 加载画面调用：缓存预加载好的场景
func cache_scene(path: String, scene: PackedScene) -> void:
	if scene:
		_cached_scenes[path] = scene


# ============================================================
# UI 面板状态（用于阻止开着面板时误触攻击 / 暂停互斥）
# ============================================================

func set_panel_open(panel_name: String, is_open: bool) -> void:
	if is_open:
		_open_panels[panel_name] = true
	else:
		_open_panels.erase(panel_name)


func is_panel_open(panel_name: String = "") -> bool:
	if panel_name.is_empty():
		return not _open_panels.is_empty()
	return _open_panels.has(panel_name)


# ============================================================
# 击杀记录 / 存档数据
# ============================================================

func get_kill_data() -> Dictionary:
	return {"total": kill_total, "by_type": kills_by_type.duplicate()}


func apply_kill_data(data: Dictionary) -> void:
	kill_total = int(data.get("total", 0))
	kills_by_type = {}
	var by_type: Dictionary = data.get("by_type", {})
	for key in by_type:
		kills_by_type[str(key)] = int(by_type[key])
	EventBus.kill_count_changed.emit(kill_total, kills_by_type)


func _reset_session() -> void:
	play_time = 0.0
	player_level = 1
	kill_total = 0
	kills_by_type = {}
	current_map = 1
	map_kill_count = 0
	map_transition = false
	game_completed = false
	is_cheated = false
	cheat_attack_multiplier = 1.0
	cheat_infinite_hp = false
	cheat_infinite_stamina = false
	cheat_infinite_mp = false
	cheat_no_cooldown = false
	cheat_speed_multiplier = 1.0
	cheat_time_scale = 1.0
	EventBus.session_reset.emit()
	cheat_status_changed.emit(false)


# ============================================================
# 作弊功能（仅用于开发测试，使用后会打上作弊标签）
# ============================================================

## 标记为已作弊（一旦标记不可撤销）
func mark_cheated() -> void:
	if not is_cheated:
		is_cheated = true
		cheat_status_changed.emit(true)

## 设置作弊攻击力倍率（multiplier >= 1.0）
func set_cheat_attack_multiplier(multiplier: float) -> void:
	if multiplier < 1.0:
		multiplier = 1.0
	mark_cheated()
	cheat_attack_multiplier = multiplier
	_sync_player_cheats()


func set_cheat_infinite_hp(enabled: bool) -> void:
	if cheat_infinite_hp == enabled:
		return
	if enabled:
		mark_cheated()
	cheat_infinite_hp = enabled
	_sync_player_cheats()


func set_cheat_infinite_stamina(enabled: bool) -> void:
	if cheat_infinite_stamina == enabled:
		return
	if enabled:
		mark_cheated()
	cheat_infinite_stamina = enabled
	_sync_player_cheats()


func set_cheat_infinite_mp(enabled: bool) -> void:
	if cheat_infinite_mp == enabled:
		return
	if enabled:
		mark_cheated()
	cheat_infinite_mp = enabled
	_sync_player_cheats()


func set_cheat_no_cooldown(enabled: bool) -> void:
	if cheat_no_cooldown == enabled:
		return
	if enabled:
		mark_cheated()
	cheat_no_cooldown = enabled
	_sync_player_cheats()


## 移动速度倍率（大于 1.0 才标记作弊，调回 1.0 视为恢复正常）
func set_cheat_speed_multiplier(multiplier: float) -> void:
	multiplier = clampf(multiplier, 1.0, 3.0)
	if multiplier > 1.0:
		mark_cheated()
	cheat_speed_multiplier = multiplier


## 游戏速度倍率（不等于 1.0 即标记作弊）
func set_cheat_time_scale(scale: float) -> void:
	scale = clampf(scale, 0.5, 3.0)
	if not is_equal_approx(scale, 1.0):
		mark_cheated()
	cheat_time_scale = scale
	if in_game and not _hit_stop_active:
		Engine.time_scale = scale

## 直接设置击杀总数（用于作弊修改）
func cheat_set_kill_total(new_total: int) -> void:
	if new_total < 0:
		new_total = 0
	var delta := new_total - kill_total
	mark_cheated()
	kill_total = new_total
	map_kill_count = maxi(map_kill_count + delta, 0)
	EventBus.kill_count_changed.emit(kill_total, kills_by_type)

## 给击杀总数加上增量
func cheat_add_kills(amount: int) -> void:
	cheat_set_kill_total(kill_total + amount)


## 一键补满本图击杀进度（差额同步计入总击杀）
func cheat_fill_map_kills() -> void:
	var goal := int(MapDB.get_map(current_map).get("kill_goal", 0))
	var missing := goal - map_kill_count
	if missing > 0:
		cheat_set_kill_total(kill_total + missing)
	else:
		mark_cheated()


## 增加经验（可触发连续升级）
func cheat_add_exp(amount: int) -> void:
	mark_cheated()
	var player := get_tree().get_first_node_in_group("player")
	if player != null:
		player.call("cheat_add_exp", amount)


## 直接升 1 级
func cheat_level_up() -> void:
	mark_cheated()
	var player := get_tree().get_first_node_in_group("player")
	if player != null:
		player.call("cheat_level_up")


## 给玩家发放道具，返回实际放入背包的数量
func cheat_give_item(item_id: String, count: int = 1) -> int:
	mark_cheated()
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		return 0
	return int(player.call("cheat_give_item", item_id, count))


## 状态全满；已死亡则原地复活
func cheat_restore_or_revive() -> String:
	mark_cheated()
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		return "未找到玩家"
	if player.has_method("is_alive") and not player.call("is_alive"):
		EventBus.player_respawn_requested.emit()
		return "已原地复活"
	player.call("restore_full")
	return "状态已全部回满"


## 秒杀当前场景内所有存活敌人（正常结算击杀、经验与掉落）
func cheat_kill_all_enemies() -> int:
	mark_cheated()
	var count := 0
	for enemy in get_tree().get_nodes_in_group("enemy"):
		if is_instance_valid(enemy) and enemy.has_method("take_damage"):
			enemy.call("take_damage", 999999.0, Vector2.ZERO, false)
			count += 1
	return count


## 跳转到指定地图（1~MapDB.MAP_COUNT），会存档并重载游戏场景
func cheat_jump_to_map(target_map: int) -> void:
	mark_cheated()
	current_map = clampi(target_map, 1, MapDB.MAP_COUNT)
	map_kill_count = 0
	map_transition = true
	load_save_on_start = true
	SaveManager.save_game()
	change_scene(GAME_SCENE)


## 获取作弊数据供存档使用
func get_cheat_data() -> Dictionary:
	return {
		"is_cheated": is_cheated,
		"cheat_attack_multiplier": cheat_attack_multiplier,
		"cheat_infinite_hp": cheat_infinite_hp,
		"cheat_infinite_stamina": cheat_infinite_stamina,
		"cheat_infinite_mp": cheat_infinite_mp,
		"cheat_no_cooldown": cheat_no_cooldown,
		"cheat_speed_multiplier": cheat_speed_multiplier,
		"cheat_time_scale": cheat_time_scale,
	}

## 从存档恢复作弊数据
func apply_cheat_data(data: Dictionary) -> void:
	is_cheated = bool(data.get("is_cheated", false))
	cheat_attack_multiplier = float(data.get("cheat_attack_multiplier", 1.0))
	if cheat_attack_multiplier < 1.0:
		cheat_attack_multiplier = 1.0
	cheat_infinite_hp = bool(data.get("cheat_infinite_hp", false))
	cheat_infinite_stamina = bool(data.get("cheat_infinite_stamina", false))
	cheat_infinite_mp = bool(data.get("cheat_infinite_mp", false))
	cheat_no_cooldown = bool(data.get("cheat_no_cooldown", false))
	cheat_speed_multiplier = clampf(float(data.get("cheat_speed_multiplier", 1.0)), 1.0, 3.0)
	cheat_time_scale = clampf(float(data.get("cheat_time_scale", 1.0)), 0.5, 3.0)
	cheat_status_changed.emit(is_cheated)
	_sync_player_cheats()
	if in_game and not _hit_stop_active:
		Engine.time_scale = cheat_time_scale


func _on_enemy_killed(enemy_type: String, _exp_reward: int, _world_position: Vector2) -> void:
	kill_total += 1
	map_kill_count += 1
	kills_by_type[enemy_type] = int(kills_by_type.get(enemy_type, 0)) + 1
	EventBus.kill_count_changed.emit(kill_total, kills_by_type)


func _on_player_exp_changed(level: int, _current_exp: int, _need_exp: int) -> void:
	player_level = level


func _sync_player_cheats() -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player != null:
		player.call("refresh_cheat_state")


# ============================================================
# 全局顿帧：短暂降低时间流速，增强打击感
# ============================================================

func _on_hit_stop_requested(duration: float) -> void:
	if _hit_stop_active or get_tree().paused:
		return
	_hit_stop_active = true
	Engine.time_scale = 0.08
	# 忽略时间缩放的计时器，保证准时恢复
	await get_tree().create_timer(duration, true, false, true).timeout
	Engine.time_scale = cheat_time_scale   # 恢复时保留作弊游戏速度
	_hit_stop_active = false


func _build_fade_layer() -> void:
	_fade_layer = CanvasLayer.new()
	_fade_layer.layer = 128
	add_child(_fade_layer)
	_fade_rect = ColorRect.new()
	_fade_rect.color = Color(0, 0, 0, 0)
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade_layer.add_child(_fade_rect)
