## ============================================================
## 全局事件总线（Autoload：EventBus）
## 所有模块之间通过这里的信号通信，避免节点之间的硬引用。
##   玩家 → UI：数值、冷却、背包、属性
##   UI → 玩家：使用道具、属性加点（请求类信号）
##   怪物/刷新点/技能 → 主场景：生成怪物、特效、掉落
##   任意模块 → 表现层：飘字、震屏、顿帧、音效、提示
## ============================================================
extends Node

@warning_ignore_start("unused_signal")

# —— 玩家状态（玩家 → UI） ——
signal player_hp_changed(current: float, maximum: float)
signal player_mp_changed(current: float, maximum: float)
signal player_stamina_changed(current: float, maximum: float)
signal player_exp_changed(level: int, current_exp: int, need_exp: int)
signal player_stats_changed(stats: Dictionary)
signal player_level_up(level: int)
signal player_hurt(amount: float)
signal player_died
signal player_respawned
signal skill_cooldowns_updated(remaining: Array, totals: Array)
signal skill_cast(skill_index: int)
signal inventory_changed(items: Array, capacity: int)
signal item_picked(item_id: String)

# —— 请求（UI / 场景 → 玩家） ——
signal player_respawn_requested
signal item_use_requested(slot_index: int)
signal attribute_point_requested(stat: String)

# —— 战斗 ——
signal enemy_killed(enemy_type: String, exp_reward: int, world_position: Vector2)
signal kill_count_changed(total: int, by_type: Dictionary)

# —— 生成请求（由主场景统一放入对应容器） ——
signal spawn_enemy_requested(enemy: Node2D)
signal spawn_effect_requested(effect: Node2D)
signal drop_item_requested(item_id: String, world_position: Vector2)

# —— 表现 ——
signal floating_text_requested(text: String, world_position: Vector2, color: Color, font_size: int)
signal camera_shake_requested(strength: float, duration: float)
signal hit_stop_requested(duration: float)
signal sfx_requested(sfx_name: String)
signal bgm_requested(track: String)

# —— UI 提示 ——
signal toast_requested(text: String)
signal interact_prompt_changed(text: String)
signal close_panels_requested
signal achievement_panel_requested
signal game_saved

# —— 成就 ——
signal achievement_unlocked(id: String)
signal session_reset
signal game_completed

@warning_ignore_restore("unused_signal")


## 世界坐标飘字
func show_text(text: String, world_position: Vector2, color: Color = Color.WHITE, font_size: int = 16) -> void:
	floating_text_requested.emit(text, world_position, color, font_size)


## 相机震动
func shake(strength: float, duration: float = 0.15) -> void:
	camera_shake_requested.emit(strength, duration)


## 播放音效（音效名见 AudioManager.SFX_NODES）
func sfx(sfx_name: String) -> void:
	sfx_requested.emit(sfx_name)


## 屏幕中上方提示
func toast(text: String) -> void:
	toast_requested.emit(text)
