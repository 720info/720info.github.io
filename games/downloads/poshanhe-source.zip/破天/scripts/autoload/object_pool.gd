## ============================================================
## 对象池（Autoload：ObjectPool）
## 频繁生成/销毁的节点（怪物、剑气、毒球、命中特效、刀光、残影、光环）统一复用：
##   acquire(scene)  取出一个实例（池空时新建），调用方设置属性后再 add_child
##   release(node)   从场景树移除并放回池中（代替 queue_free）
## 被复用的节点会重新执行 _ready()（request_ready），脚本需在 _ready 中重置运行时状态。
## 切换场景时 clear() 释放全部闲置节点，避免孤儿节点泄漏。
## ============================================================
extends Node

const MAX_IDLE_PER_SCENE := 48   # 每种场景最多缓存的闲置实例，超出直接释放

var _idle: Dictionary = {}       # 场景路径 → Array[Node]
var _pooled: Dictionary = {}     # 实例ID → true（防止重复回收）


func acquire(scene: PackedScene) -> Node:
	if scene == null:
		return null
	var key := scene.resource_path
	var list: Array = _idle.get(key, [])
	while not list.is_empty():
		var node: Node = list.pop_back()
		if is_instance_valid(node):
			_pooled.erase(node.get_instance_id())
			node.request_ready()        # 重新加入场景树时再次执行 _ready 重置状态
			if node is CanvasItem:
				var item := node as CanvasItem
				item.visible = true
				item.modulate = Color.WHITE
			if node is Node2D:
				(node as Node2D).scale = Vector2.ONE
				(node as Node2D).rotation = 0.0
			return node
	var instance := scene.instantiate()
	instance.set_meta("pool_key", key)
	return instance


## 回收节点；不是对象池创建的节点会直接 queue_free
func release(node: Node) -> void:
	if node == null or not is_instance_valid(node):
		return
	var id := node.get_instance_id()
	if _pooled.has(id):
		return
	var key := str(node.get_meta("pool_key", ""))
	var list: Array = _idle.get(key, [])
	if key.is_empty() or list.size() >= MAX_IDLE_PER_SCENE:
		node.queue_free()
		return
	_pooled[id] = true
	list.append(node)
	_idle[key] = list
	# 延迟移除：可能在物理回调中调用
	if node.get_parent():
		node.get_parent().remove_child.call_deferred(node)


## 游戏退出时释放闲置节点，避免退出时报告内存泄漏
func _exit_tree() -> void:
	clear()


## 释放全部闲置节点（切换场景时调用）
func clear() -> void:
	for key in _idle:
		for node in _idle[key]:
			if is_instance_valid(node):
				node.free()
	_idle.clear()
	_pooled.clear()


## 调试用：各池闲置数量
func get_stats() -> Dictionary:
	var stats := {}
	for key in _idle:
		stats[key.get_file()] = (_idle[key] as Array).size()
	return stats
