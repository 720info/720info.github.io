## ============================================================
## 设置管理（Autoload：SettingsManager）
## 音量（主音量/音乐/音效）、显示模式（窗口/全屏/独占全屏）、分辨率、垂直同步。
## 保存在 user://settings.cfg，启动时自动应用。F11 快速切换全屏。
## ============================================================
extends Node

const SETTINGS_PATH := "user://settings.cfg"
const RESOLUTIONS: Array[Vector2i] = [
	Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080), Vector2i(2560, 1440),
]
const WINDOW_MODE_NAMES: Array[String] = ["窗口化", "全屏", "独占全屏"]
const BUS_MASTER := "Master"
const BUS_BGM := "BGM"
const BUS_SFX := "SFX"

var master_volume := 0.8
var bgm_volume := 0.7
var sfx_volume := 0.8
var window_mode := 0          # 对应 WINDOW_MODE_NAMES 下标
var resolution_index := 2     # 对应 RESOLUTIONS 下标
var vsync_enabled := true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_audio_buses()
	var has_file := load_settings()
	if not has_file:
		resolution_index = _best_fit_resolution_index()
	apply_audio()
	apply_display.call_deferred()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("toggle_fullscreen"):
		window_mode = 0 if window_mode != 0 else 1
		apply_display()
		save_settings()
		get_viewport().set_input_as_handled()


# ============================================================
# 修改接口（设置面板调用）
# ============================================================

func set_volume(bus_name: String, linear: float) -> void:
	linear = clampf(linear, 0.0, 1.0)
	match bus_name:
		BUS_MASTER:
			master_volume = linear
		BUS_BGM:
			bgm_volume = linear
		BUS_SFX:
			sfx_volume = linear
	apply_audio()
	save_settings()


func get_volume(bus_name: String) -> float:
	match bus_name:
		BUS_BGM:
			return bgm_volume
		BUS_SFX:
			return sfx_volume
	return master_volume


func set_window_mode(index: int) -> void:
	window_mode = clampi(index, 0, WINDOW_MODE_NAMES.size() - 1)
	apply_display()
	save_settings()


func set_resolution(index: int) -> void:
	resolution_index = clampi(index, 0, RESOLUTIONS.size() - 1)
	apply_display()
	save_settings()


func set_vsync(enabled: bool) -> void:
	vsync_enabled = enabled
	apply_display()
	save_settings()


# ============================================================
# 应用
# ============================================================

func apply_audio() -> void:
	_set_bus_volume(BUS_MASTER, master_volume)
	_set_bus_volume(BUS_BGM, bgm_volume)
	_set_bus_volume(BUS_SFX, sfx_volume)


func apply_display() -> void:
	DisplayServer.window_set_vsync_mode(
		DisplayServer.VSYNC_ENABLED if vsync_enabled else DisplayServer.VSYNC_DISABLED)
	# 在编辑器内嵌运行时不修改窗口，避免报错
	if Engine.is_embedded_in_editor() or DisplayServer.get_name() == "headless":
		return
	match window_mode:
		1:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
		2:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
		_:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
			var screen := DisplayServer.window_get_current_screen()
			var usable := DisplayServer.screen_get_usable_rect(screen)
			var target := RESOLUTIONS[resolution_index]
			# 分辨率超过屏幕可用区域时自动缩小，保持 16:9
			if target.x > usable.size.x or target.y > usable.size.y:
				var ratio := minf(float(usable.size.x) / target.x, float(usable.size.y) / target.y) * 0.95
				target = Vector2i(int(target.x * ratio), int(target.y * ratio))
			DisplayServer.window_set_size(target)
			DisplayServer.window_set_position(usable.position + Vector2i(Vector2(usable.size - target) * 0.5))


# ============================================================
# 读写
# ============================================================

func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("audio", "master", master_volume)
	config.set_value("audio", "bgm", bgm_volume)
	config.set_value("audio", "sfx", sfx_volume)
	config.set_value("display", "window_mode", window_mode)
	config.set_value("display", "resolution", resolution_index)
	config.set_value("display", "vsync", vsync_enabled)
	config.save(SETTINGS_PATH)


func load_settings() -> bool:
	var config := ConfigFile.new()
	if config.load(SETTINGS_PATH) != OK:
		return false
	master_volume = float(config.get_value("audio", "master", master_volume))
	bgm_volume = float(config.get_value("audio", "bgm", bgm_volume))
	sfx_volume = float(config.get_value("audio", "sfx", sfx_volume))
	window_mode = clampi(int(config.get_value("display", "window_mode", window_mode)), 0, WINDOW_MODE_NAMES.size() - 1)
	resolution_index = clampi(int(config.get_value("display", "resolution", resolution_index)), 0, RESOLUTIONS.size() - 1)
	vsync_enabled = bool(config.get_value("display", "vsync", vsync_enabled))
	return true


func _set_bus_volume(bus_name: String, linear: float) -> void:
	var index := AudioServer.get_bus_index(bus_name)
	if index < 0:
		return
	AudioServer.set_bus_volume_db(index, linear_to_db(maxf(linear, 0.0001)))
	AudioServer.set_bus_mute(index, linear <= 0.001)


## 总线布局文件丢失时兜底创建 BGM / SFX 总线
func _ensure_audio_buses() -> void:
	for bus_name in [BUS_BGM, BUS_SFX]:
		if AudioServer.get_bus_index(bus_name) < 0:
			AudioServer.add_bus()
			var index := AudioServer.bus_count - 1
			AudioServer.set_bus_name(index, bus_name)
			AudioServer.set_bus_send(index, BUS_MASTER)


## 首次启动时选择不超过屏幕 90% 的最大分辨率
func _best_fit_resolution_index() -> int:
	if DisplayServer.get_name() == "headless":
		return 2
	var usable := DisplayServer.screen_get_usable_rect(DisplayServer.window_get_current_screen()).size
	var best := 0
	for i in RESOLUTIONS.size():
		if RESOLUTIONS[i].x <= usable.x * 0.9 and RESOLUTIONS[i].y <= usable.y * 0.9:
			best = i
	return best
