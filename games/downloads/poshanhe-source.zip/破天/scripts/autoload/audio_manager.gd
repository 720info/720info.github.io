## ============================================================
## 音频管理（Autoload：AudioManager，场景 scenes/autoload/audio_manager.tscn）
## - 背景音乐：BGM 节点，曲目通过根节点的 menu_bgm / field_bgm 属性配置
## - 音效：每种音效一个 AudioStreamPlayer 子节点（见 SFX_NODES 与各节点备注）
## - 自动监听 EventBus 播放对应音效；所有按钮点击自动播放 UI 音效
## 没有放入音频文件时静默跳过，不会报错。
## ============================================================
extends Node

## 音效名 → 节点名
const SFX_NODES := {
	"attack": "SfxAttack",        # 普攻挥剑
	"hit": "SfxHit",              # 命中敌人
	"skill_1": "SfxSkill1",       # 连光剑
	"skill_2": "SfxSkill2",       # 旋光斩
	"skill_3": "SfxSkill3",       # 飞身斩
	"skill_4": "SfxSkill4",       # 破天一式
	"dash": "SfxDash",            # 轻功
	"hurt": "SfxHurt",            # 玩家受伤
	"pickup": "SfxPickup",        # 拾取道具
	"use_item": "SfxUseItem",     # 使用药品 / 更换武器
	"death": "SfxDeath",          # 玩家死亡
	"level_up": "SfxLevelUp",     # 升级
	"enemy_die": "SfxEnemyDie",   # 怪物死亡
	"save": "SfxSave",            # 存档
	"ui_click": "SfxUIClick",     # 按钮点击
}

@export var menu_bgm: AudioStream    ## 主菜单背景音乐（建议循环 ogg）
@export var field_bgm: AudioStream   ## 野外场景背景音乐（建议循环 ogg）

@onready var bgm_player: AudioStreamPlayer = $BGM

var _current_track := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS   # 暂停时按钮音效依然可以播放
	EventBus.sfx_requested.connect(play_sfx)
	EventBus.bgm_requested.connect(play_bgm)
	EventBus.skill_cast.connect(func(index: int) -> void: play_sfx("skill_%d" % (index + 1)))
	EventBus.player_hurt.connect(func(_amount: float) -> void: play_sfx("hurt"))
	EventBus.item_picked.connect(func(_item_id: String) -> void: play_sfx("pickup"))
	EventBus.player_died.connect(func() -> void: play_sfx("death"))
	EventBus.player_level_up.connect(func(_level: int) -> void: play_sfx("level_up"))
	EventBus.enemy_killed.connect(func(_t: String, _e: int, _p: Vector2) -> void: play_sfx("enemy_die"))
	EventBus.game_saved.connect(func() -> void: play_sfx("save"))
	get_tree().node_added.connect(_on_node_added)


func play_sfx(sfx_name: String) -> void:
	var player := get_node_or_null(str(SFX_NODES.get(sfx_name, ""))) as AudioStreamPlayer
	if player == null or player.stream == null:
		return
	player.pitch_scale = randf_range(0.93, 1.07)   # 轻微随机音高，避免重复感
	player.play()


func play_bgm(track: String) -> void:
	if track == _current_track and bgm_player.playing:
		return
	_current_track = track
	var stream: AudioStream = menu_bgm if track == "menu" else field_bgm if track == "field" else null
	bgm_player.stop()
	bgm_player.stream = stream
	if stream:
		bgm_player.play()


func _on_node_added(node: Node) -> void:
	if node is BaseButton and not node.is_in_group("silent_button"):
		(node as BaseButton).pressed.connect(play_sfx.bind("ui_click"))
