## ============================================================
## 成就系统（Autoload：AchievementManager）
## 监听 EventBus 相关信号判定达成条件，达成后弹出提示并随存档持久化。
## 数据定义见 scripts/data/achievement_db.gd。
## ============================================================
extends Node

const PLAY_TIME_CHECK_INTERVAL := 5.0

var unlocked: Dictionary = {}   # id -> true
var _play_time_timer := PLAY_TIME_CHECK_INTERVAL


func _ready() -> void:
	EventBus.kill_count_changed.connect(_on_kill_count_changed)
	EventBus.player_level_up.connect(_on_level_up)
	EventBus.skill_cast.connect(_on_skill_cast)
	EventBus.item_picked.connect(_on_item_picked)
	EventBus.session_reset.connect(reset)


func _process(delta: float) -> void:
	if not GameState.in_game:
		return
	_play_time_timer -= delta
	if _play_time_timer <= 0.0:
		_play_time_timer = PLAY_TIME_CHECK_INTERVAL
		_check_condition("play_time", GameState.play_time)


func is_unlocked(id: String) -> bool:
	return unlocked.has(id)


## 面板展示用：未达成时返回当前进度数值（与 target 同单位）
func get_current_value(entry: Dictionary) -> Variant:
	match str(entry.get("condition", "")):
		"kill_total":
			return GameState.kill_total
		"level":
			return GameState.player_level
		"play_time":
			return int(GameState.play_time)
		_:
			return null


func reset() -> void:
	unlocked.clear()
	_play_time_timer = PLAY_TIME_CHECK_INTERVAL


func get_save_data() -> Array:
	return unlocked.keys()


func apply_save_data(ids: Array) -> void:
	unlocked.clear()
	for id in ids:
		unlocked[str(id)] = true


func _on_kill_count_changed(total: int, _by_type: Dictionary) -> void:
	_check_condition("kill_total", total)


func _on_level_up(level: int) -> void:
	_check_condition("level", level)


func _on_skill_cast(index: int) -> void:
	_check_condition("skill_cast", index)


func _on_item_picked(item_id: String) -> void:
	_check_condition("item_owned", item_id)


## 依条件类型扫1描成就表，命中且未解锁的一律尝试解锁
func _check_condition(condition: String, value: Variant) -> void:
	for entry in AchievementDB.ACHIEVEMENTS:
		if entry["condition"] != condition or unlocked.has(entry["id"]):
			continue
		var target = entry["target"]
		var reached: bool = (value >= target) if (value is int or value is float) else (value == target)
		if reached:
			_unlock(entry["id"])


func _unlock(id: String) -> void:
	if unlocked.has(id):
		return
	unlocked[id] = true
	var entry := AchievementDB.get_achievement(id)
	EventBus.achievement_unlocked.emit(id)
	EventBus.toast("成就达成：%s" % str(entry.get("name", id)))
	EventBus.sfx("level_up")
