## ============================================================
## 存档管理（Autoload：SaveManager）
## - 存档格式：JSON，路径 user://savegame.json（先写临时文件再替换，防止写坏）
## - 保存内容：玩家位置/复活点、等级经验、血蓝体、属性点、背包、武器、击杀记录、时长
## - 自动存档：游戏中每 AUTOSAVE_INTERVAL 秒一次 + 升级时 + 返回主菜单/退出时
## - 手动存档：地图上的存档点（SavePoint）
## 玩家数据通过鸭子类型调用 get_save_data()，不依赖玩家脚本类型。
## ============================================================
extends Node

const SAVE_PATH := "user://savegame.json"
const TEMP_PATH := "user://savegame.tmp"
const SAVE_VERSION := 1
const AUTOSAVE_INTERVAL := 60.0

var _autosave_timer := AUTOSAVE_INTERVAL


func _ready() -> void:
	EventBus.player_level_up.connect(_on_player_level_up)


func _process(delta: float) -> void:
	if not GameState.in_game:
		_autosave_timer = AUTOSAVE_INTERVAL
		return
	_autosave_timer -= delta
	if _autosave_timer <= 0.0:
		_autosave_timer = AUTOSAVE_INTERVAL
		if save_game():
			EventBus.toast("已自动存档")


## 保存游戏，成功返回 true（玩家不存在或已死亡时不保存）
func save_game() -> bool:
	var player := get_tree().get_first_node_in_group("player")
	if player == null or not player.has_method("get_save_data"):
		return false
	if player.has_method("is_alive") and not player.call("is_alive"):
		return false
	var data := {
		"version": SAVE_VERSION,
		"timestamp": Time.get_datetime_string_from_system(false, true),
		"play_time": GameState.play_time,
		"player": player.call("get_save_data"),
		"kills": GameState.get_kill_data(),
		"achievements": AchievementManager.get_save_data(),
		"current_map": GameState.current_map,
		"map_kill_count": GameState.map_kill_count,
		"cheat": GameState.get_cheat_data(),
	}
	var file := FileAccess.open(TEMP_PATH, FileAccess.WRITE)
	if file == null:
		push_warning("存档写入失败：%s" % error_string(FileAccess.get_open_error()))
		return false
	file.store_string(JSON.stringify(data, "\t"))
	file.close()
	var dir := DirAccess.open("user://")
	if dir == null:
		return false
	if dir.file_exists("savegame.json"):
		dir.remove("savegame.json")
	var err := dir.rename("savegame.tmp", "savegame.json")
	if err != OK:
		push_warning("存档替换失败：%s" % error_string(err))
		return false
	_autosave_timer = AUTOSAVE_INTERVAL
	EventBus.game_saved.emit()
	return true


## 读取存档，失败或损坏返回空字典
func read_save() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH):
		return {}
	var text := FileAccess.get_file_as_string(SAVE_PATH)
	var parsed = JSON.parse_string(text)
	if not parsed is Dictionary or not parsed.has("player"):
		push_warning("存档损坏或格式不正确，已忽略")
		return {}
	return parsed


func has_save() -> bool:
	return not read_save().is_empty()


func delete_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))


## 主菜单「继续游戏」下方显示的存档摘要
func get_save_summary() -> String:
	var data := read_save()
	if data.is_empty():
		return "暂无存档"
	var player_data: Dictionary = data.get("player", {})
	var kills: Dictionary = data.get("kills", {})
	var seconds := int(data.get("play_time", 0.0))
	var map_index := int(data.get("current_map", 1))
	var cheat_data: Dictionary = data.get("cheat", {})
	var is_cheated := bool(cheat_data.get("is_cheated", false))
	var cheat_tag := " 【作弊存档】" if is_cheated else ""
	return "第%d/%d图·%s · 等级 %d · 击杀 %d · 时长 %d分%02d秒%s · %s" % [
		map_index, MapDB.MAP_COUNT, MapDB.map_name(map_index),
		int(player_data.get("level", 1)),
		int(kills.get("total", 0)),
		floori(seconds / 60.0), seconds % 60,
		cheat_tag,
		str(data.get("timestamp", "")),
	]


func _on_player_level_up(_level: int) -> void:
	# 等玩家数值全部刷新后再存
	(func() -> void:
		if save_game():
			EventBus.toast("升级啦！已自动存档")
	).call_deferred()
