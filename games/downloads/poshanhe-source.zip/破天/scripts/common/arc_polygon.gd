## ============================================================
## 弧形占位多边形（编辑器内实时预览）
## 用于剑光、剑气等月牙形效果，弧形朝向 +X 方向。
## inner_radius 为 0 时生成扇形。
## ============================================================
@tool
class_name ArcPolygon
extends Polygon2D

@export var inner_radius: float = 20.0:
	set(value):
		inner_radius = value
		_rebuild()

@export var outer_radius: float = 32.0:
	set(value):
		outer_radius = value
		_rebuild()

@export_range(10.0, 350.0) var arc_degrees: float = 120.0:
	set(value):
		arc_degrees = value
		_rebuild()

@export_range(4, 64) var segments: int = 16:
	set(value):
		segments = value
		_rebuild()


func _ready() -> void:
	_rebuild()


func _rebuild() -> void:
	var points := PackedVector2Array()
	var half := deg_to_rad(arc_degrees) * 0.5
	for i in segments + 1:
		var angle := lerpf(-half, half, float(i) / float(segments))
		points.append(Vector2.from_angle(angle) * outer_radius)
	if inner_radius <= 0.0:
		points.append(Vector2.ZERO)
	else:
		for i in range(segments, -1, -1):
			var angle := lerpf(-half, half, float(i) / float(segments))
			# 内弧略微收窄，形成两头尖的月牙
			points.append(Vector2.from_angle(angle * 0.85) * inner_radius)
	polygon = points
