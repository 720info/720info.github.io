## ============================================================
## 美术替换位（ArtSlot）
## 场景中每个占位美术旁边都放了一个 ArtSlot 节点（Sprite2D，默认无贴图）。
## 替换美术：选中 ArtSlot → 把图片拖到 Texture 属性 → 运行时会自动
## 隐藏同级的 Polygon2D 占位图形和 "art_placeholder" 分组里的占位节点。
## 未设置贴图时本节点自动隐藏，不影响占位效果。
## ============================================================
class_name ArtSlot
extends Sprite2D

@export var hide_placeholders: bool = true


func _ready() -> void:
	_refresh()


## 运行时更换贴图（如道具图标）
func apply_texture(new_texture: Texture2D) -> void:
	texture = new_texture
	_refresh()


func _refresh() -> void:
	visible = texture != null
	if texture == null or not hide_placeholders or get_parent() == null:
		return
	for sibling in get_parent().get_children():
		if sibling == self or not sibling is CanvasItem:
			continue
		if sibling is Polygon2D or sibling.is_in_group("art_placeholder"):
			(sibling as CanvasItem).visible = false
