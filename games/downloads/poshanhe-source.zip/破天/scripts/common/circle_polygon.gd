## ============================================================
## 圆形占位多边形（编辑器内实时预览）
## 用于角色身体、树冠、阴影等占位美术；配合 scale 可做椭圆。
## 后续替换美术时，直接把该节点换成 Sprite2D 即可。
## ============================================================
@tool
class_name CirclePolygon
extends Polygon2D

@export var radius: float = 16.0:
	set(value):
		radius = value
		_rebuild()

@export_range(6, 64) var segments: int = 24:
	set(value):
		segments = value
		_rebuild()


func _ready() -> void:
	_rebuild()


func _rebuild() -> void:
	var points := PackedVector2Array()
	for i in segments:
		var angle := TAU * float(i) / float(segments)
		points.append(Vector2(cos(angle), sin(angle)) * radius)
	polygon = points
