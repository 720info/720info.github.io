## ============================================================
## 淡出特效（刀光、残影等一次性特效）
## 生成后在 lifetime 内渐隐并缩放，结束后自动销毁。
## ============================================================
extends Node2D

@export var lifetime: float = 0.2
@export var start_alpha: float = 1.0
@export var end_scale: Vector2 = Vector2(1.15, 1.15)


func _ready() -> void:
	modulate.a *= start_alpha
	var tween := create_tween().set_parallel()
	tween.tween_property(self, "modulate:a", 0.0, lifetime)
	tween.tween_property(self, "scale", scale * end_scale, lifetime)
	tween.chain().tween_callback(ObjectPool.release.bind(self))
