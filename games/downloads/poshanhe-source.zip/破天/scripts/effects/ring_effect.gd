## ============================================================
## 扩散光环特效（旋光斩剑域、升级、复活、怪物刷新）
## 使用 _draw 绘制，从小到大扩散并淡出。
## ============================================================
extends Node2D

@export var max_radius: float = 120.0
@export var color: Color = Color(0.6, 0.95, 1.0, 0.9)
@export var lifetime: float = 0.35
@export var line_width: float = 6.0

var progress := 0.0


func _ready() -> void:
	progress = 0.0   # 对象池复用时从头播放
	queue_redraw()


func _process(delta: float) -> void:
	progress += delta / lifetime
	if progress >= 1.0:
		progress = 1.0
		ObjectPool.release(self)
		return
	queue_redraw()


func _draw() -> void:
	var eased := 1.0 - pow(1.0 - progress, 3.0)
	var radius := lerpf(max_radius * 0.25, max_radius, eased)
	var alpha := color.a * (1.0 - progress)
	draw_circle(Vector2.ZERO, radius, Color(color.r, color.g, color.b, alpha * 0.25))
	draw_arc(Vector2.ZERO, radius, 0.0, TAU, 64, Color(color.r, color.g, color.b, alpha), line_width, true)
