## ============================================================
## 命中特效（技能/普攻/弹道命中时生成）
## 占位：随机旋转的星形火花 + 光圈，弹出后淡出。
## 美术替换：给子节点 ArtSlot 设置贴图（或序列帧可改成 AnimatedSprite2D），
##          占位图形会自动隐藏；颜色通过 color 统一着色。
## ============================================================
extends Node2D

@export var color: Color = Color.WHITE
@export var size_scale: float = 1.0
@export var lifetime: float = 0.22


func _ready() -> void:
	modulate = color
	rotation = randf() * TAU
	scale = Vector2.ONE * 0.4 * size_scale
	var tween := create_tween().set_parallel()
	tween.tween_property(self, "scale", Vector2.ONE * 1.15 * size_scale, lifetime) \
		.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.tween_property(self, "modulate:a", 0.0, lifetime).set_delay(lifetime * 0.3)
	tween.chain().tween_callback(ObjectPool.release.bind(self))
