## ============================================================
## 通用弹道（剑气 / 破天剑气 / 妖兽毒球）
## 直线飞行，命中带 take_damage 方法的目标造成伤害并生成命中特效；
## 碰撞检测目标由场景里的 collision_mask 决定（玩家攻击 / 敌人攻击）。
## 美术替换：场景中的 ArtSlot 节点设置贴图后会自动替换占位图形。
## ============================================================
extends Area2D

@export var speed: float = 520.0
@export var max_distance: float = 420.0
@export var damage: float = 8.0
@export var knockback_force: float = 160.0
@export var crit_chance: float = 0.0
@export var pierce: bool = false                   ## 是否贯穿目标
@export var pass_through_obstacles: bool = false   ## 是否无视障碍物
@export var hit_effect_scene: PackedScene          ## 命中特效（可为空）
@export var hit_color: Color = Color.WHITE         ## 命中特效颜色

var direction := Vector2.RIGHT
var traveled := 0.0
var finished := false
var hit_targets: Array[Node] = []


func _ready() -> void:
	# 对象池复用时重置运行时状态
	traveled = 0.0
	finished = false
	hit_targets.clear()
	monitoring = true
	rotation = direction.angle()
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	if finished:
		return
	var step := speed * delta
	position += direction * step
	traveled += step
	if traveled >= max_distance:
		_finish()


func _on_body_entered(body: Node2D) -> void:
	if finished or not is_instance_valid(body):
		return
	if body.has_method("take_damage"):
		if hit_targets.has(body):
			return
		# 目标处于无敌（如轻功冲刺）时直接穿过
		if body.has_method("is_invincible") and body.call("is_invincible"):
			return
		hit_targets.append(body)
		var is_crit := randf() < crit_chance
		var final_damage := roundf(damage * (1.6 if is_crit else 1.0))
		body.call("take_damage", final_damage, direction * knockback_force, is_crit)
		_spawn_hit_effect(body.global_position, Color(1.0, 0.85, 0.2) if is_crit else hit_color, is_crit)
		if is_crit:
			EventBus.hit_stop_requested.emit(0.04)
		if not pierce:
			_finish()
	elif not pass_through_obstacles:
		_spawn_hit_effect(global_position, hit_color.darkened(0.3), false)
		_finish()


func _spawn_hit_effect(world_position: Vector2, color: Color, is_big: bool) -> void:
	if hit_effect_scene == null:
		return
	var effect := ObjectPool.acquire(hit_effect_scene) as Node2D
	effect.position = world_position
	effect.set("color", color)
	effect.set("size_scale", 1.4 if is_big else 1.0)
	EventBus.spawn_effect_requested.emit(effect)


func _finish() -> void:
	finished = true
	set_deferred("monitoring", false)
	var tween := create_tween().set_parallel()
	tween.tween_property(self, "modulate:a", 0.0, 0.12)
	tween.tween_property(self, "scale", scale * 1.3, 0.12)
	tween.chain().tween_callback(ObjectPool.release.bind(self))
