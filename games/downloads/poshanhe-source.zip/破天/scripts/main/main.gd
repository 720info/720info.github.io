## ============================================================
## 游戏主场景控制器（组合根）
## 1. 进入场景时：新游戏 → 立即建立存档；继续游戏 → 读取存档恢复玩家与击杀记录
## 2. 把各模块通过 EventBus 发来的「生成请求」放进对应容器：
##      怪物 → Enemies，特效/弹道 → Effects，掉落物 → World/Pickups
##    统一使用 call_deferred 添加节点，避免在物理回调中修改场景树。
## ============================================================
extends Node2D

const MAX_EFFECTS := 160          # 特效/弹道同屏上限（超出时丢弃非关键特效）
const MAX_PICKUPS := 40           # 地面掉落物上限（超出时清理最早的）
const CLEANUP_INTERVAL := 5.0     # 闲置节点清理周期（秒）

@export var pickup_scene: PackedScene

var _cleanup_timer := CLEANUP_INTERVAL

@onready var player: Node2D = $Player
@onready var enemies_container: Node2D = $Enemies
@onready var effects_container: Node2D = $Effects
@onready var pickups_container: Node2D = $World/Pickups


func _ready() -> void:
	randomize()
	GameState.in_game = true
	EventBus.spawn_enemy_requested.connect(_on_spawn_enemy_requested)
	EventBus.spawn_effect_requested.connect(_on_spawn_effect_requested)
	EventBus.drop_item_requested.connect(_on_drop_item_requested)
	EventBus.bgm_requested.emit("field")
	_load_or_create_save()


func _load_or_create_save() -> void:
	if GameState.load_save_on_start:
		GameState.load_save_on_start = false
		var data := SaveManager.read_save()
		if not data.is_empty():
			player.call("apply_save_data", data.get("player", {}))
			GameState.apply_kill_data(data.get("kills", {}))
			GameState.play_time = float(data.get("play_time", 0.0))
			var saved_achievements = data.get("achievements", [])
			if saved_achievements is Array:
				AchievementManager.apply_save_data(saved_achievements)
			GameState.apply_cheat_data(data.get("cheat", {}))
			if GameState.map_transition:
				GameState.map_transition = false
				var spawn: Vector2 = MapDB.get_map(GameState.current_map)["size"] / 2.0
				player.global_position = spawn
				player.call("set_checkpoint", spawn)
				EventBus.toast("进入第 %d 图：%s · %s" % [
					GameState.current_map, MapDB.map_name(GameState.current_map),
					MapDB.get_map(GameState.current_map)["subtitle"],
				])
			else:
				EventBus.toast("读取存档成功，欢迎回来！")
			return
		EventBus.toast("存档读取失败，已开始新游戏")
	# 新游戏：等玩家初始化完成后建立第一份存档
	(func() -> void: SaveManager.save_game()).call_deferred()
	EventBus.toast("初入江湖，靠近石碑按 E 可存档")


func _on_spawn_enemy_requested(enemy: Node2D) -> void:
	enemies_container.add_child.call_deferred(enemy)


func _on_spawn_effect_requested(effect: Node2D) -> void:
	# 数量过多时丢弃装饰性特效（残影、命中火花、刀光、光环），弹道等关键节点照常生成
	if effects_container.get_child_count() >= MAX_EFFECTS and effect.is_in_group("low_priority_fx"):
		ObjectPool.release(effect)
		return
	effects_container.add_child.call_deferred(effect)


func _process(delta: float) -> void:
	_cleanup_timer -= delta
	if _cleanup_timer > 0.0:
		return
	_cleanup_timer = CLEANUP_INTERVAL
	_cleanup_idle_nodes()


## 清理闲置多余节点：地面掉落物过多时移除最早的
func _cleanup_idle_nodes() -> void:
	var pickups := pickups_container.get_children()
	for i in maxi(pickups.size() - MAX_PICKUPS, 0):
		pickups[i].queue_free()


func _on_drop_item_requested(item_id: String, world_position: Vector2) -> void:
	if pickup_scene == null:
		return
	var pickup := pickup_scene.instantiate() as Node2D
	pickup.set("item_id", item_id)
	pickup.position = world_position
	pickups_container.add_child.call_deferred(pickup)
