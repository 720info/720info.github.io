## ============================================================
## 玩家角色「一剑」（剑侠）
## 功能：
##   - WASD 八方向平滑移动，朝向跟随鼠标
##   - 鼠标左键三段普攻（前摇 → 判定 → 后摇，连招缓冲），伤害由装备武器决定
##   - 空格轻功冲刺（耗体力、冷却、无敌帧）
##   - 1~4 武功技能（连光剑 / 旋光斩 / 飞身斩 / 破天一式）
##   - 背包：拾取进包，界面点击使用药品 / 更换武器
##   - 升级获得属性点，自选加点（生命 / 内力 / 体力）
##   - 受击闪红、死亡倒地、存档点复活、存档读档
## 状态机：IDLE / MOVE / ATTACK / DASH / CAST / LUNGE / DEAD
## 通信：对外只通过 EventBus 发信号 / 收请求，不直接引用 UI 或怪物节点
## ============================================================
extends CharacterBody2D

enum State { IDLE, MOVE, ATTACK, DASH, CAST, LUNGE, DEAD }

const SWORD_REST_ROTATION := 0.35       # 持剑待机角度（弧度），剑尖基本指向出招方向
const WEAPON_MUZZLE_DISTANCE := 26.0    # 剑气发射点：武器挂点前方（剑身中段）
const LUNGE_SPEED := 950.0              # 飞身斩突进速度
const LUNGE_DURATION := 0.22            # 飞身斩突进时间
const HURT_INVINCIBLE_TIME := 0.35      # 受击后短暂无敌
const RESPAWN_INVINCIBLE_TIME := 2.0    # 复活保护时间

@export_group("移动")
@export var max_speed: float = 230.0
@export var acceleration: float = 1800.0
@export var friction: float = 2000.0

@export_group("轻功冲刺")
@export var dash_speed: float = 680.0
@export var dash_duration: float = 0.18
@export var dash_cooldown: float = 0.45
@export var dash_stamina_cost: float = 30.0

@export_group("普攻连招")
@export var attack_windup: float = 0.08     # 前摇（会被武器攻速缩放）
@export var attack_recovery: float = 0.2    # 后摇（会被武器攻速缩放）
@export var combo_window: float = 0.45      # 连招衔接窗口
@export var attack_arc_degrees: float = 130.0

@export_group("场景资源")
@export var sword_wave_scene: PackedScene
@export var potian_wave_scene: PackedScene
@export var slash_effect_scene: PackedScene
@export var ring_effect_scene: PackedScene
@export var afterimage_scene: PackedScene
@export var hit_effect_scene: PackedScene

@onready var visual: Node2D = $Visual
@onready var pivot: Node2D = $Visual/Pivot
@onready var sword: Node2D = $Visual/Pivot/Sword
@onready var blade: Polygon2D = $Visual/Pivot/Sword/Blade

var state: State = State.IDLE

# —— 属性 ——
var max_hp: float
var max_mp: float
var max_stamina: float
var hp: float
var mp: float
var stamina: float
var level: int = 1
var current_exp: int = 0
var unspent_points: int = 0
var attribute_points := {"hp": 0, "mp": 0, "stamina": 0}
var inventory := Inventory.new(GameDB.INVENTORY_CAPACITY)
var weapon_id: String = GameDB.STARTING_WEAPON

# —— 朝向 / 位置 ——
var aim_direction := Vector2.RIGHT
var facing_direction := Vector2.RIGHT
var spawn_position := Vector2.ZERO      # 复活点（存档点会更新）
var walk_time := 0.0

# —— 普攻 ——
var combo_index := 0
var combo_timer := 0.0
var attack_timer := 0.0
var attack_hit_done := false
var attack_buffered := false

# —— 冲刺 / 突进 ——
var dash_timer := 0.0
var dash_cd_timer := 0.0
var dash_direction := Vector2.ZERO
var stamina_regen_delay := 0.0
var afterimage_timer := 0.0
var lunge_damage := 0.0
var lunge_hit_targets: Array[Node] = []

# —— 技能 / 受击 ——
var cast_timer := 0.0
var invincible_timer := 0.0
var skill_cooldowns: Array[float] = [0.0, 0.0, 0.0, 0.0]
var hint_cooldown := 0.0
var sword_tween: Tween
var flash_tween: Tween
var body_tween: Tween

# —— 性能：复用的查询对象与冷却数组，避免每帧分配 ——
var _query_shape := CircleShape2D.new()
var _query_params := PhysicsShapeQueryParameters2D.new()
var _cooldown_remaining: Array = [0.0, 0.0, 0.0, 0.0, 0.0]
var _cooldown_totals: Array = [0.0, 0.0, 0.0, 0.0, 0.0]
var _cooldowns_active := true


func _ready() -> void:
	add_to_group("player")
	spawn_position = global_position
	for item_id in GameDB.STARTING_ITEMS:
		inventory.add(item_id, GameDB.STARTING_ITEMS[item_id])
	_recalculate_stats()
	hp = max_hp
	mp = max_mp
	stamina = max_stamina
	sword.rotation = SWORD_REST_ROTATION
	_apply_weapon_visual()
	_query_params.shape = _query_shape
	_query_params.collision_mask = GameDB.LAYER_ENEMY
	_query_params.collide_with_bodies = true
	_query_params.collide_with_areas = false
	for i in GameDB.SKILLS.size():
		_cooldown_totals[i] = float(GameDB.SKILLS[i]["cooldown"])
	_cooldown_totals[4] = dash_cooldown
	EventBus.player_respawn_requested.connect(_on_respawn_requested)
	EventBus.enemy_killed.connect(_on_enemy_killed)
	EventBus.item_use_requested.connect(use_item_at)
	EventBus.attribute_point_requested.connect(spend_attribute_point)
	# 等 UI 全部就绪后再同步一次数值
	_broadcast_all.call_deferred()


func _physics_process(delta: float) -> void:
	_update_timers(delta)
	_update_aim()

	match state:
		State.IDLE, State.MOVE:
			_process_free_move(delta)
		State.ATTACK:
			_process_attack(delta)
		State.DASH:
			_process_dash(delta)
		State.CAST:
			_process_cast(delta)
		State.LUNGE:
			_process_lunge(delta)
		State.DEAD:
			velocity = velocity.move_toward(Vector2.ZERO, friction * delta)

	move_and_slide()
	_animate_body(delta)


# ============================================================
# 公共接口（鸭子类型调用：怪物弹道、道具、存档点、存档系统）
# ============================================================

func is_alive() -> bool:
	return state != State.DEAD


func is_invincible() -> bool:
	return invincible_timer > 0.0 or state == State.DASH or state == State.LUNGE


func take_damage(amount: float, knockback: Vector2 = Vector2.ZERO, _is_crit: bool = false) -> void:
	if GameState.cheat_infinite_hp:
		_set_hp(max_hp)
		return
	if state == State.DEAD or is_invincible():
		return
	_set_hp(hp - amount)
	EventBus.show_text("-%d" % int(amount), global_position + Vector2(0, -36), Color(1.0, 0.3, 0.3), 18)
	EventBus.shake(5.0, 0.15)
	EventBus.player_hurt.emit(amount)
	_flash(Color(1.0, 0.2, 0.2))
	velocity += knockback
	invincible_timer = HURT_INVINCIBLE_TIME
	if hp <= 0.0:
		_die()


## 道具靠近时询问能否拾取（背包满则不吸附）
func can_collect_item(item_id: String) -> bool:
	return state != State.DEAD and inventory.can_add(item_id)


## 拾取道具：放入背包
func collect_item(item_id: String) -> bool:
	if not can_collect_item(item_id):
		return false
	inventory.add(item_id, 1)
	var info := GameDB.get_item(item_id)
	EventBus.show_text("获得 %s" % info["name"], global_position + Vector2(0, -56), Color(0.95, 0.9, 0.6), 14)
	EventBus.item_picked.emit(item_id)
	_emit_inventory()
	return true


## 使用背包格子里的道具（药品回复 / 武器装备）
func use_item_at(slot_index: int) -> void:
	if state == State.DEAD:
		return
	var slot := inventory.get_slot(slot_index)
	if slot.is_empty():
		return
	var item_id: String = slot["id"]
	var info := GameDB.get_item(item_id)
	match info.get("type", ""):
		"consumable":
			if not _apply_consumable(info):
				_hint("状态已满，无需服用", Color(0.8, 0.8, 0.8))
				return
			inventory.remove_at(slot_index, 1)
		"weapon":
			# 换下的武器放回同一格
			var old_weapon := weapon_id
			inventory.remove_at(slot_index, 1)
			inventory.slots[slot_index] = {"id": old_weapon, "count": 1}
			weapon_id = item_id
			_apply_weapon_visual()
			_recalculate_stats()
			EventBus.show_text("装备 %s" % info["name"], global_position + Vector2(0, -56), info["color"], 16)
	EventBus.sfx("use_item")
	_emit_inventory()


## 属性加点
func spend_attribute_point(stat: String) -> void:
	if unspent_points <= 0 or not attribute_points.has(stat) or state == State.DEAD:
		return
	unspent_points -= 1
	attribute_points[stat] = int(attribute_points[stat]) + 1
	var old_max_hp := max_hp
	var old_max_mp := max_mp
	var old_max_stamina := max_stamina
	_recalculate_stats()
	# 上限提升的部分同时加到当前值
	_set_hp(hp + max_hp - old_max_hp)
	_set_mp(mp + max_mp - old_max_mp)
	_set_stamina(stamina + max_stamina - old_max_stamina)


## 存档点：设置复活点
func set_checkpoint(world_position: Vector2) -> void:
	spawn_position = world_position


## 存档点：调息回满
func restore_full() -> void:
	if state == State.DEAD:
		return
	_set_hp(max_hp)
	_set_mp(max_mp)
	_set_stamina(max_stamina)


func refresh_cheat_state() -> void:
	if state == State.DEAD:
		return
	if GameState.cheat_infinite_hp:
		_set_hp(max_hp)
	if GameState.cheat_infinite_mp:
		_set_mp(max_mp)
	if GameState.cheat_infinite_stamina:
		_set_stamina(max_stamina)
	if GameState.cheat_no_cooldown:
		for i in skill_cooldowns.size():
			skill_cooldowns[i] = 0.0
			_cooldown_remaining[i] = 0.0
		_cooldown_remaining[4] = dash_cd_timer
		_cooldowns_active = dash_cd_timer > 0.0
		EventBus.skill_cooldowns_updated.emit(_cooldown_remaining, _cooldown_totals)
	_emit_stats()


## 作弊：增加经验（可触发连续升级）
func cheat_add_exp(amount: int) -> void:
	if state == State.DEAD or amount <= 0:
		return
	_gain_exp(amount)


## 作弊：直接升 1 级
func cheat_level_up() -> void:
	if state == State.DEAD:
		return
	cheat_add_exp(GameDB.exp_to_next_level(level) - current_exp)


## 作弊：发放道具入包，返回实际放入数量
func cheat_give_item(item_id: String, count: int = 1) -> int:
	var added := inventory.add(item_id, count)
	if added > 0:
		var info := GameDB.get_item(item_id)
		EventBus.show_text("获得 %s ×%d" % [info["name"], added], global_position + Vector2(0, -56), Color(0.95, 0.9, 0.6), 14)
		EventBus.item_picked.emit(item_id)
		_emit_inventory()
	return added


func get_save_data() -> Dictionary:
	return {
		"position": [global_position.x, global_position.y],
		"spawn_position": [spawn_position.x, spawn_position.y],
		"level": level,
		"exp": current_exp,
		"hp": hp,
		"mp": mp,
		"stamina": stamina,
		"unspent_points": unspent_points,
		"attribute_points": attribute_points.duplicate(),
		"weapon": weapon_id,
		"inventory": inventory.to_array(),
	}


func apply_save_data(data: Dictionary) -> void:
	level = maxi(int(data.get("level", 1)), 1)
	current_exp = maxi(int(data.get("exp", 0)), 0)
	unspent_points = maxi(int(data.get("unspent_points", 0)), 0)
	var saved_points: Dictionary = data.get("attribute_points", {})
	for key in attribute_points:
		attribute_points[key] = maxi(int(saved_points.get(key, 0)), 0)
	var saved_weapon := str(data.get("weapon", GameDB.STARTING_WEAPON))
	weapon_id = saved_weapon if GameDB.is_weapon(saved_weapon) else GameDB.STARTING_WEAPON
	var saved_inventory = data.get("inventory", [])
	if saved_inventory is Array:
		inventory.from_array(saved_inventory)
	global_position = _array_to_vector(data.get("position"), global_position)
	spawn_position = _array_to_vector(data.get("spawn_position"), spawn_position)
	_recalculate_stats()
	hp = clampf(float(data.get("hp", max_hp)), 1.0, max_hp)
	mp = clampf(float(data.get("mp", max_mp)), 0.0, max_mp)
	stamina = clampf(float(data.get("stamina", max_stamina)), 0.0, max_stamina)
	_apply_weapon_visual()
	_broadcast_all()
	EventBus.player_respawned.emit()   # 通知相机立即对准新位置


# ============================================================
# 状态处理
# ============================================================

func _process_free_move(delta: float) -> void:
	var move_input := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if move_input != Vector2.ZERO:
		velocity = velocity.move_toward(move_input * max_speed * GameState.cheat_speed_multiplier, acceleration * delta)
		state = State.MOVE
	else:
		velocity = velocity.move_toward(Vector2.ZERO, friction * delta)
		state = State.IDLE

	if _handle_action_input():
		return
	if Input.is_action_pressed("attack") and not _is_pointer_over_ui():
		_start_attack()


func _process_attack(delta: float) -> void:
	attack_timer += delta
	velocity = velocity.move_toward(Vector2.ZERO, friction * delta)
	if Input.is_action_just_pressed("attack") and not _is_pointer_over_ui():
		attack_buffered = true

	# 出招判定之后允许用轻功或技能取消后摇
	if attack_hit_done and _handle_action_input():
		return

	var windup := _attack_windup()
	if not attack_hit_done and attack_timer >= windup:
		attack_hit_done = true
		_do_attack_hit()

	var recovery := _attack_recovery() * (1.6 if combo_index == 2 else 1.0)
	if attack_timer >= windup + recovery:
		combo_index = (combo_index + 1) % 3
		combo_timer = combo_window
		if attack_buffered or (Input.is_action_pressed("attack") and not _is_pointer_over_ui()):
			_start_attack()
		else:
			state = State.IDLE
			_reset_sword(true)


func _process_dash(delta: float) -> void:
	velocity = dash_direction * dash_speed
	dash_timer -= delta
	_emit_afterimages(delta)
	if dash_timer <= 0.0:
		velocity = dash_direction * max_speed
		state = State.IDLE


func _process_cast(delta: float) -> void:
	velocity = velocity.move_toward(Vector2.ZERO, friction * delta)
	cast_timer -= delta
	if cast_timer <= 0.0:
		state = State.IDLE
		_reset_sword(true)


func _process_lunge(delta: float) -> void:
	velocity = dash_direction * LUNGE_SPEED
	dash_timer -= delta
	_emit_afterimages(delta)
	for enemy in _query_enemies(global_position + dash_direction * 12.0, 44.0):
		if lunge_hit_targets.has(enemy):
			continue
		lunge_hit_targets.append(enemy)
		_deal_damage(enemy, lunge_damage, dash_direction * 320.0, GameDB.SKILLS[2]["color"])
	if dash_timer <= 0.0 or (get_slide_collision_count() > 0 and dash_timer < LUNGE_DURATION * 0.5):
		velocity = dash_direction * max_speed * 0.5
		state = State.IDLE
		_spawn_slash(_weapon_direction(), false, Color(1.0, 0.8, 0.4, 0.85))
		_reset_sword(true)


## 统一处理轻功 / 技能按键，返回 true 表示状态已被切换
func _handle_action_input() -> bool:
	if Input.is_action_just_pressed("dash") and _try_dash():
		return true
	for i in 4:
		if Input.is_action_just_pressed("skill_%d" % (i + 1)) and _try_cast_skill(i):
			return true
	return false


## 鼠标悬停在可交互界面上时不出招，避免点击背包时误触攻击
func _is_pointer_over_ui() -> bool:
	return get_viewport().gui_get_hovered_control() != null


# ============================================================
# 普攻
# ============================================================

func _start_attack() -> void:
	if combo_timer <= 0.0:
		combo_index = 0
	state = State.ATTACK
	attack_timer = 0.0
	attack_hit_done = false
	attack_buffered = false
	facing_direction = aim_direction
	pivot.rotation = facing_direction.angle()   # 先转动武器，再以武器朝向出招
	velocity = _weapon_direction() * (140.0 if combo_index == 2 else 80.0)
	_play_sword_swing(combo_index)
	EventBus.sfx("attack")


func _do_attack_hit() -> void:
	var weapon := GameDB.get_item(weapon_id)
	var damage: float = float(weapon["attack"]) * float(GameDB.COMBO_MULTIPLIERS[combo_index])
	var reach := float(weapon["range"]) * (1.2 if combo_index == 2 else 1.0)
	var knockback_force := (260.0 if combo_index == 2 else 140.0) * float(weapon["knockback"])
	var half_arc := deg_to_rad(attack_arc_degrees) * 0.5
	var weapon_direction := _weapon_direction()
	var hit_any := false
	for enemy in _query_enemies(global_position, reach):
		var to_enemy := enemy.global_position - global_position
		if to_enemy.length() > 20.0 and absf(weapon_direction.angle_to(to_enemy)) > half_arc:
			continue
		_deal_damage(enemy, damage, to_enemy.normalized() * knockback_force, Color(1, 1, 1))
		hit_any = true
	_spawn_slash(weapon_direction, combo_index == 1, Color(weapon["color"]).lightened(0.4))
	if hit_any and combo_index == 2:
		EventBus.shake(3.0, 0.1)
		EventBus.hit_stop_requested.emit(0.05)


func _attack_windup() -> float:
	return attack_windup / float(GameDB.get_item(weapon_id)["attack_speed"])


func _attack_recovery() -> float:
	return attack_recovery / float(GameDB.get_item(weapon_id)["attack_speed"])


func _play_sword_swing(index: int) -> void:
	_reset_sword(false)
	sword_tween = create_tween()
	var duration := _attack_windup() + 0.08
	match index:
		0:
			sword.rotation = deg_to_rad(-85)
			sword_tween.tween_property(sword, "rotation", deg_to_rad(85), duration) \
				.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		1:
			sword.rotation = deg_to_rad(85)
			sword_tween.tween_property(sword, "rotation", deg_to_rad(-85), duration) \
				.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		_:
			# 第三段：直刺
			sword.rotation = 0.0
			sword.position = Vector2(-10, 0)
			sword_tween.tween_property(sword, "position", Vector2(16, 0), duration) \
				.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


# ============================================================
# 轻功
# ============================================================

func _try_dash() -> bool:
	if dash_cd_timer > 0.0:
		return false
	if not GameState.cheat_infinite_stamina and stamina < dash_stamina_cost:
		_hint("体力不足", Color(1.0, 0.85, 0.3))
		return false
	if not GameState.cheat_infinite_stamina:
		_set_stamina(stamina - dash_stamina_cost)
		stamina_regen_delay = 0.6
	dash_cd_timer = dash_cooldown
	var move_input := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	dash_direction = move_input.normalized() if move_input != Vector2.ZERO else aim_direction
	dash_timer = dash_duration
	afterimage_timer = 0.0
	state = State.DASH
	_reset_sword(false)
	EventBus.sfx("dash")
	return true


func _emit_afterimages(delta: float) -> void:
	afterimage_timer -= delta
	if afterimage_timer > 0.0 or afterimage_scene == null:
		return
	afterimage_timer = 0.03
	var image := ObjectPool.acquire(afterimage_scene) as Node2D
	image.position = global_position
	EventBus.spawn_effect_requested.emit(image)


# ============================================================
# 武功技能
# ============================================================

func _try_cast_skill(index: int) -> bool:
	var data: Dictionary = GameDB.SKILLS[index]
	if not GameState.cheat_no_cooldown and skill_cooldowns[index] > 0.0:
		_hint("%s 冷却中" % data["name"], Color(0.8, 0.8, 0.8))
		return false
	if not GameState.cheat_infinite_mp and mp < float(data["mp_cost"]):
		_hint("内力不足", Color(0.4, 0.6, 1.0))
		return false

	if not GameState.cheat_infinite_mp:
		_set_mp(mp - float(data["mp_cost"]))
	if not GameState.cheat_no_cooldown:
		skill_cooldowns[index] = float(data["cooldown"])
	facing_direction = aim_direction
	pivot.rotation = facing_direction.angle()
	_reset_sword(false)
	EventBus.skill_cast.emit(index)
	EventBus.show_text(data["name"], global_position + Vector2(0, -52), data["color"], 20)

	match data["id"]:
		"lianguang":
			_cast_lianguang(data)
		"xuanguang":
			_cast_xuanguang(data)
		"feishen":
			_cast_feishen(data)
		"potian":
			_cast_potian(data)
	return true


## 技能伤害 = 基础 + 武器攻击 × 系数（等级成长在 _deal_damage 中统一乘）
func _skill_damage(data: Dictionary) -> float:
	return float(data["base_damage"]) + float(data["weapon_scale"]) * float(GameDB.get_item(weapon_id)["attack"])


## 1 连光剑：连续三道剑气
func _cast_lianguang(data: Dictionary) -> void:
	state = State.CAST
	cast_timer = float(data["cast_time"])
	velocity = Vector2.ZERO
	var spreads := [-6.0, 0.0, 6.0]
	for i in 3:
		# process_always = false：暂停时计时器也暂停；方向在发射瞬间按武器朝向计算
		var timer := get_tree().create_timer(0.09 * i, false)
		timer.timeout.connect(_fire_wave.bind(sword_wave_scene, deg_to_rad(spreads[i]), _skill_damage(data), data["color"]))
		timer.timeout.connect(_quick_sword_flick.bind(i))


## 2 旋光斩：以自身为中心的圆形剑域
func _cast_xuanguang(data: Dictionary) -> void:
	state = State.CAST
	cast_timer = float(data["cast_time"])
	velocity = Vector2.ZERO
	var radius := float(data["radius"])
	var hit_any := false
	for enemy in _query_enemies(global_position, radius):
		var push := (enemy.global_position - global_position).normalized() * 300.0
		_deal_damage(enemy, _skill_damage(data), push, data["color"])
		hit_any = true
	_spawn_ring(radius, data["color"])
	EventBus.shake(4.0, 0.15)
	if hit_any:
		EventBus.hit_stop_requested.emit(0.06)
	sword_tween = create_tween()
	sword.rotation = 0.0
	sword_tween.tween_property(sword, "rotation", TAU * 2.0, float(data["cast_time"]))


## 3 飞身斩：向鼠标方向突进，沿途造成伤害
func _cast_feishen(data: Dictionary) -> void:
	state = State.LUNGE
	dash_direction = _weapon_direction()
	dash_timer = LUNGE_DURATION
	afterimage_timer = 0.0
	lunge_damage = _skill_damage(data)
	lunge_hit_targets.clear()
	sword.rotation = 0.0
	sword.position = Vector2(8, 0)


## 4 破天一式：蓄力后释放巨型贯穿剑气
func _cast_potian(data: Dictionary) -> void:
	state = State.CAST
	cast_timer = float(data["cast_time"])
	velocity = Vector2.ZERO
	sword_tween = create_tween().set_parallel()
	sword_tween.tween_property(sword, "rotation", deg_to_rad(-120), 0.4).set_ease(Tween.EASE_OUT)
	sword_tween.tween_property(sword, "modulate", Color(2.0, 1.5, 0.6), 0.4)
	_spawn_ring(60.0, Color(1.0, 0.8, 0.3))
	get_tree().create_timer(0.4, false).timeout.connect(_release_potian.bind(_skill_damage(data), data["color"]))


func _release_potian(damage: float, color: Color) -> void:
	if state == State.DEAD:
		return
	_reset_sword(false)
	sword_tween = create_tween()
	sword_tween.tween_property(sword, "rotation", deg_to_rad(60), 0.12)
	_fire_wave(potian_wave_scene, 0.0, damage, color)
	_spawn_ring(90.0, Color(1.0, 0.45, 0.25))
	EventBus.shake(10.0, 0.3)


func _fire_wave(scene: PackedScene, angle_offset: float, damage: float, color: Color) -> void:
	if state == State.DEAD or scene == null or not is_inside_tree():
		return
	var weapon := GameDB.get_item(weapon_id)
	var direction := _weapon_direction().rotated(angle_offset)
	var wave := ObjectPool.acquire(scene) as Node2D
	wave.position = _weapon_muzzle(direction)
	wave.set("direction", direction)
	wave.set("damage", damage * _damage_multiplier())
	wave.set("crit_chance", float(weapon["crit"]))
	wave.set("hit_effect_scene", hit_effect_scene)
	wave.set("hit_color", color)
	EventBus.spawn_effect_requested.emit(wave)


func _quick_sword_flick(index: int) -> void:
	if state == State.DEAD or not is_inside_tree():
		return
	if sword_tween and sword_tween.is_valid():
		sword_tween.kill()
	sword.rotation = deg_to_rad(-60.0 if index % 2 == 0 else 60.0)
	sword_tween = create_tween()
	sword_tween.tween_property(sword, "rotation", deg_to_rad(60.0 if index % 2 == 0 else -60.0), 0.08)


# ============================================================
# 战斗工具
# ============================================================

## 武器朝向：取剑的挂点 Pivot 的全局朝向（剑随 Pivot 旋转），近战与剑气都以此为准
func _weapon_direction() -> Vector2:
	return Vector2.from_angle(pivot.global_rotation)


## 剑气发射点：武器挂点前方，不随挥剑动画左右偏移
func _weapon_muzzle(direction: Vector2) -> Vector2:
	return pivot.global_position + direction * WEAPON_MUZZLE_DISTANCE


## 物理形状查询：获取圆形范围内的敌人（只检测「敌人」碰撞层）
func _query_enemies(center: Vector2, radius: float) -> Array[Node2D]:
	_query_shape.radius = radius
	_query_params.transform = Transform2D(0.0, center)
	var found: Array[Node2D] = []
	for result in get_world_2d().direct_space_state.intersect_shape(_query_params, 32):
		var collider = result.get("collider")
		if collider is Node2D and is_instance_valid(collider) and collider.has_method("take_damage") \
				and not found.has(collider):
			found.append(collider)
	return found


func _deal_damage(target: Node2D, base_damage: float, knockback: Vector2, effect_color: Color) -> void:
	if not is_instance_valid(target):
		return
	var is_crit := randf() < float(GameDB.get_item(weapon_id)["crit"])
	var damage := roundf(base_damage * _damage_multiplier() * (1.6 if is_crit else 1.0))
	target.call("take_damage", damage, knockback, is_crit)
	_spawn_hit_effect(target.global_position, effect_color if not is_crit else Color(1.0, 0.85, 0.2), is_crit)
	EventBus.sfx("hit")
	if is_crit:
		EventBus.hit_stop_requested.emit(0.05)


func _damage_multiplier() -> float:
	return (1.0 + GameDB.DAMAGE_GROWTH_PER_LEVEL * (level - 1)) * GameState.cheat_attack_multiplier


# ============================================================
# 属性 / 成长 / 背包
# ============================================================

func _recalculate_stats() -> void:
	max_hp = GameDB.PLAYER_BASE["max_hp"] + attribute_points["hp"] * GameDB.ATTRIBUTES["hp"]["per_point"]
	max_mp = GameDB.PLAYER_BASE["max_mp"] + attribute_points["mp"] * GameDB.ATTRIBUTES["mp"]["per_point"]
	max_stamina = GameDB.PLAYER_BASE["max_stamina"] \
		+ attribute_points["stamina"] * GameDB.ATTRIBUTES["stamina"]["per_point"]
	_emit_stats()


func _stamina_regen() -> float:
	return GameDB.PLAYER_BASE["stamina_regen"] + attribute_points["stamina"] * 1.5


func _update_timers(delta: float) -> void:
	combo_timer = maxf(combo_timer - delta, 0.0)
	dash_cd_timer = maxf(dash_cd_timer - delta, 0.0)
	hint_cooldown = maxf(hint_cooldown - delta, 0.0)
	var any_cooling := dash_cd_timer > 0.0
	for i in skill_cooldowns.size():
		skill_cooldowns[i] = maxf(skill_cooldowns[i] - delta, 0.0)
		_cooldown_remaining[i] = skill_cooldowns[i]
		any_cooling = any_cooling or skill_cooldowns[i] > 0.0
	_cooldown_remaining[4] = dash_cd_timer   # 第 5 格为轻功冷却
	# 只在有技能冷却中（以及刚结束的那一帧）才通知 UI，全部就绪时不再每帧广播
	if any_cooling or _cooldowns_active:
		EventBus.skill_cooldowns_updated.emit(_cooldown_remaining, _cooldown_totals)
	_cooldowns_active = any_cooling

	if invincible_timer > 0.0:
		invincible_timer -= delta
		visual.visible = invincible_timer <= 0.0 or fmod(invincible_timer, 0.12) > 0.05

	if state == State.DEAD:
		return
	if GameState.cheat_infinite_hp:
		_set_hp(max_hp)
	elif hp < max_hp:
		_set_hp(hp + GameDB.PLAYER_BASE["hp_regen"] * delta)
	if GameState.cheat_infinite_mp:
		_set_mp(max_mp)
	elif mp < max_mp:
		_set_mp(mp + GameDB.PLAYER_BASE["mp_regen"] * delta)
	if GameState.cheat_infinite_stamina:
		_set_stamina(max_stamina)
	elif stamina_regen_delay > 0.0:
		stamina_regen_delay -= delta
	elif stamina < max_stamina:
		_set_stamina(stamina + _stamina_regen() * delta)


func _apply_consumable(info: Dictionary) -> bool:
	var restore_hp := float(info.get("restore_hp", 0.0))
	var restore_mp := float(info.get("restore_mp", 0.0))
	var useful := (restore_hp > 0.0 and hp < max_hp) or (restore_mp > 0.0 and mp < max_mp)
	if not useful:
		return false
	if restore_hp > 0.0:
		_set_hp(hp + restore_hp)
		EventBus.show_text("+%d" % int(restore_hp), global_position + Vector2(-14, -36), Color(0.4, 1.0, 0.4), 18)
	if restore_mp > 0.0:
		_set_mp(mp + restore_mp)
		EventBus.show_text("+%d" % int(restore_mp), global_position + Vector2(14, -36), Color(0.45, 0.65, 1.0), 18)
	return true


func _on_enemy_killed(_enemy_type: String, exp_reward: int, _world_position: Vector2) -> void:
	if state == State.DEAD:
		return
	_gain_exp(exp_reward)


## 获得经验并处理连续升级（击杀与作弊加经验共用）
func _gain_exp(amount: int) -> void:
	current_exp += amount
	var leveled := false
	while current_exp >= GameDB.exp_to_next_level(level):
		current_exp -= GameDB.exp_to_next_level(level)
		_level_up()
		leveled = true
	EventBus.player_exp_changed.emit(level, current_exp, GameDB.exp_to_next_level(level))
	if leveled:
		EventBus.player_level_up.emit(level)


func _level_up() -> void:
	level += 1
	unspent_points += GameDB.POINTS_PER_LEVEL
	_recalculate_stats()
	_set_hp(max_hp)
	_set_mp(max_mp)
	EventBus.show_text("升级！等级 %d" % level, global_position + Vector2(0, -70), Color(1.0, 0.85, 0.2), 26)
	EventBus.toast("获得 %d 点属性点，按 C 分配" % GameDB.POINTS_PER_LEVEL)
	_spawn_ring(100.0, Color(1.0, 0.85, 0.3))


## 自然回复每帧都会改变数值；只有显示的整数变化或到达上下限时才通知 UI
func _set_hp(value: float) -> void:
	var old := hp
	hp = clampf(value, 0.0, max_hp)
	if _display_changed(old, hp, max_hp):
		EventBus.player_hp_changed.emit(hp, max_hp)


func _set_mp(value: float) -> void:
	var old := mp
	mp = clampf(value, 0.0, max_mp)
	if _display_changed(old, mp, max_mp):
		EventBus.player_mp_changed.emit(mp, max_mp)


func _set_stamina(value: float) -> void:
	var old := stamina
	stamina = clampf(value, 0.0, max_stamina)
	if _display_changed(old, stamina, max_stamina):
		EventBus.player_stamina_changed.emit(stamina, max_stamina)


func _display_changed(old_value: float, new_value: float, maximum: float) -> bool:
	return ceili(old_value) != ceili(new_value) or new_value <= 0.0 or is_equal_approx(new_value, maximum)


func _emit_stats() -> void:
	var weapon := GameDB.get_item(weapon_id)
	EventBus.player_stats_changed.emit({
		"level": level,
		"unspent_points": unspent_points,
		"attribute_points": attribute_points.duplicate(),
		"max_hp": max_hp,
		"max_mp": max_mp,
		"max_stamina": max_stamina,
		"weapon_id": weapon_id,
		"attack": float(weapon["attack"]),
		"attack_speed": float(weapon["attack_speed"]),
		"crit": float(weapon["crit"]),
		"damage_multiplier": _damage_multiplier(),
	})


func _emit_inventory() -> void:
	EventBus.inventory_changed.emit(inventory.to_array(), inventory.capacity)
	_emit_stats()


func _broadcast_all() -> void:
	EventBus.player_hp_changed.emit(hp, max_hp)
	EventBus.player_mp_changed.emit(mp, max_mp)
	EventBus.player_stamina_changed.emit(stamina, max_stamina)
	EventBus.player_exp_changed.emit(level, current_exp, GameDB.exp_to_next_level(level))
	_emit_inventory()


# ============================================================
# 死亡 / 复活
# ============================================================

func _die() -> void:
	state = State.DEAD
	velocity = Vector2.ZERO
	invincible_timer = 0.0
	visual.visible = true
	_reset_sword(false)
	if flash_tween and flash_tween.is_valid():
		flash_tween.kill()
	if body_tween and body_tween.is_valid():
		body_tween.kill()
	# 倒地：身体侧倒并变灰
	body_tween = create_tween().set_parallel()
	body_tween.tween_property(visual, "rotation", PI * 0.5, 0.35).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	body_tween.tween_property(visual, "modulate", Color(0.45, 0.45, 0.45), 0.35)
	EventBus.show_text("重伤倒地", global_position + Vector2(0, -60), Color(1.0, 0.3, 0.3), 24)
	EventBus.player_died.emit()


func _on_respawn_requested() -> void:
	if state != State.DEAD:
		return
	if body_tween and body_tween.is_valid():
		body_tween.kill()
	# 死亡惩罚：损失当前经验的一部分
	var lost_exp := int(current_exp * GameDB.DEATH_EXP_PENALTY)
	current_exp -= lost_exp
	global_position = spawn_position
	velocity = Vector2.ZERO
	visual.rotation = 0.0
	visual.modulate = Color.WHITE
	hp = max_hp
	mp = max_mp
	stamina = max_stamina
	combo_index = 0
	combo_timer = 0.0
	for i in skill_cooldowns.size():
		skill_cooldowns[i] = 0.0
	state = State.IDLE
	invincible_timer = RESPAWN_INVINCIBLE_TIME
	_reset_sword(false)
	_broadcast_all()
	_spawn_ring(80.0, Color(0.6, 1.0, 0.9))
	EventBus.show_text("重振旗鼓！", global_position + Vector2(0, -60), Color(0.6, 1.0, 0.9), 22)
	if lost_exp > 0:
		EventBus.toast("损失 %d 点经验" % lost_exp)
	EventBus.player_respawned.emit()


# ============================================================
# 表现
# ============================================================

func _update_aim() -> void:
	if state == State.DEAD:
		return
	var to_mouse := get_global_mouse_position() - global_position
	if to_mouse.length() > 4.0:
		aim_direction = to_mouse.normalized()
	if state == State.IDLE or state == State.MOVE or state == State.DASH:
		facing_direction = aim_direction
	pivot.rotation = facing_direction.angle()


func _animate_body(delta: float) -> void:
	if state == State.MOVE:
		walk_time += delta * 14.0
		visual.position.y = -absf(sin(walk_time)) * 2.5
	else:
		visual.position.y = move_toward(visual.position.y, 0.0, delta * 20.0)


## 武器外观：剑身颜色 / 长度随武器变化
func _apply_weapon_visual() -> void:
	var weapon := GameDB.get_item(weapon_id)
	blade.color = weapon["color"]
	sword.scale = Vector2(float(weapon["range"]) / 64.0, 1.0 + (float(weapon["knockback"]) - 1.0) * 0.6)


func _reset_sword(smooth: bool) -> void:
	if sword_tween and sword_tween.is_valid():
		sword_tween.kill()
	sword.modulate = Color.WHITE
	if smooth:
		sword_tween = create_tween().set_parallel()
		sword_tween.tween_property(sword, "rotation", SWORD_REST_ROTATION, 0.12)
		sword_tween.tween_property(sword, "position", Vector2.ZERO, 0.12)
	else:
		sword.rotation = SWORD_REST_ROTATION
		sword.position = Vector2.ZERO


func _flash(color: Color) -> void:
	if flash_tween and flash_tween.is_valid():
		flash_tween.kill()
	visual.modulate = color
	flash_tween = create_tween()
	flash_tween.tween_property(visual, "modulate", Color.WHITE, 0.25)


func _spawn_slash(direction: Vector2, flipped: bool, color: Color) -> void:
	if slash_effect_scene == null:
		return
	var slash := ObjectPool.acquire(slash_effect_scene) as Node2D
	slash.position = global_position
	slash.rotation = direction.angle()
	slash.scale = Vector2(1.0, -1.0 if flipped else 1.0)
	slash.modulate = color
	EventBus.spawn_effect_requested.emit(slash)


func _spawn_ring(radius: float, color: Color) -> void:
	if ring_effect_scene == null:
		return
	var ring := ObjectPool.acquire(ring_effect_scene) as Node2D
	ring.position = global_position
	ring.set("max_radius", radius)
	ring.set("color", color)
	EventBus.spawn_effect_requested.emit(ring)


func _spawn_hit_effect(world_position: Vector2, color: Color, is_big: bool) -> void:
	if hit_effect_scene == null:
		return
	var effect := ObjectPool.acquire(hit_effect_scene) as Node2D
	effect.position = world_position + Vector2(randf_range(-6, 6), randf_range(-8, 4))
	effect.set("color", color)
	effect.set("size_scale", 1.4 if is_big else 1.0)
	EventBus.spawn_effect_requested.emit(effect)


func _hint(text: String, color: Color) -> void:
	if hint_cooldown > 0.0:
		return
	hint_cooldown = 0.6
	EventBus.show_text(text, global_position + Vector2(0, -50), color, 16)


func _array_to_vector(value, fallback: Vector2) -> Vector2:
	if value is Array and value.size() >= 2:
		return Vector2(float(value[0]), float(value[1]))
	return fallback
