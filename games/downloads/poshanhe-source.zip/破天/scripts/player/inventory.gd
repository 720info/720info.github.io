## ============================================================
## 背包数据（纯数据类，不含界面）
## 格子为 {"id": 道具ID, "count": 数量} 或空字典；消耗品可堆叠，武器不堆叠。
## ============================================================
class_name Inventory
extends RefCounted

var capacity: int
var slots: Array[Dictionary] = []


func _init(slot_capacity: int = 20) -> void:
	capacity = slot_capacity
	clear()


func clear() -> void:
	slots.clear()
	for i in capacity:
		slots.append({})


## 是否还能放入该道具
func can_add(item_id: String) -> bool:
	var info := GameDB.get_item(item_id)
	if info.is_empty():
		return false
	var max_stack := int(info.get("stack", 1))
	for slot in slots:
		if slot.is_empty():
			return true
		if slot["id"] == item_id and int(slot["count"]) < max_stack:
			return true
	return false


## 放入道具，返回实际放入数量
func add(item_id: String, count: int = 1) -> int:
	var info := GameDB.get_item(item_id)
	if info.is_empty():
		return 0
	var max_stack := int(info.get("stack", 1))
	var remaining := count
	# 先叠加到已有格子
	for slot in slots:
		if remaining <= 0:
			break
		if not slot.is_empty() and slot["id"] == item_id and int(slot["count"]) < max_stack:
			var added := mini(max_stack - int(slot["count"]), remaining)
			slot["count"] = int(slot["count"]) + added
			remaining -= added
	# 再放入空格子
	for i in slots.size():
		if remaining <= 0:
			break
		if slots[i].is_empty():
			var added := mini(max_stack, remaining)
			slots[i] = {"id": item_id, "count": added}
			remaining -= added
	return count - remaining


## 从指定格子移除数量
func remove_at(index: int, count: int = 1) -> void:
	if index < 0 or index >= slots.size() or slots[index].is_empty():
		return
	var left := int(slots[index]["count"]) - count
	if left <= 0:
		slots[index] = {}
	else:
		slots[index]["count"] = left


func get_slot(index: int) -> Dictionary:
	if index < 0 or index >= slots.size():
		return {}
	return slots[index]


## 序列化（存档用）
func to_array() -> Array:
	var result: Array = []
	for slot in slots:
		result.append(slot.duplicate())
	return result


## 反序列化（读档用），忽略不存在的道具ID
func from_array(data: Array) -> void:
	clear()
	for i in mini(data.size(), capacity):
		var entry = data[i]
		if entry is Dictionary and entry.has("id") and not GameDB.get_item(str(entry["id"])).is_empty():
			slots[i] = {"id": str(entry["id"]), "count": maxi(int(entry.get("count", 1)), 1)}
