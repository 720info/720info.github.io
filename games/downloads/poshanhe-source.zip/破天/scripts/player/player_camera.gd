## ============================================================
## 玩家跟随相机
## 平滑跟随玩家，监听 EventBus 的震屏请求；复活时瞬移不平滑。
## ============================================================
extends Camera2D

var shake_strength := 0.0
var shake_time := 0.0


func _ready() -> void:
	var map_size: Vector2 = MapDB.get_map(GameState.current_map)["size"]
	limit_right = int(map_size.x)
	limit_bottom = int(map_size.y)
	EventBus.camera_shake_requested.connect(_on_shake_requested)
	EventBus.player_respawned.connect(reset_smoothing)


func _process(delta: float) -> void:
	if shake_time > 0.0:
		shake_time -= delta
		offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake_strength
		shake_strength = move_toward(shake_strength, 0.0, 30.0 * delta)
	else:
		offset = Vector2.ZERO
		shake_strength = 0.0


func _on_shake_requested(strength: float, duration: float) -> void:
	shake_strength = maxf(shake_strength, strength)
	shake_time = maxf(shake_time, duration)
