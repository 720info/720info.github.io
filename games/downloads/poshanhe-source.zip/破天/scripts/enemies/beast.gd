## ============================================================
## 妖兽（远程）
## 与玩家保持距离，鼓起身体蓄力后吐出毒球；玩家贴近时会后退。
## ============================================================
extends EnemyBase

@export var projectile_scene: PackedScene
@export var retreat_distance: float = 110.0

@onready var body: Node2D = $Visual/Body

var body_tween: Tween


func _get_chase_velocity(to_target: Vector2, distance: float) -> Vector2:
	if distance > attack_range * 0.85:
		return to_target.normalized() * move_speed
	if distance < retreat_distance:
		return -to_target.normalized() * move_speed * 0.8
	return Vector2.ZERO


func _on_attack_windup_started() -> void:
	_kill_body_tween()
	body_tween = create_tween()
	body_tween.tween_property(body, "scale", Vector2(1.3, 1.3), attack_windup).set_ease(Tween.EASE_OUT)


func _perform_attack() -> void:
	_kill_body_tween()
	body_tween = create_tween()
	body_tween.tween_property(body, "scale", Vector2.ONE, 0.15)
	if target == null or not is_instance_valid(target) or projectile_scene == null:
		return
	var direction := (target.global_position - global_position).normalized()
	var ball := ObjectPool.acquire(projectile_scene) as Node2D
	ball.position = global_position + direction * 18.0
	ball.set("direction", direction)
	ball.set("damage", attack_damage)
	EventBus.spawn_effect_requested.emit(ball)


func _on_hurt() -> void:
	_kill_body_tween()
	body.scale = Vector2.ONE


func _kill_body_tween() -> void:
	if body_tween and body_tween.is_valid():
		body_tween.kill()


func _on_spawn_reset() -> void:
	_on_hurt()
