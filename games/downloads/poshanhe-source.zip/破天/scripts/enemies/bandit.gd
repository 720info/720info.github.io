## ============================================================
## 山贼（近战）
## 靠近玩家后举刀蓄力（前摇预警），然后向前劈砍。
## ============================================================
extends EnemyBase

const WEAPON_REST_ROTATION := 0.7

@onready var weapon: Node2D = $Visual/Pivot/Weapon

var weapon_tween: Tween


func _on_attack_windup_started() -> void:
	_kill_weapon_tween()
	weapon_tween = create_tween().set_parallel()
	weapon_tween.tween_property(weapon, "rotation", deg_to_rad(-110), attack_windup).set_ease(Tween.EASE_OUT)
	weapon_tween.tween_property(weapon, "modulate", Color(1.8, 0.6, 0.6), attack_windup)


func _perform_attack() -> void:
	_kill_weapon_tween()
	weapon.modulate = Color.WHITE
	weapon_tween = create_tween()
	weapon_tween.tween_property(weapon, "rotation", deg_to_rad(80), 0.1).set_trans(Tween.TRANS_CUBIC)
	weapon_tween.tween_property(weapon, "rotation", WEAPON_REST_ROTATION, 0.25)
	if target == null or not is_instance_valid(target):
		return
	var to_target := target.global_position - global_position
	# 劈砍判定：距离 + 前方扇形
	if to_target.length() <= attack_range + 16.0 and absf(facing.angle_to(to_target)) < deg_to_rad(75):
		target.call("take_damage", attack_damage, to_target.normalized() * 220.0, false)


func _on_hurt() -> void:
	_kill_weapon_tween()
	weapon.rotation = WEAPON_REST_ROTATION
	weapon.modulate = Color.WHITE


func _kill_weapon_tween() -> void:
	if weapon_tween and weapon_tween.is_valid():
		weapon_tween.kill()


func _on_spawn_reset() -> void:
	_on_hurt()
