## ============================================================
## 怪物基类
## AI 状态机：巡逻 PATROL → 发现玩家 CHASE → 进入范围 ATTACK
##          受击 HURT（受击停顿 → 击退、打断出招）→ 死亡 DEAD（淡出、掉落）
##          追出领地太远 RETURN（回家并回血）
## 防卡墙：移动前用 test_move 探测前方，被挡住时尝试左右偏转绕行；
##        长时间原地不动时强制换方向绕行。
## 子类只需重写：_get_chase_velocity / _on_attack_windup_started /
##              _perform_attack / _on_hurt，即可做出不同的怪物。
## 通信：击杀、掉落、飘字全部通过 EventBus；通过 "player" 分组寻找玩家。
## ============================================================
class_name EnemyBase
extends CharacterBody2D

enum State { PATROL, CHASE, ATTACK, HURT, RETURN, DEAD }

const HIT_FREEZE_TIME := 0.07        # 受击停顿时长
const STEER_PROBE_DISTANCE := 22.0   # 转向探测距离
const STEER_ANGLES := [35.0, 70.0, 105.0, 140.0]
const STUCK_CHECK_TIME := 0.8        # 卡住检测周期
const STUCK_MIN_DISTANCE := 8.0      # 周期内移动距离低于该值视为卡住
const TARGET_REFRESH_INTERVAL := 0.2 # 重新确认玩家状态的间隔（不必每帧查询分组）
const STEER_REFRESH_INTERVAL := 0.1  # 转向探测间隔（test_move 较贵，结果短时间复用）
const SLEEP_DISTANCE := 1100.0       # 离玩家超过该距离且在巡逻时进入低频更新
const SLEEP_TICK := 0.5              # 低频更新间隔

@export_group("基础属性")
@export var enemy_type: String = "怪物"   ## 怪物种类名（击杀统计用）
@export var max_hp: float = 30.0
@export var exp_reward: int = 10

@export_group("移动")
@export var move_speed: float = 85.0
@export var patrol_speed: float = 40.0
@export var patrol_radius: float = 100.0
@export var leash_range: float = 650.0    ## 离开出生点超过该距离会放弃追击回家

@export_group("感知")
@export var detect_range: float = 230.0
@export var lose_range: float = 420.0

@export_group("攻击")
@export var attack_range: float = 42.0
@export var attack_damage: float = 8.0
@export var attack_windup: float = 0.45
@export var attack_recovery: float = 0.4
@export var attack_cooldown: float = 1.2

@export_group("掉落")
## 物品ID → 掉落概率。按顺序判定，每只怪最多掉落一件（稀有物品请放前面）
@export var drop_table: Dictionary = {"hp_potion": 0.3, "mp_potion": 0.25}

@onready var visual: Node2D = $Visual
@onready var pivot: Node2D = $Visual/Pivot
@onready var hp_bar: Node2D = $HpBar
@onready var hp_fill: ColorRect = $HpBar/Fill
@onready var name_label: Label = $HpBar/NameLabel
@onready var collision_shape: CollisionShape2D = $CollisionShape2D

var level := 1
var hp: float
var state: State = State.PATROL
var target: Node2D = null
var home_position := Vector2.ZERO
var patrol_target := Vector2.ZERO
var patrol_wait := 0.0
var state_timer := 0.0
var attack_cd_timer := 0.0
var attack_performed := false
var knockback_velocity := Vector2.ZERO
var facing := Vector2.RIGHT
var hp_bar_width := 32.0
var flash_tween: Tween

# —— 受击停顿 / 防卡墙 ——
var hit_freeze_timer := 0.0
var steer_side := 1.0
var stuck_timer := 0.0
var stuck_check_position := Vector2.ZERO
var detour_timer := 0.0
var detour_direction := Vector2.ZERO

# —— 性能 ——
var player_ref: Node2D = null        # 缓存的玩家引用
var target_refresh_timer := 0.0
var steer_timer := 0.0
var steer_cached_direction := Vector2.ZERO
var steer_cached_input := Vector2.ZERO
var sleep_timer := 0.0
var base_stats: Dictionary = {}      # 场景中配置的原始数值（对象池复用时按等级重新计算）


func _ready() -> void:
	# 对象池复用时 _ready 会再次执行：在这里重置全部运行时状态
	add_to_group("enemy")
	_capture_base_stats()
	hp = max_hp
	state = State.PATROL
	target = null
	velocity = Vector2.ZERO
	knockback_velocity = Vector2.ZERO
	attack_cd_timer = 0.0
	hit_freeze_timer = 0.0
	detour_timer = 0.0
	steer_timer = 0.0
	sleep_timer = 0.0
	target_refresh_timer = 0.0
	stuck_timer = 0.0
	collision_shape.disabled = false
	hp_bar.visible = true
	if flash_tween and flash_tween.is_valid():
		flash_tween.kill()
	visual.modulate = Color.WHITE
	visual.position = Vector2.ZERO
	home_position = global_position
	patrol_target = home_position
	stuck_check_position = global_position
	patrol_wait = randf_range(0.3, 1.2)
	steer_side = 1.0 if randf() < 0.5 else -1.0
	hp_bar_width = hp_fill.size.x
	name_label.text = "Lv.%d %s" % [level, enemy_type]
	_update_hp_bar()
	# 出生动画
	visual.scale = Vector2(0.2, 0.2)
	create_tween().tween_property(visual, "scale", Vector2.ONE, 0.3) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_on_spawn_reset()


## 刷新点在加入场景树之前调用：按等级提升血量、伤害、经验
func setup_level(new_level: int) -> void:
	_capture_base_stats()
	level = maxi(new_level, 1)
	var steps := level - 1
	max_hp = base_stats["max_hp"] * (1.0 + GameDB.ENEMY_HP_GROWTH * steps)
	attack_damage = base_stats["attack_damage"] * (1.0 + GameDB.ENEMY_DAMAGE_GROWTH * steps)
	exp_reward = int(round(base_stats["exp_reward"] * (1.0 + GameDB.ENEMY_EXP_GROWTH * steps)))


## 只在第一次记录场景里配置的原始数值
func _capture_base_stats() -> void:
	if base_stats.is_empty():
		base_stats = {"max_hp": max_hp, "attack_damage": attack_damage, "exp_reward": exp_reward}


func _physics_process(delta: float) -> void:
	if state == State.DEAD:
		return
	attack_cd_timer = maxf(attack_cd_timer - delta, 0.0)

	# 受击停顿：短暂定格并抖动，然后才开始击退
	if hit_freeze_timer > 0.0:
		hit_freeze_timer -= delta
		visual.position = Vector2(randf_range(-2, 2), randf_range(-2, 2))
		if hit_freeze_timer <= 0.0:
			visual.position = Vector2.ZERO
		return

	# 远离玩家且在巡逻：低频更新，省去 AI 与物理移动
	if state == State.PATROL and _distance_to_player() > SLEEP_DISTANCE:
		sleep_timer -= delta
		if sleep_timer > 0.0:
			return
		sleep_timer = SLEEP_TICK
		delta = SLEEP_TICK
	target_refresh_timer -= delta
	if target_refresh_timer <= 0.0:
		target_refresh_timer = TARGET_REFRESH_INTERVAL
		_refresh_target()
	elif target and not is_instance_valid(target):
		target = null
	match state:
		State.PATROL:
			_state_patrol(delta)
		State.CHASE:
			_state_chase(delta)
		State.ATTACK:
			_state_attack(delta)
		State.HURT:
			_state_hurt(delta)
		State.RETURN:
			_state_return(delta)

	move_and_slide()
	_update_stuck_detection(delta)
	pivot.rotation = lerp_angle(pivot.rotation, facing.angle(), 12.0 * delta)


# ============================================================
# 公共接口
# ============================================================

func take_damage(amount: float, knockback: Vector2 = Vector2.ZERO, is_crit: bool = false) -> void:
	if state == State.DEAD:
		return
	hp -= amount
	_update_hp_bar()
	var text := ("暴击 %d" % int(amount)) if is_crit else ("%d" % int(amount))
	var color := Color(1.0, 0.8, 0.15) if is_crit else Color(1.0, 1.0, 1.0)
	EventBus.show_text(text, global_position + Vector2(randf_range(-12, 12), -38), color, 22 if is_crit else 17)
	_flash()
	if hp <= 0.0:
		_die()
		return
	knockback_velocity = knockback
	hit_freeze_timer = HIT_FREEZE_TIME
	velocity = Vector2.ZERO
	state = State.HURT
	state_timer = 0.18
	_on_hurt()


# ============================================================
# 状态处理
# ============================================================

func _state_patrol(delta: float) -> void:
	if target and _distance_to_target() <= detect_range:
		state = State.CHASE
		EventBus.show_text("！", global_position + Vector2(0, -46), Color(1.0, 0.85, 0.2), 22)
		return
	if patrol_wait > 0.0:
		patrol_wait -= delta
		velocity = velocity.move_toward(Vector2.ZERO, 600.0 * delta)
		if patrol_wait <= 0.0:
			patrol_target = home_position + Vector2.from_angle(randf() * TAU) * randf_range(20.0, patrol_radius)
		return
	var to_point := patrol_target - global_position
	if to_point.length() < 8.0:
		patrol_wait = randf_range(1.0, 2.5)
		return
	facing = to_point.normalized()
	velocity = _steer(facing * patrol_speed)


func _state_chase(delta: float) -> void:
	var distance := _distance_to_target()
	if target == null or distance > lose_range:
		_begin_return()
		return
	if global_position.distance_to(home_position) > leash_range:
		_begin_return()
		return
	var to_target := target.global_position - global_position
	facing = to_target.normalized()
	if distance <= attack_range and attack_cd_timer <= 0.0:
		_start_attack()
		return
	var desired := _steer(_get_chase_velocity(to_target, distance))
	velocity = velocity.move_toward(desired, 900.0 * delta)


func _state_return(delta: float) -> void:
	var to_home := home_position - global_position
	# 回家途中快速回血
	hp = minf(hp + max_hp * 0.5 * delta, max_hp)
	_update_hp_bar()
	if to_home.length() < 12.0:
		state = State.PATROL
		patrol_wait = randf_range(0.5, 1.5)
		return
	facing = to_home.normalized()
	velocity = _steer(facing * move_speed)


func _begin_return() -> void:
	state = State.RETURN
	target = null


func _start_attack() -> void:
	state = State.ATTACK
	state_timer = 0.0
	attack_performed = false
	velocity = Vector2.ZERO
	_on_attack_windup_started()


func _state_attack(delta: float) -> void:
	state_timer += delta
	velocity = velocity.move_toward(Vector2.ZERO, 900.0 * delta)
	if not attack_performed and state_timer >= attack_windup:
		attack_performed = true
		attack_cd_timer = attack_cooldown
		_perform_attack()
	elif attack_performed and state_timer >= attack_windup + attack_recovery:
		state = State.CHASE


func _state_hurt(delta: float) -> void:
	state_timer -= delta
	velocity = knockback_velocity
	knockback_velocity = knockback_velocity.move_toward(Vector2.ZERO, 1400.0 * delta)
	if state_timer <= 0.0:
		state = State.CHASE


# ============================================================
# 子类可重写的钩子
# ============================================================

## 追击时的期望速度（默认：直线靠近到攻击范围内）
func _get_chase_velocity(to_target: Vector2, distance: float) -> Vector2:
	if distance > attack_range * 0.8:
		return to_target.normalized() * move_speed
	return Vector2.ZERO


## 出招前摇开始（用于预警动作）
func _on_attack_windup_started() -> void:
	pass


## 出招判定
func _perform_attack() -> void:
	pass


## 受击时（用于打断出招动画）
func _on_hurt() -> void:
	pass


## 生成 / 对象池复用时（用于重置子类的动画节点）
func _on_spawn_reset() -> void:
	pass


# ============================================================
# 防卡墙
# ============================================================

## 根据前方障碍调整移动方向：直行被挡时依次尝试左右偏转
func _steer(desired: Vector2) -> Vector2:
	if desired.length_squared() < 1.0:
		return desired
	if detour_timer > 0.0:
		return detour_direction * desired.length()
	# 期望方向变化不大时复用上次的探测结果
	steer_timer -= get_physics_process_delta_time()
	if steer_timer > 0.0 and steer_cached_input.dot(desired.normalized()) > 0.97:
		return steer_cached_direction * desired.length()
	steer_timer = STEER_REFRESH_INTERVAL
	steer_cached_input = desired.normalized()
	steer_cached_direction = _probe_direction(desired).normalized()
	return steer_cached_direction * desired.length()


func _probe_direction(desired: Vector2) -> Vector2:
	var probe := desired.normalized() * STEER_PROBE_DISTANCE
	if not test_move(global_transform, probe):
		return desired
	for angle in STEER_ANGLES:
		for side in [steer_side, -steer_side]:
			var rotated := desired.rotated(deg_to_rad(angle * side))
			if not test_move(global_transform, rotated.normalized() * STEER_PROBE_DISTANCE):
				steer_side = side   # 记住绕行方向，避免左右抖动
				return rotated
	return desired


## 周期性检查是否卡住，卡住则随机选一个方向绕行一小段
func _update_stuck_detection(delta: float) -> void:
	if detour_timer > 0.0:
		detour_timer -= delta
	var wants_to_move := state == State.CHASE or state == State.RETURN \
		or (state == State.PATROL and patrol_wait <= 0.0)
	if not wants_to_move:
		stuck_timer = 0.0
		stuck_check_position = global_position
		return
	stuck_timer += delta
	if stuck_timer < STUCK_CHECK_TIME:
		return
	if global_position.distance_to(stuck_check_position) < STUCK_MIN_DISTANCE:
		steer_side = -steer_side
		detour_direction = facing.rotated(deg_to_rad(randf_range(70.0, 110.0) * steer_side))
		detour_timer = 0.5
		if state == State.PATROL:
			patrol_wait = randf_range(0.5, 1.0)   # 巡逻卡住就换一个巡逻点
	stuck_timer = 0.0
	stuck_check_position = global_position


# ============================================================
# 工具
# ============================================================

func _refresh_target() -> void:
	var player := _get_player()
	if player and player.has_method("is_alive") and player.call("is_alive"):
		target = player
	else:
		target = null


## 缓存玩家引用，失效时才重新查询分组
func _get_player() -> Node2D:
	if player_ref == null or not is_instance_valid(player_ref) or not player_ref.is_inside_tree():
		player_ref = get_tree().get_first_node_in_group("player") as Node2D
	return player_ref


func _distance_to_player() -> float:
	var player := _get_player()
	return INF if player == null else global_position.distance_to(player.global_position)


func _distance_to_target() -> float:
	if target == null or not is_instance_valid(target):
		return INF
	return global_position.distance_to(target.global_position)


func _update_hp_bar() -> void:
	hp_fill.size.x = hp_bar_width * clampf(hp / max_hp, 0.0, 1.0)


## 受击闪光：瞬间变亮 + 挤压变形
func _flash() -> void:
	if flash_tween and flash_tween.is_valid():
		flash_tween.kill()
	visual.modulate = Color(3.0, 3.0, 3.0)
	visual.scale = Vector2(1.2, 0.85)
	flash_tween = create_tween().set_parallel()
	flash_tween.tween_property(visual, "modulate", Color.WHITE, 0.18)
	flash_tween.tween_property(visual, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK)


func _die() -> void:
	state = State.DEAD
	velocity = Vector2.ZERO
	remove_from_group("enemy")
	# 物理回调中不能直接修改碰撞状态，使用延迟调用
	collision_shape.set_deferred("disabled", true)
	hp_bar.visible = false
	EventBus.enemy_killed.emit(enemy_type, exp_reward, global_position)
	EventBus.show_text("+%d 经验" % exp_reward, global_position + Vector2(0, -58), Color(0.7, 1.0, 0.5), 14)
	_roll_drops()
	if flash_tween and flash_tween.is_valid():
		flash_tween.kill()
	var tween := create_tween().set_parallel()
	tween.tween_property(visual, "modulate", Color(1, 1, 1, 0), 0.45)
	tween.tween_property(visual, "scale", Vector2(1.3, 0.3), 0.45)
	tween.chain().tween_callback(ObjectPool.release.bind(self))


func _roll_drops() -> void:
	for item_id in drop_table:
		if randf() < float(drop_table[item_id]):
			var offset := Vector2(randf_range(-14, 14), randf_range(-14, 14))
			EventBus.drop_item_requested.emit(str(item_id), global_position + offset)
			return
