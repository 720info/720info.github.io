## ============================================================
## 成就数据表（静态配置）
## condition 字段：
##   kill_total   累计击杀数达到 target
##   level        角色等级达到 target
##   skill_cast   释放过 SKILLS 数组中 index == target 的武功
##   item_owned   拾取过 id == target 的道具/武器
##   play_time    累计游戏时长（秒）达到 target
## ============================================================
class_name AchievementDB
extends RefCounted

const ACHIEVEMENTS := [
	{"id": "first_blood", "name": "初入江湖", "desc": "击杀第一名敌人", "glyph": "杀", "condition": "kill_total", "target": 1},
	{"id": "kill_10", "name": "小有所成", "desc": "累计击杀 10 名敌人", "glyph": "杀", "condition": "kill_total", "target": 10},
	{"id": "kill_50", "name": "威震一方", "desc": "累计击杀 50 名敌人", "glyph": "杀", "condition": "kill_total", "target": 50},
	{"id": "kill_150", "name": "杀伐果断", "desc": "累计击杀 150 名敌人", "glyph": "杀", "condition": "kill_total", "target": 150},
	{"id": "level_5", "name": "崭露头角", "desc": "达到等级 5", "glyph": "升", "condition": "level", "target": 5},
	{"id": "level_10", "name": "江湖高手", "desc": "达到等级 10", "glyph": "升", "condition": "level", "target": 10},
	{"id": "level_20", "name": "一代宗师", "desc": "达到等级 20", "glyph": "升", "condition": "level", "target": 20},
	{"id": "potian", "name": "破天一剑", "desc": "释放一次「破天一式」", "glyph": "破", "condition": "skill_cast", "target": 3},
	{"id": "potian_sword", "name": "神兵在手", "desc": "获得传说神兵「破天剑」", "glyph": "神", "condition": "item_owned", "target": "potian_sword"},
	{"id": "survivor", "name": "江湖大侠", "desc": "累计游戏时长达到 30 分钟", "glyph": "侠", "condition": "play_time", "target": 1800},
]


static func get_achievement(id: String) -> Dictionary:
	for entry in ACHIEVEMENTS:
		if entry["id"] == id:
			return entry
	return {}
