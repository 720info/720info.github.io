## ============================================================
## 游戏数据表（静态配置）
## 玩家成长、武功技能、道具/武器、怪物成长的所有数值都集中在这里。
## 调平衡只改这个文件；UI 与玩家脚本都只读取这里的数据。
##
## 平衡思路（开局铁剑 攻击6）：
##   山贼 42HP → 普攻约 5~6 下、或 连光剑+普攻 2 下
##   妖兽 30HP → 连光剑一套约可击杀
##   玩家 120HP → 被山贼连砍约 13 次死亡，给足走位与药品容错
##   每升一级怪物血量 +18%、伤害 +10%，玩家靠加点 + 伤害成长 + 换武器跟上
## ============================================================
class_name GameDB
extends RefCounted

# —— 玩家成长 ——
const PLAYER_BASE := {
	"max_hp": 120.0,
	"max_mp": 60.0,
	"max_stamina": 100.0,
	"hp_regen": 0.8,        # 每秒
	"mp_regen": 2.5,        # 每秒
	"stamina_regen": 35.0,  # 每秒
}
const POINTS_PER_LEVEL := 3
const DAMAGE_GROWTH_PER_LEVEL := 0.06   # 每级伤害 +6%
const DEATH_EXP_PENALTY := 0.2          # 复活损失当前经验的 20%
const STARTING_WEAPON := "iron_sword"
const STARTING_ITEMS := {"hp_potion": 3, "mp_potion": 2}
const INVENTORY_CAPACITY := 20

## 属性加点：每点提升量
const ATTRIBUTES := {
	"hp": {"name": "生命上限", "per_point": 12.0, "desc": "每点 +12 生命上限"},
	"mp": {"name": "内力上限", "per_point": 8.0, "desc": "每点 +8 内力上限"},
	"stamina": {"name": "体力上限", "per_point": 10.0, "desc": "每点 +10 体力上限，体力回复加快"},
}
const ATTRIBUTE_ORDER := ["hp", "mp", "stamina"]


static func exp_to_next_level(level: int) -> int:
	return 40 + (level - 1) * 30


# —— 普攻 ——
const COMBO_MULTIPLIERS := [1.0, 1.15, 1.7]   # 三段伤害倍率（× 武器攻击）

# —— 武功技能（顺序即快捷栏 1~4） ——
## 伤害 = base_damage + weapon_scale × 武器攻击，再乘以等级伤害成长
const SKILLS := [
	{
		"id": "lianguang", "name": "连光剑", "glyph": "连",
		"mp_cost": 6.0, "cooldown": 1.5,
		"base_damage": 5.0, "weapon_scale": 0.6,
		"cast_time": 0.3, "color": Color(0.55, 0.85, 1.0),
		"desc": "快速向前挥出三道剑气",
	},
	{
		"id": "xuanguang", "name": "旋光斩", "glyph": "旋",
		"mp_cost": 14.0, "cooldown": 6.0,
		"base_damage": 12.0, "weapon_scale": 1.0, "radius": 130.0,
		"cast_time": 0.3, "color": Color(0.45, 1.0, 0.8),
		"desc": "原地旋身，剑域伤害周围所有敌人",
	},
	{
		"id": "feishen", "name": "飞身斩", "glyph": "飞",
		"mp_cost": 10.0, "cooldown": 5.0,
		"base_damage": 14.0, "weapon_scale": 1.2,
		"cast_time": 0.22, "color": Color(1.0, 0.78, 0.35),
		"desc": "向鼠标方向飞身突进，斩击沿途敌人（突进中无敌）",
	},
	{
		"id": "potian", "name": "破天一式", "glyph": "破",
		"mp_cost": 32.0, "cooldown": 15.0,
		"base_damage": 35.0, "weapon_scale": 2.5,
		"cast_time": 0.8, "color": Color(1.0, 0.4, 0.25),
		"desc": "蓄力后斩出贯穿一切的巨型剑气",
	},
]

# —— 道具与武器 ——
## type: consumable 消耗品 / weapon 武器
## icon: 美术图片路径（留空则使用色块+文字占位）
const ITEMS := {
	"hp_potion": {
		"name": "金创药", "type": "consumable", "glyph": "药", "icon": "res://assets/art/items/hp_potion_wuxia.svg",
		"restore_hp": 50.0, "restore_mp": 0.0, "stack": 99,
		"color": Color(0.85, 0.22, 0.2), "desc": "回复 50 点生命",
	},
	"mp_potion": {
		"name": "内力丹", "type": "consumable", "glyph": "丹", "icon": "res://assets/art/items/mp_potion_wuxia.svg",
		"restore_hp": 0.0, "restore_mp": 35.0, "stack": 99,
		"color": Color(0.25, 0.45, 0.95), "desc": "回复 35 点内力",
	},
	"big_potion": {
		"name": "大还丹", "type": "consumable", "glyph": "还", "icon": "res://assets/art/items/mp_potion_wuxia.svg",
		"restore_hp": 80.0, "restore_mp": 50.0, "stack": 99,
		"color": Color(0.8, 0.5, 0.95), "desc": "回复 80 点生命与 50 点内力",
	},
	"iron_sword": {
		"name": "铁剑", "type": "weapon", "glyph": "铁", "icon": "res://assets/art/items/sword_steel_wuxia.svg",
		"attack": 6.0, "attack_speed": 1.0, "range": 64.0, "crit": 0.10, "knockback": 1.0,
		"stack": 1, "color": Color(0.78, 0.8, 0.84), "desc": "寻常铁剑\n攻击 6 · 攻速 100% · 暴击 10%",
	},
	"steel_sword": {
		"name": "青钢剑", "type": "weapon", "glyph": "青", "icon": "res://assets/art/items/sword_steel_wuxia.svg",
		"attack": 9.0, "attack_speed": 1.05, "range": 68.0, "crit": 0.12, "knockback": 1.0,
		"stack": 1, "color": Color(0.5, 0.85, 0.9), "desc": "百炼青钢，锋利轻盈\n攻击 9 · 攻速 105% · 暴击 12%",
	},
	"heavy_sword": {
		"name": "玄铁重剑", "type": "weapon", "glyph": "玄", "icon": "res://assets/art/items/sword_steel_wuxia.svg",
		"attack": 14.0, "attack_speed": 0.8, "range": 76.0, "crit": 0.08, "knockback": 1.6,
		"stack": 1, "color": Color(0.45, 0.42, 0.55), "desc": "重剑无锋，大巧不工\n攻击 14 · 攻速 80% · 暴击 8% · 击退强",
	},
	"potian_sword": {
		"name": "破天剑", "type": "weapon", "glyph": "破", "icon": "res://assets/art/items/sword_steel_wuxia.svg",
		"attack": 19.0, "attack_speed": 1.15, "range": 72.0, "crit": 0.2, "knockback": 1.2,
		"stack": 1, "color": Color(1.0, 0.6, 0.3), "desc": "传说中的神兵\n攻击 19 · 攻速 115% · 暴击 20%",
	},
}

# —— 怪物成长（按怪物等级） ——
const ENEMY_HP_GROWTH := 0.18
const ENEMY_DAMAGE_GROWTH := 0.10
const ENEMY_EXP_GROWTH := 0.15

# —— 物理碰撞层（与 project.godot 中 layer_names 对应） ——
const LAYER_PLAYER := 1              # 第1层 玩家
const LAYER_ENEMY := 1 << 1          # 第2层 敌人
const LAYER_ITEM := 1 << 2           # 第3层 道具
const LAYER_OBSTACLE := 1 << 3       # 第4层 障碍物
const LAYER_PLAYER_ATTACK := 1 << 4  # 第5层 玩家攻击
const LAYER_ENEMY_ATTACK := 1 << 5   # 第6层 敌人攻击


static func get_item(item_id: String) -> Dictionary:
	return ITEMS.get(item_id, {})


static func is_weapon(item_id: String) -> bool:
	return get_item(item_id).get("type", "") == "weapon"


## 加载道具图标（未配置或文件不存在时返回 null，由调用方使用占位）
static func load_item_icon(item_id: String) -> Texture2D:
	var path := str(get_item(item_id).get("icon", ""))
	if path.is_empty() or not ResourceLoader.exists(path):
		return null
	return load(path) as Texture2D
