## ============================================================
## 地图数据表（静态配置）：五重江湖，逐关推进，全部通关即通关游戏
## 每张地图由 WorldBuilder 按此表程序化生成（地面/障碍/刷新点/驿站/传送阵）。
## 字段：size 地图尺寸；ground/patch/road/edge 地面/色块/道路/边界配色；
##      tree_tint/tree_count/rock_count 障碍；bandit_spawns/beast_spawns/max_alive/respawn 刷怪；
##      level_offset 怪物等级加成；kill_goal 通关所需击杀；boss 通关前需击败的首领（可选）。
## ============================================================
class_name MapDB
extends RefCounted

const MAP_COUNT := 5

const MAPS := [
	{
		"name": "青石官道", "subtitle": "江湖路远，自此启程",
		"size": Vector2(4800, 3200), "seed": 101,
		"ground": Color(0.29, 0.38, 0.25), "patch": [Color(0.25, 0.34, 0.22), Color(0.33, 0.42, 0.27)],
		"road": Color(0.6, 0.5, 0.33), "edge": Color(0.36, 0.4, 0.42),
		"tuft_dark": Color(0.2, 0.3, 0.18), "tuft_light": Color(0.38, 0.5, 0.3),
		"flowers": [Color(0.9, 0.85, 0.6), Color(0.85, 0.5, 0.45), Color(0.75, 0.75, 0.9)],
		"tree_tint": Color(1, 1, 1), "tree_count": 34, "rock_count": 14,
		"bandit_spawns": 4, "beast_spawns": 3, "max_alive": 2, "respawn": 8.0, "level_offset": 0,
		"kill_goal": 15, "save_names": ["官道驿站", "山神庙", "东关石碑"],
	},
	{
		"name": "落霞秋林", "subtitle": "满山红叶，杀机暗藏",
		"size": Vector2(4000, 2600), "seed": 202,
		"ground": Color(0.42, 0.33, 0.2), "patch": [Color(0.5, 0.36, 0.2), Color(0.36, 0.28, 0.17)],
		"road": Color(0.58, 0.44, 0.28), "edge": Color(0.32, 0.24, 0.18),
		"tuft_dark": Color(0.5, 0.28, 0.12), "tuft_light": Color(0.75, 0.5, 0.2),
		"flowers": [Color(0.95, 0.6, 0.2), Color(0.85, 0.3, 0.2), Color(0.95, 0.85, 0.4)],
		"tree_tint": Color(1.35, 0.8, 0.5), "tree_count": 60, "rock_count": 10,
		"bandit_spawns": 4, "beast_spawns": 4, "max_alive": 2, "respawn": 7.5, "level_offset": 1,
		"kill_goal": 20, "save_names": ["落霞客栈", "枫林亭", "红叶渡口"],
	},
	{
		"name": "寒江雪原", "subtitle": "朔风如刀，冰封千里",
		"size": Vector2(4400, 2800), "seed": 303,
		"ground": Color(0.8, 0.86, 0.92), "patch": [Color(0.72, 0.8, 0.9), Color(0.88, 0.92, 0.96)],
		"road": Color(0.6, 0.7, 0.8), "edge": Color(0.45, 0.55, 0.68),
		"tuft_dark": Color(0.55, 0.65, 0.78), "tuft_light": Color(0.95, 0.97, 1.0),
		"flowers": [Color(0.7, 0.85, 1.0), Color(0.95, 0.95, 1.0)],
		"tree_tint": Color(0.7, 0.95, 1.15), "tree_count": 36, "rock_count": 22,
		"bandit_spawns": 5, "beast_spawns": 4, "max_alive": 2, "respawn": 7.0, "level_offset": 2,
		"kill_goal": 25, "save_names": ["寒江渡", "雪庐", "冰崖石碑"],
	},
	{
		"name": "黄沙古道", "subtitle": "大漠孤烟，枯骨遍野",
		"size": Vector2(4800, 3000), "seed": 404,
		"ground": Color(0.78, 0.65, 0.42), "patch": [Color(0.72, 0.58, 0.36), Color(0.84, 0.72, 0.5)],
		"road": Color(0.64, 0.5, 0.3), "edge": Color(0.5, 0.38, 0.26),
		"tuft_dark": Color(0.55, 0.42, 0.22), "tuft_light": Color(0.9, 0.78, 0.5),
		"flowers": [Color(0.85, 0.55, 0.25), Color(0.7, 0.4, 0.2)],
		"tree_tint": Color(1.15, 0.95, 0.55), "tree_count": 14, "rock_count": 34,
		"bandit_spawns": 6, "beast_spawns": 5, "max_alive": 2, "respawn": 7.0, "level_offset": 3,
		"kill_goal": 30, "save_names": ["驼铃驿", "绿洲", "烽火台"],
	},
	{
		"name": "幽冥魔窟", "subtitle": "魔气冲天，最后一战",
		"size": Vector2(5000, 3200), "seed": 505,
		"ground": Color(0.17, 0.13, 0.22), "patch": [Color(0.22, 0.15, 0.3), Color(0.13, 0.1, 0.18)],
		"road": Color(0.32, 0.23, 0.4), "edge": Color(0.1, 0.07, 0.14),
		"tuft_dark": Color(0.25, 0.15, 0.35), "tuft_light": Color(0.5, 0.3, 0.65),
		"flowers": [Color(0.8, 0.3, 0.55), Color(0.5, 0.35, 0.85)],
		"tree_tint": Color(0.65, 0.4, 0.85), "tree_count": 30, "rock_count": 30,
		"bandit_spawns": 6, "beast_spawns": 6, "max_alive": 3, "respawn": 7.0, "level_offset": 4,
		"kill_goal": 30, "save_names": ["魔窟入口", "血池", "王座前"],
		"boss": {"name": "魔窟之主", "hp_scale": 9.0, "damage_scale": 1.8, "exp_scale": 12.0,
			"body_scale": 1.7, "tint": Color(0.75, 0.4, 1.0)},
	},
]


static func get_map(index: int) -> Dictionary:
	return MAPS[clampi(index, 1, MAP_COUNT) - 1]


static func map_name(index: int) -> String:
	return str(get_map(index)["name"])


static func has_boss(index: int) -> bool:
	return get_map(index).has("boss")
