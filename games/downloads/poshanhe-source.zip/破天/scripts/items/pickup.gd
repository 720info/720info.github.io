## ============================================================
## 掉落道具（药品 / 武器）
## 上下浮动；玩家靠近且背包有空位时被吸附过去，接触后放入背包。
## 通过鸭子类型调用玩家的 can_collect_item() / collect_item()。
## 超时未拾取会闪烁后消失（武器存在时间更长）。
## 美术替换：GameDB.ITEMS 中配置 icon 路径，或直接给 ArtSlot 设置贴图。
## ============================================================
extends Area2D

@export var item_id: String = "hp_potion"
@export var magnet_range: float = 80.0
@export var magnet_speed: float = 280.0
@export var lifetime: float = 40.0

@onready var visual: Node2D = $Visual
@onready var base: Polygon2D = $Visual/Base
@onready var glow: Polygon2D = $Visual/Glow
@onready var glyph_label: Label = $Visual/Glyph
@onready var art_slot: ArtSlot = $Visual/ArtSlot
@onready var name_label: Label = $NameLabel

var age := 0.0
var collected := false
var player_ref: Node2D = null   # 缓存玩家引用，避免每帧查询分组


func _ready() -> void:
	var info := GameDB.get_item(item_id)
	if info.is_empty():
		queue_free()
		return
	var item_color: Color = info["color"]
	var is_weapon := GameDB.is_weapon(item_id)
	base.color = item_color.darkened(0.2)
	glow.color = Color(item_color.r, item_color.g, item_color.b, 0.35)
	glyph_label.text = info["glyph"]
	name_label.text = info["name"]
	name_label.add_theme_color_override("font_color", item_color.lightened(0.45))
	if is_weapon:
		lifetime *= 2.0
		glow.scale = Vector2(1.5, 1.5)   # 武器光圈更大更醒目
	art_slot.apply_texture(GameDB.load_item_icon(item_id))
	# 掉落弹出动画
	visual.scale = Vector2(0.3, 0.3)
	create_tween().tween_property(visual, "scale", Vector2.ONE, 0.25) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _physics_process(delta: float) -> void:
	if collected:
		return
	age += delta
	visual.position.y = sin(age * 4.0) * 3.0 - 4.0
	glow.rotation += delta
	if age > lifetime - 3.0:
		visible = fmod(age, 0.3) > 0.15
	if age >= lifetime:
		queue_free()
		return
	if player_ref == null or not is_instance_valid(player_ref):
		player_ref = get_tree().get_first_node_in_group("player") as Node2D
		if player_ref == null:
			return
	var player := player_ref
	var to_player := player.global_position - global_position
	# 先做便宜的距离判断，远处的道具不调用玩家方法
	if to_player.length() > magnet_range:
		return
	if not player.has_method("can_collect_item") or not player.call("can_collect_item", item_id):
		return
	global_position += to_player.normalized() * minf(magnet_speed * delta, to_player.length())
	if overlaps_body(player) and player.call("collect_item", item_id):
		_play_collect()


func _play_collect() -> void:
	collected = true
	set_deferred("monitoring", false)
	var tween := create_tween().set_parallel()
	tween.tween_property(self, "scale", Vector2(1.6, 1.6), 0.15)
	tween.tween_property(self, "modulate:a", 0.0, 0.15)
	tween.chain().tween_callback(queue_free)
