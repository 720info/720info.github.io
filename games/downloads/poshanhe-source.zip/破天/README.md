# 破天一剑 · 武侠 ARPG（Godot 4.7.2 / GDScript）

用 Godot 4.7.2 打开本文件夹，按 **F5** 运行（启动加载画面 → 主菜单）。

美术替换、素材来源、性能说明、打包步骤和测试清单见 **`docs/美术替换与发布指南.md`**。项目已内置一套本地生成的像素武侠 SVG 素材，位于 `assets/art/`，每个占位旁仍预留了 `ArtSlot` 替换节点。

## 操作
| 按键 | 功能 |
|---|---|
| WASD / 方向键 | 移动 |
| 鼠标左键（可按住）/ J | 三段普攻 |
| 空格 | 轻功冲刺（冲刺中无敌） |
| 1 / 2 / 3 / 4 | 连光剑 / 旋光斩 / 飞身斩 / 破天一式 |
| B 或 I | 行囊（点击使用药品、更换武器） |
| C | 属性加点 |
| E | 在存档点存档、回满状态 |
| ESC | 暂停；有面板打开时先关闭面板 |
| F11 | 切换全屏 |

## 目录结构
```
assets/                 美术 / 音频 / 字体资源放这里（各子目录有说明.txt）
resources/              main_theme.tres（全局 UI 主题与字体）、default_bus_layout.tres（音频总线）
scenes/
  autoload/audio_manager.tscn   音频节点（BGM + 15 个音效）
  main.tscn                     游戏主场景
  player/ enemies/ effects/ items/ world/
  ui/hud/ ui/inventory/ ui/attribute/ ui/menus/
scripts/
  autoload/   event_bus（信号总线）object_pool（对象池）game_state（流程/击杀/顿帧）save_manager（存档）
              settings_manager（设置）audio_manager（音频）
  data/       game_db.gd（所有数值：技能、道具、武器、成长、怪物成长）
  common/     circle_polygon / arc_polygon（占位图形）art_slot（美术替换位）
  player/ enemies/ effects/ items/ world/ ui/ main/
```

## 场景结构
```
loading_screen.tscn（启动加载画面，多线程预加载主菜单与游戏场景）
main_menu.tscn（Control 铺满屏幕）
 ├ Background（程序化水墨山水，可替换为 TextureRect）
 ├ TitleBox / MenuBox（开始 / 继续 / 设置 / 退出）
 └ SettingsPanel
main.tscn（Node2D，开启 Y 排序）
 ├ World
 │  ├ Ground（z=-10）  ├ Boundary  ├ Obstacles（树 / 石头 / 池塘）
 │  ├ SpawnPoints（6 个刷新点）  ├ SavePoints（3 块存档石碑）  └ Pickups
 ├ Enemies（怪物容器）  ├ Player  ├ Effects（特效与弹道，z=5）
 └ UI
    ├ FloatingTextLayer  ├ HUD（layer 1）  ├ InventoryPanel / AttributePanel（layer 5）
    ├ GameOver（layer 15，暂停时也运行）  └ PauseMenu（layer 20，暂停时也运行）
```
**通信规则：** 模块之间只通过 `EventBus` 信号通信。玩家通过 `"player"` 分组查找，其他交互用鸭子类型调用，比如 `take_damage`、`collect_item`、`get_save_data`。

## 替换美术
- 选中场景里的 `ArtSlot` 节点，把图片拖到它的 Texture 属性上。运行时同一层的占位 Polygon2D 会自动隐藏。
- 道具图标：在 `GameDB.ITEMS` 里填 `"icon": "res://assets/art/items/xxx.png"`，背包和掉落物会自动使用这张图。
- 技能图标：给 `scenes/ui/hud/skill_slot.tscn` 的 `ArtIcon` 设置贴图，也可以在 `hud.gd` 里按技能分别设置。
- 字体：`resources/main_theme.tres` 的 `default_font`。

## 替换音效
打开 `scenes/autoload/audio_manager.tscn`，把音频文件拖到对应 `Sfx*` 节点的 Stream 属性上（每个节点的 editor_description 写明了用途）。背景音乐拖到根节点的 `Menu Bgm` / `Field Bgm` 属性上。播放由代码自动完成：监听 EventBus 信号，按钮点击也会自动播放音效。

## 存档
- 位置：`user://savegame.json`。macOS 在 `~/Library/Application Support/Godot/app_userdata/破天一剑/`，Windows 在 `%APPDATA%\Godot\app_userdata\破天一剑\`。
- 自动存档时机：每 60 秒、升级时、返回主菜单或退出时、关闭窗口时。
- 手动存档：地图上的石碑，按 E。存档同时会回满状态，并把该处设为复活点。

## 打包发布
1. **安装导出模板：** 编辑器 → 编辑器 → 管理导出模板 → 下载 4.7.2。
2. **导出预设：** `export_presets.cfg` 已配置 Windows（x86_64，pck 内嵌到 exe）和 macOS（universal）两个预设。项目 → 导出，直接选择即可。
3. **图标：** Windows 需要 .ico，填到预设的 application/icon；macOS 默认使用 icon.svg，也可以提供 .icns。
4. **macOS 签名：** 预设默认用 ad-hoc 签名。对外分发时，需要 Apple 开发者证书签名并公证，否则用户需要右键 → 打开。
5. **字体（重要）：** 当前使用系统字体（Windows 用微软雅黑，macOS 用冬青黑体）。正式发布建议把免费可商用的中文字体（如思源黑体、霞鹜文楷）放进 `assets/fonts/`，再设置为主题的 default_font，保证所有电脑显示一致。
6. **版本号：** 修改 `project.godot` 里的 `config/version`（主菜单右下角会显示）和两个导出预设里的版本号。
7. 发布前删除自己电脑上的测试存档（见上面的存档路径），并用导出后的包完整试玩一遍。
