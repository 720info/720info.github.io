# Debug Session: portal-e-p-bugs
Status: [OPEN] | Created: 2026-10-02
Project: 破天一剑 (Godot 4.7)
Bug: ① 传送门按 E 无法传送；② P 面板"跳转到选中地图"报错/崩溃

---
## Step 1: Hypotheses (可证伪假设，每个对应观测点)

| ID | Hypothesis | 预测 (若为真) | 观测方式 |
|---|---|---|---|
| H1 | 用户运行的是 build/macos/potian.pck 旧导出包，源码修改未重新导出到 .pck | 旧 .pck 时间戳早于本次修改时间；用 strings 搜 potian.pck 找不到 `_deferred_jump_map` 字符串 | stat .pck + strings potian.pck \| grep _deferred |
| H2 | map_gate/save_point 的 `_unhandled_input` 根本不触发 — HUD 某个 Control 把 E 键 accept 了 | 插桩 print `[MGATE unhandled]` 后控制台完全无该输出；或 `player_inside==null` 时也不触发 | print_debug 插桩 + Godot --verbose 运行 |
| H3 | `_unhandled_input` 触发但 `player_inside` 判空失败（body_entered 信号没连 / 组名不对） | 插桩 `[MGATE entered]` 不出现 或 `[MGATE unhandled] player_inside=null` | print_debug 在 _on_body_entered 和 _unhandled_input |
| H4 | hud.gd 跳转按钮：`_close_cheat_panel()` 立即 queue_free，call_deferred 绑定在被销毁的实例上导致方法不执行，或 Window grab_focus 吞掉事件 | 插桩 `[HUD jump_btn]` 之后 `[HUD deferred_jump]` 从不出现 | print_debug 5 个关键节点：按钮按下→关面板前→关面板后→_deferred_jump_map 进入→cheat_jump_to_map 返回 |
| H5 | `OptionButton.get_selected_id()` 返回值是 Null/Variant 非 int，或 HUD 构造时 `MapDB.MAP_COUNT` 尚未就绪（Autoload 顺序），导致 _close_cheat_panel() 之前的语句直接抛异常 | Godot 控制台出现 "Invalid get index" 或 "Cannot convert" 报错行 | 运行时 stderr/godot.log 捕获 |

---
## Step 2: Instrumentation Log Plan
### map_gate.gd (L38-L51) 插桩 4 点
- A: _on_body_entered 触发 → 打印组名 + player_inside
- B: _on_body_exited 触发
- C: _unhandled_input 触发（不管 player_inside 是否为 null）
- D: _process 检测到 _interact_pressed=true 前后

### save_point.gd (L26-L37) 同构 4 点
- E: _on_body_entered → F: _on_body_exited → G: _unhandled_input → H: _process 消费

### hud.gd (L588-L630) 插桩 5 点
- I:  jump_btn lambda 第一行（进入回调）
- J:  target_map 计算完 clampi 之后 → 打印 sid, selected_idx, target_map
- K:  _close_cheat_panel() 调用前
- L:  _deferred_jump_map() 第一行（证明 call_deferred 生效）
- M:  GameState.cheat_jump_to_map 调用前

---
## Step 3: Evidence (待填充)
| Hypothesis | Evidence | Verdict |
|---|---|---|
| H1 | (pending) | |
| H2 | (pending) | |
| H3 | (pending) | |
| H4 | (pending) | |
| H5 | (pending) | |

---
## Step 4: Fix + Verification
(pending after evidence)
